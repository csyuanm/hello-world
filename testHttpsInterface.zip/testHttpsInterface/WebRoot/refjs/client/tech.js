function pageInit(){
	var u = nlapiGetUser();
	nlapiLogExecution('DEBUG', 'u', u);
	var user = nlapiLoadRecord('employee', u);
	nlapiLogExecution('DEBUG', 'user', JSON.stringify(user));
	if(tech){
		var count = nlapiGetLineItemCount('item');
		nlapiLogExecution('DEBUG', 'user', JSON.stringify(user)); 
	}
}

function isTech(){
	var u = parseInt(nlapiGetUser(), 10);
	var user = nlapiLoadRecord('employee', u);
	var tech = false;
	var count = user.getLineItemCount('roles');
	for(var i=0; i<count; i++){
		var role = user.getLineItemValue('roles', 'selectedrole', i + 1);
		if(role == 1086){
			tech = true;
		}
	}
	return tech;
}