function insertLogInfo(info) {
	if (info == null) {
		return 0;
	}

	var logInfo = nlapiCreateRecord('customrecord_alioloe');
	logInfo.setFieldValue('name', "update_error_log");
	logInfo.setFieldValue('custrecord_ns_order_id', info.tranid);
	logInfo.setFieldValue('custrecord_aliorderid', info.otherrefnum);
	logInfo.setFieldValue('custrecord_errormessages', info.errorinfo);
	nlapiSubmitRecord(logInfo, true);

	if (info.internalid == null || info.internalid == '') {
		return 1;
	}
	//日志表中
	var salesOrder = nlapiLoadRecord('salesorder', info.internalid);
	if (salesOrder == null) {
		return 1;
	}
	var errorInfo = info.errorinfo;
	var recordInfo = errorInfo.substr(0, 250);
	salesOrder.setFieldValue('custbody_carrier_message', recordInfo);
	try {
		nlapiSubmitRecord(salesOrder, true);
		return 2;
	} catch (e) { // 异常
		return 1;
	}

}