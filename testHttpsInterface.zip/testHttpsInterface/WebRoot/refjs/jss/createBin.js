function createBIN(dataIn) {
  var bin = dataIn.bin;
  var loc = dataIn.loc;
  var fba = dataIn.fba;
  var res = {};
  var filter = new Array();
  var col= new Array();
  col[0] = new nlobjSearchColumn('binnumber');
  filter[0] = new nlobjSearchFilter('binnumber', null, 'is', bin);
  var x = nlapiSearchRecord('bin', null, filter, col);
  if(x == null){
    var record = nlapiCreateRecord('bin');
    record.setFieldValue('binnumber', bin);
    record.setFieldValue('location', loc);
    record.setFieldValue('custrecord_is_fba_bin', fba);
    var id = nlapiSubmitRecord(record, false);
    res.id = id;
    res.created = true;
  }else{
    res.id = null;
    res.created = false;
  }
  return res;
}