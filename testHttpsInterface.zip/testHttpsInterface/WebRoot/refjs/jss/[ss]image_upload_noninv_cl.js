/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       05 Mar 2015     Sansom L
 *
 * 2017/6: ALLAN TAKE
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */

var $_loader_html = '<img id="ajax_loader" src="/core/media/media.nl?id=3163&c=277620&h=d69b4eca424b740dcc1d" style="z-index: 9999; position: fixed; display: block; left:45%; top:28%;">';
$_loader_html += '<div class="ppp-wrapper" style="background: none repeat scroll 0 0 #000; bottom: 0; display: block; left: 0; opacity: 0.5; overflow: hidden; position: fixed; right: 0; top: 0; z-index: 9000;"></div>';

function clientNonInvPageInit(type) {
    jQuery('span#custitem_image_url_fs_lbl_uir_label').parent().append(getCustomButtonHtml('Upload', 'upload_image'));
    jQuery('span#custitem_image_url_fs_lbl_uir_label').parent().append(getCustomButtonHtml('Save', 'save_image'));
    //jQuery('span#custitem_image_url_fs_lbl_uir_label').parent().append(getCustomButtonHtml('Preview', 'preview_image'));
    jQuery('#tbl_custom_save_button').hide();
}

function upload_image() {
    nlOpenWindow('/app/common/media/mediaitem.nl?restricttype=PNGIMAGE%2CBMPIMAGE%2CJPGIMAGE%2CTIFFIMAGE%2CPJPGIMAGE%2CGIFIMAGE%2CIMAGE&target=custom21:custitem_image_url&l=T', '_blank', 'width=640,height=480,resizable=yes,scrollbars=yes');
}

function save_image() {

    jQuery('body').append($_loader_html);
    jQuery('body').css('overflow', 'hidden');

    var imageUrl = nlapiGetFieldValue('custitem_image_url');

    var img = new Image();
    img.src = imageUrl;

    img.onload = function () {
        //nlapiRequestURL(nlapiGetFieldValue('custitem_image_url'), null, null, handleResponse);
        handleResponse(nlapiGetFieldValue('custitem_image_url'));
    };

    img.onerror = function () {
        alert('No image exist!');
    };
}

function getReturn(response) {
    var return_val = JSON.parse(response.getBody());
    if (return_val.code == 'success') {
        alert('File saved successfully :' + return_val.value);
    } else {
        alert('Error : ' + return_val.value);
    }
    jQuery('#ajax_loader').remove();
    jQuery('.ppp-wrapper').remove();
    jQuery('body').css('overflow', 'visible');
}

function handleResponse(url) {
    var params = new Array();
    //params['custparam_data'] = encodeURIComponent(response.getBody());
    params['custparam_data'] = url;
    var names = nlapiGetFieldValue('custitem_image_url').split('/');
    params['custparam_name'] = names[names.length - 1];
    nlapiRequestURL('https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=81&deploy=1', params, null, getReturn);
    //nlapiRequestURL('http://api.ning.com/files/58v-ee3J3CKynDP9SP5XWVzvdxL772zI2e2L4c7c8D6Ngtj8lHlRwqORTjPaxBcqCWvIW36Sjw*ZaU9Hhq5G0Kvl-kUR3LS8/google_logo.png');
}

function getCustomButtonHtml(label, func_name) {
    var html = '<span class="uir-field"><div style="margin: 0 0 0 5px !important" id="tbl_custom_' + label.toLowerCase() + '_button" class="uir-button"><div id="tbl_custom_' + label.toLowerCase() + '_button" class="pgBntG">';
    html += '<div id="tdbody_custom_' + label.toLowerCase() + '_button" class="bntBgB">';
    html += '<input style="padding:0 5px !important" type="button" _mousedown="F" style="" class="rndbuttoninpt bntBgT" value="' + label + '" ';
    html += 'id="cust_' + label.toLowerCase() + '_button" name="cust_' + label.toLowerCase() + '_button" onclick="' + func_name + '(); return false;" onmousedown="this.setAttribute(\'_mousedown\',\'T\'); ';
    html += 'setButtonDown(true, false, this);" onmouseup="this.setAttribute(\'_mousedown\',\'F\'); setButtonDown(false, false, this);" ';
    html += 'onmouseout="if(this.getAttribute(\'_mousedown\')==\'T\') setButtonDown(false, false, this);" onmouseover="if(this.getAttribute(\'_mousedown\')==\'T\') setButtonDown(true, false, this);">';
    html += '</div></div></div></span>';
    return html;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientNonInvFieldChanged(type, name, linenum) {
    if (name == 'custitem_image_url') {
        if (nlapiGetFieldValue(name) == '') {
            jQuery('#tbl_custom_save_button').hide();
            jQuery('#tbl_custom_upload_button').show();
        } else {
            var preview_html = '<img src="' + nlapiGetFieldValue('custitem_image_url') + '" />';
            nlapiSetFieldValue('custitem_preview_image', preview_html);
            jQuery('#tbl_custom_upload_button').hide();
            jQuery('#tbl_custom_save_button').show();
        }
    }
}
