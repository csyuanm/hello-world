/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 May 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
/*
 * Type: Schedule 
 * Script : po isShipped email sc
 * ScriptUrl : https://system.na1.netsuite.com/app/common/scripting/script.nl?id=960
 */


function mail(type) {
   
	try{

	var mailto = ['johnny@zake.com','mikej@zake.com','enddyzeng@zakeusa.com'];
	var search = nlapiLoadSearch('transaction',"2515");
    var columns = search.getColumns();

	
	var today = nlapiDateToString(new Date(),'date');
	nlapiLogExecution('Debug','today time',today);
	var date = today.split(' ');
	date = date[0];
	
	search.addFilter(new nlobjSearchFilter('custbody_expected_ship_date',null,'on',date));
	
	
	var fromIndex = 0;
	var toIndex = 500;
	
	var resultSet = search.runSearch();
	var result = resultSet.getResults(fromIndex,toIndex);
	
	nlapiLogExecution('Debug','search result ',JSON.stringify(result));
	
	while(result != null && result.length > 0){
	    
		for(var i = 0 ;i<result.length;i++){
			
			checkGovernance();
			
			var id = result[i].getId();
			var po = nlapiLookupField('purchaseorder',id,'tranid');
			nlapiLogExecution('Debug','<<<po>>>',po);
			var exShippedDate = result[i].getValue(columns[1]);
			
			if(po && date == exShippedDate){
				
				var url = nlapiResolveURL('RECORD','purchaseorder',id);
				url = "https://system.na1.netsuite.com" + url;
				
				nlapiSendEmail(1659, mailto,'Unshipped '+po+' Notification',"Expected Ship Date is Today for "+"Purchase order: "+url,null,'ratul@webbee.biz');
				nlapiSubmitField('purchaseorder',id,'custbody_is_shipped_mailed','T');
				nlapiLogExecution('Debug','<<<>>>','email done');
			}
			
			
		}
		fromIndex = toIndex;
		toIndex += 500;
		result = resultSet.getResults(fromIndex, toIndex);
	
	}
	}catch(e){
		nlapiLogExecution('Debug','<<<ERROR>>>',e);
	}
}


function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}



