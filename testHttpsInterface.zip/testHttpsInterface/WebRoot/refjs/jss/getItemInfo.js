function getItemInfo(dataIn){
  var item = dataIn.item;
  var filter = new Array();
  var col= new Array();
  var obj = {};
  col[0] = new nlobjSearchColumn('itemid');
  filter[0] = new nlobjSearchFilter('itemid', null, 'is', item);
  var x = nlapiSearchRecord('item', null, filter, col);
  if(x == null){
    obj.exists = false;
    obj.record = null;
    obj.id = null;
  }else{
    obj.exists = true;
    var id = x[0].id;
    obj.id = id;
    var record = nlapiLoadRecord('inventoryitem', id);
    obj.record = record
  }
  return obj;
}
