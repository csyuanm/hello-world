function createItem(dataIn){
  var rec = nlapiCreateRecord('inventoryitem');
  rec.setFieldValue('custitem_legacy_3b_sku', dataIn["Legacy_3B_SKU"]);
  rec.setFieldValue('itemid', dataIn["Item_Name/Number"]);
  rec.setFieldValue('displayname', dataIn["Display_Name/Code"]);
  rec.setFieldValue('usebins', 'T');
  rec.setFieldValue('location', 2);
  rec.setFieldValue('taxschedule', 2);  // tax code is 10
  rec.setFieldValue('class', 45);
  if(dataIn["sub_item_of"] != ''){
    nlapiLogExecution('DEBUG', 'name', JSON.stringify(dataIn["Item_Name/Number"]));
    rec.setFieldValue('matrixtype', 'CHILD');
    var filter = new Array();
    filter[0] = new nlobjSearchFilter('itemid', null, 'is', dataIn["sub_item_of"]);
    var x = nlapiSearchRecord('inventoryitem', null, filter);
    rec.setFieldValue('parent', x[0].id);
    if(dataIn["Matrix_Color"] != ''){
      rec.setFieldValue('custitem_var_color', dataIn["Matrix_Color"]);
    }
    if(dataIn["Matrix_Size"] != ''){
      rec.setFieldValue('custitem_var_size', dataIn["Matrix_Size"]);
    }
    if(dataIn["Matrix_Style"] != ''){
      if(dataIn["Matrix_Style"] != undefined){
        rec.setFieldValue('custitem_var_style', dataIn["Matrix_Style"]);
      }
    }
  }
  /*if(dataIn.Matrix_Type == "Parent"){
    rec.setFieldValue('matrixtype', 'PARENT');
  }*/
  var id = nlapiSubmitRecord(rec, true);
  return id;
}