function run(request, response) {

    //try {

    if (request.getMethod() == 'GET') { // GET

        logparams(request);

        var subs = request.getParameter('subs');
        if (subs == Subsidiaries.ZakeInternational) {
            var itemfulfillment_id = request.getParameter('itemfulfillment_id');
            var itemfulfillment = nlapiLoadRecord('itemfulfillment', itemfulfillment_id);
            var renderer = nlapiCreateTemplateRenderer();
            renderer.setTemplate(nlapiLoadFile('SuiteScripts/ItemFulfillment/FirstClassEnvelopLabel.html').getValue());
            renderer.addRecord('itemfulfillment', itemfulfillment);
            var xml = renderer.renderToString();
            var file = nlapiXMLToPDF(xml);
            response.setContentType('PDF', itemfulfillment.getFieldValue('tranid') + '.pdf', 'inline');
            response.write(file);
        } else if (subs == Subsidiaries.TaiwuInternational) {

            var action = request.getParameter('action');
            var ffId = request.getParameter('ffId');

            if (action == 'fixShippingLabel') {
                var createdfrom = request.getParameter('createdfrom');

                var ffRec = nlapiLoadRecord('itemfulfillment', ffId);

                var shipment = new Shipment(ffRec.getFieldValue('createdfrom'));

                var labelDetails = shipment.getShippingLabelDetails();
                _addBinInfo(ffId, labelDetails);
                labelDetails.tracking_number = ffRec.getFieldValue('custbody_sz_carrier_trackingnumber');

                // E邮宝分拣码更新
                var isEPacket = nlapiLookupField('customrecord_sz_shippingmethod', ffRec.getFieldValue('custbody_ship_method_sz'), 'custrecord_is_epacket');
                if (isEPacket == 'T') {
                    var ePackePickCode = getEPacketCode(ffRec.getFieldValue('shipcountry'), ffRec.getFieldValue('shipzip'));
                    if (ePackePickCode == null) {
                        // 这个在打印label 时候有检查了
                        // ffRec.setFieldValue('custbody_tw_fulfillment_status', 19); // 包裹错误
                        ffRec.setFieldValue('memo', 'ePacket 包裹 不过没有找到Pick Code，请注意！');
                    } else {
                        labelDetails.ePackePickCode = ePackePickCode;
                        //  ffRec.setFieldValue('custbody_tw_fulfillment_status', 3); // 成功
                        ffRec.setFieldValue('memo', 'ePacket 包裹 Pick Code 添加！');
                    }
                }

                ffRec.setFieldValue('custbody_shippinglabel_info', JSON.stringify(labelDetails));
                nlapiSubmitRecord(ffRec, true);

                nlapiSetRedirectURL('record', 'itemfulfillment', ffId);
            } else if (action == 'backToPrint') {

                var ffRec = nlapiLoadRecord('itemfulfillment', ffId);
                ffRec.setFieldValue('custbody_tw_fulfillment_status', '3');
                ffRec.setFieldValue('shipstatus', 'B'); // Packed
                nlapiSubmitRecord(ffRec, true);

                nlapiSetRedirectURL('record', 'itemfulfillment', ffId);

            } else if (action == 'markPrinted') {
                nlapiSubmitField('itemfulfillment', ffId, 'custbody_tw_fulfillment_status', 7);
                nlapiSetRedirectURL('record', 'itemfulfillment', ffId);
            }
        }


    } else { // POST


    }
    //} catch (e) {
    //    processException(e);
    //}


}


function _addBinInfo(ffId, info) {
    var search = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('internalid', null, 'is', ffId),
        new nlobjSearchFilter('type', 'item', 'anyof', [
            'InvtPart', 'Kit'
        ]),
        // new nlobjSearchFilter('accounttype', null, 'is', 'COGS')
        new nlobjSearchFilter('accounttype', null, 'is', '@NONE@')
    ], [
        new nlobjSearchColumn('item'),
        new nlobjSearchColumn('quantity'),
        new nlobjSearchColumn('binnumber', 'inventoryDetail')
    ]);

    var mapping = {};
    search.forEach(function (searchResult, index) {
        var linenumber = index + 1;

        mapping[linenumber + '_' + searchResult.getValue('item')] = searchResult.getText('binnumber', 'inventoryDetail');
        //return {
        //    _id: linenumber + '_' + searchResult.getValue('item'),
        //    binnumber: searchResult.getText('binnumber', 'inventoryDetail')
        //}
    });

    // var ffRec = nlapiLoadRecord('itemfulfillment', ffId);
    // var info = JSON.parse(ffRec.getFieldValue('custbody_shippinglabel_info'));
    info.items.forEach(function (item) {
        item.binnumber = mapping[item._id];
    });

    return info;
    // ffRec.setFieldValue('custbody_shippinglabel_info', JSON.stringify(info));
}

