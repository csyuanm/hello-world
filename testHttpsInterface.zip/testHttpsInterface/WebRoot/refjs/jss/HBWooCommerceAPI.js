//'use strict';
//
//var request = require('request');
//var OAuth   = require('oauth-1.0a');
//var _url    = require('url');
//
//module.exports = WooCommerceAPI;

/**
 * WooCommerce REST API wrapper
 *
 * @param {Object} opt
 */
function WooCommerceAPI() {

    //var opt = {
    //    // url: 'https://45.79.1.197',
    //    url: 'https://hautebrush.com', // Your store url (required)
    //    // version: 'v3', // WooCommerce API version (optional)
    //    // verifySsl: true, // Use `false` when need test with self-signed certificates, default is `true` (optional)
    //    // encoding: 'utf8', // Encode, default is 'utf8' (optional)
    //    consumerKey: 'ck_d71fb5a1e1cf13235db5e41cb56765bbae233c96', // Your API consumer key (required)
    //    consumerSecret: 'cs_6c352a7494f2813af6df6b52e9ba31b886180e13' // Your API consumer secret (required)
    //};

    var opt = {
        // url: 'https://45.79.1.197',
        url: CONNECTOR_CONFIG.url, // Your store url (required)
        // version: 'v3', // WooCommerce API version (optional)
        // verifySsl: true, // Use `false` when need test with self-signed certificates, default is `true` (optional)
        // encoding: 'utf8', // Encode, default is 'utf8' (optional)
        consumerKey: CONNECTOR_CONFIG.consumerKey, // Your API consumer key (required)
        consumerSecret: CONNECTOR_CONFIG.consumerSecret // Your API consumer secret (required)
    };

    if (!(this instanceof WooCommerceAPI)) {
        return new WooCommerceAPI(opt);
    }

    opt = opt || {};

    if (!(opt.url)) {
        throw new Error('url is required');
    }

    if (!(opt.consumerKey)) {
        throw new Error('consumerKey is required');
    }

    if (!(opt.consumerSecret)) {
        throw new Error('consumerSecret is required');
    }

    this.classVersion = '1.0.4';
    this._setDefaultsOptions(opt);
}

/**
 * Set default options
 *
 * @param {Object} opt
 */
WooCommerceAPI.prototype._setDefaultsOptions = function (opt) {
    this.url = opt.url;
    this.version = opt.version || 'v3';
    this.isSsl = /^https/i.test(this.url);
    this.consumerKey = opt.consumerKey;
    this.consumerSecret = opt.consumerSecret;
    this.verifySsl = false === opt.verifySsl ? false : true;
    this.encoding = opt.encoding || 'utf8';
};

/**
 * Normalize query string for oAuth
 *
 * @param  {string} url
 * @return {string}
 */
WooCommerceAPI.prototype._normalizeQueryString = function (url) {
    // Exit if don't find query string
    if (-1 === url.indexOf('?')) {
        return url;
    }

    var query = _url.parse(url, true).query;
    var params = [];
    var queryString = '';

    for (var p in query) {
        params.push(p);
    }
    params.sort();

    for (var i in params) {
        if (queryString.length) {
            queryString += '&';
        }

        queryString += encodeURIComponent(params[i]).replace('%5B', '[').replace('%5D', ']');
        queryString += '=';
        queryString += encodeURIComponent(query[params[i]]);
    }

    return url.split('?')[0] + '?' + queryString;
};

/**
 * Get URL
 *
 * @param  {String} endpoint
 *
 * @return {String}
 */
WooCommerceAPI.prototype._getUrl = function (endpoint) {
    var url = '/' === this.url.slice(-1) ? this.url : this.url + '/';
    url = url + 'wc-api/' + this.version + '/' + endpoint;

    if (!this.isSsl) {
        return this._normalizeQueryString(url);
    }

    return url;
};

/**
 * Get OAuth
 *
 * @return {Object}
 */
WooCommerceAPI.prototype._getOAuth = function () {
    var data = {
        consumer: {
            public: this.consumerKey,
            secret: this.consumerSecret
        },
        signature_method: 'HMAC-SHA256'
    };

    if ('v3' !== this.version) {
        data.last_ampersand = false;
    }

    return new OAuth(data);
};

/**
 * Do requests
 *
 * @param  {String}   method
 * @param  {String}   endpoint
 * @param  {Object}   data
 * @param  {Function} callback
 *
 * @return {Object}
 */
WooCommerceAPI.prototype._request = function (method, endpoint, data, callback) {
    var url = this._getUrl(endpoint);

    var params = {
        url: url,
        method: method,
        encoding: this.encoding,
        headers: {
            'User-Agent': 'WooCommerce API SuiteScript.js/' + this.classVersion,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    };

    if (this.isSsl) {
        params.auth = {
            user: this.consumerKey,
            pass: this.consumerSecret
        };
        if (!this.verifySsl) {
            params.strictSSL = false;
        }
    } else {
        params.qs = this._getOAuth().authorize({
            url: url,
            method: method
        });
    }

    params.body = null;
    if (data) {
        params.body = JSON.stringify(data);
    }

    //{
    //    "url": "https://swagway.com/wc-api/v3/orders",
    //    "method": "GET",
    //    "encoding": "utf8",
    //    "headers": {
    //    "User-Agent": "WooCommerce API SuiteScript.js/1.0.4",
    //        "Content-Type": "application/json",
    //        "Accept": "application/json"
    //},
    //    "auth": {
    //    "user": "ck_1fcda4afb8e2938c8eb7b1d184f4ef39264ca5be",
    //        "pass": "cs_ffa0115ec855d517a286b860f55646a78bb90407"
    //}
    //}

    //return request(params, callback);
    _log('params', params);


    var response = _getResponse(params);

    if (!callback) {
        //return request(params);
        return response;
    }

    return callback(response);
};

function _getResponse(params, retryTimes) {

    //var _auth = 'Basic ' + Base64.encode(params.auth.user + ':' + params.auth.pass);
    //_audit('_auth', _auth);
    //return;

    // 直接写好得了， 费劲 TODO
    //var _auth = 'Basic Y2tfZDcxZmI1YTFlMWNmMTMyMzVkYjVlNDFjYjU2NzY1YmJhZTIzM2M5Njpjc182YzM1MmE3NDk0ZjI4MTNhZjZkZjZiNTJlOWJhMzFiODg2MTgwZTEz';
    var _auth = CONNECTOR_CONFIG._auth;


    // : 最多3次调用
    retryTimes = retryTimes || 3;

    try {
        return nlapiRequestURL(params.url, params.body, {

            // : 只运行一次encode Need to 优化
            Authorization: _auth,
            "Content-Type": "application/json"

        }, params.method);

    } catch (e) {
        // SSS_CONNECTION_TIME_OUT
        parseException(e);

        if (e instanceof nlobjError) {
            if (e.getCode() == 'SSS_CONNECTION_TIME_OUT') {
                retryTimes--;
                _audit('Woo API -- retryTimes', retryTimes);
                if (retryTimes) {
                    return _getResponse(params, retryTimes);
                } else {
                    throw nlapiCreateError('WOO_API_REQUEST_ERROR', 'Tried 3 times and not success!')
                }
            } else {
                throw nlapiCreateError('WOO_API_REQUEST_ERROR', 'Tried 3 times and not success!');
            }
        } else {
            throw nlapiCreateError('WOO_API_REQUEST_ERROR', 'Tried 3 times and not success!');
        }

    }
}

/**
 * GET requests
 *
 * @param  {String}   endpoint
 * @param  {Function} callback
 *
 * @return {Object}
 */
WooCommerceAPI.prototype.get = function (endpoint, callback) {
    return this._request('GET', endpoint, null, callback);
};

/**
 * POST requests
 *
 * @param  {String}   endpoint
 * @param  {Object}   data
 * @param  {Function} callback
 *
 * @return {Object}
 */
WooCommerceAPI.prototype.post = function (endpoint, data, callback) {
    return this._request('POST', endpoint, data, callback);
};

/**
 * PUT requests
 *
 * @param  {String}   endpoint
 * @param  {Object}   data
 * @param  {Function} callback
 *
 * @return {Object}
 */
WooCommerceAPI.prototype.put = function (endpoint, data, callback) {
    return this._request('PUT', endpoint, data, callback);
};

/**
 * DELETE requests
 *
 * @param  {String}   endpoint
 * @param  {Function} callback
 *
 * @return {Object}
 */
WooCommerceAPI.prototype.delete = function (endpoint, callback) {
    return this._request('DELETE', endpoint, null, callback);
};
