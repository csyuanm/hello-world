function popup(req, res){
  var html =  '<html><body><h1>Hello World</h1></body></html>';
  res.write(html);
}
