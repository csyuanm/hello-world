/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       31 Mar 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function sendMailToCustomer(type){
	
	try{
	
	var record = nlapiGetNewRecord();
	
	var oldRecord = nlapiGetOldRecord();
  
	var oldStatus = oldRecord.getFieldValue('shipstatus');
	var newStatus = record.getFieldValue('shipstatus');
	
	
	if(oldStatus == 'B' && newStatus == "C")
	{
		var marketPlace = record.getFieldValue('custbody_storefront_list');
		//var emailSent = record.getFieldValue('');
		
		if(marketPlace == "8"){
			
			var bcc = 'ratul@webbee.biz';
			var cc = 'caleb@zake.com';
			var storeEmail = 'support@swagtron.com';
			//var href = 'https://swagtron.com/register/'
			var customerId = record.getFieldValue('entity');
			nlapiLogExecution('Debug','customerId',customerId);
			
		    var custEmail = nlapiLookupField('customer',customerId,'email');
		    var custName = nlapiLookupField('customer',customerId,'firstname');
		    
		    var createdFrm = record.getFieldValue('createdfrom');
		    var po = nlapiLookupField('salesorder',createdFrm,'otherrefnum');
		    
		    var trackingArr = [];
		    
		    var count = record.getLineItemCount('packageups');
		    for(var i = 1;i<=count;i++){
		    	
		    	var trackingNo = record.getLineItemValue('packageups','packagetrackingnumberups',i);
		    	nlapiLogExecution('Debug','trackingNo',trackingNo)
		    	if(trackingNo)
		    	trackingArr.push(trackingNo);
		    	
		    }
		    var trackingNos = trackingArr.join(',')
		    nlapiLogExecution('Debug','trackingNos',trackingNos)
			
		    var email_tmpl_id = '143';//170
			var email_tmpl = nlapiLoadRecord('emailtemplate', email_tmpl_id);
			var email_subject_tmpl = email_tmpl.getFieldValue('subject');
			var email_body_tmpl = email_tmpl.getFieldValue('content');
			var renderer = nlapiCreateTemplateRenderer();
			
			renderer.setTemplate(email_subject_tmpl);
			var email_subject = renderer.renderToString();
			//email_subject.replace("{{order}}",po);
			renderer.setTemplate(email_body_tmpl);
			var email_body = renderer.renderToString();
			email_body = email_body.replace("{{TRACKING_NUM}}",trackingNos).replace("{{STOREFRONT_EMAIL}}",storeEmail);
//			email_body = email_body.replace("{{customer}}",custName).replace("{{order}}",po).replace("{{trackingNo}}",trackingNos).replace("{{href}}",href).replace("{{storeEmail}}",storeEmail);

			var rec = {};
			rec.entity = '13087';
			
			nlapiSendEmail('3888120', 'aj@webbeeglobal.com',email_subject,email_body,cc,bcc,rec);
			
			
			
		}
	}
	
	}catch(e){
		nlapiLogExecution('Debug','error',e);
	}
	
}





//var email_template_id = '';
//var emailMerger = nlapiCreateEmailMerger(email_template_id); 
//	var  mergeResult = emailMerger.merge();
//var subject = mergeResult.getSubject();
//subject = subject.replace('{{order}}',po);
//
// var  emailBody = mergeResult.getBody();
//var message = '<html><body>' + emailBody.replace("{{customer}}",custName).replace("{{order}}",po).replace("{{trackingNo}}",trackingNo).replace("{{href}}",href).replace("{{storeEmail}}",storeEmail) + '</body></html>';			
//
//var records = new Object();
//records['transaction'] = recId;			
//nlapiSendEmail('', custEmail, subject, message, null,bcc, records, null);
