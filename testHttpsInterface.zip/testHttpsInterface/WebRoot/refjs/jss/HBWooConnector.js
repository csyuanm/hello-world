var context = nlapiGetContext();
var DEPLOYMENT_ID = nlapiGetContext().getDeploymentId();
_audit('DEPLOYMENT_ID', DEPLOYMENT_ID);

// 脚本工作开始时间
// {"time":"2016-01-29T10:00:00.00Z"}


function run() {
    for (var i = 0; i < CONFIG_LIST.length; i++) {
        CONNECTOR_CONFIG = CONFIG_LIST[i];
        getHBSalesOrders();
        CONNECTOR_CONFIG = null;
    }
}

function getTimeFrom() {

    try {
        var path = CONNECTOR_CONFIG.path + CONNECTOR_CONFIG.timeFileName;
        var timefrom = nlapiLoadFile(path).getValue();
        // 延迟 5分钟
        return this.moment(timefrom.replace('.00Z', '')).subtract(5, 'minutes').format('YYYY-MM-DDTHH:mm:ss') + '.00Z';

    } catch (e) {

        if (e instanceof nlobjError && e.getCode() == 'RCRD_DSNT_EXIST') {

            var d = getUTCDateTime();
            var currentUTCDate = this.moment(d);

            var timefrom = currentUTCDate.subtract(300, 'minutes').format('YYYY-MM-DDTHH:mm:ss') + '.00Z';
            var f = nlapiCreateFile(CONNECTOR_CONFIG.timeFileName, 'PLAINTEXT', timefrom);
            f.setFolder(CONNECTOR_CONFIG.folderId);
            nlapiSubmitFile(f);

            return timefrom;

        } else {
            throw e;
        }
    }
}

function getHBSalesOrders() {

    var exeReport = [];

    try {

        var next_url = '--URL--';

        var deploymentId = nlapiGetContext().getDeploymentId();
        _log('deploymentId', deploymentId);

        if (deploymentId == CONNECTOR_CONFIG.deploymentId) {

            var scripted_url = context.getSetting('SCRIPT', 'custscript_hb_next_url');
            _audit('scripted_url', scripted_url);

            if (scripted_url) {
                next_url = scripted_url;
                wooRequest(scripted_url, exeReport);
            } else {

                // 这里是关键， 取的是当前时间。。。。。
                var d = getUTCDateTime();
                var currentUTCDate = this.moment(d);
                var timeto = currentUTCDate.format('YYYY-MM-DDTHH:mm:ss') + '.00Z';

                next_url = 'orders?status=processing&filter[limit]=50&filter[updated_at_min]=' + getTimeFrom() + '&filter[updated_at_max]=' + timeto;
                wooRequest(next_url, exeReport); // First the Next URL is the init URL
            }


        } else { // for fix
            next_url = context.getSetting('SCRIPT', 'custscript_hb_next_url');
            wooRequest(next_url, exeReport); // First the Next URL is the init URL
        }
        if (exeReport.length) {
            _log_email('(' + exeReport.length + ') ' + next_url.replace('orders?status=processing&filter[limit]=50&', '') + ' ' + deploymentId,
                JSON.stringify(exeReport, null, 2));
        }


    } catch (e) {
        //processException(e);
        e = parseException(e);
        nlapiSendEmail(530, 'allan@zakeusa.com', DEPLOYMENT_ID + ' -> HB.com connector ERROR REPORT! ' + e.userMessage, [
            e.message,
            JSON.stringify(exeReport, null, 2),
            next_url,
            nlapiDateToString(new Date(), 'datetimetz')
        ].join('\r\n')); // If issues then 执行 主程序 with next URL
        //_log_email('Swagway.com exe report WITH ERROR! - ' + nlapiDateToString(new Date(), 'datetimetz'), JSON.stringify(exeReport, null, 2) + '\r\n' + next_url);
    }

}
var minutes_range = 30; // TODO:

function wooRequest(url, exeReport) {

    _audit('wooRequest', url);

    // Initialize the WooCommerceAPI class
    var WooCommerce = new WooCommerceAPI();

    var response = WooCommerce.get(url);

    var salesOrderList = response.getBody();
    _log('response.getBody()', salesOrderList);

    salesOrderList = JSON.parse(salesOrderList);
    if (salesOrderList.hasOwnProperty('orders')) {
        salesOrderList = salesOrderList.orders;
    } else {
        salesOrderList = [salesOrderList.order];
    }


    if (salesOrderList.length) {
        _audit('salesOrderList.length', salesOrderList.length);
        var errorReport = [];

        for (var i = 0, len = salesOrderList.length; i < len; i++) {
            var salesOrder = salesOrderList[i];

            try {

                var so = createHBSalesOrder(salesOrder);
                _log('so-----------------', so);

                exeReport.push('ID: ' + salesOrder.id + ' ---> ' + so.code + '/' + so.id);


            } catch (e) {
                var ex = parseException(e);
                exeReport.push('ID: ' + salesOrder.id + ' ---> ' + ex.getUserMessage());
                errorReport.push('ID: ' + salesOrder.id + ' ---> ' + ex.getUserMessage() + '--->' + ex.message);
                // nlapiSendEmail(-5, 'allan@zakeusa.com', ex.userMessage, ex.message);
            }

        }

        if (errorReport.length) {
            _log_email(nlapiGetContext().getDeploymentId() + '***customdeploy_hbconnector ERROR!! errorReport - ' + nlapiDateToString(new Date(),
                'datetimetz'), JSON.stringify(errorReport, null, 2) + '\r\n' + url);
        }
    }


    //_log('getHeader', response.getHeader('Link'));
    //_audit('getHeaders', response.getHeaders('Link'));
    // ["<https://swagway.com/wc-api/v3/orders?filter[limit]=2&page=9155>; rel=\"last\"","<https://swagway.com/wc-api/v3/orders?filter[limit]=2&page=2>; rel=\"next\""]
    // <https://swagway.com/wc-api/v3/orders?status=processing&page=16>; rel="next"

    // : 无限循环直到没有  // 如果return result 的header里面有Next 则递归， 直到没有了 break；
    var headers = response.getHeaders('Link');
    _audit('headers---', headers);

    if (headers && Array.isArray(headers) && headers.length) {

        var next = null;

        for (var j = 0; j < headers.length; j++) {
            var link = headers[j];
            if (link.indexOf('rel="next"') != -1) {
                next = link;
                break;
            }
        }
        _audit('next', next);
        if (next) {

            var nextURL = next.replace('; rel="next"', '');
            nextURL = nextURL.replace('<https://hautebrush.com/wc-api/v3/', '');
            nextURL = nextURL.replace(/\>/g, '');
            //wooRequest(nextURL, exeReport);

            var params = {};
            params['custscript_hb_next_url'] = nextURL;
            //params['exeReport'] = exeReport; // : 这里是需要考虑的

            var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
            _audit('nlapiScheduleScript', status);

            //if (status == 'QUEUED') {
            //    _audit("Reschedule for usage reset. and len is " + len);
            //}

        } else {
            saveWooNextTime(url);
        }

    } else {
        saveWooNextTime(url);
    }

    nlapiLogExecution('AUDIT', 'AUDIT: checkGovernance---------', nlapiGetContext().getRemainingUsage());
}

function saveWooNextTime(url) {

    if (DEPLOYMENT_ID == CONNECTOR_CONFIG.deploymentId) {

        // size: 23 for time
        var timeto_index = url.indexOf('filter[updated_at_max]=');
        var timeto = url.substring(timeto_index + 23, timeto_index + 23 + 23);

        //var nextTime = this.moment(timeto.replace('.00Z', '')).add(minutes_range, 'minutes').format('YYYY-MM-DDTHH:mm:ss') + '.00Z';
        //var f = nlapiCreateFile(CONNECTOR_CONFIG.timeFileName, 'PLAINTEXT', JSON.stringify({
        //    time: nextTime
        //}));
        //f.setFolder(369098); //

        var f = nlapiCreateFile(CONNECTOR_CONFIG.timeFileName, 'PLAINTEXT', timeto);
        f.setFolder(CONNECTOR_CONFIG.folderId); //

        nlapiSubmitFile(f);

        _audit('saveWooNextTime', timeto);
    }
}

// 防止和 Swagway External ID 有重复 ， 所以加了一个前缀 表示区别
function _makeHBExternalID(id) {
    return 'HB' + id;
}

//var WEIGHT_SPLIT_CONDITION = 20; // of lb
var START_NUMBER = 2918;

function createHBSalesOrder(order) {

    //if (DEPLOYMENT_ID == 'customdeploy_woo_connector_every') {
    //
    //}

    //if (parseInt(order.id) < START_NUMBER) {
    //    return {
    //        success: false,
    //        code: 'Ignore_SALES_ORDER---- ' + order.id,
    //        id: null
    //    };
    //}

    // 防止到 NS 中是 30483.0
    order.id = order.id.toString();
    order.order_number = order.order_number.toString();

    _log('===============' + order.id, order.order_number);

    // TCheck sales order id ---------- Commented if test -------------------------
    //var searchExistingOrder = nlapiSearchRecord('salesorder', null, [
    //    new nlobjSearchFilter('mainline', null, 'is', 'T'),
    //    new nlobjSearchFilter('externalid', null, 'is', order.id),
    //    new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.ZakeInternational),
    //    new nlobjSearchFilter('custbody_marketplace', null, 'is', MarketplaceShipName.Swagway)
    //]);

    var _hbExternalId = _makeHBExternalID(order.id);

    var searchExistingOrder = nlapiSearchRecord('salesorder', null, [
        ['externalid', 'is', _hbExternalId],
        'OR',
        ['otherrefnum', 'equalto', _hbExternalId]
    ]);

    if (searchExistingOrder != null) {
        _log('searchExistingOrder has result', searchExistingOrder.length); // 通常来说是 3 from debugger
        return {
            success: false,
            code: 'EXISTING_SALES_ORDER',
            id: searchExistingOrder[0].getId()
        };
    }

    // 1, 先建立Customer and address information
    var customerId = saveOrUpdateCustomer(order);
    _log('customerId', customerId);

    // 2,
    var salesOrder = nlapiCreateRecord('salesorder', {
        recordmode: 'dynamic',
        customform: '151' // TODO:
    });

    salesOrder.setFieldValue('entity', customerId);
    salesOrder.setFieldValue('location', 2);

    // : externalid---------- Commented if testing
    salesOrder.setFieldValue('externalid', _hbExternalId);
    salesOrder.setFieldValue('otherrefnum', _hbExternalId);

    salesOrder.setFieldValue('custbody_storefront_order', order.order_number.toString());
    salesOrder.setFieldValue('custbody_storefront', 'hautebrush.com');

    salesOrder.setFieldValue('custbody_storefront_list', STOREFRONT.HauteBrush);

    if (parseFloat(order.total_shipping)) {
        salesOrder.setFieldValue('shippingcost', order.total_shipping);
    } else {
        salesOrder.setFieldValue('shippingcost', 0);
    }

    salesOrder.setFieldValue('custbody_marketplace', 13);
    salesOrder.setFieldValue('custbody_customer_email', order.customer.email);
    //if (isValidEmailAddress(order.customer.email)) {
    //    salesOrder.setFieldValue('custbody_customer_email', order.customer.email);
    //}

    // :currency -- default is US
    if (order.currency == 'USD') {
        salesOrder.setFieldValue('currency', 1);

    }

    //To Be determined	 	6
    //Standard	 	1
    //Third day select	 	2
    //Second Day Air	 	3
    //Next Day	 	4
    //International Shipping From US	 	5

    salesOrder.setFieldValue('custbody_market_ship_serv_lvl', 1);

    salesOrder.setFieldValue('memo', 'created by hautebrush.com connector');

    order.line_items.forEach(function (item, index) {

        salesOrder.selectNewLineItem('item');

        var iteminfo = searchNetSuiteItem(item);
        _log('iteminfo', iteminfo);

        salesOrder.setCurrentLineItemValue('item', 'item', iteminfo.id);
        salesOrder.setCurrentLineItemValue('item', 'location', '2'); // : for confirm 继承 from main line location.

        salesOrder.setCurrentLineItemValue('item', 'quantity', item.quantity);

        //var subtotal = parseFloat(item.total) / parseInt(item.quantity);
        salesOrder.setCurrentLineItemValue('item', 'rate', item.price);
        //salesOrder.setCurrentLineItemValue('item', 'rate', item.subtotal);

        if (item.subtotal_tax != '0.00') { // 有Tax的话就是 IN 的tax for 7%
            salesOrder.setCurrentLineItemValue('item', 'taxcode', '10');
        }

        // :
        //"meta": [
        //    {
        //        "key": "color",
        //        "label": "Color",
        //        "value": "Black"
        //    },
        //    {
        //        "key": "Backordered",
        //        "label": "Backordered",
        //        "value": "1"
        //    }
        //]

        salesOrder.commitLineItem('item');

    });


    // custbody_delay_fulfill
    if (order.total == '0.00') {
        nlapiSendEmail(530, 'allan@zakeusa.com,johnny@zake.com', '[HB_NOTIEDS] #' + order.id, [
            'order.total = 0',
            JSON.stringify(order, null, 2)
        ].join('\r\n'));
        // salesOrder.setFieldValue('custbody_delay_fulfill', 'T');
    }

    //"coupon_lines":[
    //    {
    //        "id": 81874,
    //        "code": "ellen-85504zxtc36674",
    //        "amount": "399.99"
    //    }
    //],

    if (order.hasOwnProperty('coupon_lines') && order.coupon_lines.length) {
        //var coupon = order.coupon_lines[0];
        salesOrder.setFieldValue('custbody_marketplace_coupon_code', JSON.stringify(order.coupon_lines));

        //salesOrder.selectNewLineItem('item');
        //
        //salesOrder.setCurrentLineItemValue('item', 'item', '42933'); // Swagway.com Coupon
        //salesOrder.setCurrentLineItemValue('item', 'description', coupon.code);
        //salesOrder.setCurrentLineItemValue('item', 'price', '-1'); // Custom
        //salesOrder.setCurrentLineItemValue('item', 'rate', '-' + coupon.amount);
        //
        //salesOrder.commitLineItem('item');
    }

    //Order.MonetaryDetails.Payments.Payment.forEach(function(_Payment){
    //
    //});
    // nlapiLogExecution('debug', 'Swagway order before create time is', new Date().getTime());

    salesOrder.setFieldValue('orderstatus', 'B'); // Auto-approved

    var total = salesOrder.getFieldValue('total');
    _audit('total compare', total + ': ' + order.total);
    if (total != order.total) {
        _log_email('HB order total was different', order.id);
    }

    // --- IN TIME, CREATE USER EVENT HAS BEEN WORKING..!
    var id = nlapiSubmitRecord(salesOrder, true);
    //nlapiLogExecution('debug', 'Swagway order create time is', new Date().getTime());
    //

    // On Creation Time..
    // **** User Event 的After Submit 是包含在这个方法之前的！！！ After Submit OK 之后才这个OK
    // **** User Event Afer submit OK 之后才执行这个 set Field Value。。。

    _log('sales order has been created', '<a target="blank" href="' + nlapiResolveURL('record', 'salesorder', id) + '">View Order</a>');
    return {
        success: true,
        code: 'NEW_SALES_ORDER',
        id: id
        //cashsale_id: JSON.stringify(cashsale_id)
    };
}


//function getNetSuiteItemInfo(sku) {
//
//
//}

function searchNetSuiteItem(item) {

    // : 这里对于旧的Feed 默认的Location 是SB and Pending confirm
    // Swagway 都是 SB Warehouse
    var DEFAULT_LOCATION = '2';

    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');
    columns[1] = new nlobjSearchColumn('itemid');
    columns[2] = new nlobjSearchColumn('description');
    columns[3] = new nlobjSearchColumn('weight');

    var search = nlapiSearchRecord('item', null, [
        [
            ['name', 'is', item.sku],
            'OR',
            ['custitem_legacy_3b_sku', 'is', item.sku],
            'OR',
            ['custitem_legacy_3b_sku_2', 'is', item.sku],
            'OR',
            ['custitem_legacy_3b_sku_3', 'is', item.sku]
        ],

        // isinactive
        'AND',
        [
            ['isinactive', 'is', 'F']
        ]
    ], columns);

    if (search != null) {
        if (search.length > 1) {
            throw createError('1 more same SKU on system! ' + item.sku);
        } else {
            return {
                id: search[0].getId(),
                location: DEFAULT_LOCATION,
                weight: search[0].getValue('weight')
            }
        }
    } else {
        throw createError('No ' + item.sku + ' SKU on NetSuite');
    }

}

function isValidEmailAddress(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}

function saveOrUpdateCustomer(order) {


    var customer = order.customer;

    // : need 区别开Subsidiary
    var filter = [
        new nlobjSearchFilter('isinactive', null, 'is', 'F'),
        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.ZakeInternational)
    ];

    var email = customer.email;
    filter.push(new nlobjSearchFilter('email', null, 'is', email));
    //if (isValidEmailAddress(email)) {
    //    filter.push(new nlobjSearchFilter('email', null, 'is', email));
    //} else {
    //    throw createError('No customer email found and return NULL...');
    //    //return null;
    //}

    var customerSearch = nlapiSearchRecord('customer', null, filter);

    var shippingAddress = order.shipping_address;
    var _shippingAddress = {
        "country": shippingAddress.country,
        "state": shippingAddress.state,
        "city": shippingAddress.city,
        "addr1": shippingAddress.address_1,
        "addr2": shippingAddress.address_2,
        "addressee": shippingAddress.first_name + ' ' + shippingAddress.last_name,
        "zip": shippingAddress.postcode,
        "phone": shippingAddress.phone || ''
    };

    var billingAddress = order.billing_address;
    var _billingAddress = {
        "country": billingAddress.country,
        "state": billingAddress.state,
        "city": billingAddress.city,
        "addr1": billingAddress.address_1,
        "addr2": billingAddress.address_2,
        "addressee": billingAddress.first_name + ' ' + billingAddress.last_name,
        "zip": billingAddress.postcode,
        "phone": billingAddress.phone || ''
    };

    customer.first_name = customer.first_name || billingAddress.first_name;
    customer.last_name = customer.last_name || billingAddress.last_name;

    var phone = customer.billing_address.phone || customer.shipping_address.phone || '';
    if (customerSearch == null) { // New

        _log('New for customer');
        var customerRecord = nlapiCreateRecord('customer');

        // TODO: Ebay 的Customer 的Subsidiary 都是要是ZakeInternational 的吗， 还是说要和Ebay 的Account 有关联 比如ClaimThis 这个关联一个Subsidiary？
        customerRecord.setFieldValue('subsidiary', Subsidiaries.ZakeInternational);
        _log('New Customer Subsidiary', 'ZakeInternational');

        customerRecord.setFieldValue('isperson', 'T');
        customerRecord.setFieldValue('firstname', customer.first_name);
        customerRecord.setFieldValue('lastname', customer.last_name);
        customerRecord.setFieldValue('phone', phone);
        customerRecord.setFieldValue('email', email);

        if (JSON.stringify(_shippingAddress) === JSON.stringify(_billingAddress)) {
            setAddressLine(customerRecord, _shippingAddress);
        } else {
            setAddressLine(customerRecord, _shippingAddress, 'defaultshipping');
            setAddressLine(customerRecord, _billingAddress, 'defaultbilling');
        }

        return nlapiSubmitRecord(customerRecord, true);
        // customerRecord = nlapiLoadRecord('customer');
        // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
        // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));

    } else { // Update

        _log("Update for the customer");

        var customerId = customerSearch[0].getId();
        var customerRecord = nlapiLoadRecord('customer', customerId);

        var existingShippingAddressId = getExistingAddressId(customerRecord, _shippingAddress, 'defaultshipping');
        var existingBillingAddressId = getExistingAddressId(customerRecord, _billingAddress, 'defaultbilling');

        if (existingShippingAddressId == null && existingBillingAddressId == null) {

            _log('----Set new _ShippingAddress for existing customer');

            if (JSON.stringify(_shippingAddress) === JSON.stringify(_billingAddress)) {
                setAddressLine(customerRecord, _shippingAddress);
            } else {
                setAddressLine(customerRecord, _shippingAddress, 'defaultshipping');
                setAddressLine(customerRecord, _billingAddress, 'defaultbilling');
            }

        } else if (existingShippingAddressId == null) {
            setAddressLine(customerRecord, _shippingAddress, 'defaultshipping');
        } else if (existingBillingAddressId == null) {
            setAddressLine(customerRecord, _billingAddress, 'defaultbilling');
        }

        customerRecord.setFieldValue('isperson', 'T');
        customerRecord.setFieldValue('firstname', customer.first_name);
        customerRecord.setFieldValue('lastname', customer.last_name);

        if (customerRecord.getFieldValue('phone')) {
            customerRecord.setFieldValue('altphone', customerRecord.getFieldValue('phone'));
            customerRecord.setFieldValue('phone', phone);
        } else {
            customerRecord.setFieldValue('phone', phone);
        }

        if (!customerRecord.getFieldValue('subsidiary')) {
            customerRecord.setFieldValue('subsidiary', Subsidiaries.ZakeInternational);
            _log('Updated Customer Subsidiary---', 'ZakeInternational');
        }

        //else {
        //    _log('Updated Customer Subsidiary', customerRecord.getFieldText('subsidiary'));
        //}

        return nlapiSubmitRecord(customerRecord, true);
        // customerRecord = nlapiLoadRecord('customer');
        // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
        // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));
    }

}

function setAddressLine(customer, addressObject, specificField) {
    customer.selectNewLineItem('addressbook');

    for (var name in addressObject) {
        customer.setCurrentLineItemValue('addressbook', name, addressObject[name]);
    }

    if (specificField) {
        customer.setCurrentLineItemValue('addressbook', specificField, 'T');
    } else {
        customer.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
        customer.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
    }

    customer.commitLineItem('addressbook');
}

function getExistingAddressId(customer, addressObject, defaultField) {

    var addressId = null;

    var lineCount = customer.getLineItemCount('addressbook');
    if (lineCount) {
        for (var line = 1; line <= lineCount; line++) {

            var address = {
                'country': customer.getLineItemValue('addressbook', 'country', line),
                'state': customer.getLineItemValue('addressbook', 'state', line),
                'city': customer.getLineItemValue('addressbook', 'city', line),
                'zip': customer.getLineItemValue('addressbook', 'zip', line),
                'addressee': customer.getLineItemValue('addressbook', 'addressee', line),
                'addr1': customer.getLineItemValue('addressbook', 'addr1', line),
                'addr2': customer.getLineItemValue('addressbook', 'addr2', line),
                'phone': customer.getLineItemValue('addressbook', 'phone', line)
            };

            if (exactlySame(address, addressObject)) {

                _log('exactlySame---------- address');
                addressId = customer.getLineItemValue('addressbook', 'id', line);

                if (defaultField) {
                    if (customer.getLineItemValue('addressbook', defaultField, line) !== 'T') {
                        customer.setLineItemValue('addressbook', defaultField, line, 'T');
                        // nlapiSubmitRecord(customer, true);
                    }
                }

                break;
            }
        }
    }


    return addressId;

}

function _fieldProcess(key, value) {
    if (key == 'phone') {
        return trimPhone(value);
    } else {
        if (!value) value = '';
        return value;
    }
}

function exactlySame(address, orderAddress) {

    for (var key in address) {

        var field1 = address[key];
        field1 = _fieldProcess(key, field1);

        if (orderAddress.hasOwnProperty(key)) {
            var field2 = orderAddress[key];
            field2 = _fieldProcess(key, field2);

            if (field1 !== field2) {
                //_log('different in ' + key);
                return false;
            }

        } else {

            //_log('Not in ' + key);
            return false;
        }
    }

    return true;

}

function trimPhone(phone) {
    if (!phone) {
        phone = '';
    }

    if (typeof phone !== 'string') phone = phone.toString();

    var regx = new RegExp('[^0-9]', 'g');
    phone = phone.replace(regx, '');

    return phone;

}