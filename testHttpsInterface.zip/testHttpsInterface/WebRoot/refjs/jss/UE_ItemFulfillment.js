// https://system.netsuite.com/help/helpcenter/en_US/Output/Help/section_N2962963.html
// Test: https://system.na1.netsuite.com/app/accounting/transactions/itemship.nl?id=52297&whence=&cmid=1447570885675
function beforeLoad(type, form, request) {
    try {

        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("beforeLoad____________ id: " + id + " recType: " + recType + " type: " + type);

        form.setScript('customscript_itemfulfillment_client');

        //_log('status', nlapiGetFieldValue('shipstatus'));
        // 42548	First Class Envelop
        if (nlapiGetFieldValue('shipmethod') == 42548 && type == 'view') {
            form.addButton('custpage_print_first_class_label', 'Print First Class Envelop Label', 'printFirstClassLabel(' + id + ')');
        }


        var subs = nlapiGetFieldValue('subsidiary');
        if (subs == Subsidiaries.TaiwuInternational) {
            var shipstatus = nlapiGetFieldValue('shipstatus');
            if (type == 'view') {
                form.addButton("custpage_print_one", "面单预览", "window.open(" + "'/app/site/hosting/scriptlet.nl?script=601&deploy=4&" + serializeURL({
                    fulfillments: id//,
                    //id: id
                }) + "'" + ",'_blank'),window.focus()");
                form.addButton("custpage_label_fix", "修复面单", "window.location='/app/site/hosting/scriptlet.nl?script=232&deploy=1&" + serializeURL({
                    action: "fixShippingLabel",
                    ffId: id,
                    subs: subs
                    //id: id
                }) + "'");

                if (shipstatus != 'C') {
                    form.addButton("custpage_label_fix", "重打面单", "window.location='/app/site/hosting/scriptlet.nl?script=232&deploy=1&" + serializeURL({
                        action: "backToPrint",
                        ffId: id,
                        subs: subs
                        //id: id
                    }) + "'");
                    form.addButton("custpage_label_fix", "标志打印", "window.location='/app/site/hosting/scriptlet.nl?script=232&deploy=1&" + serializeURL({
                        action: "markPrinted",
                        ffId: id,
                        subs: subs
                        //id: id
                    }) + "'");
                }

            }

            // form.addButton("custpage_print_one", "单独打面单", "window.location='/app/site/hosting/scriptlet.nl?script=601&deploy=4&fulfillments=" + id + "'");
        }

        _log("beforeLoad____________end");
    } catch (e) {
        processException(e);
    }

}


function beforeSubmit(type) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        //_log("beforeSubmit______________start id: " + id + " recType: " + recType + " type: " + type);
        //
        //
        //_log("beforeSubmit______________end");
        var subs = nlapiGetFieldValue('subsidiary');
        if (type == 'create' || type == 'edit') {

            if (subs == Subsidiaries.ZakeInternational) {
                _log('zake fulfillment beforeSubmit', nlapiGetRecordId());
                var custbody_mpl_number = nlapiGetFieldValue('custbody_mpl_number');
                if (!custbody_mpl_number) {
                    var soMPLNumber = nlapiLookupField('salesorder', nlapiGetFieldValue('createdfrom'), 'custbody_mpl_number');
                    if (soMPLNumber) {
                        nlapiSetFieldValue('custbody_mpl_number', soMPLNumber);
                    }
                }
            } else if (subs == Subsidiaries.TaiwuInternational) {
                // custbody_tw_fulfillment_status
                //if (nlapiGetFieldValue('custbody_tw_fulfillment_status') == '17') {
                //    var shipment = new Shipment(nlapiGetFieldValue('createdfrom'));
                //
                //    var labelDetails = shipment.getShippingLabelDetails();
                //    _addBinInfo(nlapiGetRecordId(), labelDetails);
                //
                //    // "tracking_number":"LK113423938CN"}
                //    labelDetails.tracking_number = nlapiGetFieldValue('custbody_sz_carrier_trackingnumber');
                //    nlapiSetFieldValue('custbody_shippinglabel_info', JSON.stringify(labelDetails));
                //
                //    nlapiSetFieldValue('custbody_tw_fulfillment_status', '3');
                //}

                _log('这个包裹的Location是', nlapiGetFieldValue('location'));

                //if (!isOverseaLocation) {
                //
                //}

                // 更新面单信息


            }


            var sku = [];
            var desc = [];

            var linecount = nlapiGetLineItemCount('item');
            var line = 1;

            for (; line <= linecount; line++) {
                sku.push(nlapiGetLineItemText('item', 'item', line));
                desc.push(nlapiGetLineItemValue('item', 'itemdescription', line));
            }

            sku.sort(); // 升序

            sku = sku.join('/'); // TODO: 如果速度不行用 ID 来排序
            desc = desc.join(' / ');
            _log(sku, desc);

            nlapiSetFieldValue('custbody_shipment_sku', _cutText(sku));
            nlapiSetFieldValue('custbody_shipment_label', _cutText(desc)); // : legacy SKU 需要考虑

            nlapiSetFieldValue('custbody_item_type_quantity', nlapiGetLineItemCount('item'));

            // : bin信息

            //var newRecord = nlapiGetNewRecord();
            //var subRecord = newRecord.viewSubrecord('inventorydetail');
            //
            //var a = 1;

        }


    } catch (e) {
        processException(e);
    }

}


function afterSubmit(type) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("afterSubmit-------------------- id: " + id + " recType: " + recType + " type: " + type);
        _log('状态', nlapiGetFieldValue('status'));
        var subs = nlapiGetFieldValue('subsidiary');
        if (type == 'create' || type == 'edit') {

            if (subs == Subsidiaries.ZakeInternational) {
                var ec = nlapiGetContext().getExecutionContext();
                _log('ec', ec);
                if (ec == 'scheduled') {

                    var alertMessage = 'The fulfillment with more than 1 tracking number, you need to pay attention.';
                    var soid = nlapiGetFieldValue('createdfrom');
                    var soRec = nlapiLoadRecord('salesorder', soid);

                    var packageCount = nlapiGetLineItemCount('packageups');
                    if (packageCount && parseInt(packageCount) > 1) {

                        soRec.setFieldValue('custbody_has_issues', 'T');
                        soRec.setFieldValue('memo', alertMessage);
                        nlapiSubmitRecord(soRec, true);
                        // nlapiSubmitField('salesorder', nlapiGetFieldValue('createdfrom'), 'custbody_has_issues', 'T', true);
                    } else {
                        if (soRec.getFieldValue('memo') == alertMessage) {
                            soRec.setFieldValue('custbody_has_issues', 'F');
                            soRec.setFieldValue('memo', 'OK');
                            nlapiSubmitRecord(soRec, true);
                        }
                    }
                }
            }

            else if (subs == Subsidiaries.TaiwuInternational) {

                //View	Audit	chinaToday	2/10/2017	2:47 am	E179 Chengli Hou	2017-02-10 07:47:22	Remove
                //View	Audit	chinaToday nlapiDateToString	2/10/2017	2:47 am	E179 Chengli Hou	2/10/2017 7:47:22 am	Remove
                //View	Audit	chinaToday---	2/10/2017	2:47 am	E179 Chengli Hou	"2017-02-10T15:47:22.160Z"	Remove
                //View	Audit	today ---UTC 时间	2/10/2017	2:47 am	E179 Chengli Hou	"2017-02-10T07:47:22.160Z"	Remove


                // TODO: 这部分代码成熟之后可以用， 判断， 如果有bnumber 了，那么就不Search and sort 了。。
                var filters = [];
                filters.push(new nlobjSearchFilter('internalid', null, 'is', nlapiGetRecordId()));
                filters.push(new nlobjSearchFilter('accounttype', null, 'is', '@NONE@'));

                var columns = [];
                columns.push(new nlobjSearchColumn('internalid', 'inventorydetail'));
                columns.push(new nlobjSearchColumn('binnumber', 'inventorydetail'));
                columns.push(new nlobjSearchColumn('inventorynumber', 'inventorydetail'));

                var results = nlapiSearchRecord('itemfulfillment', null, filters, columns);
                var binnumber_list = [];
                if (results != null) {
                    for (var i = 0; i < results.length; i++) {
                        var bnumber = results[i].getText('binnumber', 'inventorydetail');
                        if (bnumber) {
                            binnumber_list.push(bnumber);
                        }

                    }
                }

                _log('binnumber_list', binnumber_list);

                if (binnumber_list.length) {

                    binnumber_list.sort(); // 升序
                    binnumber_list = binnumber_list.join('/');

                    //custbody_fulfillment_bins
                    nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(), 'custbody_fulfillment_bins', _cutText(binnumber_list), true);
                }


            }


            //_log('status', nlapiGetFieldValue('shipstatus'));
            //if (nlapiGetFieldValue('shipstatus') == 'C') {
            //    //  这个是NS 原生的字段， 在其他地方有特别作用的，
            //    // If SO with Pending Billing or Billed status then we think of that SO is all SHIPPED
            //    //nlapiSubmitField('salesorder', nlapiGetFieldValue('createdfrom'), 'shipcomplete', 'T', true);
            //}
        } else if (type == 'delete') {
            // 取得的是本身的 ID 即使触发的是从别处
            if (subs == Subsidiaries.TaiwuInternational) {

                var createdfrom = nlapiGetFieldValue('createdfrom');
                _audit('createdfrom', createdfrom);
                nlapiSubmitField('salesorder', createdfrom, 'custbody_taiwu_fulfill_status_code', 8);

                //var custbody_tw_fulfillment_status = nlapiGetFieldValue('custbody_tw_fulfillment_status');
                //_audit('custbody_tw_fulfillment_status on delete', custbody_tw_fulfillment_status);
                //
                //if (custbody_tw_fulfillment_status == '7') {
                //    var oldRec = nlapiGetOldRecord();
                //    var tranid = oldRec.getFieldValue('tranid');
                //    _sendEmail('allan@zakeusa.com,tangjingsong@zakeusa.com,wubaochun@zakeusa.com,lichaofan@zakeusa.com,liangzuxiang@zakeusa.com',
                //        oldRec.getFieldText('custbody_location') + ' - 包裹 ' + tranid + ' 被删除，请注意！', '这个订单 ' + nlapiGetFieldText('createdfrom') +
                //        ' 的包裹 ' + tranid + '面单已经打印， 但是又被删除了，请仓库注意！');
                //}

            }
        } else if (type == 'ship' && subs == Subsidiaries.TaiwuInternational) {
            //// TODO: 有时间加入 shipped time
            //var today = new Date(); // UTC时间
            //_audit('today ---UTC 时间', today);
            //var chinaToday = today.addHours(8);
            //_audit('chinaToday---', chinaToday);
            //
            ////chinaToday = chinaToday.toString(); //.replace(/"/g, '')
            ////nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(), 'custbody_cn_shipped_time', chinaToday);
            //// nlapiSetFieldValue('custbody_cn_shipped_time', chinaToday);
            //
            ////_audit('chinaToday nlapiDateToString', nlapiDateToString(chinaToday, 'datetimetz'));
            //
            //// TODO: 有时间改造 Format 方法 把 addHours 放到方法里面调用！！ 嘿嘿
            //_audit('chinaToday00000000000', chinaToday.format("yyyy-MM-dd hh:mm:ss"));

        }

        _log("afterSubmit end");
    } catch (e) {
        processException(e);
    }

}
