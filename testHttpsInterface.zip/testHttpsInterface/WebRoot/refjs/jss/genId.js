/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       08 May 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function clientPageInit(type) {
    try {
        //var execution = nlapiGetContext().getExecutionContext();
        //if ( execution == 'userinterface'){
        if (type == 'create') {

            var name = 'created';
            var itemid = '100-1000';
            var columns = new Array();
            columns[0] = new nlobjSearchColumn(name);
            columns[1] = new nlobjSearchColumn('itemid');
            columns[2] = new nlobjSearchColumn('created');
            columns[2].setSort(true);

            var results = nlapiSearchRecord('item', null, null, columns);
            // console.log("Result is " + result);
            // var itemIDs = results[results.length-1].getValue(name);
            if (results != null) {
                for (var i = 0; i < results.length; i++) {
                    var itemID = results[i].getValue('itemid');
                    //console.log("Result is " + itemID);
                    var rule = /(\d{3})\D(\d{4})/;
                    if (rule.test(itemID)) {
                        var newItemID = (parseInt(RegExp.$2) + 1).toString();
                        if (newItemID > 9999) {
                            itemid = (parseInt(RegExp.$1) + 1) + "-0000";
                            break;
                        }
                        // alert(newItemID);
                        itemid = RegExp.$1 + "-" + newItemID.replace(/\d+/g, function (m) {

                            return "0000".substring(0, 4 - m.length) + m;
                        });
                        break;
                    }
                }
            }

            nlapiSetFieldValue('itemid', itemid, true, true);
        }
        //}
    } catch (e) {

        nlapiLogExecution('error', "Inventory ID", e);
    }
}