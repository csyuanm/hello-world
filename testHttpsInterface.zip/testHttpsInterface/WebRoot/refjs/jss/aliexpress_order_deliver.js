function getOrderDeliver() {
  var columns = new Array();
  columns[0] = new nlobjSearchColumn( 'otherrefnum' );
  columns[1] = new nlobjSearchColumn( 'tranid' );
  var searchresults = nlapiSearchRecord('Transaction', 'customsearch1631', null, columns);
  
  return searchresults;
}