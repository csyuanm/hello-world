function getOrderList() {

  var columns = new Array();
//  columns[0] = new nlobjSearchColumn( 'internalid' );
  columns[0] = new nlobjSearchColumn( 'otherrefnum' );
  columns[1] = new nlobjSearchColumn( 'tranid' );
  	//customsearch1521
	var searchresults = nlapiSearchRecord('Transaction', 'customsearch1521', null, columns);

	return searchresults;
}