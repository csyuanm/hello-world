var COUNTRY_MAPPING = [ {
    "Countries and Regions": "Angola",
    "国家或地区": "安哥拉",
    "国际域名缩写": "AO",
    "电话代码": "244",
    "时差": "-7"
}, {
    "Countries and Regions": "Afghanistan",
    "国家或地区": "阿富汗",
    "国际域名缩写": "AF",
    "电话代码": "93",
    "时差": "0"
}, {
    "Countries and Regions": "Albania",
    "国家或地区": "阿尔巴尼亚",
    "国际域名缩写": "AL",
    "电话代码": "355",
    "时差": "-7"
}, {
    "Countries and Regions": "Algeria",
    "国家或地区": "阿尔及利亚",
    "国际域名缩写": "DZ",
    "电话代码": "213",
    "时差": "-8"
}, {
    "Countries and Regions": "Andorra",
    "国家或地区": "安道尔共和国",
    "国际域名缩写": "AD",
    "电话代码": "376",
    "时差": "-8"
}, {
    "Countries and Regions": "Anguilla",
    "国家或地区": "安圭拉岛",
    "国际域名缩写": "AI",
    "电话代码": "1264",
    "时差": "-12"
}, {
    "Countries and Regions": "Antigua and Barbuda",
    "国家或地区": "安提瓜和巴布达",
    "国际域名缩写": "AG",
    "电话代码": "1268",
    "时差": "-12"
}, {
    "Countries and Regions": "Argentina",
    "国家或地区": "阿根廷",
    "国际域名缩写": "AR",
    "电话代码": "54",
    "时差": "-11"
}, {
    "Countries and Regions": "Armenia",
    "国家或地区": "亚美尼亚",
    "国际域名缩写": "AM",
    "电话代码": "374",
    "时差": "-6"
}, {
    "Countries and Regions": "Ascension",
    "国家或地区": "阿森松",
    "国际域名缩写": "",
    "电话代码": "247",
    "时差": "-8"
}, {
    "Countries and Regions": "Australia",
    "国家或地区": "澳大利亚",
    "国际域名缩写": "AU",
    "电话代码": "61",
    "时差": "2"
}, {
    "Countries and Regions": "Austria",
    "国家或地区": "奥地利",
    "国际域名缩写": "AT",
    "电话代码": "43",
    "时差": "-7"
}, {
    "Countries and Regions": "Azerbaijan",
    "国家或地区": "阿塞拜疆",
    "国际域名缩写": "AZ",
    "电话代码": "994",
    "时差": "-5"
}, {
    "Countries and Regions": "Bahamas",
    "国家或地区": "巴哈马",
    "国际域名缩写": "BS",
    "电话代码": "1242",
    "时差": "-13"
}, {
    "Countries and Regions": "Bahrain",
    "国家或地区": "巴林",
    "国际域名缩写": "BH",
    "电话代码": "973",
    "时差": "-5"
}, {
    "Countries and Regions": "Bangladesh",
    "国家或地区": "孟加拉国",
    "国际域名缩写": "BD",
    "电话代码": "880",
    "时差": "-2"
}, {
    "Countries and Regions": "Barbados",
    "国家或地区": "巴巴多斯",
    "国际域名缩写": "BB",
    "电话代码": "1246",
    "时差": "-12"
}, {
    "Countries and Regions": "Belarus",
    "国家或地区": "白俄罗斯",
    "国际域名缩写": "BY",
    "电话代码": "375",
    "时差": "-6"
}, {
    "Countries and Regions": "Belgium",
    "国家或地区": "比利时",
    "国际域名缩写": "BE",
    "电话代码": "32",
    "时差": "-7"
}, {
    "Countries and Regions": "Belize",
    "国家或地区": "伯利兹",
    "国际域名缩写": "BZ",
    "电话代码": "501",
    "时差": "-14"
}, {
    "Countries and Regions": "Benin",
    "国家或地区": "贝宁",
    "国际域名缩写": "BJ",
    "电话代码": "229",
    "时差": "-7"
}, {
    "Countries and Regions": "Bermuda Is.",
    "国家或地区": "百慕大群岛",
    "国际域名缩写": "BM",
    "电话代码": "1441",
    "时差": "-12"
}, {
    "Countries and Regions": "Bolivia",
    "国家或地区": "玻利维亚",
    "国际域名缩写": "BO",
    "电话代码": "591",
    "时差": "-12"
}, {
    "Countries and Regions": "Botswana",
    "国家或地区": "博茨瓦纳",
    "国际域名缩写": "BW",
    "电话代码": "267",
    "时差": "-6"
}, {
    "Countries and Regions": "Brazil",
    "国家或地区": "巴西",
    "国际域名缩写": "BR",
    "电话代码": "55",
    "时差": "-11"
}, {
    "Countries and Regions": "Brunei",
    "国家或地区": "文莱",
    "国际域名缩写": "BN",
    "电话代码": "673",
    "时差": "0"
}, {
    "Countries and Regions": "Bulgaria",
    "国家或地区": "保加利亚",
    "国际域名缩写": "BG",
    "电话代码": "359",
    "时差": "-6"
}, {
    "Countries and Regions": "Burkina-faso",
    "国家或地区": "布基纳法索",
    "国际域名缩写": "BF",
    "电话代码": "226",
    "时差": "-8"
}, {
    "Countries and Regions": "Burma",
    "国家或地区": "缅甸",
    "国际域名缩写": "MM",
    "电话代码": "95",
    "时差": "-1.3"
}, {
    "Countries and Regions": "Burundi",
    "国家或地区": "布隆迪",
    "国际域名缩写": "BI",
    "电话代码": "257",
    "时差": "-6"
}, {
    "Countries and Regions": "Cameroon",
    "国家或地区": "喀麦隆",
    "国际域名缩写": "CM",
    "电话代码": "237",
    "时差": "-7"
}, {
    "Countries and Regions": "Canada",
    "国家或地区": "加拿大",
    "国际域名缩写": "CA",
    "电话代码": "1",
    "时差": "-13"
}, {
    "Countries and Regions": "Cayman Is.",
    "国家或地区": "开曼群岛",
    "国际域名缩写": "",
    "电话代码": "1345",
    "时差": "-13"
}, {
    "Countries and Regions": "Central African Republic",
    "国家或地区": "中非共和国",
    "国际域名缩写": "CF",
    "电话代码": "236",
    "时差": "-7"
}, {
    "Countries and Regions": "Chad",
    "国家或地区": "乍得",
    "国际域名缩写": "TD",
    "电话代码": "235",
    "时差": "-7"
}, {
    "Countries and Regions": "Chile",
    "国家或地区": "智利",
    "国际域名缩写": "CL",
    "电话代码": "56",
    "时差": "-13"
}, {
    "Countries and Regions": "China",
    "国家或地区": "中国",
    "国际域名缩写": "CN",
    "电话代码": "86",
    "时差": "0"
}, {
    "Countries and Regions": "Colombia",
    "国家或地区": "哥伦比亚",
    "国际域名缩写": "CO",
    "电话代码": "57",
    "时差": "0"
}, {
    "Countries and Regions": "Congo",
    "国家或地区": "刚果",
    "国际域名缩写": "CG",
    "电话代码": "242",
    "时差": "-7"
}, {
    "Countries and Regions": "Cook Is.",
    "国家或地区": "库克群岛",
    "国际域名缩写": "CK",
    "电话代码": "682",
    "时差": "-18.3"
}, {
    "Countries and Regions": "Costa Rica",
    "国家或地区": "哥斯达黎加",
    "国际域名缩写": "CR",
    "电话代码": "506",
    "时差": "-14"
}, {
    "Countries and Regions": "Cuba",
    "国家或地区": "古巴",
    "国际域名缩写": "CU",
    "电话代码": "53",
    "时差": "-13"
}, {
    "Countries and Regions": "Cyprus",
    "国家或地区": "塞浦路斯",
    "国际域名缩写": "CY",
    "电话代码": "357",
    "时差": "-6"
}, {
    "Countries and Regions": "Czech Republic",
    "国家或地区": "捷克",
    "国际域名缩写": "CZ",
    "电话代码": "420",
    "时差": "-7"
}, {
    "Countries and Regions": "Denmark",
    "国家或地区": "丹麦",
    "国际域名缩写": "DK",
    "电话代码": "45",
    "时差": "-7"
}, {
    "Countries and Regions": "Djibouti",
    "国家或地区": "吉布提",
    "国际域名缩写": "DJ",
    "电话代码": "253",
    "时差": "-5"
}, {
    "Countries and Regions": "Dominica Rep.",
    "国家或地区": "多米尼加共和国",
    "国际域名缩写": "DO",
    "电话代码": "1890",
    "时差": "-13"
}, {
    "Countries and Regions": "Ecuador",
    "国家或地区": "厄瓜多尔",
    "国际域名缩写": "EC",
    "电话代码": "593",
    "时差": "-13"
}, {
    "Countries and Regions": "Egypt",
    "国家或地区": "埃及",
    "国际域名缩写": "EG",
    "电话代码": "20",
    "时差": "-6"
}, {
    "Countries and Regions": "EI Salvador",
    "国家或地区": "萨尔瓦多",
    "国际域名缩写": "SV",
    "电话代码": "503",
    "时差": "-14"
}, {
    "Countries and Regions": "Estonia",
    "国家或地区": "爱沙尼亚",
    "国际域名缩写": "EE",
    "电话代码": "372",
    "时差": "-5"
}, {
    "Countries and Regions": "Ethiopia",
    "国家或地区": "埃塞俄比亚",
    "国际域名缩写": "ET",
    "电话代码": "251",
    "时差": "-5"
}, {
    "Countries and Regions": "Fiji",
    "国家或地区": "斐济",
    "国际域名缩写": "FJ",
    "电话代码": "679",
    "时差": "4"
}, {
    "Countries and Regions": "Finland",
    "国家或地区": "芬兰",
    "国际域名缩写": "FI",
    "电话代码": "358",
    "时差": "-6"
}, {
    "Countries and Regions": "France",
    "国家或地区": "法国",
    "国际域名缩写": "FR",
    "电话代码": "33",
    "时差": "-8"
}, {
    "Countries and Regions": "French Guiana",
    "国家或地区": "法属圭亚那",
    "国际域名缩写": "GF",
    "电话代码": "594",
    "时差": "-12"
}, {
    "Countries and Regions": "Gabon",
    "国家或地区": "加蓬",
    "国际域名缩写": "GA",
    "电话代码": "241",
    "时差": "-7"
}, {
    "Countries and Regions": "Gambia",
    "国家或地区": "冈比亚",
    "国际域名缩写": "GM",
    "电话代码": "220",
    "时差": "-8"
}, {
    "Countries and Regions": "Georgia",
    "国家或地区": "格鲁吉亚",
    "国际域名缩写": "GE",
    "电话代码": "995",
    "时差": "0"
}, {
    "Countries and Regions": "Germany",
    "国家或地区": "德国",
    "国际域名缩写": "DE",
    "电话代码": "49",
    "时差": "-7"
}, {
    "Countries and Regions": "Ghana",
    "国家或地区": "加纳",
    "国际域名缩写": "GH",
    "电话代码": "233",
    "时差": "-8"
}, {
    "Countries and Regions": "Gibraltar",
    "国家或地区": "直布罗陀",
    "国际域名缩写": "GI",
    "电话代码": "350",
    "时差": "-8"
}, {
    "Countries and Regions": "Greece",
    "国家或地区": "希腊",
    "国际域名缩写": "GR",
    "电话代码": "30",
    "时差": "-6"
}, {
    "Countries and Regions": "Grenada",
    "国家或地区": "格林纳达",
    "国际域名缩写": "GD",
    "电话代码": "1809",
    "时差": "-14"
}, {
    "Countries and Regions": "Guam",
    "国家或地区": "关岛",
    "国际域名缩写": "GU",
    "电话代码": "1671",
    "时差": "2"
}, {
    "Countries and Regions": "Guatemala",
    "国家或地区": "危地马拉",
    "国际域名缩写": "GT",
    "电话代码": "502",
    "时差": "-14"
}, {
    "Countries and Regions": "Guinea",
    "国家或地区": "几内亚",
    "国际域名缩写": "GN",
    "电话代码": "224",
    "时差": "-8"
}, {
    "Countries and Regions": "Guyana",
    "国家或地区": "圭亚那",
    "国际域名缩写": "GY",
    "电话代码": "592",
    "时差": "-11"
}, {
    "Countries and Regions": "Haiti",
    "国家或地区": "海地",
    "国际域名缩写": "HT",
    "电话代码": "509",
    "时差": "-13"
}, {
    "Countries and Regions": "Honduras",
    "国家或地区": "洪都拉斯",
    "国际域名缩写": "HN",
    "电话代码": "504",
    "时差": "-14"
}, {
    "Countries and Regions": "Hongkong",
    "国家或地区": "香港",
    "国际域名缩写": "HK",
    "电话代码": "852",
    "时差": "0"
}, {
    "Countries and Regions": "Hungary",
    "国家或地区": "匈牙利",
    "国际域名缩写": "HU",
    "电话代码": "36",
    "时差": "-7"
}, {
    "Countries and Regions": "Iceland",
    "国家或地区": "冰岛",
    "国际域名缩写": "IS",
    "电话代码": "354",
    "时差": "-9"
}, {
    "Countries and Regions": "India",
    "国家或地区": "印度",
    "国际域名缩写": "IN",
    "电话代码": "91",
    "时差": "-2.3"
}, {
    "Countries and Regions": "Indonesia",
    "国家或地区": "印度尼西亚",
    "国际域名缩写": "ID",
    "电话代码": "62",
    "时差": "-0.3"
}, {
    "Countries and Regions": "Iran",
    "国家或地区": "伊朗",
    "国际域名缩写": "IR",
    "电话代码": "98",
    "时差": "-4.3"
}, {
    "Countries and Regions": "Iraq",
    "国家或地区": "伊拉克",
    "国际域名缩写": "IQ",
    "电话代码": "964",
    "时差": "-5"
}, {
    "Countries and Regions": "Ireland",
    "国家或地区": "爱尔兰",
    "国际域名缩写": "IE",
    "电话代码": "353",
    "时差": "-4.3"
}, {
    "Countries and Regions": "Israel",
    "国家或地区": "以色列",
    "国际域名缩写": "IL",
    "电话代码": "972",
    "时差": "-6"
}, {
    "Countries and Regions": "Italy",
    "国家或地区": "意大利",
    "国际域名缩写": "IT",
    "电话代码": "39",
    "时差": "-7"
}, {
    "Countries and Regions": "Ivory Coast",
    "国家或地区": "科特迪瓦",
    "国际域名缩写": "",
    "电话代码": "225",
    "时差": "-6"
}, {
    "Countries and Regions": "Jamaica",
    "国家或地区": "牙买加",
    "国际域名缩写": "JM",
    "电话代码": "1876",
    "时差": "-12"
}, {
    "Countries and Regions": "Japan",
    "国家或地区": "日本",
    "国际域名缩写": "JP",
    "电话代码": "81",
    "时差": "1"
}, {
    "Countries and Regions": "Jordan",
    "国家或地区": "约旦",
    "国际域名缩写": "JO",
    "电话代码": "962",
    "时差": "-6"
}, {
    "Countries and Regions": "Kampuchea (Cambodia )",
    "国家或地区": "柬埔寨",
    "国际域名缩写": "KH",
    "电话代码": "855",
    "时差": "-1"
}, {
    "Countries and Regions": "Kazakstan",
    "国家或地区": "哈萨克斯坦",
    "国际域名缩写": "KZ",
    "电话代码": "327",
    "时差": "-5"
}, {
    "Countries and Regions": "Kenya",
    "国家或地区": "肯尼亚",
    "国际域名缩写": "KE",
    "电话代码": "254",
    "时差": "-5"
}, {
    "Countries and Regions": "Korea",
    "国家或地区": "韩国",
    "国际域名缩写": "KR",
    "电话代码": "82",
    "时差": "1"
}, {
    "Countries and Regions": "Kuwait",
    "国家或地区": "科威特",
    "国际域名缩写": "KW",
    "电话代码": "965",
    "时差": "-5"
}, {
    "Countries and Regions": "Kyrgyzstan",
    "国家或地区": "吉尔吉斯坦",
    "国际域名缩写": "KG",
    "电话代码": "331",
    "时差": "-5"
}, {
    "Countries and Regions": "Laos",
    "国家或地区": "老挝",
    "国际域名缩写": "LA",
    "电话代码": "856",
    "时差": "-1"
}, {
    "Countries and Regions": "Latvia",
    "国家或地区": "拉脱维亚",
    "国际域名缩写": "LV",
    "电话代码": "371",
    "时差": "-5"
}, {
    "Countries and Regions": "Lebanon",
    "国家或地区": "黎巴嫩",
    "国际域名缩写": "LB",
    "电话代码": "961",
    "时差": "-6"
}, {
    "Countries and Regions": "Lesotho",
    "国家或地区": "莱索托",
    "国际域名缩写": "LS",
    "电话代码": "266",
    "时差": "-6"
}, {
    "Countries and Regions": "Liberia",
    "国家或地区": "利比里亚",
    "国际域名缩写": "LR",
    "电话代码": "231",
    "时差": "-8"
}, {
    "Countries and Regions": "Libya",
    "国家或地区": "利比亚",
    "国际域名缩写": "LY",
    "电话代码": "218",
    "时差": "-6"
}, {
    "Countries and Regions": "Liechtenstein",
    "国家或地区": "列支敦士登",
    "国际域名缩写": "LI",
    "电话代码": "423",
    "时差": "-7"
}, {
    "Countries and Regions": "Lithuania",
    "国家或地区": "立陶宛",
    "国际域名缩写": "LT",
    "电话代码": "370",
    "时差": "-5"
}, {
    "Countries and Regions": "Luxembourg",
    "国家或地区": "卢森堡",
    "国际域名缩写": "LU",
    "电话代码": "352",
    "时差": "-7"
}, {
    "Countries and Regions": "Macao",
    "国家或地区": "澳门",
    "国际域名缩写": "MO",
    "电话代码": "853",
    "时差": "0"
}, {
    "Countries and Regions": "Madagascar",
    "国家或地区": "马达加斯加",
    "国际域名缩写": "MG",
    "电话代码": "261",
    "时差": "-5"
}, {
    "Countries and Regions": "Malawi",
    "国家或地区": "马拉维",
    "国际域名缩写": "MW",
    "电话代码": "265",
    "时差": "-6"
}, {
    "Countries and Regions": "Malaysia",
    "国家或地区": "马来西亚",
    "国际域名缩写": "MY",
    "电话代码": "60",
    "时差": "-0.5"
}, {
    "Countries and Regions": "Maldives",
    "国家或地区": "马尔代夫",
    "国际域名缩写": "MV",
    "电话代码": "960",
    "时差": "-7"
}, {
    "Countries and Regions": "Mali",
    "国家或地区": "马里",
    "国际域名缩写": "ML",
    "电话代码": "223",
    "时差": "-8"
}, {
    "Countries and Regions": "Malta",
    "国家或地区": "马耳他",
    "国际域名缩写": "MT",
    "电话代码": "356",
    "时差": "-7"
}, {
    "Countries and Regions": "Mariana Is",
    "国家或地区": "马里亚那群岛",
    "国际域名缩写": "",
    "电话代码": "1670",
    "时差": "1"
}, {
    "Countries and Regions": "Martinique",
    "国家或地区": "马提尼克",
    "国际域名缩写": "",
    "电话代码": "596",
    "时差": "-12"
}, {
    "Countries and Regions": "Mauritius",
    "国家或地区": "毛里求斯",
    "国际域名缩写": "MU",
    "电话代码": "230",
    "时差": "-4"
}, {
    "Countries and Regions": "Mexico",
    "国家或地区": "墨西哥",
    "国际域名缩写": "MX",
    "电话代码": "52",
    "时差": "-15"
}, {
    "Countries and Regions": "Moldova Republic of",
    "国家或地区": "摩尔多瓦",
    "国际域名缩写": "MD",
    "电话代码": "373",
    "时差": "-5"
}, {
    "Countries and Regions": "Monaco",
    "国家或地区": "摩纳哥",
    "国际域名缩写": "MC",
    "电话代码": "377",
    "时差": "-7"
}, {
    "Countries and Regions": "Mongolia",
    "国家或地区": "蒙古",
    "国际域名缩写": "MN",
    "电话代码": "976",
    "时差": "0"
}, {
    "Countries and Regions": "Montserrat Is",
    "国家或地区": "蒙特塞拉特岛",
    "国际域名缩写": "MS",
    "电话代码": "1664",
    "时差": "-12"
}, {
    "Countries and Regions": "Morocco",
    "国家或地区": "摩洛哥",
    "国际域名缩写": "MA",
    "电话代码": "212",
    "时差": "-6"
}, {
    "Countries and Regions": "Mozambique",
    "国家或地区": "莫桑比克",
    "国际域名缩写": "MZ",
    "电话代码": "258",
    "时差": "-6"
}, {
    "Countries and Regions": "Namibia",
    "国家或地区": "纳米比亚",
    "国际域名缩写": "NA",
    "电话代码": "264",
    "时差": "-7"
}, {
    "Countries and Regions": "Nauru",
    "国家或地区": "瑙鲁",
    "国际域名缩写": "NR",
    "电话代码": "674",
    "时差": "4"
}, {
    "Countries and Regions": "Nepal",
    "国家或地区": "尼泊尔",
    "国际域名缩写": "NP",
    "电话代码": "977",
    "时差": "-2.3"
}, {
    "Countries and Regions": "Netheriands Antilles",
    "国家或地区": "荷属安的列斯",
    "国际域名缩写": "",
    "电话代码": "599",
    "时差": "-12"
}, {
    "Countries and Regions": "Netherlands",
    "国家或地区": "荷兰",
    "国际域名缩写": "NL",
    "电话代码": "31",
    "时差": "-7"
}, {
    "Countries and Regions": "New Zealand",
    "国家或地区": "新西兰",
    "国际域名缩写": "NZ",
    "电话代码": "64",
    "时差": "4"
}, {
    "Countries and Regions": "Nicaragua",
    "国家或地区": "尼加拉瓜",
    "国际域名缩写": "NI",
    "电话代码": "505",
    "时差": "-14"
}, {
    "Countries and Regions": "Niger",
    "国家或地区": "尼日尔",
    "国际域名缩写": "NE",
    "电话代码": "227",
    "时差": "-8"
}, {
    "Countries and Regions": "Nigeria",
    "国家或地区": "尼日利亚",
    "国际域名缩写": "NG",
    "电话代码": "234",
    "时差": "-7"
}, {
    "Countries and Regions": "North Korea",
    "国家或地区": "朝鲜",
    "国际域名缩写": "KP",
    "电话代码": "850",
    "时差": "1"
}, {
    "Countries and Regions": "Norway",
    "国家或地区": "挪威",
    "国际域名缩写": "NO",
    "电话代码": "47",
    "时差": "-7"
}, {
    "Countries and Regions": "Oman",
    "国家或地区": "阿曼",
    "国际域名缩写": "OM",
    "电话代码": "968",
    "时差": "-4"
}, {
    "Countries and Regions": "Pakistan",
    "国家或地区": "巴基斯坦",
    "国际域名缩写": "PK",
    "电话代码": "92",
    "时差": "-2.3"
}, {
    "Countries and Regions": "Panama",
    "国家或地区": "巴拿马",
    "国际域名缩写": "PA",
    "电话代码": "507",
    "时差": "-13"
}, {
    "Countries and Regions": "Papua New Cuinea",
    "国家或地区": "巴布亚新几内亚",
    "国际域名缩写": "PG",
    "电话代码": "675",
    "时差": "2"
}, {
    "Countries and Regions": "Paraguay",
    "国家或地区": "巴拉圭",
    "国际域名缩写": "PY",
    "电话代码": "595",
    "时差": "-12"
}, {
    "Countries and Regions": "Peru",
    "国家或地区": "秘鲁",
    "国际域名缩写": "PE",
    "电话代码": "51",
    "时差": "-13"
}, {
    "Countries and Regions": "Philippines",
    "国家或地区": "菲律宾",
    "国际域名缩写": "PH",
    "电话代码": "63",
    "时差": "0"
}, {
    "Countries and Regions": "Poland",
    "国家或地区": "波兰",
    "国际域名缩写": "PL",
    "电话代码": "48",
    "时差": "-7"
}, {
    "Countries and Regions": "French Polynesia",
    "国家或地区": "法属玻利尼西亚",
    "国际域名缩写": "PF",
    "电话代码": "689",
    "时差": "3"
}, {
    "Countries and Regions": "Portugal",
    "国家或地区": "葡萄牙",
    "国际域名缩写": "PT",
    "电话代码": "351",
    "时差": "-8"
}, {
    "Countries and Regions": "Puerto Rico",
    "国家或地区": "波多黎各",
    "国际域名缩写": "PR",
    "电话代码": "1787",
    "时差": "-12"
}, {
    "Countries and Regions": "Qatar",
    "国家或地区": "卡塔尔",
    "国际域名缩写": "QA",
    "电话代码": "974",
    "时差": "-5"
}, {
    "Countries and Regions": "Reunion",
    "国家或地区": "留尼旺",
    "国际域名缩写": "",
    "电话代码": "262",
    "时差": "-4"
}, {
    "Countries and Regions": "Romania",
    "国家或地区": "罗马尼亚",
    "国际域名缩写": "RO",
    "电话代码": "40",
    "时差": "-6"
}, {
    "Countries and Regions": "Russia",
    "国家或地区": "俄罗斯",
    "国际域名缩写": "RU",
    "电话代码": "7",
    "时差": "-5"
}, {
    "Countries and Regions": "Saint Lueia",
    "国家或地区": "圣卢西亚",
    "国际域名缩写": "LC",
    "电话代码": "1758",
    "时差": "-12"
}, {
    "Countries and Regions": "Saint Vincent",
    "国家或地区": "圣文森特岛",
    "国际域名缩写": "VC",
    "电话代码": "1784",
    "时差": "-12"
}, {
    "Countries and Regions": "Samoa Eastern",
    "国家或地区": "东萨摩亚(美)",
    "国际域名缩写": "",
    "电话代码": "684",
    "时差": "-19"
}, {
    "Countries and Regions": "Samoa Western",
    "国家或地区": "西萨摩亚",
    "国际域名缩写": "",
    "电话代码": "685",
    "时差": "-19"
}, {
    "Countries and Regions": "San Marino",
    "国家或地区": "圣马力诺",
    "国际域名缩写": "SM",
    "电话代码": "378",
    "时差": "-7"
}, {
    "Countries and Regions": "Sao Tome and Principe",
    "国家或地区": "圣多美和普林西比",
    "国际域名缩写": "ST",
    "电话代码": "239",
    "时差": "-8"
}, {
    "Countries and Regions": "Saudi Arabia",
    "国家或地区": "沙特阿拉伯",
    "国际域名缩写": "SA",
    "电话代码": "966",
    "时差": "-5"
}, {
    "Countries and Regions": "Senegal",
    "国家或地区": "塞内加尔",
    "国际域名缩写": "SN",
    "电话代码": "221",
    "时差": "-8"
}, {
    "Countries and Regions": "Seychelles",
    "国家或地区": "塞舌尔",
    "国际域名缩写": "SC",
    "电话代码": "248",
    "时差": "-4"
}, {
    "Countries and Regions": "Sierra Leone",
    "国家或地区": "塞拉利昂",
    "国际域名缩写": "SL",
    "电话代码": "232",
    "时差": "-8"
}, {
    "Countries and Regions": "Singapore",
    "国家或地区": "新加坡",
    "国际域名缩写": "SG",
    "电话代码": "65",
    "时差": "0.3"
}, {
    "Countries and Regions": "Slovakia",
    "国家或地区": "斯洛伐克",
    "国际域名缩写": "SK",
    "电话代码": "421",
    "时差": "-7"
}, {
    "Countries and Regions": "Slovenia",
    "国家或地区": "斯洛文尼亚",
    "国际域名缩写": "SI",
    "电话代码": "386",
    "时差": "-7"
}, {
    "Countries and Regions": "Solomon Is",
    "国家或地区": "所罗门群岛",
    "国际域名缩写": "SB",
    "电话代码": "677",
    "时差": "3"
}, {
    "Countries and Regions": "Somali",
    "国家或地区": "索马里",
    "国际域名缩写": "SO",
    "电话代码": "252",
    "时差": "-5"
}, {
    "Countries and Regions": "South Africa",
    "国家或地区": "南非",
    "国际域名缩写": "ZA",
    "电话代码": "27",
    "时差": "-6"
}, {
    "Countries and Regions": "Spain",
    "国家或地区": "西班牙",
    "国际域名缩写": "ES",
    "电话代码": "34",
    "时差": "-8"
}, {
    "Countries and Regions": "Sri Lanka",
    "国家或地区": "斯里兰卡",
    "国际域名缩写": "LK",
    "电话代码": "94",
    "时差": "0"
}, {
    "Countries and Regions": "St.Lucia",
    "国家或地区": "圣卢西亚",
    "国际域名缩写": "LC",
    "电话代码": "1758",
    "时差": "-12"
}, {
    "Countries and Regions": "St.Vincent",
    "国家或地区": "圣文森特",
    "国际域名缩写": "VC",
    "电话代码": "1784",
    "时差": "-12"
}, {
    "Countries and Regions": "Sudan",
    "国家或地区": "苏丹",
    "国际域名缩写": "SD",
    "电话代码": "249",
    "时差": "-6"
}, {
    "Countries and Regions": "Suriname",
    "国家或地区": "苏里南",
    "国际域名缩写": "SR",
    "电话代码": "597",
    "时差": "-11.3"
}, {
    "Countries and Regions": "Swaziland",
    "国家或地区": "斯威士兰",
    "国际域名缩写": "SZ",
    "电话代码": "268",
    "时差": "-6"
}, {
    "Countries and Regions": "Sweden",
    "国家或地区": "瑞典",
    "国际域名缩写": "SE",
    "电话代码": "46",
    "时差": "-7"
}, {
    "Countries and Regions": "Switzerland",
    "国家或地区": "瑞士",
    "国际域名缩写": "CH",
    "电话代码": "41",
    "时差": "-7"
}, {
    "Countries and Regions": "Syria",
    "国家或地区": "叙利亚",
    "国际域名缩写": "SY",
    "电话代码": "963",
    "时差": "-6"
}, {
    "Countries and Regions": "Taiwan",
    "国家或地区": "台湾省",
    "国际域名缩写": "TW",
    "电话代码": "886",
    "时差": "0"
}, {
    "Countries and Regions": "Tajikstan",
    "国家或地区": "塔吉克斯坦",
    "国际域名缩写": "TJ",
    "电话代码": "992",
    "时差": "-5"
}, {
    "Countries and Regions": "Tanzania",
    "国家或地区": "坦桑尼亚",
    "国际域名缩写": "TZ",
    "电话代码": "255",
    "时差": "-5"
}, {
    "Countries and Regions": "Thailand",
    "国家或地区": "泰国",
    "国际域名缩写": "TH",
    "电话代码": "66",
    "时差": "-1"
}, {
    "Countries and Regions": "Togo",
    "国家或地区": "多哥",
    "国际域名缩写": "TG",
    "电话代码": "228",
    "时差": "-8"
}, {
    "Countries and Regions": "Tonga",
    "国家或地区": "汤加",
    "国际域名缩写": "TO",
    "电话代码": "676",
    "时差": "4"
}, {
    "Countries and Regions": "Trinidad and Tobago",
    "国家或地区": "特立尼达和多巴哥",
    "国际域名缩写": "TT",
    "电话代码": "1809",
    "时差": "-12"
}, {
    "Countries and Regions": "Tunisia",
    "国家或地区": "突尼斯",
    "国际域名缩写": "TN",
    "电话代码": "216",
    "时差": "-7"
}, {
    "Countries and Regions": "Turkey",
    "国家或地区": "土耳其",
    "国际域名缩写": "TR",
    "电话代码": "90",
    "时差": "-6"
}, {
    "Countries and Regions": "Turkmenistan",
    "国家或地区": "土库曼斯坦",
    "国际域名缩写": "TM",
    "电话代码": "993",
    "时差": "-5"
}, {
    "Countries and Regions": "Uganda",
    "国家或地区": "乌干达",
    "国际域名缩写": "UG",
    "电话代码": "256",
    "时差": "-5"
}, {
    "Countries and Regions": "Ukraine",
    "国家或地区": "乌克兰",
    "国际域名缩写": "UA",
    "电话代码": "380",
    "时差": "-5"
}, {
    "Countries and Regions": "United Arab Emirates",
    "国家或地区": "阿拉伯联合酋长国",
    "国际域名缩写": "AE",
    "电话代码": "971",
    "时差": "-4"
}, {
    "Countries and Regions": "United Kiongdom",
    "国家或地区": "英国",
    "国际域名缩写": "GB",
    "电话代码": "44",
    "时差": "-8"
}, {
    "Countries and Regions": "United States of America",
    "国家或地区": "美国",
    "国际域名缩写": "US",
    "电话代码": "1",
    "时差": "-13"
}, {
    "Countries and Regions": "Uruguay",
    "国家或地区": "乌拉圭",
    "国际域名缩写": "UY",
    "电话代码": "598",
    "时差": "-10.3"
}, {
    "Countries and Regions": "Uzbekistan",
    "国家或地区": "乌兹别克斯坦",
    "国际域名缩写": "UZ",
    "电话代码": "233",
    "时差": "-5"
}, {
    "Countries and Regions": "Venezuela",
    "国家或地区": "委内瑞拉",
    "国际域名缩写": "VE",
    "电话代码": "58",
    "时差": "-12.3"
}, {
    "Countries and Regions": "Vietnam",
    "国家或地区": "越南",
    "国际域名缩写": "VN",
    "电话代码": "84",
    "时差": "-1"
}, {
    "Countries and Regions": "Yemen",
    "国家或地区": "也门",
    "国际域名缩写": "YE",
    "电话代码": "967",
    "时差": "-5"
}, {
    "Countries and Regions": "Yugoslavia",
    "国家或地区": "南斯拉夫",
    "国际域名缩写": "YU",
    "电话代码": "381",
    "时差": "-7"
}, {
    "Countries and Regions": "Zimbabwe",
    "国家或地区": "津巴布韦",
    "国际域名缩写": "ZW",
    "电话代码": "263",
    "时差": "-6"
}, {
    "Countries and Regions": "Zaire",
    "国家或地区": "扎伊尔",
    "国际域名缩写": "ZR",
    "电话代码": "243",
    "时差": "-7"
}, {
    "Countries and Regions": "Zambia",
    "国家或地区": "赞比亚",
    "国际域名缩写": "ZM",
    "电话代码": "260",
    "时差": "-6"
} ];

var YANWEN_CONTRY_ENUM = [ {
    cn_name: "俄罗斯",
    en_name: "RUSSIA",
    country_code: "RU",
    country_pick_code: 21
}, {
    cn_name: "美国",
    en_name: "AMERICA",
    country_code: "US",
    country_pick_code: 22
}, {
    cn_name: "英国",
    en_name: "BRITAIN",
    country_code: "GB",
    country_pick_code: 23
}, {
    cn_name: "巴西",
    en_name: "BRAZIL",
    country_code: "BR",
    country_pick_code: 24
}, {
    cn_name: "澳大利亚",
    en_name: "AUSTRALIA",
    country_code: "AU",
    country_pick_code: 25
}, {
    cn_name: "法国",
    en_name: "FRANCE",
    country_code: "FR",
    country_pick_code: 26
}, {
    cn_name: "西班牙",
    en_name: "SPAIN",
    country_code: "ES",
    country_pick_code: 27
}, {
    cn_name: "加拿大",
    en_name: "CANADA",
    country_code: "CA",
    country_pick_code: 28
}, {
    cn_name: "以色列",
    en_name: "ISRAEL",
    country_code: "IL",
    country_pick_code: 29
}, {
    cn_name: "意大利",
    en_name: "ITALY",
    country_code: "IT",
    country_pick_code: 30
}, {
    cn_name: "德国",
    en_name: "GERMANY",
    country_code: "DE",
    country_pick_code: 31
}, {
    cn_name: "智利",
    en_name: "CHILE",
    country_code: "CL",
    country_pick_code: 32
}, {
    cn_name: "瑞典",
    en_name: "SWEDEN",
    country_code: "SE",
    country_pick_code: 33
}, {
    cn_name: "白俄罗斯",
    en_name: "BELARUS",
    country_code: "BY",
    country_pick_code: 34
}, {
    cn_name: "挪威",
    en_name: "NORWAY",
    country_code: "NO",
    country_pick_code: 35
}, {
    cn_name: "荷兰",
    en_name: "NETHERLAND",
    country_code: "NL",
    country_pick_code: 36
}, {
    cn_name: "乌克兰",
    en_name: "UKRAINE",
    country_code: "UA",
    country_pick_code: 37
}, {
    cn_name: "瑞士",
    en_name: "SWITZERLAND",
    country_code: "CH",
    country_pick_code: 38
}, {
    cn_name: "墨西哥",
    en_name: "MEXICO",
    country_code: "MX",
    country_pick_code: 39
}, {
    cn_name: "波兰",
    en_name: "POLAND",
    country_code: "PL",
    country_pick_code: 40
} ];

function AliShipInfo(salesOrderId) {
    this.id = salesOrderId;
    var search = nlapiSearchRecord("salesorder", null, [ new nlobjSearchFilter("internalid", null, "is", salesOrderId), new nlobjSearchFilter("type", "item", "anyof", [ "InvtPart", "Kit" ]) ], [ new nlobjSearchColumn("trandate"), new nlobjSearchColumn("currency"), new nlobjSearchColumn("tranid"), new nlobjSearchColumn("type"), new nlobjSearchColumn("memo"), new nlobjSearchColumn("memomain"), new nlobjSearchColumn("custbody_carrier_req_time"), new nlobjSearchColumn("entity"), new nlobjSearchColumn("firstname", "customerMain"), new nlobjSearchColumn("middlename", "customerMain"), new nlobjSearchColumn("lastname", "customerMain"), new nlobjSearchColumn("email", "customerMain"), new nlobjSearchColumn("companyname", "customerMain"), new nlobjSearchColumn("rate"), new nlobjSearchColumn("quantity"), new nlobjSearchColumn("amount"), new nlobjSearchColumn("item"), new nlobjSearchColumn("weight", "item"), new nlobjSearchColumn("weightunit", "item"), new nlobjSearchColumn("custitem_sz_item_tags", "item"), new nlobjSearchColumn("displayname", "item"), new nlobjSearchColumn("salesdescription", "item"), new nlobjSearchColumn("itemid", "item"), new nlobjSearchColumn("custitem_legacy_tong_sku", "item"), new nlobjSearchColumn("custitem_cn_declared_name", "item"), new nlobjSearchColumn("custitem_en_declared_name", "item"), new nlobjSearchColumn("custcol_ebay_item_id"), new nlobjSearchColumn("custcol_ebay_item_title"), new nlobjSearchColumn("custcol_ebay_transaction_id"), new nlobjSearchColumn("custcol_ebay_transaction_site_id"), new nlobjSearchColumn("custbody_ebay_seller_id"), new nlobjSearchColumn("custbody_ebay_order_id"), new nlobjSearchColumn("custbody_ebay_sales_record_number"), new nlobjSearchColumn("custbody_ebay_buyer_id"), new nlobjSearchColumn("otherrefnum"), new nlobjSearchColumn("custbody_sz_carrier_trackingnumber"), new nlobjSearchColumn("shipcountry"), new nlobjSearchColumn("shipcountrycode"), new nlobjSearchColumn("shipstate"), new nlobjSearchColumn("shipcity"), new nlobjSearchColumn("shipaddress1"), new nlobjSearchColumn("shipaddress2"), new nlobjSearchColumn("shipphone"), new nlobjSearchColumn("shipzip"), new nlobjSearchColumn("shipaddressee"), new nlobjSearchColumn("custbody_carrier_shipment_number"), new nlobjSearchColumn("custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_apicode", "custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_from", "custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_fromphone", "custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_pickupaddress", "custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_shipfromaddress", "custbody_ship_method_sz"), new nlobjSearchColumn("custrecord_sz_sm_returnaddress", "custbody_ship_method_sz"), new nlobjSearchColumn("custbody_linked_ebay_account"), new nlobjSearchColumn("custrecord_ebay_api_token", "custbody_linked_ebay_account") ]);
    if (search == null) {
        throw nlapiCreateError("FulfillmentException", "没有这个 SO 的Search " + salesOrderId);
    } else {
        this.search = search;
    }
}

AliShipInfo.prototype.getShippingLabelDetails = function() {
    var shipmentSearch = this.getSearch();
    var shipmentInfo = this.getMainline();
    var shippinglabel_info = {};
    shippinglabel_info.otherrefnum = shipmentInfo.getValue("otherrefnum");
    shippinglabel_info.email = shipmentInfo.getValue("email", "customerMain");
    shippinglabel_info.ffid = shipmentInfo.getId();
    shippinglabel_info.companyname = shipmentInfo.getValue("companyname", "customerMain");
    shippinglabel_info.salesOrderId = shipmentInfo.getId();
    shippinglabel_info.channelcode = shipmentInfo.getValue("custrecord_sz_sm_apicode", "custbody_ship_method_sz");
    var shipaddressee = shipmentInfo.getValue("shipaddressee");
    shippinglabel_info.name = shipaddressee;
    shippinglabel_info.entity = shipaddressee;
    shippinglabel_info.shipaddress1 = shipmentInfo.getValue("shipaddress1");
    shippinglabel_info.shipaddress2 = shipmentInfo.getValue("shipaddress2");
    shippinglabel_info.shipcity = shipmentInfo.getValue("shipcity");
    shippinglabel_info.shipstate = shipmentInfo.getValue("shipstate");
    shippinglabel_info.shipcountry = shipmentInfo.getValue("shipcountry");
    shippinglabel_info.shipcountry_text = shipmentInfo.getText("shipcountry");
    var yanwen_country_pick_code = YANWEN_CONTRY_ENUM.find(function(item) {
        return item.country_code == shippinglabel_info.shipcountry;
    });
    if (!yanwen_country_pick_code) {
        yanwen_country_pick_code = "";
    } else {
        yanwen_country_pick_code = yanwen_country_pick_code.country_pick_code;
    }
    shippinglabel_info.yanwen_country_pick_code = yanwen_country_pick_code;
    shippinglabel_info.shipphone = shipmentInfo.getValue("shipphone");
    shippinglabel_info.shipzip = shipmentInfo.getValue("shipzip");
    shippinglabel_info.currency = shipmentInfo.getText("currency");
    var zipCode = shipmentInfo.getValue("shipzip");
    if (zipCode.indexOf("-") != -1) {
        zipCode = zipCode.substring(0, zipCode.indexOf("-"));
    }
    shippinglabel_info._shipzip = zipCode;
    shippinglabel_info.from = shipmentInfo.getValue("custrecord_sz_sm_from", "custbody_ship_method_sz").replace(/\r\n/g, "<br/>");
    shippinglabel_info.fromphone = shipmentInfo.getValue("custrecord_sz_sm_fromphone", "custbody_ship_method_sz");
    var countryChineseName = COUNTRY_MAPPING.find(function(countryMapping) {
        return countryMapping["国际域名缩写"] == shippinglabel_info.shipcountry;
    });
    if (countryChineseName) {
        shippinglabel_info.shipcountry_cn = countryChineseName["国家或地区"];
    } else {
        shippinglabel_info.shipcountry_cn = shippinglabel_info.shipcountry;
    }
    shippinglabel_info.id = "000194P" + shipmentInfo.getId();
    shippinglabel_info.pid = "P" + shipmentInfo.getId();
    var totalweight = 0;
    var totalvalue = 0;
    var totalquantity = 0;
    shippinglabel_info.items = shipmentSearch.map(function(itemSearchResult, index) {
        var quantity = itemSearchResult.getValue("quantity");
        quantity = parseInt(quantity);
        totalquantity += quantity;
        var weight = itemSearchResult.getValue("weight", "item");
        var weightunit = itemSearchResult.getValue("weightunit", "item");
        if (weightunit == "lb") {
            weight = 453.59237 * parseFloat(weight);
        }
        weight = _mathround(weight);
        var weight_total = _mathround(weight * quantity);
        totalweight += weight_total;
        var v = 4 + Math.random();
        v = _mathround(v);
        var declaredValue = v;
        var sku = itemSearchResult.getValue("itemid", "item");
        if (sku.indexOf(":") != -1) {
            sku = sku.substring(sku.indexOf(":") + 1);
        }
        sku = sku.trim();
        var rate = parseFloat(itemSearchResult.getValue("rate"));
        totalvalue += rate;
        var linenumber = index + 1;
        var custitem_cn_declared_name = itemSearchResult.getValue("custitem_cn_declared_name", "item");
        var custitem_en_declared_name = itemSearchResult.getValue("custitem_en_declared_name", "item");
        var name = itemSearchResult.getValue("displayname", "item") || itemSearchResult.getValue("salesdescription", "item");
        var name2 = custitem_cn_declared_name || custitem_en_declared_name;
        var tags = itemSearchResult.getValue("custitem_sz_item_tags", "item");
        tags = tags.split("");
        if (tags.contains(3)) {
            name = name2;
        }
        return {
            _id: linenumber + "_" + itemSearchResult.getValue("item"),
            name: name,
            weight: weight,
            weight_kg: weight / 1e3,
            weight_total: weight_total,
            weight_kg_total: weight_total / 1e3,
            currency: itemSearchResult.getText("currency"),
            declaredValue: declaredValue,
            rate: rate,
            sku: sku,
            quantity: quantity,
            custcol_ebay_item_id: itemSearchResult.getValue("custcol_ebay_item_id"),
            custcol_ebay_item_title: itemSearchResult.getValue("custcol_ebay_item_title"),
            custcol_ebay_transaction_id: itemSearchResult.getValue("custcol_ebay_transaction_id"),
            custcol_ebay_transaction_site_id: itemSearchResult.getValue("custcol_ebay_transaction_site_id"),
            custitem_cn_declared_name: custitem_cn_declared_name,
            custitem_en_declared_name: custitem_en_declared_name
        };
    });
    shippinglabel_info.itemcount = shippinglabel_info.items.length;
    shippinglabel_info.totalquantity = totalquantity;
    shippinglabel_info.totalweight = _mathround(totalweight);
    shippinglabel_info.totalweight_kg = _mathround(totalweight / 1e3);
    shippinglabel_info.totalvalue = shipmentInfo.getValue("amount");
    shippinglabel_info.declaredItems = [ shippinglabel_info.items[0] ];
    shippinglabel_info.declaredTotalWeight = shippinglabel_info.items[0].weight_total;
    shippinglabel_info.declaredTotalWeightKG = shippinglabel_info.items[0].weight_kg_total;
    shippinglabel_info.declaredTotalValue = shippinglabel_info.items[0].declaredValue;
    shippinglabel_info.custbody_carrier_shipment_number = shipmentInfo.getValue("custbody_carrier_shipment_number");
	shippinglabel_info.trackingno = shipmentInfo.getValue("custbody_sz_carrier_trackingnumber");
    shippinglabel_info.tranid = shipmentInfo.getValue("tranid");
    var trandate = shipmentInfo.getValue("trandate");
    trandate = nlapiStringToDate(trandate);
    trandate = trandate.format("yyyy-MM-dd");
    shippinglabel_info.trandate = trandate;
    return shippinglabel_info;
};

AliShipInfo.prototype.getMainline = function() {
    return this.search[0];
};

AliShipInfo.prototype.getSearch = function() {
    return this.search;
};