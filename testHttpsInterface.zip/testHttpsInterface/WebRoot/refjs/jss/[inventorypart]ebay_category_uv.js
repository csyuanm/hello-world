/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Feb 2015     Sansom Li
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){
	try{		
		if ( type == 'create' || type == 'edit' )
		{
			var execution = nlapiGetContext().getExecutionContext();
			if ( execution == 'userinterface'  && nlapiGetFieldValue('customform') == '15') // Z:Ebay Listing Kit Form
			{
				
				for ( var i = 1; i <= MAX_SUB_CATEGORY; i++ ){
					var field = form.addField('custpage_field_subcategory' + i, 'select', 'Ebay Category ' + i + ':');
					nlapiSetFieldDisplay('custpage_field_subcategory' + i, false);
				}
				
				for ( var i = 1; i <= MAX_SPECIFICS; i++ ){
					nlapiSetFieldDisplay('custitem_item_specific_' + i + '_value', false);
					nlapiSetFieldDisplay('custitem_item_specific_' + i, false);
					var text_field = form.addField('custpage_field_specific_' + i + '_text_val', 'text', '', null);
					text_field.setDisplaySize('36');
					form.addField('custpage_field_specific_' + i + '_value', 'select', null, null);					
					nlapiSetFieldDisplay('custpage_field_specific_' + i + '_text_val', false);
					nlapiSetFieldDisplay('custpage_field_specific_' + i + '_value', false);
					nlapiSetFieldDisplay('custpage_field_specific_' + i + '_text_val', false);
				}
			}
/*			if(execution == 'userinterface' && nlapiGetFieldValue('customform') == '49'){
				var ebayTitle = form.addField('custpage_ebay_title_text', 'text', 'EBAY LISTING TITLE *');
				var select = form.addField('custpage_ebay_title_select', 'select');
				
				//var select = form.addField('custpage_mybutton_china_shipping_method',null,null,'main','fieldGroup221',19,1);
					select.addSelectOption('1', 'China Post');
				  select.addSelectOption('2', 'Dutch Post');
				  select.addSelectOption('3', 'ePacket'); 
				  nlapiSetFieldDisplay('custpage_ebay_title_text', true);
				  nlapiSetFieldDisplay('custpage_ebay_title_select', false);
				  form.insertField(ebayTitle,'description');
				  form.insertField(select,'description');
			}*/
		}
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on before load func', e);
	}
}
