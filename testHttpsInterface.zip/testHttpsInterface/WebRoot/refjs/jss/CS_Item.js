/*
 * Script owner: Chenglihou ( description added by Hamilton )
 *
 * Revised date: 12/21/2016
 *
 * Purpose: breakeven pricelevel ( Brett, Lars, Hamilton )
 *
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * Please note: this script manged by Allan,
 * so anyone who revise the file must email to Allan if not then may override!
 *
 */
function CurrencyRateUSDtoCNY() {
    var rate = nlapiExchangeRate('USD', 'CNY');
    return Math.round(rate * 10000) / 10000;
}
console.log("Item Client Edit");

//jQuery(document).ready(function () {
//    // added by Hamilton Nieri
//    var user = nlapiGetUser();
//    var role = nlapiGetRole();
////    if ( user == '15' || user == '131206' || role == '1143' || role == '1145' ) { // Brett and Lars
////        console.log( jQuery("#pricing_mh").parent().parent().parent().parent().attr("class") );
////    jQuery("#pricing_mh").parent().parent().parent().parent().hide();
////    }
//});

function pageInit(type) {
    _log("page inint!", arguments);
    var parent = nlapiGetFieldValue("parent");
    console.log(parent);
    if (parent) {
        jQuery("#custom39_form").next().hide();
    }

    var subs = nlapiGetFieldValue('subsidiary');
    if (subs == Subsidiaries.ShenzhenB2B) {
        if (type == 'create' || type == 'edit') {
            if (!nlapiGetFieldValue('salesdescription')) {
                var purchasedescription = nlapiGetFieldValue('purchasedescription');
                if (purchasedescription) {
                    nlapiSetFieldValue('salesdescription', purchasedescription);
                }
            }
        }
    }

}

function saveRecord() {
    if (nlapiGetFieldValue('subsidiary') == 3) { // Taiwu
        var usebins = nlapiGetFieldValue('usebins');
        if (usebins == "F") {
            alert('Taiwu subsidiary must checked Use Bins!');
            return false;
        }
    }
    return true;
}

function validateField(type, name, linenum) {
    _log("validateField", arguments);
    return true;
}

function fieldChanged(type, name, linenum) {
    try {
        _log("fieldChanged", arguments);
        if (name == "class") {
            var categoryId = nlapiGetFieldValue("class");
            console.log(categoryId);
            if (categoryId) {
                var category = nlapiSearchRecord("classification", null, [
                    new nlobjSearchFilter("internalid", null, "is", categoryId)
                ], [
                    new nlobjSearchColumn("custrecord_cat_act_cogs"),
                    new nlobjSearchColumn("custrecord_cat_act_income")
                ]);
                console.log(category);
                if (category != null && category.length && category.length == 1) {
                    var cogs = category[0].getValue("custrecord_cat_act_cogs");
                    var income = category[0].getValue("custrecord_cat_act_income");
                    if (cogs && income) {
                        nlapiSetFieldValue("cogsaccount", cogs, true, true);
                        nlapiSetFieldValue("incomeaccount", income, true, true);
                    } else {
                        alert("Category " + nlapiGetFieldText("class") + " have not connect with COGS account or Income accounts.");
                    }
                }
            }
        }
    } catch (e) {
        processException(e);
    }
}

function postSourcing(type, name, linenum) {
}

function lineInit(type) {
    _log("lineInit", arguments);
}

function validateLine(type) {
    _log("validateLine", arguments);
    return true;
}

function recalc(type) {
    _log("recalc", type);
}

function validateInsert(type) {
    _log("validateInsert", arguments);
    return false;
}

function validateDelete(type) {
    _log("validateDelete", arguments);
    return false;
}

jQuery("#custitem_item_var_picture").ossImage({
    Type: "textbox"
});

jQuery("#custitem_ebay_gallery_pictures").ossImage();

jQuery("#custitem_ebay_body_pictures").ossImage();

function previewListingDescription() {
    post_to_url("/app/site/hosting/scriptlet.nl?script=470&deploy=1", {
        action: "previewListingDescription",
        title: nlapiGetFieldValue("custitem_web_store_title") || "#Title#",
        featureddescription: nlapiGetFieldValue("featureddescription"),
        custitem_ebay_body_pictures: nlapiGetFieldValue("custitem_ebay_body_pictures"),
        storedetaileddescription: nlapiGetFieldValue("storedetaileddescription")
    });
}