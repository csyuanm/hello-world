/*
@@@ NetSuite AliExpress

@@@	ali.ns.let.js

@@@ description

reference document for ali API

http://gw.api.alibaba.com/dev/doc/intl/sys_description.htm?spm=5261.6681697.882438617.3.qdt6bn&ns=aliexpress.open

@@@ version 0.0.1

@@@ copyright 2015 zakeusa.com

*/

function service(request, response){
	try{
		var $sign_string = 'client_id' + $appKey + 'redirect_uri' + $redirectUrl + 'sitealiexpress';
		var hash = CryptoJS.HmacSHA1($sign_string, $appSecret);
		var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);	
		var $code_sign = bin2hex(hashInBase64).toUpperCase();
		var $get_code_url = 'http://gw.api.alibaba.com/auth/authorize.htm?client_id=' + $appKey + '&site=aliexpress&redirect_uri=' + $redirectUrl + '&_aop_signature=' + $code_sign;

		nlapiLogExecution('debug', 'result', $get_code_url);
		response.write($get_code_url);
	}catch(error){
		var stErrorString = '';				
		if (error.getDetails != undefined){
			stErrorString = error.getCode() + ': ' + error.getDetails();
			nlapiLogExecution('ERROR', 'Process Error', stErrorString);
		}else{
			stErrorString = error.toString();
			nlapiLogExecution('ERROR', 'Unexpected Error', stErrorString); 
		}
	}
}