function itemID(type){
  var rec = currentRecord = nlapiGetNewRecord();
  var loc = rec.getFieldValue('location');
  var con = rec.getFieldValue('custitem_product_condition');
  var conCode = condition[con];
  if(conCode == undefined){
    conCode = '';
  }
  var name = rec.getFieldValue('itemid');
  var id;
  nlapiLogExecution('DEBUG','name', name);
  if(name != ''){
    id = conCode+name;
  }else{
    var lastID = getLast();
    nlapiLogExecution('DEBUG','lastID', lastID);
    id = getNext(lastID);
    nlapiLogExecution('DEBUG','id', id);
    if(nameCon(id)){
      var core = id.slice(2);
      id = loc+core;
    }else{
      var core = id.slice(1);
      id = loc+core;
    }
  }
  rec.setFieldValue('usebins', 'T');
  rec.setFieldValue('itemid', id);
}
var condition = {
  1: 'O',
  2: 'U',
  3: 'F',
  4: 'M',
  5: 'P',
  6: '',
  7: 'S'
}

function nameCon(name){
  return /^[a-zA-Z]/.test(name);
}

function checkName(name){
  var con = nameCon(name);
  if(con){
    nlapiLogExecution('DEBUG', 'condition in last number', name);
    name = name.slice(1, name.length).toUpperCase();
    nlapiLogExecution('DEBUG', 'condition in last number2', name);
  }
  var fil = new Array();
  fil[0] = new nlobjSearchFilter('itemid', null, 'contains', name);
  var search = nlapiSearchRecord('inventoryitem', null, fil);
  nlapiLogExecution('DEBUG','search', JSON.stringify(search));
  if(search == null){
    return false;
  }else{
    return true;
  }
}

function getLast(){
  var cols = new Array();
  cols[0] = new nlobjSearchColumn('created').setSort(true);
  cols[1] = new nlobjSearchColumn('itemid');
  var search = nlapiSearchRecord('inventoryitem', null, null, cols);
  for(var i = 0; i < search.length; i++){
    var id = search[i].getValue('itemid');
    var index = id.indexOf('-');
    if(index > 0){
      continue;
    }else{
      return id;
    }
  }
}

function getNext(lastID){
  var con = nameCon(lastID);
  if(con){
    nlapiLogExecution('DEBUG', 'getNext  last number1', lastID);
    lastID = lastID.slice(1, lastID.length).toUpperCase();
    nlapiLogExecution('DEBUG', 'getNext  last number2', lastID);
  }
  var id = incremint(lastID);
  nlapiLogExecution('DEBUG','getNext', id);
  if(checkName(id)){
    return getNext(id);
  }else{
     nlapiLogExecution('DEBUG','getNext return', id);
    return id.toUpperCase();
  }
}

function incremint(str){
  return (parseInt(str, 36)+1).toString(36);
}