/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       25 May 2017     ratul
 * Allan: revised for distinguish subsidiary
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @returns {Boolean} True to continue save, false to abort save
 */

/**
 *
 /* *


 **/



function clientSaveRecord() {

    var context = nlapiGetContext();
    nlapiLogExecution('Debug', 'context', context.getExecutionContext());
    var subs = nlapiGetFieldValue('subsidiary');
    if (subs != 3) {
        if (context.getExecutionContext() == 'userinterface') {


            var shipTo = nlapiGetFieldValue('shipaddress');
            var shipCarrier = nlapiGetFieldValue('shipcarrier');
            var shipMethod = nlapiGetFieldValue('shipmethod');

            if (shipTo == '' && shipCarrier == '' && shipMethod == '') {
                alert('please provide SHIP TO SELECT,SHIPPING CARRIER,SHIPPING METHOD');
                return false;
            }
            if (shipTo == '') {
                alert('please provide SHIP TO SELECT');
                return false;
            }
            if (shipCarrier == '') {
                alert('please provide SHIPPING CARRIER');
                return false;
            }
            if (shipMethod == '') {
                alert('please provide SHIPPING METHOD ');
                return false;
            }


        }
    }


    return true;
}



function validateLine(type){
	
	if(type == 'item'){
		
		var rate = nlapiGetCurrentLineItemValue('item','rate');
		nlapiLogExecution('Debug','rate',rate);
		if(!rate){
			alert('Please provide RATE');
			return false;
		}
			
		return true;
	}
	
	return true;
	
}
