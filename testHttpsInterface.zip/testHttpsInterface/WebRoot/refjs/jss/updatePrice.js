function updatePrice(obj){
  //var x = nlapiSearchRecord('item', null, new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', obj.sku));
  return JSON.stringify(obj);
}