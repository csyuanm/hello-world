if (typeof this.console == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function Exception(code, message, info) {
    this.code = code;
    this.message = message;
    this.info = info;
}

function parseException(e) {
    var code, message;
    var info = null;
    var userMessage = null;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = e.getCode() || "nlobjError";
            var st = e.getStackTrace();
            if (typeof console == "undefined") {
                message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + st.join(", ");
            } else {
                message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + st.toString();
            }
            userMessage = e.getDetails();
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof Exception) {
            code = e.code;
            message = e.message;
            info = e.info;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (userMessage == null) userMessage = message;
    return {
        code: code,
        ERROR_CODE: code,
        message: message,
        userMessage: userMessage,
        info: info
    };
}

function processException(e, info, sendEmail) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "<br/><br/>" + info;
    }
    if (typeof console == "undefined") {
        if (sendEmail != false) {
            _log("nlapiSendEmail", code);
            var context = nlapiGetContext();
            var sname = [ context.getDeploymentId(), "@Subsidiary" + context.getSubsidiary(), context.getEmail(), "Role" + nlapiGetRole() ].join("/");
            nlapiSendEmail(530, "allan@zakeusa.com", "[" + code + "] " + sname, message);
        }
    } else {
        alert(code + "///" + message);
    }
    _nlapiLogExecution("ERROR", code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

function disabledFields(fields) {
    var defaultFields = [ "customform", "name" ];
    if (typeof fields != "undefined" && Array.isArray(fields)) {
        fields = fields.concat(defaultFields);
    } else {
        fields = defaultFields;
    }
    _disabledFields(fields);
}

function _disabledFields(fields) {
    if (nlapiGetContext().getUser() == "530" && nlapiGetRole() == "3") {} else {
        if (fields && Array.isArray(fields) && fields.length) {
            fields.forEach(function(field) {
                nlapiGetField(field).setDisplayType("disabled");
            });
        }
    }
}

function _nlapiLogExecution(logType, title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (typeof console == "undefined") {
            if (detail) {
                if (typeof detail == "object") {
                    if (detail === null) {
                        nlapiLogExecution(logType, title, "/// null VALUE HERE");
                    } else {
                        if (format) {
                            nlapiLogExecution(logType, title, JSON.stringify(detail, undefined, 4));
                        } else {
                            nlapiLogExecution(logType, title, JSON.stringify(detail));
                        }
                    }
                } else {
                    nlapiLogExecution(logType, title, detail);
                }
            } else {
                nlapiLogExecution(logType, title, detail);
            }
        } else {
            if (typeof title == "object") {
                title = JSON.stringify(title, null, 2);
            }
            if (typeof detail == "object") {
                console.log(title + "///" + JSON.stringify(detail, null, 2));
            } else {
                console.log(title + "///" + detail);
            }
        }
    }
}

function _log(title, detail) {
    var logType = "debug";
    _nlapiLogExecution(logType, title, detail);
}

function _audit(title, detail) {
    _nlapiLogExecution("AUDIT", title, detail);
}

function _log_email(title, detail) {
    detail = detail || "something was warning";
    _log("[EMAIL] " + title, detail);
    nlapiSendEmail(530, "allan@zakeusa.com", nlapiGetContext().getDeploymentId() + ": " + title, detail);
}

function _sendEmail(to, title, detail) {
    title = nlapiGetContext().getDeploymentId() + ": " + title;
    _log("[SENTEMAIL] " + to + " " + title, detail);
    nlapiSendEmail(530, to, title, detail);
}

if (!Array.prototype.find) {
    Object.defineProperty(Array.prototype, "find", {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function(predicate) {
            if (this == null) {
                throw new TypeError("Array.prototype.find called on null or undefined");
            }
            if (typeof predicate !== "function") {
                throw new TypeError("predicate must be a function");
            }
            var list = Object(this);
            var length = list.length >>> 0;
            var thisArg = arguments[1];
            var value;
            for (var i = 0; i < length; i++) {
                if (i in list) {
                    value = list[i];
                    if (predicate.call(thisArg, value, i, list)) {
                        return value;
                    }
                }
            }
            return undefined;
        }
    });
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

Array.prototype.remove = function(value) {
    var a = this;
    var index = a.indexOf(value);
    if (index > -1) {
        a.splice(index, 1);
    }
};

Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) < 0;
    });
};

Array.prototype.same = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) >= 0;
    });
};

function allTheSame(array) {
    var first = array[0];
    return array.every(function(element) {
        return element === first;
    });
}

function randString(x) {
    var s = "";
    while (s.length < x && x > 0) {
        var r = Math.random();
        s += r < .1 ? Math.floor(r * 100) : String.fromCharCode(Math.floor(r * 26) + (r > .5 ? 97 : 65));
    }
    return s;
}

function _uniqid() {
    var rs = randString(8);
    var range = [ 3, 4, 5, 6, 7, 8 ];
    var n = Math.random();
    n = n.toString();
    n = n.replace("0.", "");
    var found = false;
    for (var i = 0, len = n.length; i < len; i++) {
        var index = parseInt(n[i]);
        if (range.contains(index)) {
            found = true;
            return rs.substring(0, index);
        }
    }
    if (found == false) {
        return rs.substring(0, 5);
    }
}

function _toarray(obj) {
    if (!Array.isArray(obj)) obj = [ obj ];
    return obj;
}

function _stringxml(xmlarry) {
    return xmlarry.map(function(node) {
        return node.trim();
    }).join("");
}

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
    children.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function createTextFile(name, content, folderId) {
    folderId = folderId || 80473;
    var file = nlapiCreateFile(name + ".txt", "PLAINTEXT", content);
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function _renderPage(html, obj) {
    for (var o in obj) {
        var k = "{{" + o + "}}";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function _renderPage2(html, obj) {
    for (var o in obj) {
        var k = "#" + o + "#";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function _auditUsage() {
    _audit("getRemainingUsage USAGE", nlapiGetContext().getRemainingUsage());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        var spendTime = Math.round((new Date().getTime() - this.startTime) / 1e3) + "s";
        _audit("_audit - [Profiling]", spendTime);
        return spendTime;
    }
};

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(url ? url : location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function _mathround(a) {
    return Math.round(a * 100) / 100;
}

var IS_NS_SANDBOX = false;

var NS_DOMAIN = "system.na1.netsuite.com";

if (nlapiGetContext().getEnvironment() == "SANDBOX") {
    IS_NS_SANDBOX = true;
    NS_DOMAIN = "system.sandbox.netsuite.com";
}

var Subsidiaries = {
    ZakeUSAHolding: 2,
    Swagway: 4,
    TaiwuInternational: 3,
    ZakeInternational: 1
};

function logparams(request) {
    _log("request.getMethod()----", request.getMethod());
    _log("---logparams---", getparams(request));
}

function getparams(request) {
    var params = request.getAllParameters();
    var paramlist = [];
    for (var param in params) {
        paramlist.push({
            parameter: param,
            value: params[param]
        });
    }
    return paramlist;
}

function checkGovernance(usageLimit) {
    usageLimit = usageLimit || 500;
    if (nlapiGetContext().getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < usageLimit) {
        nlapiLogExecution("AUDIT", "checkGovernance---", nlapiGetContext().getRemainingUsage());
        var state = nlapiYieldScript();
        _audit("state.status", state.status + "--- Size: " + state.size);
        if (state.status == "FAILURE") {
            throw nlapiCreateError("YIELD_SCRIPT_ERROR", "Failed to yield script, exiting<br/>Reason = " + state.reason + "<br/>Size = " + state.size + "<br/>Information = " + state.information);
        } else if (state.status == "RESUME") {
            nlapiLogExecution("debug", "checkGovernance-------------", nlapiGetContext().getRemainingUsage());
            nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        }
    } else {
        nlapiGetContext().setPercentComplete((1e4 - nlapiGetContext().getRemainingUsage()) / 100);
    }
}

function rescheduled(params) {
    var context = nlapiGetContext();
    if (context.getExecutionContext() != "scheduled") {
        return false;
    }
    var remainingUsage = nlapiGetContext().getRemainingUsage();
    if (remainingUsage < 500) {
        _audit("remainingUsage", remainingUsage);
        var status = null;
        if (params) {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
        } else {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        }
        _audit("status", status);
        if (status == "QUEUED") {
            _audit("Reschedule for usage reset ...", remainingUsage);
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

var MarketplaceShipService = {
    ToBeDetermined: 6,
    Standard: 1,
    ThirdDaySelect: 2,
    SecondDayAir: 3,
    NextDay: 4,
    InternationalShippingFromUS: 5
};

var MarketplaceShipName = {
    AliExpress: 1,
    Amazon: 2,
    eBay: 3,
    Wish: 4,
    _3BBestbuy: 5,
    _3BNewegg: 6,
    Rakuten: 7,
    PCDirect: 8,
    _3Btech: 9,
    Swagway: 10,
    Hautebrush: 13
};

var MARKETPLACE_LIST = [ {
    marketplaceId: 13,
    ARAccount: "1151",
    formid: "151",
    name: "Hautebrush"
}, {
    marketplaceId: 10,
    ARAccount: "177",
    formid: "151",
    name: "Swagway"
}, {
    marketplaceId: 3,
    ARAccount: "1127",
    formid: "178",
    name: "EbayClaimthis"
}, {
    marketplaceId: 2,
    ARAccount: "176",
    formid: "263",
    name: "SavannahAmazon",
    store: "1"
}, {
    marketplaceId: 2,
    ARAccount: "174",
    formid: "199",
    name: "BetterChoiceAmazon",
    store: "8"
}, {
    marketplaceId: 5,
    ARAccount: "1177",
    formid: "220",
    name: "ThreeBTechBestBuy"
}, {
    marketplaceId: 7,
    ARAccount: "1129",
    formid: "220",
    name: "ThreeBTechRakuten"
}, {
    marketplaceId: 6,
    ARAccount: "1128",
    formid: "150",
    name: "NeweggZake"
}, {
    marketplaceId: 9,
    ARAccount: "1130",
    formid: "150",
    name: "ThreeBTechNet"
}, {
    marketplaceId: 8,
    ARAccount: "1131",
    formid: "150",
    name: "PCDirect"
} ];

var SALES_ORDER_FORM = {
    SWAGWAY: 151,
    EBAY: 178
};

function getUTCDateTime() {
    var now = new Date();
    var offset = now.getTimezoneOffset();
    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
    nlapiLogExecution("debug", "getUTCDateTime", utcDate);
    return utcDate;
}

var DateCompare = {
    convert: function(d) {
        return d.constructor === Date ? d : d.constructor === Array ? new Date(d[0], d[1], d[2]) : d.constructor === Number ? new Date(d) : d.constructor === String ? new Date(d) : typeof d === "object" ? new Date(d.year, d.month, d.date) : NaN;
    },
    compare: function(a, b) {
        return isFinite(a = this.convert(a).valueOf()) && isFinite(b = this.convert(b).valueOf()) ? (a > b) - (a < b) : NaN;
    },
    inRange: function(d, start, end) {
        return isFinite(d = this.convert(d).valueOf()) && isFinite(start = this.convert(start).valueOf()) && isFinite(end = this.convert(end).valueOf()) ? start <= d && d <= end : NaN;
    }
};

function beforeLoad(type, form, request) {
    try {
        swagwayInvoiceForm(type);
    } catch (e) {
        processException(e);
    }
}

function beforeSubmit(type) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    try {
        swagwayInvoiceForm(type);
    } catch (e) {
        processException(e, "id: " + id + " type: " + recType);
    }
}

function swagwayInvoiceForm(type) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    _log("swagwayInvoiceForm id: " + id + " recType: " + recType + " type: " + type);
    if (type == "create" && recType == "invoice") {
        var marketplace = nlapiGetFieldValue("custbody_marketplace");
        var accountid = MARKETPLACE_LIST.filter(function(m) {
            return m.marketplaceId == marketplace;
        });
        if (accountid.length) {
            if (accountid.length == 1) {
                accountid = accountid[0].ARAccount;
                nlapiSetFieldValue("account", accountid);
            } else {
                accountid = accountid.filter(function(item) {
                    return item.store == nlapiGetFieldValue("custbody_orderfrom");
                });
                if (accountid.length && accountid.length == 1) {
                    accountid = accountid[0].ARAccount;
                    nlapiSetFieldValue("account", accountid);
                }
            }
        }
    }
}