function start(request, response){
  var url = "https://system.na1.netsuite.com/app/common/shipping/pngclient.nl?kDoc=40364&printtype=uspsshippinglabel&whence=";
  var headers = {"User-Agent-x": "SuiteScript-Call",
               "Authorization": 'NLAuth nlauth_account=277620,nlauth_email=jake@zake.com,nlauth_signature=@Eldar4242,nlauth_role=3',
               "Content-Type": "application/json"};
  var res = nlapiRequestURL('http://www.google.com', null, headers);
  response.write(JSON.stringify(res.body));
}
