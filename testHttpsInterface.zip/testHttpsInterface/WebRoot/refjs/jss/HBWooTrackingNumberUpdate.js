function run() {
    for (var i = 0; i < CONFIG_LIST.length; i++) {
        CONNECTOR_CONFIG = CONFIG_LIST[i];

        var searchResult = nlapiSearchRecord('itemfulfillment', null, [
            new nlobjSearchFilter('mainline', null, 'is', 'T'),
            new nlobjSearchFilter('custbody_marketplace', null, 'is', CONNECTOR_CONFIG.marketplace),
            new nlobjSearchFilter('status', null, 'is', 'ItemShip:C'),
            new nlobjSearchFilter('custbody_tracking_number_sync', null, 'is', 'F'),
            new nlobjSearchFilter('custbody_storefront_order', null, 'isnotempty'),
            new nlobjSearchFilter('trandate', null, 'after', '5/31/2016')
        ], [
            new nlobjSearchColumn('custbody_storefront_order'),
            new nlobjSearchColumn('trackingnumbers')
        ]);
        updateWooTracking(searchResult);
        CONNECTOR_CONFIG = null;
    }
}


// : return order with Completed status == orders/bulk
// 没有合适的 bulk 一个一个sales order来吧
function updateWooTracking(searchResult) {

    //Type	is Item Fulfillment
    //Main Line	is true
    //Created From : Marketplace (Custom)	is Swagway
    //Status	is Item Fulfillment:Shipped
    //Tracking Number Sync (Custom)	is false

    //var searchResult = nlapiSearchRecord(null, 'customsearch380');


    if (searchResult != null) {
        var WooCommerce = new WooCommerceAPI();

        var len = searchResult.length;
        _log('updateWooTracking--- Size: ', len);

        for (var i = 0; i < len; i++) {

            try {

                var custbody_storefront_order = searchResult[i].getValue('custbody_storefront_order');
                if (custbody_storefront_order) {

                    _log('custbody_storefront_order', custbody_storefront_order);

                    // update notes
                    var NOTES_UPDATED = false;
                    var response = WooCommerce.post('orders/' + custbody_storefront_order + '/notes', {
                        "order_note": {
                            customer_note: true,
                            // You order has been shipped, your tracking number is XXXXXXXXXXXXXX
                            'note': 'You order has been shipped, your tracking number is ' + searchResult[i].getValue('trackingnumbers')
                            // "note": "tracking numbers is " + searchResult[i].getValue('trackingnumbers') + ' written from NetSuite.'
                        }
                    });
                    _log('response.getBody()', response.getBody());
                    response = JSON.parse(response.getBody());
                    if (response.hasOwnProperty('order_note')) {
                        if (response.order_note.hasOwnProperty('id')) {
                            NOTES_UPDATED = true;
                        }
                    }


                    // update sales order status
                    var STATUS_UPDATED = false;
                    var response = WooCommerce.post('orders/' + custbody_storefront_order, {
                        "order": {
                            "status": "completed"
                        }
                    });
                    response = JSON.parse(response.getBody());
                    if (response.hasOwnProperty('order')) {
                        if (response.order.hasOwnProperty('id')) {
                            STATUS_UPDATED = true;
                        }
                    }


                    if (NOTES_UPDATED && STATUS_UPDATED) {
                        // update the fulfillment
                        nlapiSubmitField('itemfulfillment', searchResult[i].getId(), 'custbody_tracking_number_sync', 'T', true);
                    }
                }


            } catch (e) {
                if (e instanceof nlobjError) {
                    if (e.getCode() == 'WOO_API_REQUEST_ERROR') {
                        throw e;
                    } else {
                        processException(e);
                    }
                } else {
                    processException(e);
                }

            }

            checkGovernance();

        }

    } else {
        _audit('not found search');
    }


}
