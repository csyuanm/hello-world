/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       05 Jun 2017     ratul
 *
 */

/**
 * @param {Object} dataIn Parameter object
 * @returns {Object} Output object
 */
function getFulFillment(params){
	
 var itemfulfillment = [];
 var recodrs = [];
 
 //
  
var search= nlapiLoadSearch('transaction','2596');
//search.addFilter(new nlobjSearchFilter('internalid',null,'is','1674573'));


if(params.timeDiff){
	
	   var fromdate = new Date();
	   fromdate.setTime(((fromdate.getTime())-params.timeDiff));// 
	   fromdate = nlapiDateToString(fromdate,'datetime');	 
	   nlapiLogExecution('Debug','fromdate',fromdate);
	   var current_date = new Date();
	   var current_sec = current_date.getTime();
	   current_date = nlapiDateToString(new Date(current_sec),'datetime');
	   nlapiLogExecution('Debug','current_date',current_date);
   
	   search.addFilter(new nlobjSearchFilter('lastmodifieddate', null, 'within', fromdate, current_date));
	}

var columns = search.getColumns();
var resultSet = search.runSearch();
if(!params.recordPosBegin){
 params.recordPosBegin=0;
}
if(!params.recordPosEnd){
 params.recordPosEnd=99;
}
var results = resultSet.getResults(params.recordPosBegin/4,params.recordPosEnd/4); 

if (results != null&&results.length>0) {
     nlapiLogExecution('DEBUG','results',results)
     nlapiLogExecution('DEBUG','results',results.length);

 for(var i=0;i<results.length;i++){
 
     var item_record=[];
  var id=results[i].getId();
//   nlapiLogExecution('DEBUG','id',id);
   var obj = nlapiLoadRecord('itemfulfillment',id);
  var createdfrom=obj.getFieldValue('createdfrom');
  
  var so_status=results[i].getValue(columns[7]);
  var tracking_no=results[i].getValue(columns[3]);
  var pckg_cnt=results[i].getValue(columns[8]);
  var ship_cost=results[i].getValue(columns[9]);
  var carrier=results[i].getValue(columns[10]);
  
  if(carrier == 'nonups')
	  carrier = "United States Postal Service"
  
  var ship_method=results[i].getText(columns[11]);
  var ship_date=results[i].getValue(columns[0]);
  
  var a=[];
  var b=[];
  a=ship_date.split('/')
  var date=a[1];
  var month=a[0];
  b=a[2].split(' ')
  var year=b[0];
  ship_date=date+'/'+month+'/'+year+' 00:00 am';
  nlapiLogExecution('DEBUG','ship_date',ship_date);

   var lines = obj.getLineItemCount('item');
   for (var j = 1; j <= lines; j++) {
          var itemid = obj.getLineItemValue('item', 'item', j);
          var quantity= obj.getLineItemValue('item', 'quantity', j);
       
       var element={
         "nsid":itemid,
         "quantity":quantity
       };
      item_record.push(element); 
   }
       var itemfulfillment_records={ 
         'itemfulfillment_nsid':id,
         'salesorder_nsid':createdfrom,
         'salesorderstatus':so_status,
         'fulfillmentdate':ship_date
       };
       var pkg={
          'trackingnumbers':"9400110200881240000078",
          'packagecount':pckg_cnt,
          'shippingcost':ship_cost,
          'weight':'',
          'shippingmethod':ship_method,
          'carriername':carrier
       };
        var data={
          'itemfulfillment_records':itemfulfillment_records,
          'items':item_record,
          'package':pkg
        };

      recodrs.push(data);

}

    } 
      var rawData = {
  "itemfulfillment": [
    {
      "itemfulfillment_records": {
        "itemfulfillment_nsid": "88519181",
        "salesorder_nsid": "25294654",
        "salesorderstatus": "fullyBilled",
        "fulfillmentdate": "12/06/2017 00:00 am"
      },
      "items": [
        {
          "nsid": "102381",
          "quantity": "1"
        },
         {
          "nsid": "102382",
          "quantity": "1"
        }
      ],
      "package": {
        "trackingnumbers": "9400110200881240000178",
        "packagecount": "1",
        "shippingcost": ".00",
        "weight": "",
        "shippingmethod": "USPS First-Class Mail®  (up to 14oz total weight)",
        "carriername": "United States Postal Service"
      }
    }
  ]
} ;
  //nlapiSubmitField('salesorder','25294654','custbody_tracked','F');
      if(nlapiLookupField('salesorder','25294654','custbody_tracked') == "T"){
  rawData = {'itemfulfillment': []};
}
      nlapiSubmitField('salesorder','25294654','custbody_tracked','T');
      return rawData;//{};
    }

