function updateOrderInfo(info) {

	try {
		nlapiLogExecution('debug', 'info', JSON.stringify(info));

		if (info == null || info.internalid == ''
				|| info.internationallogisticsId == '') {
			return 0;
		}

		var salesOrder = nlapiLoadRecord('salesorder', info.internalid);
      if(salesOrder == null){
        return 0 ;
      }

		var shipment = new Shipment(info.internalid);
		var ticketInfo = shipment.getShippingLabelDetails();
		if(ticketInfo!=null && ticketInfo.trackingno !=null && ticketInfo.trackingno !=''){
			return 2;
		}

		ticketInfo.tracking_number = info.internationallogisticsId;

		if (info.from !=null && info.from != '' ) {
			ticketInfo.from = info.from;
		}
		if (info.fromphone != null && info.fromphone != '') {
			ticketInfo.fromphone = info.fromphone;
		}

		salesOrder.setFieldValue('custbody_shippinglabel_info', JSON
				.stringify(ticketInfo));

		salesOrder.setFieldValue('custbody_sz_carrier_trackingnumber',
				info.internationallogisticsId);// 跟踪号
		salesOrder.setFieldValue('custbody_carrier_shipment_number',
				info.onlineLogisticsId);// 流水号

		salesOrder.setFieldValue('custbody_tw_fulfillment_status', 3);// 成功状态
		salesOrder.setFieldValue('custbody_shiping_changed', "F");

      try{
        var backId = nlapiSubmitRecord(salesOrder, true);
        nlapiLogExecution('DEBUG', 'upload trackingno successfully', 'ID =' + backId);
      }catch(e){
        nlapiLogExecution('ERROR', e.getCode(), e.getDetails());
      }


		return 2;

	} catch (e) { // 异常
		return 1;
	}

}