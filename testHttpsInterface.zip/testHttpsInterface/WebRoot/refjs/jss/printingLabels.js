function print1(type){

     var suiteletURL = 'https://debugger.na1.netsuite.com'+nlapiResolveURL('SUITELET', 'customscript_zake_print_suitelet', 'customdeploy1')+'&custparam_ifid='+nlapiGetRecordId();

    window.open(suiteletURL);

}




function beforeLoad_addButton (type, form, request){


      if (type == "view"){


          form.addButton('custpage_print1', 'Print Label', 'print1()');


          form.setScript('customscript_zake_print_button');



      }


}


function suitelet_print(request, response){


     var ifid = request.getParameter('custparam_ifid');
var record=nlapiLoadRecord('itemfulfillment',ifid);
var strName = "<table width=\"100%\">";
strName += "<tr><td>";
strName += "<h1>P</h1>";
strName += "</td>";
strName += "<td align=\"right\">";
strName += "<barcode codetype=\"maxicode\" showtext=\"true\" value=\"";
strName += record.getFieldValue('shipaddress');
strName += "\"/>";
strName += "</td></tr>";
strName += "<tr><td colspan=\"2\"><b>";
strName += record.getFieldText('shipmethod');

strName += "</b></td></tr>";
strName += "<tr><td colspan=\"2\">";
strName += "</td></tr>";
strName += "<tr><td colspan=\"2\">";
strName += "<barcode codetype=\"code128\" showtext=\"true\" value=\"";
strName += record.getLineItemValue('packageusps','packagetrackingnumberusps' ,1);
strName += "\"/>";
strName += "</td></tr>";
strName += "<tr><td colspan=\"2\">";
strName += "</td></tr>";
strName += "</table>";

// build up BFO-compliant XML using well-formed HTML
var xml = "<?xml version=\"1.0\"?>\n<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">\n";
xml += "<pdf><head><style>table, th, td { border: 1px solid black; border-collapse: collapse;} </style></head> \n<body font-size=\"12\" width=\"105mm\" height=\"148mm\">\n";
xml += "<p></p>";
xml += strName;
xml += "</body>\n</pdf>";

// run the BFO library to convert the xml document to a PDF
var file = nlapiXMLToPDF( xml );

// set content type, file name, and content-disposition (inline means display in browser)
response.setContentType('PDF','Pricing List.pdf', 'inline');

// write response to the client
response.write( file.getValue() );









}
