
	/**
	 * Module Description
	 * 
	 * Version    Date            Author           Remarks
	 * 1.00       14 Sep 2015     Govind
	 *
	 */

	/**
	 * @param {var
	 *            string} type Context Types: scheduled, ondemand, userinterface,
	 *            aborted, skipped
	 * @returns {Void}
	 */

	function generate_rma(type) {
		
		var Base64 = {
			_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
			encode : function(e) {
				var t = "";
				var n, r, i, s, o, u, a;
				var f = 0;
				e = Base64._utf8_encode(e);
				while (f < e.length) {
					n = e.charCodeAt(f++);
					r = e.charCodeAt(f++);
					i = e.charCodeAt(f++);
					s = n >> 2;
					o = (n & 3) << 4 | r >> 4;
					u = (r & 15) << 2 | i >> 6;
					a = i & 63;
					if (isNaN(r)) {
						u = a = 64
					} else if (isNaN(i)) {
						a = 64
					}
					t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o)
							+ this._keyStr.charAt(u) + this._keyStr.charAt(a)
				}
				return t
			},
			decode : function(e) {
				var t = "";
				var n, r, i;
				var s, o, u, a;
				var f = 0;
				e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
				while (f < e.length) {
					s = this._keyStr.indexOf(e.charAt(f++));
					o = this._keyStr.indexOf(e.charAt(f++));
					u = this._keyStr.indexOf(e.charAt(f++));
					a = this._keyStr.indexOf(e.charAt(f++));
					n = s << 2 | o >> 4;
					r = (o & 15) << 4 | u >> 2;
					i = (u & 3) << 6 | a;
					t = t + String.fromCharCode(n);
					if (u != 64) {
						t = t + String.fromCharCode(r)
					}
					if (a != 64) {
						t = t + String.fromCharCode(i)
					}
				}
				t = Base64._utf8_decode(t);
				return t
			},
			_utf8_encode : function(e) {
				e = e.replace(/\r\n/g, "\n");
				var t = "";
				for ( var n = 0; n < e.length; n++) {
					var r = e.charCodeAt(n);
					if (r < 128) {
						t += String.fromCharCode(r)
					} else if (r > 127 && r < 2048) {
						t += String.fromCharCode(r >> 6 | 192);
						t += String.fromCharCode(r & 63 | 128)
					} else {
						t += String.fromCharCode(r >> 12 | 224);
						t += String.fromCharCode(r >> 6 & 63 | 128);
						t += String.fromCharCode(r & 63 | 128)
					}
				}
				return t
			},
			_utf8_decode : function(e) {
				var t = "";
				var n = 0;
				var r = c1 = c2 = 0;
				while (n < e.length) {
					r = e.charCodeAt(n);
					if (r < 128) {
						t += String.fromCharCode(r);
						n++
					} else if (r > 191 && r < 224) {
						c2 = e.charCodeAt(n + 1);
						t += String.fromCharCode((r & 31) << 6 | c2 & 63);
						n += 2
					} else {
						c2 = e.charCodeAt(n + 1);
						c3 = e.charCodeAt(n + 2);
						t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6
								| c3 & 63);
						n += 3
					}
				}
				return t
			}
		};
		var mymail='govind@webbee.biz';
		var mail_cc='aj@webbeeglobal.com';
		var obj = nlapiGetContext();
		var internalid = obj.getSetting('SCRIPT', 'custscript_account_id');
	var count=0;
	var columns = [];
		columns.push(new nlobjSearchColumn('custrecord_amazon_seller_id'));
		columns.push(new nlobjSearchColumn('custrecord_aws_access_key_id'));
		columns.push(new nlobjSearchColumn('custrecord_secret_key'));
		columns.push(new nlobjSearchColumn('custrecord_amazon_enabled_sites'));
		columns.push(new nlobjSearchColumn('custrecord_fba_invoice_form'));
		columns.push(new nlobjSearchColumn('custrecord_mfn_salesorder_form'));
		columns.push(new nlobjSearchColumn('internalid'));
		columns.push(new nlobjSearchColumn('name'));
		columns.push(new nlobjSearchColumn('custrecord_fbm_warehouse'));
		columns.push(new nlobjSearchColumn('custrecord_amz_fba_warehouse'));
		columns.push(new nlobjSearchColumn('custrecord_accnt_time'));
		columns.push(new nlobjSearchColumn('custrecord_rmatime'));

		var filters  = [];
		filters.push(new nlobjSearchFilter('custrecord_amazon_seller_id', null,
				'isnotempty'));
		filters.push(new nlobjSearchFilter('internalid',null,'is',internalid));
		var search_result = nlapiSearchRecord('customrecord_amazon_accounts', null,
				filters, columns);
		var token=0;
		var tokencount=0;
		for ( var i = 0; (i < search_result.length)||(token!=0); i++) {
			try{
				if(token!=0){i=i-token;}
				var fromTime=search_result[i].getValue('custrecord_rmatime')
			var accnt_time=search_result[i].getValue('custrecord_accnt_time');		
			var sellerId = search_result[i].getValue('custrecord_amazon_seller_id');
			var actname = search_result[i].getValue('name');
			var awsKey = search_result[i].getValue('custrecord_aws_access_key_id');
			var securityKey = search_result[i].getValue('custrecord_secret_key');
			var site = search_result[i].getText('custrecord_amazon_enabled_sites');
			var cust_form_mfn = search_result[i]
					.getValue('custrecord_mfn_salesorder_form');
			var cust_form_afn = search_result[i]
					.getValue('custrecord_fba_invoice_form');
			var mfn_warehouse = search_result[i]
					.getValue('custrecord_fbm_warehouse');
			var afn_warehouse = search_result[i]
					.getValue('custrecord_amz_fba_warehouse');
			var columns = [];
			columns.push(new nlobjSearchColumn('custrecord_amazon_marketplace_id'));
			var filters = [];
			filters.push(new nlobjSearchFilter('name', null, 'is', site));
			var search_result2 = nlapiSearchRecord(
					'customrecord_amazon_global_sites', null, filters, columns);
			var marketId = search_result2[0]
					.getValue('custrecord_amazon_marketplace_id');

			nlapiLogExecution('DEBUG', 'Account: ', actname);


			var timestamp = new Date();
			timestamp = timestamp.toISOString();
			timestamp = encodeURIComponent(timestamp);
			nlapiLogExecution('DEBUG','currenttime', timestamp);
		if(fromTime==''){
			var fromTime = new Date();
	        fromTime.setMilliseconds((fromTime.getMilliseconds()-86400000));
			fromTime = fromTime.toISOString();
			fromTime = encodeURIComponent(fromTime);
			}
		
			nlapiLogExecution('DEBUG','fromTime',fromTime);

			if(token==0)
			{var queryString = request_string(awsKey,fromTime,marketId,sellerId,timestamp);}
			else{var queryString=request_string_lasttoken(awsKey,sellerId,timestamp,nexttoken);token=0;tokencount++}
//			Execution('DEBUG','querystring',queryString);
			var orderstring = "POST\nmws.amazonservices.com\n/Orders/2013-09-01\n"
					+ queryString;
			var hash = CryptoJS.HmacSHA256(orderstring, securityKey);
			var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
			hashInBase64 = encodeURIComponent(hashInBase64); 		 	 	 	
			CheckGovernance();
			
			var orderresponse = nlapiRequestURL(
					'https://mws.amazonservices.com/Orders/2013-09-01?'
							+ queryString + "&Signature=" + hashInBase64,
					queryString + "&Signature=" + hashInBase64, null);
			nlapiLogExecution('DEBUG', 'orderresponse', orderresponse.getBody());
			var orderxml = nlapiStringToXML(orderresponse.getBody());
			if (orderresponse.getBody() != '') {
				var tot_ord = orderxml.getElementsByTagName('Order');
				nlapiLogExecution('DEBUG', 'orders', tot_ord.length);
				for ( var k = 0; k <tot_ord.length; k++) {
					var amazonOrderId = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName(
							'AmazonOrderId').item(0);
					if (!amazonOrderId) {
						amazonOrderId = '';
					} else
						amazonOrderId = amazonOrderId.textContent;
					if (amazonOrderId !='') {
						nlapiLogExecution('DEBUG','amazonOrderId '+(k+1),amazonOrderId);

						var fulfillmentChannel = orderxml.item(0)
						.getElementsByTagName('FulfillmentChannel').item(0);
				if (!fulfillmentChannel) {
					fulfillmentChannel = '';
				} else
					fulfillmentChannel = fulfillmentChannel.textContent;

				var sellerOrderId = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName(
						'SellerOrderId').item(0);
				if (!sellerOrderId) {
					sellerOrderId = '';
				} else
					sellerOrderId = sellerOrderId.textContent;
//				nlapiLogExecution('DEBUG','sku type', fulfillmentChannel);

				if (fulfillmentChannel =='AFN') {
					fulfillmentChannel=1;
//					nlapiLogExecution('DEBUG','sku type', fulfillmentChannel);
					var warehouse = afn_warehouse;
					var cust_form = cust_form_afn;
					var record = 'invoice'; 
				} else  {
					fulfillmentChannel=2;
					nlapiLogExecution('DEBUG','sku type', fulfillmentChannel);

					var warehouse = mfn_warehouse;
					var cust_form = cust_form_mfn;
					var record = 'salesorder'
				}
				var chck_ord=searchRecord(record,amazonOrderId);
				nlapiLogExecution('DEBUG','chck_ord',chck_ord);

				if(chck_ord!=1){ 
					nlapiLogExecution('DEBUG','SO is present');
					
							// ***********Create RMA*************//
				
				try{	
					nlapiLogExecution('DEBUG','customer_id :',chck_ord[1]);
					nlapiLogExecution('DEBUG','salesorder_id :',chck_ord[0]);

					var customer_id = chck_ord[1];
					var salesorder=nlapiLoadRecord('salesorder',chck_ord[0]);							
								var obj = nlapiCreateRecord('returnauthorization', {
									recordmode : 'dynamic'
								});
								obj.setFieldValue('customform',124);
						    	obj.setFieldValue('createdfrom',chck_ord[0]);
								obj.setFieldValue('entity', customer_id);
								obj.setFieldValue('otherrefnum', amazonOrderId);
								var warehouse=salesorder.getFieldValue('location');
								obj.setFieldValue('location', warehouse);
								var totaltax=salesorder.getFieldValue('custbody__amazonordertax');
								obj.setFieldValue('custbody__amazonordertax',totaltax);
								var shipping_cost=salesorder.getFieldValue('shippingcost');
								obj.setFieldValue('shippingcost', shipping_cost); 
								obj.setFieldValue('custbody_marketplace', 2);
								obj.setFieldValue('memo','customer wants to return it ');
								var tot_ord_itm =salesorder.getLineItemCount('item');
								var item_found=0;
								var totaltax=0;
								for ( var j = 1; j <= tot_ord_itm; j++) {
									var itemid=salesorder.getLineItemValue('item', 'item',j);
									var itemPrice=salesorder.getLineItemValue('item', 'rate',j);
									var quantityOrdered=salesorder.getLineItemValue('item', 'quantity',j);
									var orderItemId=salesorder.getLineItemValue('item', 'custcol_amazon_itemid',j);
									var taxcode=salesorder.getLineItemValue('item', 'taxcode',j);
									obj.selectNewLineItem('item');
									obj.setCurrentLineItemValue('item', 'item', itemid);
									obj.setCurrentLineItemValue('item', 'rate',itemPrice);
									if(taxcode)
									{obj.setCurrentLineItemValue('item','taxcode',taxcode);}
									obj.setCurrentLineItemValue('item', 'quantity',quantityOrdered);
									obj.setCurrentLineItemValue('item', 'custcol_amazon_itemid',orderItemId);
									obj.commitLineItem('item');
								}
								obj.setFieldValue('custbody__amazonordertax',totaltax);
								obj.setFieldValue('shippingcost', shipping_cost);
								obj.setFieldValue('location', warehouse);
								salesorder.setFieldValue('status','SalesOrd:C')
								var recId = nlapiSubmitRecord(obj);
								nlapiLogExecution('DEBUG', 'recId', recId);
								}

							
					
			catch (error) {nlapiSendEmail(1659,mymail, 'Err: for '+amazonOrderId+' | '+actname,error);}

						}
				else{
					nlapiSendEmail(1659,mymail, 'SalesOrder not present for '+amazonOrderId+' | '+actname,'SalesOrder not present for '+amazonOrderId);

					}
				}						
				}
				}
			try{
				var check_nexttoken = orderxml.getElementsByTagName('NextToken');
	if(check_nexttoken.length>0){
		token++;
		var nexttoken=orderxml.item(0).getElementsByTagName('NextToken').item(0).textContent;
		nexttoken=encodeURIComponent(nexttoken);
	nlapiLogExecution('DEBUG','nexttoken',nexttoken);nlapiLogExecution('DEBUG','nexttokens',check_nexttoken.length);
	}
			}
			catch (er) {
				nlapiSendEmail(1659,mymail, 'Err: in next token ',er);
				}
			CheckGovernance();
			var record = nlapiLoadRecord('customrecord_amazon_accounts',internalid);
			record.setFieldValue('custrecord_lastupdatetime',timestamp);
			var submit = nlapiSubmitRecord(record, true);
		}
		
			catch(err){
			 	nlapiSendEmail(1659,mymail, 'Err: RMA  of order id '+amazonOrderId+' | '+actname,err);
			 }
			
		}}
	

	// *************************************function to get item
	// nsid********************************//
	function getnsid(seller_sku, site, acctname,skutype) {

		var column = [];
		column.push(new nlobjSearchColumn('custrecord_sites'));
		column.push(new nlobjSearchColumn('custrecord_account_name'));
		column.push(new nlobjSearchColumn('custrecord_custitem'));

		var filter = [];
		filter.push(new nlobjSearchFilter('custrecord_sites', null, 'is', site));
		filter.push(new nlobjSearchFilter('custrecord_account_name', null, 'is',acctname));
		filter.push(new nlobjSearchFilter('custrecord_skutype',null,'is',skutype))
		filter.push(new nlobjSearchFilter('custrecord_sku', null, 'is', seller_sku));
		var search_result1 = nlapiSearchRecord('customrecord_amazon_listings',
				null, filter, column);
		if (search_result1 != null) {
			var item_id = search_result1[0].getValue('custrecord_custitem');
			return item_id;
		} else {
			
			return 0;
		}

	}
	

	function searchRecord(record_type,value){
		 
		var filters=[]; 
		 filters.push(new nlobjSearchFilter('mainline',null,'is',true));
		 filters.push(new nlobjSearchFilter('status',null,'anyof',['SalesOrd:G','SalesOrd:E']));
		 filters.push(new nlobjSearchFilter('otherrefnum',null,'equalto',value));
		 var column=[];
		 column.push(new nlobjSearchColumn('otherrefnum'));
		 column.push(new nlobjSearchColumn('entity'));	 
		 column.push(new nlobjSearchColumn('status'));

		 var searchResults = nlapiSearchRecord(record_type, null, filters, column);
		 if(searchResults != null && searchResults.length>=1){
			 var recid=searchResults[0].getId();
			 var rec_po_no=searchResults[0].getValue('otherrefnum');
			 var cust_id=searchResults[0].getValue('entity');
			 var so_status=searchResults[0].getValue('status');
			 if(so_status=='Billed'){
             var so_details=[recid,cust_id];
			 nlapiLogExecution('DEBUG','so_details',so_details);
			 return so_details;		
		}
			 else{
				 var obj=nlapiLoadRecord('salesorder', recid);
					obj.setFieldValue('status','SalesOrd:C');
					nlapiSubmitRecord(obj); 
					return 1;
			 }}
		 else{
			 return 1;
		 }

	}
	function request_string(awsKey,fromTime,marketId,sellerId,timestamp){
		var queryString = "AWSAccessKeyId=" + awsKey + "&Action=ListOrders"
		+ "&LastUpdatedAfter=" + fromTime + "&MarketplaceId.Id.1="
		+ marketId + "&OrderStatus.Status.1=Canceled"
		+ "&SellerId=" + sellerId
		+ "&SignatureMethod=HmacSHA256" + "&SignatureVersion=2"
		+ "&Timestamp=" + timestamp + "&Version=2013-09-01";
		return queryString;
		nlapiLogExecution('DEBUG', 'qs1', queryString);
	}
	function request_string_lasttoken(awsKey,sellerId,timestamp,nexttoken){
		var querystring='AWSAccessKeyId='+awsKey
			+'&Action=ListOrdersByNextToken'
			+'&NextToken='+nexttoken
			+'&SellerId='+sellerId
			+'&SignatureMethod=HmacSHA256'
			+'&SignatureVersion=2'
			+'&Timestamp='+timestamp
			+'&Version=2013-09-01';
		return querystring;
		nlapiLogExecution('DEBUG', 'qs1', queryString);

	}
	function CheckGovernance() {
	    try {
	        var currentContext = nlapiGetContext();

	        if (currentContext.getRemainingUsage() < 100) {
	            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
	            var state = nlapiYieldScript();

	            if (state.status == 'FAILURE') {
	                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
	            }
	            else if (state.status == 'RESUME') {
	                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
	            }
	        }
	    }
	    catch (ex) {
	    	
	        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
		 	nlapiSendEmail(1659,mymail, 'Err: in CheckGovernance() ',ex);

	    }
	}


