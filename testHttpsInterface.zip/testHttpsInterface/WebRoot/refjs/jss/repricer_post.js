/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       27 Jan 2016     Rohit
 *
 */

/**
 * @param {Object}
 *            dataIn Parameter object
 * @returns {Object} Output object
 */
function set_values(params) {
	var time = new Date();
	time = new Date();
	time.setMilliseconds(time.getMilliseconds() + 10800000);
	time = nlapiDateToString(time, 'datetimetz');
	if (params.RepricerInfo) {
		var listings = (params.RepricerInfo);
		nlapiLogExecution('DEBUG', 'a', listings);
		nlapiLogExecution('DEBUG', 'length', listings.length);

	}
	for (var i = 0; i < listings.length; i++) {
		try {
			var listing_id = listings[i].listing_id;
			var buybox_withus = listings[i].buybox_withus;
			var lower_price1 = parseFloat(listings[i].lower_price1);
			var lower_price2 = parseFloat(listings[i].lower_price2);
			var lower_price3 = parseFloat(listings[i].lower_price3);
			var lower_price4 = parseFloat(listings[i].lower_price4);
			var sale_price = parseFloat(listings[i].current_price);
			var current_price=parseFloat(listings[i].current_price);
			var shipping_price=parseFloat(listings[i].shipping);

			

			nlapiLogExecution('DEBUG', 'listing_id', listing_id);
			nlapiLogExecution('DEBUG', 'current_price', current_price);
			nlapiLogExecution('DEBUG', 'shipping_price', shipping_price);



		
			nlapiLogExecution('DEBUG', 'listing_id', listing_id);
			var obj = nlapiLoadRecord('customrecord_amazon_listings',
					listing_id);

			var required_position = obj
					.getFieldValue('custrecord_amazonposition');
			var floor_price = obj.getFieldValue('custrecordamzn_floorprice');
			nlapiLogExecution('DEBUG', 'sale_price', sale_price);

			nlapiLogExecution('DEBUG', 'required_position', required_position);

			// .................................1
             if (obj.getFieldValue('custrecord_is_price_overwrite') == 'T') 
               {
					obj.setFieldValue('custrecord_amazonprice', obj
							.getFieldValue('custrecord_price_overwrite'));
				}

			else 
				{
				if(sale_price>0&&(obj
					.getFieldValue('custrecord_active_repricer')=='T')) {
				/*
				 * 2. If �Required Amazon position� field is filled with the
				 * user choice �Button�, sales price will be >= �Floor price�,
				 * and Price decrease until we have the button (buy box), time
				 * stamp when is the last time we get the button (buy box)
				 * _internal. // If sales price = Floor price, email to
				 * leo@zake.com, reminder@zakeusa.com, brett@3btch.net
				 * 
				 * If Sales price drops more than 3 times within 1 day,email to
				 * leo@zake.com, reminder@zakeusa.com, brett@3btch.net
				 * 
				 * If we do not have the button (buy box), and we are not No.1,
				 * drop sales price to = Current No.1 - $0.01 and >= Floor
				 * price. If we do not have the button (buy box), and we are
				 * currently No.1, drop sales price to = Current sales price *
				 * 99% and >= Floor price. // If we have the button (buy box),
				 * check �Interval record�_internal (No. 2 price - Sales price )
				 * If Blank, and No. 2 price - Sales price >=$0.01 for more than
				 * 24 hours, record data in �Interval record�_internal and then
				 * raise sales price to = Current Sales price + 10%*( No. 2
				 * price - Sales price) and (10%*( No. 2 price - Sales price) >
				 * =$0.01), otherwise, stay put. If Not blank, No. 2 price -
				 * Sales price <> Interval record, then raise sales price to =
				 * Current Sales price + 10%*( No. 2 price - Sales price) and
				 * (10%*( No. 2 price - Sales price) > =$0.01). overwrite the
				 * �Interval record�_internal.
				 */
				// ReqPos :Button
				if (required_position == 1) {

					if (buybox_withus == 'yes') {
						var value = 'T';
						obj.setFieldValue('custrecord_time_buybox', time);
					} else {
						if (sale_price == lower_price1
								&& (sale_price * 0.99) > floor_price) {
							sale_price = sale_price * 0.99;
						} else if (sale_price != lower_price1) {
							sale_price = lower_price1 - 0.01;
						}

					}
					if (sale_price == floor_price) {
						// email
					}

				}
				// ReqPos:1
				// red Amazon position� field is filled with the user choice
				// �No. 1�,
				// a. If Current No.1 is not us, Current No.1 - Floor price =<
				// $0.01, send an e-mail alert
				// b. If Current No.1 is not us, Current No.1 - Floor price >=
				// $0.01, then price = Current No.1 price - $0.01;
				// c. if we are current No.1 and No.2 price � our price > $0.01,
				// change our price = curren
				else if (required_position == 2) {
					if (sale_price == lower_price1 && lower_price1 != 0) {
						if (lower_price2 - sale_price > 0.01
								&& (lower_price2 != 0)) {
							sale_price = lower_price2 - 0.01;
						}
					} else {
						if (lower_price1 - floor_price <= 0.01) {
							// mail
						} else {
							sale_price = lower_price1 - 0.01;
						}
					}
					nlapiLogExecution('DEBUG', 'changed sale_price', sale_price);

				}
				// 4. If �Required Amazon position� field is filled with the
				// user choice �No. 2�,
				// a. If Current No.1 & No.2 are not us, Current No.2 - Floor
				// price =< $0.01, send an e-mail alter.
				// b. If Current No.1 is not us, Current No.1 - Floor price >=
				// $0.01, then price = Current No.1 price - $0.01;
				// c. If Current No.1 is not us, Current No.1 - Floor price =<
				// $0.01, then
				// i. If current No.2 is us, and No.3 � our price > $0.01, our
				// price = No.3 price - $0.01.
				// ii. If current No. 2 is not us, and No.2 price � Floor price
				// > $0.01, price = Current No.2 price - $0.01;
				// ReqPos:2
				else if (required_position == 3) {
					if (sale_price != lower_price1
							&& sale_price != lower_price2) {
						if (lower_price2 - floor_price <= 0.01) {
							// mail
						} else {
							sale_price = lower_price2 - 0.01;
						}
					} else if (sale_price == lower_price2) {
						if (lower_price1 - floor_price > 0.01) {
							sale_price = lower_price3 - 0.01;
						} else {
							if (lower_price3 - sale_price > 0.01) {
								sale_price = lower_price3 - 0.01
							}
						}

					} else {
						if (lower_price1 - floor_price >= 0.01) {
							sale_price = lower_price1 - 0.01;
						}
					}

				}
				// 5. If �Required Amazon position� field is filled with the
				// user choice �No. 3�,
				// a. If Current No.1, No.2 & No.3 are not us, Current No.3 -
				// Floor price =< $0.01, send an e-mail alter.
				// b. If Current No.1 is not us, Current No.1 - Floor price >=
				// $0.01, then price = Current No.1 price - $0.01;
				// c. If Current No.1 is not us, Current No.1 - Floor price =<
				// $0.01, then
				// i. If there are only two merchants, send an e-mail alert.
				// ii. If current No.2 is us, and No.3 � our price > $0.01, our
				// price = No.3 price - $0.01.
				// iii.If current No. 2 is not us, and
				// 1. If No.2 price � Floor price > $0.01, price = Current No.2
				// price - $0.01;
				// 2. If No.2 price � Floor price =< $0.01,
				// a. If there are only three merchants, send an e-mail alert
				// b. If current No.3 is us, and current No.4 � our price >
				// $0.01, our price = No.4 price - $0.01.
				// c. If current No.3 is not us,
				// i. If No.3 price � Floor price > $0.01, price = Current No.3
				// price - $0.01;
				// ReqPos:3
				else if (required_position == 4) {
					nlapiLogExecution('DEBUG', 'required_position', required_position);

					if (sale_price != lower_price1
							&& sale_price != lower_price2
							&& sale_price != lower_price3) {
						if (lower_price3 - floor_price <= 0.01) {
							// ///////email
						} else {
							sale_price = lower_price3 - 0.01;
						}
					} else if (sale_price == lower_price2) {
						if (lower_price1 != 0 && lower_price2 != 0
								&& lower_price3 == 0 && lower_price4 == 0) {
							// mail:only two merchant
						}

						else {
							if (lower_price1 - floor_price >= 0.01) {
								sale_price = lower_price1 - 0.01;
							} else if ((lower_price3 - sale_price > 0.01)
										&& (lower_price3 != 0)){
								
							}
						}
					}

					else if (sale_price == lower_price3) {
						if (lower_price1 != 0 && lower_price2 != 0
								&& lower_price3 != 0 && lower_price4 == 0) {
							// maia:onle three mercant
						}

						else {
							if (lower_price2 - floor_price > 0.01) {
								sale_price = lower_price2 - 0.01;
							} else {
								if (lower_price4 - sale_price > 0.01) {
									sale_price = lower_price4 - 0.01;
								}
							}
						}

					}

				}
				// 6. If �Required Amazon position� field is filled with the
				// user choice �Others�,
				// If weekly sale qty >= 150% of Estimated weekly sales qty,
				// email to leo@zake.com, reminder@zakeusa.com, brett@3btch.net
				// if weekly sale qty =< 50% of Estimated weekly sales qty,
				// sales price = current price x 90% and sales price >= Floor
				// price.
				// If sales price = current price x 90% and sales price =< Floor
				// price, sales price = floor price, and email to
				// leo@zake.com,reminder@zakeusa.com, brett@3btch.net

				// ReqPos:others
				else if (required_position == 5) {

				}

			}
//				else if(sale_price>0&&(obj
//						.getFieldValue('custrecord_active_repricer')=='F'))
		}
			if (buybox_withus == 'yes') { 
				var value = 'T';
				obj.setFieldValue('custrecord_time_buybox', time);
			} 
			else {
				var value = 'F';
			}
			sale_price=sale_price.toFixed(2);
			if(sale_price<floor_price){
				sale_price=floor_price;
			}
			
			if(sale_price==lower_price1||(lower_price1==0)){
				obj.setFieldValue('custrecord_current_position', 2);
			}
			else if(sale_price==lower_price2){
				obj.setFieldValue('custrecord_current_position', 3);
			}
			else if(sale_price==lower_price3){
				obj.setFieldValue('custrecord_current_position', 4);
			}
			else{
				obj.setFieldValue('custrecord_current_position', 5);

			}
			if(sale_price=='NaN'||sale_price==0){
				sale_price=current_price;
			}
			obj.setFieldValue('custrecord_shippingprice',shipping_price);
			obj.setFieldValue('custrecord_amazonprice',sale_price);
			obj.setFieldValue('custrecord_check_buybox', value);
			obj.setFieldValue('custrecord_price1', lower_price1);
			obj.setFieldValue('custrecord_price2', lower_price2);
			obj.setFieldValue('custrecord_price3', lower_price3);
			var success = nlapiSubmitRecord(obj);

		} catch (e) {
			nlapiLogExecution('DEBUG', 'ERR', e);
//			nlapiSendEmail(1659, 'govind@webbee.biz',
//					'Err: Repricer | listing id ' + listing_id, e);

		}

	}
	return "success";

}
