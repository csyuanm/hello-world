/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       27 Apr 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function mail(type){
	
	try{
	
		if(type == "create"){
			
			var po = nlapiGetFieldValue('tranid');
			
			var exShippedDate = nlapiGetFieldValue('custbody_expected_ship_date');
			if(exShippedDate){
				var isShipped = nlapiGetFieldValue('custbody_is_shipped');
				var mailto = ['johnny@zake.com','mikej@zake.com','enddyzeng@zakeusa.com'];
				
				var today = nlapiDateToString(new Date(),'date');
				nlapiLogExecution('Debug','today time',today);
				var date = today.split(' ');
				date = date[0];
				
				if(date == exShippedDate && isShipped == 'F'){
					
					nlapiSendEmail(1659, mailto,'Unshipped '+po+' Notification',po,null,'ratul@webbee.biz');
					nlapiLogExecution('Debug','<<<>>>','email done');
				}
				
				nlapiLogExecution('Debug','exShippedDate',exShippedDate);
				nlapiLogExecution('Debug','po',po);
				nlapiLogExecution('Debug','isShipped',isShipped);
				nlapiLogExecution('Debug','today',date);
			}
			
		}
	}catch(e){
		nlapiLogExecution('Debug','error in script',e);
	}
  
}
