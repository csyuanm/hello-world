function getMPL(obj){
  var batchRecord = nlapiLoadRecord("customrecord_mpl_record", obj);
  var data = batchRecord.getFieldValue("custrecord_mpl_data");
  nlapiLogExecution('DEBUG', 'getMPL', JSON.stringify(obj));
  return JSON.parse(data);
}
