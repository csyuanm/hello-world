// 深圳抓单脚本 for Restlet

//var NS_CONTEXT = nlapiGetContext();
//var DEPLOYMENT_ID = nlapiGetContext().getDeploymentId();
//_audit('DEPLOYMENT_ID', DEPLOYMENT_ID);

var RUNNING_ACCOUNT = {};

function run(datain) {

    // var P = new Profiling();

    _audit('Ebay get order on datain', JSON.stringify(datain, null, 2));

    var info = datain.__info;
    RUNNING_ACCOUNT.EBAY_ACCOUNT_ID = info.EBAY_ACCOUNT_ID;
    var PageNumber = info.pageNumber;
    var timefrom = info.timefrom;
    var timeto = info.timeto;

    var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [
        new nlobjSearchFilter('internalid', null, 'is', info.EBAY_ACCOUNT_ID)
    ], [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_ebay_api_token'),
        new nlobjSearchColumn('custrecord_ebay_global_site_access'),
        new nlobjSearchColumn('custrecord_ea_subsidiary'),
        new nlobjSearchColumn('custrecord_ebay_shortname'),
        new nlobjSearchColumn('custrecord_ebay_account_storefront')
    ]);

    _log('ebayAccountSearch.length', ebayAccountSearch.length);

    RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN = ebayAccountSearch[0].getValue('custrecord_ebay_api_token');
    RUNNING_ACCOUNT.SUBSIDIARY = ebayAccountSearch[0].getValue('custrecord_ea_subsidiary');
    RUNNING_ACCOUNT.STOREFRONT = ebayAccountSearch[0].getValue('custrecord_ebay_account_storefront');

    RUNNING_ACCOUNT.custrecord_ebay_shortname = ebayAccountSearch[0].getValue('custrecord_ebay_shortname');

    var ebay_account = ebayAccountSearch[0];
    var ebayAccountName = ebay_account.getValue('name');
    var custrecord_ebay_shortname = ebay_account.getValue('custrecord_ebay_shortname');

    var GetOrdersResponse = datain.__response;
    refactoryOrdersResponse(GetOrdersResponse.GetOrdersResponse);

    GetOrdersResponse = GetOrdersResponse.GetOrdersResponse;

    var exeReport = [];
    exeReport.push('PageNumber: ' + PageNumber);
    exeReport.push('ReturnedOrderCountActual: ' + GetOrdersResponse.ReturnedOrderCountActual);

    if (GetOrdersResponse.Ack == 'Success' || GetOrdersResponse.Ack == 'Warning') {

        if (GetOrdersResponse.Ack == 'Warning') {

            var Errors = datain.__response.GetOrdersResponse.Errors;
            if (Errors.ErrorCode == '21917182') {
                // 忽略这个
            } else if (Array.isArray(Errors)) {
                var yes = Errors.every(function (Error) {
                    return Error.ErrorCode == '21917182';
                });

                if (yes) {

                } else {
                    _log_email('Ebay get order 有点问题2', JSON.stringify(datain))
                }
            } else {
                _log_email('Ebay get order 有点问题', JSON.stringify(datain))
            }
        }

        if (GetOrdersResponse.ReturnedOrderCountActual != '0') {
            var OrderArray = GetOrdersResponse.OrderArray;
            if (OrderArray) {
                var Order = GetOrdersResponse.OrderArray.Order;

                for (var i = 0; i < Order.length; i++) {

                    var _Order = Order[i];
                    _log('SRN: -------------------------', _Order.ShippingDetails.SellingManagerSalesRecordNumber);

                    try {

                        var OrderResult = createEbaySalesOrder(_Order, ebay_account, info);
                        exeReport.push(ebayAccountName + ' -- OrderID: ' + _Order.OrderID + ' / SRN: ' + _Order.ShippingDetails.SellingManagerSalesRecordNumber + ' ---> OrderID: ' + OrderResult.id + ' --- ' + JSON.stringify(OrderResult));

                    } catch (e) {
                        e = parseException(e);
                        _log_email(ebayAccountName + ' / ' + e.code + ' - RANGE: ' + timefrom + '-' + timeto, e.message + '<br/><br/>' + JSON.stringify(_Order));
                        exeReport.push('ERROR! ' + ebayAccountName + ' -- OrderID: ' + _Order.OrderID + ' / SRN: ' + _Order.ShippingDetails.SellingManagerSalesRecordNumber + ' ---> ' + e.userMessage);
                        createMissingSalesOrder(_Order, e.getUserMessage());
                    }

                    checkGovernance();
                }
            }

        } else {
            _audit('ORDER SIZE: 0');
            // _log_email('GetOrders--- 0: responseJSON', JSON.stringify(GetOrdersResponse, null, 2) + '\r\n' + xml);
        }

    } else {
        _log_email('Ebay Ack Error', GetOrdersResponse.Ack + '\r\n' + JSON.stringify(GetOrdersResponse.Errors));
    }

    //if (custrecord_ebay_shortname == 'CD' || custrecord_ebay_shortname == 'RMT') {
    //    _log_email(custrecord_ebay_shortname + ' - Time: ' + P.end() + ' ORDER REPORT(' + (exeReport.length - 2) + ') ' + timefrom + ' ~ ' + timeto + ' PageNumber: ' + PageNumber,
    //        JSON.stringify(exeReport, null, 2));
    //}

    RUNNING_ACCOUNT = {};
    _audit(exeReport, exeReport);
    return {
        success: true,
        exeReport: exeReport
    };

}

function createMissingSalesOrder(salesOrder, errorMessage) {
    errorMessage = _cutText(errorMessage);

    var orderId = salesOrder.OrderID;
    var search = nlapiSearchRecord('customrecord_missing_sales_order', null, [
        new nlobjSearchFilter('custrecord_mso_id', null, 'is', orderId)
    ]);

    if (search == null) {
        var mso = nlapiCreateRecord('customrecord_missing_sales_order');
        mso.setFieldValue('custrecord_mso_marketplace', MarketplaceShipName.eBay);
        mso.setFieldValue('custrecord_mso_ebay_account', RUNNING_ACCOUNT.EBAY_ACCOUNT_ID);
        mso.setFieldValue('custrecord_mso_id', orderId);
        mso.setFieldValue('custrecord_mso_srn', RUNNING_ACCOUNT.custrecord_ebay_shortname + '-' + salesOrder.ShippingDetails.SellingManagerSalesRecordNumber);
        mso.setFieldValue('custrecord_mso_subsidiary', Subsidiaries.TaiwuInternational);
        mso.setFieldValue('custrecord_mso_reason', errorMessage);
        mso.setFieldValue('custrecord_mso_info', JSON.stringify(salesOrder));
        return nlapiSubmitRecord(mso, true);
    }

    return search[0].getId();

}

//OrderArray.Order
//    .TransactionArray.Transaction
//    .ShippingDetails
//    .ShipmentTrackingDetails	ShipmentTrackingDetailsType	Conditionally,
//    repeatable: [0..*]

/**
 *  Refactory Orders Response
 *  If Conditionally, repeatable: [0..*]
 *  Then make array for this
 * @param GetOrdersResponse
 */
function refactoryOrdersResponse(GetOrdersResponse) {

    // if (GetOrdersResponse.ReturnedOrderCountActual == '0') return; // GetOrdersResponse;

    if (GetOrdersResponse.hasOwnProperty('OrderArray') && GetOrdersResponse.OrderArray.Order) {
        if (!Array.isArray(GetOrdersResponse.OrderArray.Order)) {
            GetOrdersResponse.OrderArray.Order = [GetOrdersResponse.OrderArray.Order];
        }
        GetOrdersResponse.OrderArray.Order.forEach(function (Order) {
            if (!Array.isArray(Order.TransactionArray.Transaction)) {
                Order.TransactionArray.Transaction = [Order.TransactionArray.Transaction];
            }
            if (Order.MonetaryDetails) {
                if (!Array.isArray(Order.MonetaryDetails.Payments.Payment)) {
                    Order.MonetaryDetails.Payments.Payment = [Order.MonetaryDetails.Payments.Payment];
                }
            }
            Order.ExternalTransaction = _toarray(Order.ExternalTransaction);
        });
    }

    //return GetOrdersResponse;
}

var OverseaLocationShippingService = [
    'UPS2DayAirAM',     //ebay:UPS Next Day Air
    'UPSNextDayAir',
    'UPSGround',     //ebay:UPS Ground
    //'',     //ebay:UPS Surepost
    //'',     //ebay:UPS Surepost
    //'',     //ebay:UPS Surepost
    'CA_UPS3DaySelectUnitedStates',     //ebay:UPS 3 Day Select
    //'',     //ebay:UPS 2nd Day Air
    //'',     //ebay:UPS Next Day Air Saver
    //'',     //ebay:UPS Surepost
    'USPSFirstClass',     //ebay:USPS First Class Package
    'USPSFirstClassMailInternational',
    //'',     //ebay:USPS Retail Ground
    //'',     //ebay:USPS First Class Mail Intl / First Class Package Intl Service
    'USPSExpressFlatRateEnvelope',     //ebay:USPS Priority Mail
    'USPSExpressMail',
    //'',     //ebay:USPS Parcel Select Ground
    //'',     //ebay:USPS Media Mail
    //'',     //ebay:USPS Priority Mail Express
    //'',     //ebay:USPS Priority Mail Medium Flat Rate Box
    'USPSExpressFlatRateEnvelope',     //ebay:USPS Priority Mail Express Flat Rate Envelope
    'USPSPriorityMailLargeFlatRateBox',     //ebay:USPS Priority Mail Large Flat Rate Box
    'USPSPriorityMailSmallFlatRateBox',     //ebay:USPS Priority Mail Small Flat Rate Box
    'USPSPriorityMailPaddedFlatRateEnvelope',     //ebay:USPS Priority Mail Padded Flat Rate Envelope
    'USPSPriorityMailLegalFlatRateEnvelope',     //ebay:USPS Priority Mail Legal Flat Rate Envelope
    'USPSExpressMailLegalFlatRateEnvelope'      //ebay:USPS Priority Mail Express Legal Flat Rate Envelope

];

//function toArray(obj) {
//    if (Array.isArray(obj)) {
//        return obj
//    } else {
//        return [obj];
//    }
//}

// 区别其他的channel 千万不要修改！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
function makeNSEbayID(id) {
    return 'EBAY' + id;
}

function createEbaySalesOrder(Order, ebay_account, info) {

    _log('ebay_order_OrderStatus', Order.OrderStatus);

    if (Order.OrderStatus == 'Completed') {

        if (info && info.bigfix == true) {

            var salesRecordNumber = Order.ShippingDetails.SellingManagerSalesRecordNumber;
            var refnum = ebay_account.getValue('custrecord_ebay_shortname') + '-' + salesRecordNumber;

            var search = nlapiSearchRecord('customrecord_ebay_insert_order', null, [
                new nlobjSearchFilter('name', null, 'is', refnum),
                new nlobjSearchFilter('custrecord_ebay_insert_yes', null, 'is', 'F')
            ]);

            if (search != null) {

                var result = _createSO(Order, ebay_account, info);

                var rec = nlapiLoadRecord('customrecord_ebay_insert_order', search[0].getId());
                rec.setFieldValue('custrecord_ebay_insert_yes', 'T');
                rec.setFieldValue('custrecord_insert_memo', _cutText(JSON.stringify(result)));
                nlapiSubmitRecord(rec, true);

                return result;

                //try {
                //    var result = _createSO(Order, ebay_account, info);
                //
                //    var rec = nlapiLoadRecord('customrecord_ebay_insert_order', search[0].getId());
                //    rec.setFieldValue('custrecord_ebay_insert_yes', 'T');
                //    rec.setFieldValue('custrecord_insert_memo', _cutText(JSON.stringify(result)));
                //    nlapiSubmitRecord(rec, true);
                //
                //    return result;
                //} catch (e) {
                //
                //    e = parseException(e);
                //    createMissingSalesOrder(_Order, e.getUserMessage());
                //
                //    return {
                //        success: false,
                //        code: e.code,
                //        id: null
                //    };
                //}

            } else {
                return {
                    success: false,
                    code: refnum + ' 不在需要补单的列表中',
                    id: null
                };
            }


        }


        // 这个Check 先去掉， 可能不适用于中国这边的逻辑 - 2016/8/22
        //var createdTime = Order.CreatedTime;
        //createdTime = new Date(createdTime);
        //createdTime = createdTime.format('yyyy/MM/dd');
        //
        //// : need up startTime to global var
        //var startTime = new Date(new Date().getTime() - 3 * 7 * 24 * 60 * 60 * 1000);
        //startTime = startTime.format('yyyy/MM/dd');
        //
        //_log('time range', createdTime + ' --- start from: ' + startTime);
        //
        //if (DateCompare.compare(createdTime, startTime) == -1) {
        //    return {
        //        success: false,
        //        code: 'ORDER_CREATE_TIME_ON_3_WEEKS_AGO',
        //        id: null
        //    };
        //}

        // ------------------------------------------- Check Condition Start -----------------------------------
        // : 通途 -- 这里先注释掉， 为了好测试
        // check if order has been shipped
        // https://ebaydts.com/eBayKBDetails?KBid=5024
        // http://stackoverflow.com/questions/14844391/ebay-trading-api-getorders-check-if-order-is-marked-as-shipped

        if (Order.hasOwnProperty('ShippedTime')) {
            return {
                success: false,
                code: 'ORDER_HAS_BEEN_SHIPPED已经发运了',
                id: null
            };
        }

        var isSomeTrackingDetails = Order.TransactionArray.Transaction.some(function (item) {
            return item.hasOwnProperty('ShippingDetails') && item.ShippingDetails.hasOwnProperty('ShipmentTrackingDetails');
        });
        if (isSomeTrackingDetails) {
            return {
                success: false,
                code: 'isSomeTrackingDetails有发运信息',
                id: null
            };
        }

        if (!Order.hasOwnProperty('MonetaryDetails')) {
            return {
                success: false,
                code: 'PAYMENT_FALSE付钱有问题',
                id: null
            };
        }

        // ------------------------------------------- Check Condition End -----------------------------------

        if (Order.CancelStatus == 'NotApplicable' || Order.CancelStatus == 'CancelRejected') {

            return _createSO(Order, ebay_account, info);

        } else {
            return {
                success: false,
                code: 'CancelStatus_is_not_NotApplicable取消状态不匹配',
                id: null
            };
        }
    } else if (Order.OrderStatus == 'Cancelled') {
        _log_email('Cancelled Ebay Order JSON --Cancelled', JSON.stringify(Order));

        var cancelledSalesOrderSearch = nlapiSearchRecord('salesorder', null, [
            new nlobjSearchFilter('custbody_ebay_order_id', null, 'is', Order.OrderID)
        ], [
            new nlobjSearchColumn('status')
        ]);

        if (cancelledSalesOrderSearch != null) {
            if (cancelledSalesOrderSearch.length == 1) {

                var cancelledSalesOrder = cancelledSalesOrderSearch[0];
                var status = cancelledSalesOrder.getValue('status');
                if (status == 'pendingFulfillment') {

                    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
                        new nlobjSearchFilter('createdfrom', null, 'is', cancelledSalesOrder.getId()),
                        new nlobjSearchFilter('mainline', null, 'is', 'T')
                    ]);

                    if (ffSearch != null) {
                        ffSearch.forEach(function (ffRec) {
                            nlapiDeleteRecord('itemfulfillment', ffRec.getId())
                        })
                    }

                    _closeSalesOrder(cancelledSalesOrder.getId());

                    return {
                        success: false,
                        code: 'Cancelled____return订单被关闭而且包裹被删除',
                        id: null,
                        OrderStatus: Order.OrderStatus
                    };
                }

            }
        }

        return {
            success: false,
            code: 'Cancelled____return__是Canclled的订单但是NS没有找到',
            id: null,
            OrderStatus: Order.OrderStatus
        };

    } else {

        // {"OrderID":"152192329162-1499076054005","OrderStatus":"CancelPending","
        if (Order.OrderStatus == 'CancelPending') {
            return {
                success: false,
                code: 'CancelPending',
                id: null,
                OrderStatus: Order.OrderStatus
            };
        }

        else if (Order.OrderStatus != 'Active') {
            _log_email('Ebay Order JSON with New Status', JSON.stringify(Order));
            return {
                success: false,
                code: '__Unknow___这是啥状态__不知道',
                id: null,
                OrderStatus: Order.OrderStatus
            };
        }

        else {

            return {
                success: false,
                code: 'Just_Active订单还没有好',
                id: null,
                OrderStatus: Order.OrderStatus
            };
        }

    }


}

function _createSO(Order, ebay_account, info) {

    // Check payments status
    //var PaymentStatus = Order.MonetaryDetails.Payments.Payment.every(function (Payment) {
    //    return Payment.PaymentStatus == 'Succeeded';
    //});

    //_log('PaymentStatus', PaymentStatus);

    // A CheckoutStatus.eBayPaymentStatus value of 'NoPaymentFailure'
    // and a CheckoutStatus.Status value of 'Complete' indicates that checkout is complete.

    //"CheckoutStatus": {
    //    "eBayPaymentStatus": "PayPalPaymentInProcess",
    //        "LastModifiedTime": "2015-07-15T08:28:38.000Z",
    //        "PaymentMethod": "PayPal",
    //        "Status": "Complete",
    //        "IntegratedMerchantCreditCardEnabled": "false"
    //},


    // In the ExternalTransaction container, the ExternalTransactionID field is the the PayPal TransactionID.
    // You can use this to sync up with the PayPal IPNs, APIs or reports. You need to ensure that you have set the DetailLevel field to ReturnAll when you make the request.


    // https://ebaydts.com/eBayKBDetails?KBid=1788
    // PaidTime
    if (Order.hasOwnProperty('PaidTime') &&
            // PaymentStatus == true &&
        Order.CheckoutStatus.eBayPaymentStatus == 'NoPaymentFailure' &&
        Order.CheckoutStatus.Status == 'Complete') {


        // *************** FIRST OF FIRST FOR CHECK!!!!!!!!!! ************************
        var searchExistingOrder = nlapiSearchRecord('salesorder', null, [
            new nlobjSearchFilter('externalid', null, 'is', makeNSEbayID(Order.OrderID))
        ]);
        if (searchExistingOrder != null) {
            return {
                success: false,
                code: 'EXISTING_SALES_ORDER__NS有这个单了',
                id: searchExistingOrder[0].getId()
            };
        }

        _audit(makeNSEbayID(Order.OrderID), searchExistingOrder);


        //var TransactionArray = toArray(Order.TransactionArray);
        // 取第一个Transaction 就行。
        var Transaction = Order.TransactionArray.Transaction[0];
        var nsCurrency = getNSCurrency(Order);

        // 1, 先建立Customer and address information
        var customerId = saveOrUpdateCustomer(Order, Transaction);

        var customform_id = '313'; // 太武国际 Sales Order - Invoice

        // 2, 然后Place items in order
        var salesOrder = nlapiCreateRecord('salesorder', {
            recordmode: 'dynamic',
            customform: customform_id
        });
        salesOrder.setFieldValue('custbody_script_memo', 'Ebay订单下载成功！');

        // var salesOrder = nlapiCreateRecord('salesorder');


        // salesOrder.setFieldValue('customform', customform_id);
        salesOrder.setFieldValue('entity', customerId.id);
        salesOrder.setFieldValue('orderstatus', 'B'); //


        var _total = Order.Total.__text;
        _total = parseFloat(_total);
        salesOrder.setFieldValue('custbody_order_total', _total);

        salesOrder.setFieldValue('currency', nsCurrency.INTERNALID);

        // 2016-11-21: 转移到User Event of SO
        //var currencyCode = salesOrder.getFieldText('currency');
        //if (currencyCode != "USD") {
        //    var exchangerate = salesOrder.getFieldValue('exchangerate');
        //    exchangerate = parseFloat(exchangerate);
        //    var usdTotal = _mathround((exchangerate * _total) / 6.6986);
        //    //salesOrder.setFieldValue('custbody_ebay_so_total', usdTotal);
        //    salesOrder.setFieldValue('custbody_us_dollar_total', usdTotal);
        //} else {
        //    salesOrder.setFieldValue('custbody_us_dollar_total', _total);
        //}

        // custbody_customer_memo
        //  "BuyerCheckoutMessage": "Please ASAP. Thank you",
        if (Order.BuyerCheckoutMessage) {
            salesOrder.setFieldValue('custbody_customer_memo', _cutTextLength(Order.BuyerCheckoutMessage));
            salesOrder.setFieldValue('custbody_delay_fulfill', 'T');
        }

        var createdtime = new Date(Order.CreatedTime);
        salesOrder.setFieldValue('custbody_order_created_time', nlapiDateToString(createdtime, 'datetimetz'));
        salesOrder.setFieldValue('custbody_paidtime', nlapiDateToString(new Date(Order.PaidTime), 'datetimetz'));
        salesOrder.setFieldValue('trandate', nlapiDateToString(createdtime, 'date'));

        salesOrder.setFieldValue('custbody_ebay_currency', Order.Total._currencyID);
        salesOrder.setFieldValue('custbody_ebay_total', Order.Total.__text);
        salesOrder.setFieldValue('custbody_ebay_seller_id', Order.SellerUserID);
        salesOrder.setFieldValue('custbody_ebay_order_status', Order.OrderStatus);

        salesOrder.setFieldValue('custbody_market_ship_serv_lvl', 6); // To Be Determined

        // : externalid---------- Commented if testing 这个是确保唯一性的 NS 原生字段！
        salesOrder.setFieldValue('externalid', makeNSEbayID(Order.OrderID));
        salesOrder.setFieldValue('custbody_ebay_order_id', Order.OrderID);
        salesOrder.setFieldValue('custbody_ebay_buyer_id', Order.BuyerUserID);

        var salesRecordNumber = Order.ShippingDetails.SellingManagerSalesRecordNumber;
        salesOrder.setFieldValue('custbody_ebay_sales_record_number', salesRecordNumber);
        salesOrder.setFieldValue('otherrefnum', ebay_account.getValue('custrecord_ebay_shortname') + '-' + salesRecordNumber);
        salesOrder.setFieldValue('custbody_storefront_order', salesRecordNumber);
        salesOrder.setFieldValue('custbody_storefront', Order.SellerUserID);
        salesOrder.setFieldValue('custbody_marketplace', '3'); // Which for Ebay

        // 中国用 Linked Ebay Account 就得了 中国这个都是统一的， 具体区分看 Linked Ebay Account
        // salesOrder.setFieldValue('custbody_storefront_list', RUNNING_ACCOUNT.STOREFRONT);
        salesOrder.setFieldValue('custbody_storefront_list', 23);


        //salesOrder.setFieldValue('shipcarrier', 'nonups');
        //salesOrder.setFieldValue('shipmethod', '35170');
        //salesOrder.setFieldValue('shippingcost', 0);

        if (parseFloat(Order.ShippingServiceSelected.ShippingServiceCost.__text)) {
            salesOrder.setFieldValue('shippingcost', Order.ShippingServiceSelected.ShippingServiceCost.__text);
        } else {
            salesOrder.setFieldValue('shippingcost', 0);
        }

        //nlapiGetFieldValue('shipcarrier')
        //"nonups"
        salesOrder.setFieldValue('shipcarrier', 'nonups');
        salesOrder.setFieldValue('shipmethod', '66630'); // China TBD

        salesOrder.setFieldValue('custbody_customer_email', customerId.email);

        var itemLocations = [];
        // 73 Ebay海外仓
        var shippingService = Order.ShippingServiceSelected.ShippingService;
        if (OverseaLocationShippingService.contains(shippingService)) {
            itemLocations = [84]; // 4PX
            // _log_email('Oversea order' + Order.OrderID);
        }

        if (itemLocations.length && itemLocations.length == 1) {
            Order.TransactionArray.Transaction.forEach(function (_Transaction, index) {
                commitLineItem(salesOrder, _Transaction, Order, 84, index)
            });
        } else {
            Order.TransactionArray.Transaction.forEach(function (_Transaction, index) {
                commitLineItem(salesOrder, _Transaction, Order, itemLocations, index)
            });
        }


        // Ebay fee
        //var ebayFee = 0;
        //var ebayFeeCurrencyId = '';
        //Order.ExternalTransaction.forEach(function (trnas, index) {
        //    if (index == 0) {
        //        ebayFeeCurrencyId = trnas.FeeOrCreditAmount._currencyID;
        //    }
        //    ebayFee += parseFloat(trnas.FeeOrCreditAmount.__text);
        //});
        //salesOrder.setFieldValue('custbody_ebay_fee', _mathround(ebayFee));
        //var currencyInternalId = NSCurrencies.find(function (item) {
        //    return item.ISOCODE == ebayFeeCurrencyId;
        //});
        //if (currencyInternalId) {
        //    salesOrder.setFieldValue('custbody_ebay_fee_currency', currencyInternalId.INTERNALID);
        //} else {
        //    _log_email('Fee 货币没有发现', ebayFeeCurrencyId);
        //}

        // custbody_paypal_transaction_id
        if (Order.hasOwnProperty('ExternalTransaction') && Array.isArray(Order.ExternalTransaction)) {
            salesOrder.setFieldValue('custbody_paypal_transaction_id', Order.ExternalTransaction.map(function (item) {
                return item.ExternalTransactionID;
            }).join(","));
        }

        // Paylpal fee
        var paypalFee = 0;
        Order.ExternalTransaction.forEach(function (externalTransaction) {
            paypalFee += parseFloat(externalTransaction.FeeOrCreditAmount.__text);
        });
        paypalFee = _mathround(paypalFee);
        if (paypalFee > 0) {
            // Payment Line
            // 80447	 	 	Paypal Fee Charge	 	For Sale
            // 98475 this for new one
            salesOrder.selectNewLineItem('item');
            //salesOrder.setCurrentLineItemValue('item', 'item', 102214); // Service Type Item
            salesOrder.setCurrentLineItemValue('item', 'item', 113345); // Paypal fee line item

            // 这个默认为1
            //salesOrder.setCurrentLineItemValue('item', 'quantity', _Transaction.QuantityPurchased);

            salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
            salesOrder.setCurrentLineItemValue('item', 'rate', '-' + paypalFee);

            salesOrder.commitLineItem('item');
        } else {

            // 使用 custbody_pp_checked 来标记 PP fee line 缺失的订单
            salesOrder.setFieldValue('custbody_pp_checked', 'T');
            //_log_email(Order.OrderID + ' | without fee line item', '请注意看下后续的 Invoice 收款不能对账， 请注意修改这个SO for fee line item.');
        }

        if (allTheSame(itemLocations)) {
            salesOrder.setFieldValue('location', itemLocations[0]);
        } else {
            salesOrder.setFieldValue('custbody_script_memo', '商品位于不同的仓库， 请人工处理这个订单， 谢谢！');
            salesOrder.setFieldValue('custbody_has_issues', 'T');
        }

        // Data
        salesOrder.setFieldValue('custbody_api_data', JSON.stringify(Order));
        salesOrder.setFieldValue('custbody_linked_ebay_account', RUNNING_ACCOUNT.EBAY_ACCOUNT_ID);

        var total = salesOrder.getFieldValue('total');
        if (parseFloat(total) != _mathround(parseFloat(Order.Total.__text) - paypalFee)) {
            _log_email('Ebay order total was different', Order.OrderID + ' /// ' + total + ' - ' + Order.Total.__text);
        }

        var id = nlapiSubmitRecord(salesOrder, true);
        _log('sales order has been created', id);


        return {
            success: true,
            code: 'NEW_SALES_ORDER',
            id: id
            //cashsale_id: JSON.stringify(cashsale_id)
        };
    } else {
        return {
            success: false,
            code: 'PAYMENT_FALSE付钱有问题',
            id: null
        };
    }
}


function _closeSalesOrder(id) {

    var so = nlapiLoadRecord('salesorder', id);
    var linecount = so.getLineItemCount('item');
    var i = 1;
    for (; i <= linecount; i++) {
        so.setLineItemValue('item', 'isclosed', i, 'T');
    }
    nlapiSubmitRecord(so, true);
    _log('SO ' + id + ' was successfully closed.');

}

// Combo case #311436744982-634012910021
function commitLineItem(salesOrder, _Transaction, ebay_order, itemLocations, index) {

    var sku = null;
    // var ebayItemId = null;

    if (_Transaction.hasOwnProperty('Variation')) {
        sku = _Transaction.Variation.SKU;
        // ebayItemId = Transaction.Variation.ItemID;
    } else {
        sku = _Transaction.Item.SKU;
        // ebayItemId = Transaction.Item.ItemID;
    }

    sku = sku.trim();

    //if (sku.indexOf('|') != -1) {
    //    sku = sku.substring(0, sku.indexOf('|'));
    //}
    var rest = '';
    var lastVerticalBarIndex = sku.lastIndexOf('|');
    if (lastVerticalBarIndex != -1) {
        rest = sku.substring(lastVerticalBarIndex + 1);
        sku = sku.substring(0, lastVerticalBarIndex);
    }

    _log('SKU', sku);

    var iteminfo = searchNetSuiteItem(sku);
    _log('iteminfo', iteminfo);

    if (Array.isArray(itemLocations)) {// 本地仓

        if (rest == 'FBAXT') {
            // TODO:钟晓婷 'sku|FBAXT'; 本地仓转FBA发货设置 6/29/2017 36 FBA 亚马逊仓库
            // TODO: start
            if (Array.isArray(iteminfo)) {// Kit item
                iteminfo.forEach(function (iteminfo) {
                    iteminfo.location = 36;
                });
            } else {// 普通item
                iteminfo.location = 36;
            }
            // TODO: end
            _log_email('检查看看FBAXT', ebay_order.OrderID);
        }


        if (Array.isArray(iteminfo)) { // Kit item
            iteminfo.forEach(function (iteminfo) {
                itemLocations.push(iteminfo.location);
            });
        } else { // 普通item
            itemLocations.push(iteminfo.location);
        }

    } else { // 海外仓
        if (Array.isArray(iteminfo)) {// Kit item
            iteminfo.forEach(function (iteminfo) {
                iteminfo.location = itemLocations;
            });
        } else {// 普通item
            iteminfo.location = itemLocations;
        }
    }


    // if (!itemLocations.length) { 这个逻辑块好像没有啥用啊
    //if (!itemLocations.length) {
    //    if (Array.isArray(iteminfo)) {
    //        iteminfo.forEach(function (iteminfo) {
    //            itemLocations.push(iteminfo.location);
    //        });
    //    } else {
    //        itemLocations.push(iteminfo.location);
    //    }
    //}
    //
    //
    //else {
    //    if (Array.isArray(iteminfo)) {
    //        iteminfo.forEach(function (iteminfo) {
    //            iteminfo.location = itemLocations[0];
    //        });
    //    } else {
    //        iteminfo.location = itemLocations[0];
    //    }
    //}

    // --------------- start -----------------
    if (Array.isArray(iteminfo)) { // from dictionary
        // 递归！
        iteminfo.forEach(function (_item, comboIndex) {

            salesOrder.selectNewLineItem('item');

            salesOrder.setCurrentLineItemValue('item', 'item', _item.id);
            salesOrder.setCurrentLineItemValue('item', 'location', _item.location);
            salesOrder.setCurrentLineItemValue('item', 'quantity', parseInt(_Transaction.QuantityPurchased) * parseInt(_item.qty));

            salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level

            if (comboIndex === 0) { // : 这个需要加上 每个产品的价格多少！！如果Kit 记录上面有的话
                //salesOrder.setCurrentLineItemValue('item', 'rate', parseFloat(_Transaction.TransactionPrice.__text) / (parseInt(_Transaction.QuantityPurchased) * parseInt(_item.qty)));
                salesOrder.setCurrentLineItemValue('item', 'rate', parseFloat(_Transaction.TransactionPrice.__text) / parseInt(_item.qty));
            } else {
                salesOrder.setCurrentLineItemValue('item', 'rate', 0);
            }


            _commitLineItem(salesOrder, _Transaction, ebay_order);
            salesOrder.commitLineItem('item');
        });

    }

    //else if (iteminfo.hasOwnProperty('qty')) { // from dictionary
    //    salesOrder.selectNewLineItem('item');
    //    salesOrder.setCurrentLineItemValue('item', 'item', iteminfo.id);
    //    salesOrder.setCurrentLineItemValue('item', 'location', iteminfo.location);
    //    salesOrder.setCurrentLineItemValue('item', 'quantity', parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty));
    //    salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
    //    salesOrder.setCurrentLineItemValue('item', 'rate', parseFloat(_Transaction.TransactionPrice.__text) / (parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty)));
    //    _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
    //    salesOrder.commitLineItem('item');
    //
    //}

    else {

        salesOrder.selectNewLineItem('item');

        salesOrder.setCurrentLineItemValue('item', 'item', iteminfo.id);
        salesOrder.setCurrentLineItemValue('item', 'location', iteminfo.location);
        salesOrder.setCurrentLineItemValue('item', 'quantity', _Transaction.QuantityPurchased);

        // 当开启 Dynamic 的时候 这里的 Item 添加 属性的先后顺序也是有讲究的， 太牛了。。
        salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
        salesOrder.setCurrentLineItemValue('item', 'rate', _Transaction.TransactionPrice.__text);

        _commitLineItem(salesOrder, _Transaction, ebay_order);
        salesOrder.commitLineItem('item');

    }
    // --------------- end -------------------


}

function _commitLineItem(salesOrder, _Transaction, ebay_order) {

    // 如果Customer no taxable
    // 这里就不用设置taxcode inline 了


    //"ShippingAddress": {
    //    "Name": "Donald Watkins",
    //        "Street1": "622 Woods Crossing Ln",
    //        "Street2": "",
    //        "CityName": "Indianapolis",
    //        "StateOrProvince": "IN",
    //        "Country": "US",
    //        "CountryName": "United States",
    //        "Phone": "317 701 0541",
    //        "PostalCode": "46239-2162",
    //        "AddressID": "530188146024",
    //        "AddressOwner": "eBay",
    //        "ExternalAddressID": ""
    //},

    //_log('ebay_order.ShippingAddress', ebay_order.ShippingAddress);
    //
    //if (ebay_order.ShippingAddress.Country == 'US' && ebay_order.ShippingAddress.StateOrProvince == 'IN') {
    //    salesOrder.setCurrentLineItemValue('item', 'taxcode', '-8');        // "-8" for -Not Taxable-
    //} else {
    //
    //    // 42569 UNDEF_CN for 0%
    //    salesOrder.setCurrentLineItemValue('item', 'taxcode', 42569);
    //}


    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_item_id', _Transaction.Item.ItemID);

    _log('Order.ShippingDetails.SalesTax.SalesTaxState', ebay_order.ShippingDetails.SalesTax.SalesTaxState);


    //else {
    //    salesOrder.setCurrentLineItemValue('item', 'texcode', -7);
    //}

    // paypal transaction id
    // salesOrder.setCurrentLineItemValue('item', 'custcol_payment_transaction_id', Order.MonetaryDetails.Payments.Payment[index].ReferenceID.__text);
    salesOrder.setCurrentLineItemValue('item', 'custcol_payment_transaction_id', ebay_order.ExternalTransaction.ExternalTransactionID);

    // custcol_ebay_transaction_id
    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_transaction_id', _Transaction.TransactionID);
    // custcol_ebay_transaction_site_id
    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_transaction_site_id', _Transaction.TransactionSiteID);
    // custcol_ebay_item_sku
    salesOrder.setCurrentLineItemValue('item', 'custcol_sellersku', _Transaction.Item.SKU);

}

//function getNetSuiteItemInfo(sku) {
//
//
//}

function searchNetSuiteItem(sku, onlyInventoryItemTag) {

    sku = sku.trim();

    _log('searchNetSuiteItem---------sku', sku);
    // : http://stackoverflow.com/questions/5915096/get-random-item-from-javascript-array
    // :: for test
    //var item = SZ_TEST_ITEMS[Math.floor(Math.random() * SZ_TEST_ITEMS.length)];
    //return {
    //    id: item,
    //    location: 34 // 34 Shenzhen YMW 深圳杨美仓库
    //};

    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');
    columns[1] = new nlobjSearchColumn('itemid');
    columns[2] = new nlobjSearchColumn('description');
    columns[3] = new nlobjSearchColumn('preferredlocation');

    // location
    columns[4] = new nlobjSearchColumn('location');

    var search = nlapiSearchRecord('item', null, [
        ['subsidiary', 'is', Subsidiaries.TaiwuInternational],
        'AND',
        ['type', 'is', 'InvtPart'],
        'AND',
        ['isinactive', 'is', 'F'],
        'AND',
        ['matrix', 'is', 'F'], // 真是的Item
        'AND',
        [
            ['name', 'is', sku],
            'OR',
            ['custitem_legacy_tong_sku', 'is', sku]
        ]
    ], columns);

    if (search != null) {

        if (search.length == 1) {
            _log('search1 got result');
            return {
                id: search[0].getId(),
                location: search[0].getValue('location')
            }
        } else {
            throw createEbayError('SKU: ' + sku + ' 搜索Item的Name 和Legacy 自动时候找到了多条记录！ 记录条数: ' + search.length);
        }

    } else {  // custitem_sku_alias

        columns[5] = new nlobjSearchColumn('custitem_sku_alias');

        var search = nlapiSearchRecord('item', null, [
            new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
            new nlobjSearchFilter('custitem_sku_alias', null, 'contains', sku),
            new nlobjSearchFilter('matrix', null, 'is', 'F')
        ], columns);

        if (search != null) {

            var sku_alias = search.map(function (searchResult) {
                return {
                    id: searchResult.getId(),
                    location: searchResult.getValue('location'),
                    alias: searchResult.getValue('custitem_sku_alias')
                }
            });

            var match = sku_alias.filter(function (item) {
                var alias = item.alias.split(';');

                return alias.contains(sku);
                // return alias.trim() == sku;
                // return alias.indexOf(sku) != -1;
            });

            // 别名: luoliyi00032;lidan00032
            if (match.length == 1) {

                _log('match custitem_sku_alias got result');

                return {
                    id: match[0].id,
                    location: match[0].location
                };

            } else {
                throw createEbayError('第二次搜索， 别名搜索匹配到了多条记录！ SKU: ' + sku + ' 记录条数: ' + search.length + ' sku_alias结果： ' + JSON.stringify(sku_alias));
            }

        } else {

            if (!onlyInventoryItemTag) {

                _log('search3 got result');
                return searchKitItem(sku);
            }


        }

    }

}

function searchKitItem(kitSku) {

    var kitSearch = nlapiSearchRecord('customrecord_kit', null, [
        ['isinactive', 'is', 'F'],
        'AND',
        [
            ['externalid', 'is', kitSku],
            'OR',
            ['custrecord_kit_sku', 'is', kitSku],
            'OR',
            ['custrecord_sku_alias', 'contains', kitSku]
        ]
    ], [
        new nlobjSearchColumn('custrecord_kit_mapping')
    ]);

    //00328=3
    //00816=1;00819=1

    if (kitSearch != null) {
        if (kitSearch.length == 1) {
            var kitMapping = kitSearch[0].getValue('custrecord_kit_mapping');
            kitMapping = kitMapping.split(';');

            var itemResult = [];
            for (var i = 0; i < kitMapping.length; i++) {
                var mapping = kitMapping[i];
                var subSKU = mapping.substring(0, mapping.indexOf('='));
                var qty = parseInt(mapping.substring(mapping.indexOf('=') + 1));

                var item = searchNetSuiteItem(subSKU, true);
                item.qty = qty;

                itemResult.push(item);

            }

            return itemResult;

        } else {
            throw createEbayError('第三次Kit搜索发现了多条记录！ SKU: ' + kitSku +
            ' and search size: ' + kitSearch.length +
            ' and search is: ' + kitSearch.map(function (sr) {
                return sr.getId();
            }).join(', '));
        }
    } else {

        throw createEbayError('第三次搜索SKU： ' + kitSku + ' 连Kit搜索都木有啊！');
    }

}

function GetSellingManagerSaleRecordRequest(orderId) {
    _audit('GetSellingManagerSaleRecordRequest', orderId);
    var xml = ['<?xml version="1.0" encoding="utf-8"?>',
        '<GetSellingManagerSaleRecordRequest xmlns="urn:ebay:apis:eBLBaseComponents">',
        '  <RequesterCredentials>',
        '        <eBayAuthToken>' + RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN + '</eBayAuthToken>',
        '  </RequesterCredentials>',
        '  <OrderID>' + orderId + '</OrderID>',
        '</GetSellingManagerSaleRecordRequest>'].join("");

    var response = nlapiRequestURL('https://api.ebay.com/ws/api.dll', xml, extend(EbayRequest.headers, {
        'X-EBAY-API-SITEID': '0',
        'X-EBAY-API-CALL-NAME': 'GetSellingManagerSaleRecord',
        'X-EBAY-API-COMPATIBILITY-LEVEL': '945'
    }));

    response = new X2JS().xml_str2json(response.getBody());
    _log_email('GetSellingManagerSaleRecordRequest', JSON.stringify(response));

    return response.GetSellingManagerSaleRecordResponse.SellingManagerSoldOrder.BuyerEmail;
}

function isValidEmailAddress(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}

function getCustomerEmail(Transaction, orderId) {

    // : 都是要归到 主Email中
    var Email = Transaction.Buyer.Email;
    var EbayMemberEmail = Transaction.Buyer.StaticAlias;

    //if (isValidEmailAddress(Email)) {
    //    return Email;
    //}

    //
    //Why do I get "Invalid Request" for the Buyer Email in the GetItemTransactions, GetOrders, GetSellerTransactions, GetOrderTransactions & GetItem response?
    //    Summary
    //
    //    GetItemTransactions, GetOrders, GetOrderTransactions, GetSellerTransactions & GetItem returns
    // the Buyer Email Intermediation address (ie buyername@members.ebay.com) only if all of the following are true:
    //The caller is in a transactional relationship for the item
    //The call is being executed within a certain amount of time after the transaction is created.  Based on Trust and Safety policies, the time is unspecified and can vary by site.
    //
    //    As a best practice, we recommend that you make the transaction calls within a day so that you have all the updated information.  For instance, make a call to GetSellerTransactions every day with the ModTimeFilter set to the last time you made the call to the current time.  If you get information about transactions individually via GetItemTransactions, then make the call as soon as you get the notification about the sale.

    //"Buyer": {
    //    "Email": "Invalid Request",
    //        "StaticAlias": "punkhe_hsib5727tbz@members.ebay.co.uk",
    //        "UserFirstName": "danny",
    //        "UserLastName": "peters"
    //},

    if (Email && Email != 'Invalid Request') {
        return Email;
    }
    // else if (isValidEmailAddress(EbayMemberEmail)) {
    else if (EbayMemberEmail) {
        //_audit('EbayMemberEmail', EbayMemberEmail);
        return EbayMemberEmail;
    }
    else {
        var responseEmail = GetSellingManagerSaleRecordRequest(orderId);
        if (isValidEmailAddress(responseEmail)) {
            return responseEmail;
        } else {
            return '';
            //throw createEbayError('No customer email found and return NULL...');
        }
    }
}

//function _splitName(name, size){
//
//    var specIndex = name.indexOf(' ');
//    if(specIndex != -1) {
//        return name.substring(0, specIndex);
//    } else {
//
//    }
//
//}

function createCustomerRecord(Order, Transaction, _ShippingAddress, _BillingAddress, _email) {

    _log('New for customer');
    var newCustomerRecord = nlapiCreateRecord('customer');

    // https://system.sandbox.netsuite.com/app/common/entity/custjob.nl?id=1768250&scrollid=1768250&whence=&cmid=1466410720236 for currency

    //if (Transaction.TransactionSiteID == 'US') {
    //
    //    // https://system.na1.netsuite.com/app/common/multicurrency/currencylist.nl?whence=
    //    // NS Currency Internal ID
    //    //1	USD	USD	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
    //    //2	GBP	GBP	No	No	Yes
    //    //3	CAD	CAD	No	No	Yes
    //    //4	EUR	EUR	No	No	Yes
    //    //5	CNY	CNY	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
    //    //6	AUD	AUD	No	No	Yes
    //    //7	HKD	HKD	No	No	Yes
    //    //8	INR	INR	No	No	Yes
    //    //9	MYR	MYR	No	No	Yes
    //    //10	PHP	PHP	No	No	Yes
    //    //11	PLN	PLN	No	No	Yes
    //    //12	RUB	RUB	No	No	Yes
    //    //13	SGD	SGD	No	No	Yes
    //    //14	CHF	CHF	No	No	Yes
    //    //15	JPY	JPY	No	No	Yes
    //
    //    newCustomerRecord.setFieldValue('currency', 1);
    //}

    newCustomerRecord.setFieldValue('currency', 5); // 这里总是人民币

    var nsCurrency = getNSCurrency(Order);
    newCustomerRecord.selectNewLineItem('currency');
    newCustomerRecord.setCurrentLineItemValue('currency', 'currency', nsCurrency.INTERNALID);
    newCustomerRecord.commitLineItem('currency');


    newCustomerRecord.setFieldValue('subsidiary', RUNNING_ACCOUNT.SUBSIDIARY);
    newCustomerRecord.setFieldValue('isperson', 'T');

    if (Transaction.Buyer.UserFirstName) {
        newCustomerRecord.setFieldValue('firstname', Transaction.Buyer.UserFirstName);
    } else {
        newCustomerRecord.setFieldValue('firstname', '*');
    }

    // The field lastname contained more than the maximum number ( 32 ) of characters allowed.
    // "UserLastName": "Chandrasekharan pillai saraswathyamma"
    var lastName = Transaction.Buyer.UserLastName;
    if (lastName.length > 32) lastName = lastName.substring(0, 32);
    if (!lastName || lastName == 'null') {
        lastName = Transaction.Buyer.UserFirstName;
        if (!lastName) {
            lastName = '*';
        }
    }
    newCustomerRecord.setFieldValue('lastname', lastName);

    newCustomerRecord.setFieldValue('phone', _ShippingAddress.phone);
    // taxable
    newCustomerRecord.setFieldValue('taxable', 'F');
    //if (usedMainEmailFlag) {
    //    customerRecord.setFieldValue('email', Email);
    //} else {
    //    customerRecord.setFieldValue('custentity_ebay_member_email', EbayMemberEmail);
    //}
    if (_email) newCustomerRecord.setFieldValue('email', _email);

    if (_BillingAddress == null) {
        setAddressLine(newCustomerRecord, _ShippingAddress);
    } else {
        // 不用对比了， 发到国外的肯定这2个Address 是不一样的！
        setAddressLine(newCustomerRecord, _ShippingAddress, 'defaultshipping');
        setAddressLine(newCustomerRecord, _BillingAddress, 'defaultbilling');
    }


    return nlapiSubmitRecord(newCustomerRecord, true);

    // customerRecord = nlapiLoadRecord('customer');
    // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
    // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));

}

// http://www.ebay.com/gds/Shipping-to-APO-AE-/10000000013943736/g.html
function _processCountryCode(countryCode) {
    if (countryCode == 'AA') {
        // AA for Armed Forces Americas,
        return 'US';
    }
    return countryCode;
}
//
//"Total": {
//    "_currencyID": "GBP",
//        "__text": "2.65"
//},
function getNSCurrency(Order) {
    var nsCurrency = NSCurrencies.find(function (item) {
        return Order.Total._currencyID == item.ISOCODE;
    });
    if (!nsCurrency) {
        throw createEbayError('No found this country currency ' + Order.TransactionSiteID)
    }

    return nsCurrency;
}

function _manipulateAddress(ShippingAddress) {

    if (ShippingAddress.StateOrProvince) {
        if (ShippingAddress.StateOrProvince.length > 30) {
            var state = ShippingAddress.StateOrProvince;
            var s1 = '', s2 = '';
            if (state.indexOf(',') != -1) {
                s1 = state.substring(0, state.indexOf(','));
                s2 = state.substring(state.indexOf(',') + 1);
            } else if (state.indexOf(' ') != -1) {
                s1 = state.substring(0, state.indexOf(' '));
                s2 = state.substring(state.indexOf(' ') + 1);
            } else {
                s1 = state.substring(0, 30);
                s2 = state.substring(30);
            }
            ShippingAddress.StateOrProvince = s2;
            ShippingAddress.Street2 = ShippingAddress.Street2 + ' ' + s1;
        }
    } else {
        ShippingAddress.StateOrProvince = ShippingAddress.CityName;
    }


    if (!ShippingAddress.Street2) {
        ShippingAddress.Street2 = '';
    }

    ShippingAddress.Phone = ShippingAddress.Phone.trim();
    // The field phone contained more than the maximum number ( 22 ) of characters allowed.
    // "Phone": "61424598744 61424598744",
    // "Phone": "418 427 2952 4184272952",

    if (ShippingAddress.Phone) {
        if (ShippingAddress.Phone.length > 22) {
            var sindex = ShippingAddress.Phone.lastIndexOf(' ');
            if (sindex != -1) {
                ShippingAddress.Phone = ShippingAddress.Phone.substring(0, sindex);
            } else {
                ShippingAddress.Phone = ShippingAddress.Phone.substring(0, 22);
            }
        }
        // 电话号码要是 7 位 或者7 位以上
        // "Phone":"99752"
        else if (ShippingAddress.Phone.length < 7) {

            var a = 7 - ShippingAddress.Phone.length;
            a = a - 1; // for -

            var zero = [];
            for (var i = 0; i < a; i++) {
                zero.push('0');
            }
            if (zero.length == 0) {
                zero = ['0'];
            }
            ShippingAddress.Phone = ShippingAddress.Phone + '-' + zero.join('');
        }
        ShippingAddress.Phone = ShippingAddress.Phone.replace(/\s/g, '');
    }


    return ShippingAddress;
}

function saveOrUpdateCustomer(Order, Transaction) {

    // The field firstname contained more than the maximum number ( 32 ) of characters allowed.
    var fname = Transaction.Buyer.UserFirstName;
    if (fname.length > 32) {
        fname = fname.substring(0, 32);
        Transaction.Buyer.UserFirstName = fname;
    }

    //"ShippingAddress": {
    //        "Name": "Михаил Сацкевич",
    //        "Street1": "Ozernaya, dom 4",
    //        "Street2": [],
    //        "CityName": "Polesski",
    //        "StateOrProvince": "Brestskaya oblast, Luninetski raion",
    //        "Country": "BY",
    //        "CountryName": "Belarus",
    //        "Phone": "447689550",
    //        "PostalCode": "225671",
    //        "AddressID": "4897313952015",
    //        "AddressOwner": "eBay",
    //        "ExternalAddressID": []
    //},

    // Code: EXCEEDED_MAX_FIELD_LENGTH
    // Detail: The field state contained more than the maximum number ( 30 ) of characters allowed.

    var SUBSIDIARY = RUNNING_ACCOUNT.SUBSIDIARY;

    var ShippingAddress = Order.ShippingAddress;
    ShippingAddress = _manipulateAddress(ShippingAddress);

    var _ShippingAddress = {
        "country": _processCountryCode(ShippingAddress.Country),
        "state": ShippingAddress.StateOrProvince,
        "city": ShippingAddress.CityName,
        "addr1": ShippingAddress.Street1,
        "addr2": ShippingAddress.Street2,
        "addressee": ShippingAddress.Name,
        "zip": ShippingAddress.PostalCode,
        "phone": ShippingAddress.Phone || Order.ShippingAddress.Phone || ''
    };
    var _BillingAddress = null;

    if (Order.IsMultiLegShipping == 'true') {
        _BillingAddress = _ShippingAddress;
        var logisticAddress = Order.MultiLegShippingDetails.SellerShipmentToLogisticsProvider.ShipToAddress;
        logisticAddress = _manipulateAddress(logisticAddress);
        _ShippingAddress = {
            "country": _processCountryCode(logisticAddress.Country),
            "state": logisticAddress.StateOrProvince,
            "city": logisticAddress.CityName,
            "addr1": logisticAddress.Street1,
            "addr2": logisticAddress.Street2,
            "addressee": logisticAddress.ReferenceID,
            "zip": logisticAddress.PostalCode,
            "phone": ShippingAddress.Phone || Order.ShippingAddress.Phone || ''
        };
    }


    _log('ShippingAddress', _ShippingAddress);

    var _email = getCustomerEmail(Transaction, Order.OrderID);

    var id = null;

    if (_email) {

        var filter = [
            new nlobjSearchFilter('isinactive', null, 'is', 'F')
        ];
        filter.push(new nlobjSearchFilter('email', null, 'is', _email));
        filter.push(new nlobjSearchFilter('subsidiary', null, 'is', SUBSIDIARY));

        var customerSearch = nlapiSearchRecord('customer', null, filter);

        if (customerSearch == null) { // New

            id = createCustomerRecord(Order, Transaction, _ShippingAddress, _BillingAddress, _email);

        } else { // Update

            _log("Update for the customer", _email);

            var customerId = customerSearch[0].getId();
            var existingCustomerRecord = nlapiLoadRecord('customer', customerId);

            //if (Transaction.TransactionSiteID == 'US') {
            //    // USD
            //
            //    //1	USD	USD	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
            //    //2	GBP	GBP	No	No	Yes
            //    //3	CAD	CAD	No	No	Yes
            //    //4	EUR	EUR	No	No	Yes
            //    //5	CNY	CNY	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
            //    //6	AUD	AUD	No	No	Yes
            //    //7	HKD	HKD	No	No	Yes
            //    //8	INR	INR	No	No	Yes
            //    //9	MYR	MYR	No	No	Yes
            //    //10	PHP	PHP	No	No	Yes
            //    //11	PLN	PLN	No	No	Yes
            //    //12	RUB	RUB	No	No	Yes
            //    //13	SGD	SGD	No	No	Yes
            //    //14	CHF	CHF	No	No	Yes
            //    //15	JPY	JPY	No	No	Yes
            //
            //    existingCustomerRecord.setFieldValue('currency', 1);
            //}
            existingCustomerRecord.setFieldValue('currency', 5); // 这里总是人民币

            var nsCurrency = getNSCurrency(Order);

            var addFlag = true;
            var currencyLineCount = existingCustomerRecord.getLineItemCount('currency');
            for (var line = 1; line <= currencyLineCount; line++) {
                var cur = existingCustomerRecord.getLineItemValue('currency', 'currency', line);
                if (cur == nsCurrency.INTERNALID) {
                    addFlag = false;
                    break;
                }
            }
            if (addFlag) {
                existingCustomerRecord.selectNewLineItem('currency');
                existingCustomerRecord.setCurrentLineItemValue('currency', 'currency', nsCurrency.INTERNALID);
                existingCustomerRecord.commitLineItem('currency');
            }

            if (_BillingAddress == null) {

                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log('Set new address _ShippingAddress for existing customer');
                    setAddressLine(existingCustomerRecord, _ShippingAddress);
                } else {
                    existingCustomerRecord.setLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber, 'T');
                    existingCustomerRecord.setLineItemValue('addressbook', 'defaultbilling', existingShippingAddress.linenumber, 'T');
                }
            } else {

                // 因为是 发往国外的 ， 这里 bill Address 和ship Address 肯定是不一样， 否则参考 Noure script

                // Billing address
                var existingBillingAddress = lookupExistingAddress(existingCustomerRecord, _BillingAddress);
                if (existingBillingAddress.addressId == null) {
                    _log('Set new address _BillingAddress for existing customer');
                    setAddressLine(existingCustomerRecord, _BillingAddress, 'defaultbilling');
                } else {
                    if (existingCustomerRecord.getLineItemValue('addressbook', 'defaultbilling', existingBillingAddress.linenumber) !== 'T') {
                        existingCustomerRecord.setLineItemValue('addressbook', 'defaultbilling', existingBillingAddress.linenumber, 'T');
                    }
                }

                // Shipping address
                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log('Set new address existingShippingAddress2222 for existing customer');
                    setAddressLine(existingCustomerRecord, _ShippingAddress, 'defaultshipping');
                } else {
                    if (existingCustomerRecord.getLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber) !== 'T') {
                        existingCustomerRecord.setLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber, 'T');
                    }
                }
            }

            existingCustomerRecord.setFieldValue('isperson', 'T');

            var first_name = Transaction.Buyer.UserFirstName || '*';
            existingCustomerRecord.setFieldValue('firstname', first_name);
            existingCustomerRecord.setFieldValue('lastname', Transaction.Buyer.UserLastName);

            if (existingCustomerRecord.getFieldValue('phone') && ShippingAddress.Phone != existingCustomerRecord.getFieldValue('phone')) {
                existingCustomerRecord.setFieldValue('altphone', existingCustomerRecord.getFieldValue('phone'));
                existingCustomerRecord.setFieldValue('phone', ShippingAddress.Phone);
            } else {
                existingCustomerRecord.setFieldValue('phone', ShippingAddress.Phone);
            }

            existingCustomerRecord.setFieldValue('taxable', 'F');
            id = nlapiSubmitRecord(existingCustomerRecord, true);

            // customerRecord = nlapiLoadRecord('customer');
            // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
            // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));
        }
    } else {

        nlapiSendEmail(530, 'allan@zakeusa.com', '[EBAY_ORDER_NOTIES] ID:' + Order.OrderID, 'THE ORDER NO EMAIL.' + JSON.stringify(Order));
        id = createCustomerRecord(Order, Transaction, ShippingAddress, _ShippingAddress, _email);
    }

    return {
        id: id,
        email: _email
    };

}

//function setAddressLine(customer, addressObject, defaultField) {
//    customer.selectNewLineItem('addressbook');
//
//    for (var name in addressObject) {
//        customer.setCurrentLineItemValue('addressbook', name, addressObject[name]);
//    }
//
//    if (defaultField) customer.setCurrentLineItemValue('addressbook', defaultField, 'T');
//
//    customer.commitLineItem('addressbook');
//}
function setAddressLine(customer, addressObject, specificField) {
    customer.selectNewLineItem('addressbook');

    for (var name in addressObject) {
        customer.setCurrentLineItemValue('addressbook', name, addressObject[name]);
    }

    if (specificField) {
        customer.setCurrentLineItemValue('addressbook', specificField, 'T');
    } else {
        customer.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
        customer.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
    }

    customer.commitLineItem('addressbook');
}

function lookupExistingAddress(customer, addressObject /*, defaultField */) {

    var addressId = null;
    var linenumber = null;

    var lineCount = customer.getLineItemCount('addressbook');
    if (lineCount) {
        for (var line = 1; line <= lineCount; line++) {

            var address = {
                'country': customer.getLineItemValue('addressbook', 'country', line),
                'state': customer.getLineItemValue('addressbook', 'state', line),
                'city': customer.getLineItemValue('addressbook', 'city', line),
                'zip': customer.getLineItemValue('addressbook', 'zip', line),
                'addressee': customer.getLineItemValue('addressbook', 'addressee', line),
                'addr1': customer.getLineItemValue('addressbook', 'addr1', line),
                'addr2': customer.getLineItemValue('addressbook', 'addr2', line),
                'phone': customer.getLineItemValue('addressbook', 'phone', line)
            };

            if (exactlySame(address, addressObject)) {

                addressId = customer.getLineItemValue('addressbook', 'id', line);
                linenumber = line;

                // : 这段基本没啥用， 准备remove呢
                //if (defaultField) {
                //    if (customer.getLineItemValue('addressbook', defaultField, line) !== 'T') {
                //        customer.setLineItemValue('addressbook', defaultField, line, 'T');
                //        // nlapiSubmitRecord(customer, true);
                //    }
                //}

                break;
            }
        }
    }


    return {
        addressId: addressId,
        linenumber: linenumber
    };

}

function _fieldProcess(key, value) {
    if (key == 'phone') {
        return trimPhone(value);
    } else {
        if (!value) value = '';
        return value;
    }
}

function exactlySame(address, orderAddress) {

    for (var key in address) {

        var field1 = address[key];
        field1 = _fieldProcess(key, field1);

        if (orderAddress.hasOwnProperty(key)) {
            var field2 = orderAddress[key];
            field2 = _fieldProcess(key, field2);

            if (field1 !== field2) {
                _log('different in ' + key);
                return false;
            }

        } else {

            _log('Not in ' + key);
            return false;
        }
    }

    return true;

}

function trimPhone(phone) {
    if (!phone) {
        phone = '';
    }

    if (typeof phone !== 'string') phone = phone.toString();

    var regx = new RegExp('[^0-9]', 'g');
    phone = phone.replace(regx, '');

    return phone;

}