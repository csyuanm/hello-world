/*!
 // Allan Hou
 // allan@zakeusa.com
 // Skype: allan.houchengli
 //
 // Purpose: add the preview link into item record
 //
 // Revisions:
 * @param type
 * @param form
 * @param request
 */
function beforeLoad(type, form, request) {
    var subs = nlapiGetFieldValue('subsidiary');
    if (subs == Subsidiaries.ShenzhenB2B) {
        if (type == 'create') {
            var purchasedescription = nlapiGetFieldValue('purchasedescription');
            if (purchasedescription) {
                nlapiSetFieldValue('salesdescription', purchasedescription);
            }
        }
    }

}

function beforeSubmit(type) {
    //var subs = nlapiGetFieldValue('subsidiary');
    //if (subs == Subsidiaries.ShenzhenB2B) {
    //    if (type == 'edit' || type == 'create') {
    //        nlapiSetFieldValue('subsidiary', Subsidiaries.ZakeUSAHolding);
    //        nlapiSetFieldValue('includechildren', 'T');
    //    }
    //}
}

function handlerEmail(handlerField) {
    //var ff = nlapiGetFieldValue(handlerField);
    //var oldRecord = nlapiGetOldRecord();
    //var newRecord = nlapiGetNewRecord();
    //var handlerNew = newRecord.getFieldValue(handlerField);
    //var handlerOld = oldRecord.getFieldValue(handlerField);
    //_log("ff", ff);
    //_log("handlerNew", handlerNew);
    //_log("handlerOld", handlerOld);
    //if (handlerNew) {
    //    if (handlerNew != handlerOld) {
    //        _sendEmail(handlerNew, "Item " + nlapiGetFieldValue("itemid") + " need to post to marketplace.", "Please go to the item record and prep to posting");
    //    }
    //}

    var handler = nlapiGetFieldValue(handlerField);
    _log("handler", handler);
    if (handler) {
        _sendEmail(handler,
            "Item " + nlapiGetFieldValue("itemid") + " need to post to marketplace.",
            "Please go to the item record and prep to posting");

    }
}

function afterSubmit(type) {

    var subs = nlapiGetFieldValue('subsidiary');
    if (subs == Subsidiaries.TaiwuInternational) {
        if (type == 'create') {
            handlerEmail("custitem_ebay_handler");
            handlerEmail("custitem_wish_handler");
            handlerEmail("custitem_amazon_handler");
        } else if (type == 'edit') {
            var dis_value = nlapiGetFieldValue('custitem_internal_marketing_position');
            if (dis_value) {
                if (_isChanged('custitem_internal_marketing_position')) {
                    var search = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
                        new nlobjSearchFilter('custrecord_ebay_feed_item', null, 'is', nlapiGetRecordId())
                    ]);
                    if (search != null) {
                        for (var i = 0; i < search.length; i++) {
                            nlapiSubmitField(search[i].getRecordType(), search[i].getId(), 'custrecord_ef_cease_when_sold_out', dis_value);
                        }
                    }
                }

            }
        }
    }


}

function _isChanged(watchFields) {

    var oldRecord = nlapiGetOldRecord();
    var is_changed = false;

    for (var j = 0; j < watchFields.length; j++) {
        var field = watchFields[j];
        var oldValue = oldRecord.getFieldValue(field);
        var currentValue = nlapiGetFieldValue(field);
        if (!oldValue) oldValue = null;
        if (!currentValue) currentValue = null;
        if (oldValue !== currentValue) {
            is_changed = true;
            break;
        }
    }

    return is_changed;
}