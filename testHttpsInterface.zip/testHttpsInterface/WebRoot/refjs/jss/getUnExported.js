function getUnExported(){
  var filter = new Array();
  filter[0] = new nlobjSearchFilter('custbody_exported', null, 'is', 'F');
  var x = nlapiSearchRecord('salesorder', null, filter);
  return x;
}
