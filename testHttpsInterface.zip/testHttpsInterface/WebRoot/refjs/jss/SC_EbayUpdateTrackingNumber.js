var DEPLOYMENT_ID = nlapiGetContext().getDeploymentId();

_audit("DEPLOYMENT_ID", DEPLOYMENT_ID);

function run() {
    if (DEPLOYMENT_ID == "customdeploy_sc_ebay_tracking_manually") {
        DEPLOYMENT_ID = "customdeploy_sc_update_ebay_tracking";
    }
    var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [ new nlobjSearchFilter("custrecord_ea_subsidiary", null, "is", Subsidiaries.ZakeInternational), new nlobjSearchFilter("custrecord_acc_deployment_upload_track", null, "is", DEPLOYMENT_ID) ], [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_ebay_api_token"), new nlobjSearchColumn("custrecord_ebay_global_site_access") ]);
    ebayAccountSearch.forEach(function(searchResult) {
        var token = searchResult.getValue("custrecord_ebay_api_token");
        var ebayAccountId = searchResult.getId();
        var ebayAccountName = searchResult.getValue("name");
        _log(searchResult.getValue("name") + " -- " + ebayAccountId, token);
        uploadTrackingNumber(ebayAccountId, token, ebayAccountName);
        trackSplitOrders(ebayAccountId, token, ebayAccountName);
    });
}

function uploadTrackingNumber(ebayAccountId, token, ebayAccountName) {
    var search = nlapiLoadSearch(null, "customsearch461");
    search.addFilters([ new nlobjSearchFilter("custbody_linked_ebay_account", "createdfrom", "is", ebayAccountId) ]);
    var resultSet = search.runSearch();
    var searchResults = resultSet.getResults(0, 1e3);
    if (searchResults.length) {
        var len = searchResults.length;
        _log("updateWooTracking--- Size: ", len);
        var updateList = [];
        for (var i = 0; i < searchResults.length; i++) {
            try {
                var ebayOrderId = searchResults[i].getValue("custbody_ebay_order_id", "createdfrom");
                if (ebayOrderId) {
                    var shipmethod = searchResults[i].getText("shipmethod");
                    var carrierCode = getShippingCarrierCode(shipmethod);
                    var trackingnumbers = searchResults[i].getValue("trackingnumbers");
                    trackingnumbers = trackingnumbers.split("<BR>");
                    var txml = trackingnumbers.map(function(tnumber) {
                        var tracking_xml = "" + "    <ShipmentTrackingDetails>" + "      <ShippingCarrierUsed>" + carrierCode + "</ShippingCarrierUsed>" + "      <ShipmentTrackingNumber>" + tnumber + "</ShipmentTrackingNumber>" + "    </ShipmentTrackingDetails>";
                        return tracking_xml;
                    }).join("");
                    var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<CompleteSaleRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "    <eBayAuthToken>" + token + "</eBayAuthToken>", "  </RequesterCredentials>", "  <WarningLevel>High</WarningLevel>", "  <OrderID>" + ebayOrderId + "</OrderID>", "  <Shipped>true</Shipped>", "  <Shipment>", txml, "  </Shipment>", "</CompleteSaleRequest>" ].map(function(node) {
                        return node.trim();
                    }).join("");
                    _log("xml", xml);
                    var header = extend(EbayRequest.headers, {
                        "X-EBAY-API-SITEID": "0",
                        "X-EBAY-API-CALL-NAME": "CompleteSale",
                        "X-EBAY-API-COMPATIBILITY-LEVEL": "925"
                    });
                    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
                    response = new X2JS().xml_str2json(response.getBody());
                    _log("response", response);
                    var soRec = nlapiLoadRecord("salesorder", searchResults[i].getValue("createdfrom"));
                    if (response.CompleteSaleResponse.Ack == "Success") {
                        soRec.setFieldValue("custbody_script_memo", "Ebay tracking number synchronized");
                        soRec.setFieldValue("custbody_has_issues", "F");
                        soRec.setFieldValue("custbody_tracking_number_sync", "T");
                    } else {
                        var smemo = JSON.stringify(response.CompleteSaleResponse);
                        if (smemo.length > 300) smemo = smemo.substring(0, 300);
                        soRec.setFieldValue("custbody_script_memo", smemo);
                        soRec.setFieldValue("custbody_has_issues", "T");
                        _log_email("CompleteSaleResponse is error " + ebayOrderId, JSON.stringify(response.CompleteSaleResponse));
                    }
                    nlapiSubmitRecord(soRec, true);
                    updateList.push(searchResults[i].getValue("custbody_storefront_order", "createdfrom"));
                } else {
                    _log_email("Search 1 not found ebay id on upload tracking number", searchResults[i].getId());
                }
            } catch (e) {
                processException(e);
            }
            checkGovernance();
        }
        _sendEmail("leo@zake.com", ebayAccountName + " 标准单 Tracking Updated! (" + updateList.length + ")", JSON.stringify(updateList, null, 2));
    } else {}
}

function trackSplitOrders(ebayAccountId, token, ebayAccountName) {
    var search = nlapiLoadSearch(null, "2717");
    search.addFilters([ new nlobjSearchFilter("custbody_linked_ebay_account", null, "is", ebayAccountId) ]);
    var resultSet = search.runSearch();
    var searchResults = resultSet.getResults(0, 1e3);
    if (searchResults.length) {
        var len = searchResults.length;
        _log("trackSplitOrders Size: ", len);
        var updateList = [];
        var single = [], combo = [];
        for (var j = 0; j < len; j++) {
            var searchResult = searchResults[j];
            var ebayOrderId = searchResult.getValue("custbody_ebay_order_id");
            var ItemID = searchResult.getValue("custcol_ebay_item_id");
            var TransactionID = searchResult.getValue("custcol_ebay_transaction_id");
            var OrderLineItemID = ItemID + "-" + TransactionID;
            var trackingnumbers = searchResult.getValue("trackingnumbers");
            var status = searchResult.getValue("status");
            if (ebayOrderId == OrderLineItemID) {
                single.push(searchResult);
            } else {
                if (trackingnumbers) {
                    if (status == "pendingBilling" || status == "fullyBilled") {
                        combo.push(searchResult);
                    }
                }
            }
        }
        _log("report", "single: " + single.length + " combo: " + combo.length);
        _trackSingle(token, single, updateList);
        for (var a = 0; a < combo.length; a++) {
            _trackCombo(token, combo[a], updateList);
            checkGovernance();
        }
        if (updateList.length) {
            _sendEmail("leo@zake.com", ebayAccountName + " Tracking Updated: 分单(" + updateList.length + ")", JSON.stringify(updateList, null, 2));
        }
    }
}

function _trackSingle(token, searchResults, updateList) {
    _log("_trackSingle");
    if (searchResults.length) {
        var len = searchResults.length;
        _log("update splitted order --- Size: ", len);
        var ebayOrderGroup = {};
        for (var j = 0; j < len; j++) {
            var searchResult = searchResults[j];
            var ebayOrderId = searchResult.getValue("custbody_ebay_order_id");
            if (ebayOrderId) {
                if (ebayOrderGroup.hasOwnProperty(ebayOrderId)) {
                    ebayOrderGroup[ebayOrderId].id.push(searchResult.getId());
                    ebayOrderGroup[ebayOrderId].info.push({
                        shipmethod: searchResult.getText("shipmethod"),
                        trackingnumbers: searchResult.getValue("trackingnumbers"),
                        status: searchResult.getValue("status")
                    });
                } else {
                    ebayOrderGroup[ebayOrderId] = {
                        id: [ searchResult.getId() ],
                        info: [ {
                            shipmethod: searchResult.getText("shipmethod"),
                            trackingnumbers: searchResult.getValue("trackingnumbers"),
                            status: searchResult.getValue("status")
                        } ]
                    };
                }
            }
        }
        _log("ebayOrderGroup", ebayOrderGroup);
        for (var eid in ebayOrderGroup) {
            var salesOrder = ebayOrderGroup[eid];
            var isOK = salesOrder.info.every(function(item) {
                return (item.status == "pendingBilling" || item.status == "fullyBilled") && item.trackingnumbers;
            });
            _log("isOK", isOK);
            if (isOK) {
                try {
                    _log("EBAY ORDER ID-------------", eid);
                    var txml = "";
                    salesOrder.info.forEach(function(info) {
                        var track_code = getShippingCarrierCode(info.shipmethod);
                        var trackingnumbers = info.trackingnumbers;
                        trackingnumbers = trackingnumbers.split("<BR>");
                        trackingnumbers.forEach(function(track_number) {
                            txml += "" + "    <ShipmentTrackingDetails>" + "      <ShippingCarrierUsed>" + track_code + "</ShippingCarrierUsed>" + "      <ShipmentTrackingNumber>" + track_number + "</ShipmentTrackingNumber>" + "    </ShipmentTrackingDetails>";
                        });
                    });
                    var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<CompleteSaleRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "    <eBayAuthToken>" + token + "</eBayAuthToken>", "  </RequesterCredentials>", "  <WarningLevel>High</WarningLevel>", "  <OrderID>" + eid + "</OrderID>", "  <Shipped>true</Shipped>", "  <Shipment>", txml, "  </Shipment>", "</CompleteSaleRequest>" ].map(function(node) {
                        return node.trim();
                    }).join("");
                    _log("xml", xml);
                    var header = extend(EbayRequest.headers, {
                        "X-EBAY-API-SITEID": "0",
                        "X-EBAY-API-CALL-NAME": "CompleteSale",
                        "X-EBAY-API-COMPATIBILITY-LEVEL": "925"
                    });
                    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
                    response = new X2JS().xml_str2json(response.getBody());
                    _log("response", response);
                    if (response.CompleteSaleResponse.Ack == "Success") {
                        salesOrder.id.forEach(function(_id) {
                            var soRec = nlapiLoadRecord("salesorder", _id);
                            soRec.setFieldValue("custbody_script_memo", "Ebay tracking number synchronized");
                            soRec.setFieldValue("custbody_has_issues", "F");
                            soRec.setFieldValue("custbody_tracking_number_sync", "T");
                            nlapiSubmitRecord(soRec, true);
                        });
                    } else {
                        _log_email("CompleteSaleResponse is error " + ebayOrderId, ebayOrderId);
                    }
                    updateList.push(eid);
                } catch (e) {
                    processException(e);
                }
                checkGovernance();
            }
        }
    }
}

function _trackCombo(token, searchResult, updateList) {
    _log("_trackCombo");
    var soId = searchResult.getId();
    var ebayOrderId = searchResult.getValue("custbody_ebay_order_id");
    var ItemID = searchResult.getValue("custcol_ebay_item_id");
    var TransactionID = searchResult.getValue("custcol_ebay_transaction_id");
    var OrderLineItemID = ItemID + "-" + TransactionID;
    var shipmethod = searchResult.getText("shipmethod");
    var track_code = getShippingCarrierCode(shipmethod);
    var trackingnumbers = searchResult.getValue("trackingnumbers");
    try {
        _log("EBAY ORDER ID-------------", ebayOrderId);
        var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<CompleteSaleRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "    <eBayAuthToken>" + token + "</eBayAuthToken>", "  </RequesterCredentials>", "  <WarningLevel>High</WarningLevel>", "  <Shipped>true</Shipped>", "  <ItemID>" + ItemID + "</ItemID>", "  <TransactionID>" + TransactionID + "</TransactionID>", "  <Shipment>", "    <ShipmentTrackingDetails>", "      <ShippingCarrierUsed>" + track_code + "</ShippingCarrierUsed>", "      <ShipmentTrackingNumber>" + trackingnumbers + "</ShipmentTrackingNumber>", "    </ShipmentTrackingDetails>", "  </Shipment>", "</CompleteSaleRequest>" ].map(function(node) {
            return node.trim();
        }).join("");
        _log("xml", xml);
        var header = extend(EbayRequest.headers, {
            "X-EBAY-API-SITEID": "0",
            "X-EBAY-API-CALL-NAME": "CompleteSale",
            "X-EBAY-API-COMPATIBILITY-LEVEL": "925"
        });
        var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
        response = new X2JS().xml_str2json(response.getBody());
        _log("response", response);
        if (response.CompleteSaleResponse.Ack == "Success") {
            var soRec = nlapiLoadRecord("salesorder", soId);
            soRec.setFieldValue("custbody_script_memo", "Ebay tracking number is tracked.");
            soRec.setFieldValue("custbody_has_issues", "F");
            soRec.setFieldValue("custbody_tracking_number_sync", "T");
            nlapiSubmitRecord(soRec, true);
        } else {
            _log_email("CompleteSaleResponse Ack not success. " + ebayOrderId, JSON.stringify(response, null, 2));
        }
        updateList.push(soId + " " + response.CompleteSaleResponse.Ack);
    } catch (e) {
        processException(e);
    }
}

function getShippingCarrierCode(shipmethod) {
    shipmethod = shipmethod.toUpperCase();
    if (shipmethod.indexOf("USPS") != -1) {
        return "USPS";
    } else if (shipmethod.indexOf("UPS") != -1) {
        return "UPS";
    } else if (shipmethod.indexOf("FedEx") != -1) {
        return "FedEx";
    } else if (shipmethod.indexOf("DHL") != -1) {
        return "DHL";
    } else {
        return "Other";
    }
}

function updateTrackingNumber(token, ShippingCarrierUsed, trackingnumber) {}