var TBD =	6;
var Standard = 1;
var ThreeDay = 2;
var TwoDay = 3;
var NextDay = 4;
var International = 5;


function import(dataIn){
  var shipping = 37625;  // internal id of shipping item
  var assembly = 40258;  // internal id of assembly item
  var id = getID(dataIn);
  var address = getAddress(id, dataIn.shipping);
  var items = dataIn.items;
  var rec = nlapiCreateRecord('salesorder');
  rec.setFieldValue('entity', id);
  rec.setFieldValue('location', 2);  // 2 = South Bend-Primary
  rec.setFieldValue('custbody_storefront', dataIn.storefront);
  rec.setFieldValue('custbody_marketplace', dataIn.market);
  rec.setFieldValue('subsidiary', 1); // 1 = zake usa holding
  rec.setFieldValue('memo', 'Import from Peter');
  rec.setFieldValue('customform', 118);
  if(dataIn.ship_via == "Ground"){
    rec.setFieldValue('custbody_market_ship_serv_lvl', Standard);
    rec.setFieldValue("orderstatus", "B");
  }else if (dataIn.ship_via == "2 Days") {
    rec.setFieldValue('custbody_market_ship_serv_lvl', TwoDay);
    rec.setFieldValue("orderstatus", "B");
  }else if (dataIn.ship_via == "3 Days") {
    rec.setFieldValue('custbody_market_ship_serv_lvl', ThreeDay);
    rec.setFieldValue("orderstatus", "B");
  }else if (dataIn.ship_via == "International") {
    rec.setFieldValue('custbody_market_ship_serv_lvl', International);
    rec.setFieldValue("orderstatus", "A");
  }else if (dataIn.ship_via == "Next Day") {
    rec.setFieldValue('custbody_market_ship_serv_lvl', NextDay);
    rec.setFieldValue("orderstatus", "A");
  }else{
    rec.setFieldValue('custbody_market_ship_serv_lvl', TBD);
    rec.setFieldValue("orderstatus", "A");
  }
  for(var i = 0; i < items.length; i++){
    var single = items[i];
    if(single.description == "Sales Tax"){
      rec.setFieldValue('istaxable', 'T');
      rec.setFieldValue('taxitem', 10);
      continue;
    }else if(single.description == "Freight Charges"){
      rec.selectNewLineItem('item');
      rec.setCurrentLineItemValue('item', 'item', shipping);
      rec.setCurrentLineItemValue('item', 'quantity', 1);
      rec.setCurrentLineItemValue('item', 'price', '-1');
      rec.setCurrentLineItemValue('item', 'rate', single.price);
      rec.commitLineItem('item');
      continue;
    }else if(single.description == "assembly"){
      rec.selectNewLineItem('item');
      rec.setCurrentLineItemValue('item', 'item', assembly);
      rec.setCurrentLineItemValue('item', 'quantity', 1);
      rec.setCurrentLineItemValue('item', 'price', '-1');
      rec.setCurrentLineItemValue('item', 'rate', single.price);
      rec.commitLineItem('item');
      continue;
    }else{
      var filter = new Array();
      filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', single.item_id);
      var item = nlapiSearchRecord('inventoryitem', null, filter);
      if(item == null){
        return "Error: Item not found: "+JSON.stringify(single);
      }
      rec.selectNewLineItem('item');
      rec.setCurrentLineItemValue('item', 'item', item[0].id);
      rec.setCurrentLineItemValue('item', 'quantity', single.qty);
      rec.setCurrentLineItemValue('item', 'price', '-1');
      rec.setCurrentLineItemValue('item', 'rate', single.price);
      rec.commitLineItem('item');
    }
  }
  nlapiLogExecution('DEBUG', 'rec', JSON.stringify(rec));
  var submited = nlapiSubmitRecord(rec);
  var obj = {};
  obj.salesOrder = {
    id: submited,
    type: 'salesOrder'
  };
  /*var int = parseInt(submited);  // pending fullfilment is fine, and look at raj's email
  var cash = nlapiTransformRecord('salesorder', int, 'cashsale');
  var cashID = nlapiSubmitRecord(cash, true);
  obj.cash = {
   id: cashID,
   type: 'cashorder'
 };*/
  return obj;
}


function getID(dataIn){
  var filter = new Array();
  filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.email);
  var x = nlapiSearchRecord('customer', null, filter);
  if(x == null){
    var id = createCustomer(dataIn);
    return id;
  }else{
    var id = x[0].id;
    return id;
  }
}

function getAddress(id, shipping){
  var address = null;
  var record = nlapiLoadRecord('customer', id);
  var count = record.getLineItemCount('addressbook');
  for(var i = 0; i < count; i++){
    var addr = record.getLineItemValue('addressbook', 'addr1', i+1);
    if(addr == shipping.addr1){
      address = i+1;
    }
  }
  if(address == null){
    record.selectNewLineItem('addressbook');
    record.setCurrentLineItemValue('addressbook', 'addr1', shipping.ship_addr1);
    record.setCurrentLineItemValue('addressbook', 'addr2', shipping.ship_addr2);
    record.setCurrentLineItemValue('addressbook', 'city', shipping.ship_city);
    record.setCurrentLineItemValue('addressbook', 'state', shipping.ship_state);
    record.setCurrentLineItemValue('addressbook', 'zip', shipping.ship_zip);
    record.commitLineItem('addressbook');
    nlapiSubmitRecord('customer', record);
    address = count + 1;
  }
  return address;
}


function createCustomer(customer){
  var cust = nlapiCreateRecord('customer');
  var billing = customer.billing;
  var shipping = customer.shipping;
  cust.setFieldValue('isperson', 'T');
  cust.setFieldValue('subsidiary', 1); // 1 = zake usa holding
  cust.setFieldValue('firstname', customer.firstname);
  cust.setFieldValue('lastname', customer.lastname);
  cust.setFieldValue('email', customer.email);
  cust.setFieldValue('phone', customer.phone);
  cust.selectNewLineItem('addressbook');
  cust.setCurrentLineItemValue('addressbook', 'addr1', customer.shipping.addr1);
  cust.setCurrentLineItemValue('addressbook', 'addr2', customer.shipping.addr2);
  cust.setCurrentLineItemValue('addressbook', 'city', customer.shipping.city);
  cust.setCurrentLineItemValue('addressbook', 'state', customer.shipping.state);
  cust.setCurrentLineItemValue('addressbook', 'zip', customer.shipping.zip);
  cust.commitLineItem('addressbook');
  if(customer.billing.addr1 != customer.shipping.addr1){
    cust.selectNewLineItem('addressbook');
    cust.setCurrentLineItemValue('addressbook', 'addr1', customer.billing.addr1);
    cust.setCurrentLineItemValue('addressbook', 'addr2', customer.billing.addr2);
    cust.setCurrentLineItemValue('addressbook', 'city', customer.billing.city);
    cust.setCurrentLineItemValue('addressbook', 'state', customer.billing.state);
    cust.setCurrentLineItemValue('addressbook', 'zip', customer.billing.zip);
    cust.commitLineItem('addressbook');
  }
  var id = nlapiSubmitRecord(cust);
  return id;
}


function beforSubmit(){
  nlapiLogExecution('DEBUG', 'beforSubmit', 'befor submit');
}

function beforLoad(){
  nlapiLogExecution('DEBUG', 'beforLoad', 'befor load');
}

function after(){
  nlapiLogExecution('DEBUG', 'after', ' after');
}
