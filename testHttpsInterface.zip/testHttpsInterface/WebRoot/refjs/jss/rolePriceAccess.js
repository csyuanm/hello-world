/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       14 Mar 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){
	
    try{ 
    	var context = nlapiGetContext();
		var role = context.getRole();
		
		if(type == "edit"){
			
			nlapiLogExecution('Audit','In edit mode','<<-done->>')
			
			nlapiLogExecution('Audit','role id',role);
			if(role != "1094"){
				
				var field1 = form.getField('custitem_amazon_bco_fba_bp');
				field1.setDisplayType('disabled');
				var field2 = form.getField('custitem_amazon_bco_mfn_bp');
				field2.setDisplayType('disabled');
				
			}
			
            
			
			
		}
		
		if(type == 'view'){
			
			if(role == "1162"){
				
				
				
				
			}
			
		}
    }catch(e){
    	nlapiLogExecution('Debug','error in price Access script',e);
    }
	
}
