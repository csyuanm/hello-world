/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       03 Jul 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function setFieldDisplayUE(type, form, request){
     
	if (type == 'edit') {
		
		var role = nlapiGetRole();
		
		
			nlapiLogExecution('Debug','role',role);
			var purchasePriceFld = form.getField('cost');	
			var proposedRMBPriceFld = form.getField('custitem_proposed_unit_cost_rmb');
			var proposedUnitCostFld = form.getField('custitem_proposed_unit_cost');
			
			proposedRMBPriceFld.setMandatory(false);
			proposedUnitCostFld.setMandatory(false);
			purchasePriceFld.setDisplayType('normal').setMandatory(false);//.setDisplayType('inline')
			
		
		
		
	}
	
}
