/*!
 * accounting.js v0.4.1, copyright 2014 Open Exchange Rates, MIT license, http://openexchangerates.github.io/accounting.js
 */
(function(p, z) {
    function q(a) {
        return !!("" === a || a && a.charCodeAt && a.substr);
    }
    function m(a) {
        return u ? u(a) : "[object Array]" === v.call(a);
    }
    function r(a) {
        return "[object Object]" === v.call(a);
    }
    function s(a, b) {
        var d, a = a || {}, b = b || {};
        for (d in b) b.hasOwnProperty(d) && null == a[d] && (a[d] = b[d]);
        return a;
    }
    function j(a, b, d) {
        var c = [], e, h;
        if (!a) return c;
        if (w && a.map === w) return a.map(b, d);
        for (e = 0, h = a.length; e < h; e++) c[e] = b.call(d, a[e], e, a);
        return c;
    }
    function n(a, b) {
        a = Math.round(Math.abs(a));
        return isNaN(a) ? b : a;
    }
    function x(a) {
        var b = c.settings.currency.format;
        "function" === typeof a && (a = a());
        return q(a) && a.match("%v") ? {
            pos: a,
            neg: a.replace("-", "").replace("%v", "-%v"),
            zero: a
        } : !a || !a.pos || !a.pos.match("%v") ? !q(b) ? b : c.settings.currency.format = {
            pos: b,
            neg: b.replace("%v", "-%v"),
            zero: b
        } : a;
    }
    var c = {
        version: "0.4.1",
        settings: {
            currency: {
                symbol: "$",
                format: "%s%v",
                decimal: ".",
                thousand: ",",
                precision: 2,
                grouping: 3
            },
            number: {
                precision: 0,
                grouping: 3,
                thousand: ",",
                decimal: "."
            }
        }
    }, w = Array.prototype.map, u = Array.isArray, v = Object.prototype.toString, o = c.unformat = c.parse = function(a, b) {
        if (m(a)) return j(a, function(a) {
            return o(a, b);
        });
        a = a || 0;
        if ("number" === typeof a) return a;
        var b = b || ".", c = RegExp("[^0-9-" + b + "]", [ "g" ]), c = parseFloat(("" + a).replace(/\((.*)\)/, "-$1").replace(c, "").replace(b, "."));
        return !isNaN(c) ? c : 0;
    }, y = c.toFixed = function(a, b) {
        var b = n(b, c.settings.number.precision), d = Math.pow(10, b);
        return (Math.round(c.unformat(a) * d) / d).toFixed(b);
    }, t = c.formatNumber = c.format = function(a, b, d, i) {
        if (m(a)) return j(a, function(a) {
            return t(a, b, d, i);
        });
        var a = o(a), e = s(r(b) ? b : {
            precision: b,
            thousand: d,
            decimal: i
        }, c.settings.number), h = n(e.precision), f = 0 > a ? "-" : "", g = parseInt(y(Math.abs(a || 0), h), 10) + "", l = 3 < g.length ? g.length % 3 : 0;
        return f + (l ? g.substr(0, l) + e.thousand : "") + g.substr(l).replace(/(\d{3})(?=\d)/g, "$1" + e.thousand) + (h ? e.decimal + y(Math.abs(a), h).split(".")[1] : "");
    }, A = c.formatMoney = function(a, b, d, i, e, h) {
        if (m(a)) return j(a, function(a) {
            return A(a, b, d, i, e, h);
        });
        var a = o(a), f = s(r(b) ? b : {
            symbol: b,
            precision: d,
            thousand: i,
            decimal: e,
            format: h
        }, c.settings.currency), g = x(f.format);
        return (0 < a ? g.pos : 0 > a ? g.neg : g.zero).replace("%s", f.symbol).replace("%v", t(Math.abs(a), n(f.precision), f.thousand, f.decimal));
    };
    c.formatColumn = function(a, b, d, i, e, h) {
        if (!a) return [];
        var f = s(r(b) ? b : {
            symbol: b,
            precision: d,
            thousand: i,
            decimal: e,
            format: h
        }, c.settings.currency), g = x(f.format), l = g.pos.indexOf("%s") < g.pos.indexOf("%v") ? !0 : !1, k = 0, a = j(a, function(a) {
            if (m(a)) return c.formatColumn(a, f);
            a = o(a);
            a = (0 < a ? g.pos : 0 > a ? g.neg : g.zero).replace("%s", f.symbol).replace("%v", t(Math.abs(a), n(f.precision), f.thousand, f.decimal));
            if (a.length > k) k = a.length;
            return a;
        });
        return j(a, function(a) {
            return q(a) && a.length < k ? l ? a.replace(f.symbol, f.symbol + Array(k - a.length + 1).join(" ")) : Array(k - a.length + 1).join(" ") + a : a;
        });
    };
    if ("undefined" !== typeof exports) {
        if ("undefined" !== typeof module && module.exports) exports = module.exports = c;
        exports.accounting = c;
    } else "function" === typeof define && define.amd ? define([], function() {
        return c;
    }) : (c.noConflict = function(a) {
        return function() {
            p.accounting = a;
            c.noConflict = z;
            return c;
        };
    }(p.accounting), p.accounting = c);
})(this);

if (typeof module !== "undefined" && module.exports) {} else if (typeof this.alert == "function") {
    if (!window.console) {
        window.console = {
            log: function() {}
        };
    }
} else {}

function processException(e) {
    var code, message;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = "nlobjError";
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + e.getStackTrace().join(", ");
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (this.alert) alert("Something is wrong! Please concat IT team for help. " + code + ": " + message);
    nlapiSendEmail(-5, "59532543@qq.com", code, message);
    return {
        code: code,
        message: message
    };
}

var LOGGING = {
    maxLength: 100,
    logList: [],
    add: function(message) {
        if (typeof message == "object") {
            message = JSON.stringify(message);
        }
        var list = LOGGING.logList;
        list.push(message);
        var maxLength = LOGGING.maxLength;
        if (list.length >= maxLength) {
            var outLength = list.length - maxLength;
            list.splice(0, outLength);
        }
    },
    clear: function() {
        LOGGING.logList = [];
    },
    getDetail: function() {
        return LOGGING.logList.join("\r\n");
    }
};

function _log(title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 2);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
        } else {
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            console.log(message);
        }
    }
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

function X2JS(config) {
    "use strict";
    var VERSION = "1.1.5";
    config = config || {};
    initConfigDefaults();
    initRequiredPolyfills();
    function initConfigDefaults() {
        if (config.escapeMode === undefined) {
            config.escapeMode = true;
        }
        config.attributePrefix = config.attributePrefix || "_";
        config.arrayAccessForm = config.arrayAccessForm || "none";
        config.emptyNodeForm = config.emptyNodeForm || "text";
        if (config.enableToStringFunc === undefined) {
            config.enableToStringFunc = true;
        }
        config.arrayAccessFormPaths = config.arrayAccessFormPaths || [];
        if (config.skipEmptyTextNodesForObj === undefined) {
            config.skipEmptyTextNodesForObj = true;
        }
        if (config.stripWhitespaces === undefined) {
            config.stripWhitespaces = true;
        }
        config.datetimeAccessFormPaths = config.datetimeAccessFormPaths || [];
    }
    var DOMNodeTypes = {
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        CDATA_SECTION_NODE: 4,
        COMMENT_NODE: 8,
        DOCUMENT_NODE: 9
    };
    function initRequiredPolyfills() {
        function pad(number) {
            var r = String(number);
            if (r.length === 1) {
                r = "0" + r;
            }
            return r;
        }
        if (typeof String.prototype.trim !== "function") {
            String.prototype.trim = function() {
                return this.replace(/^\s+|^\n+|(\s|\n)+$/g, "");
            };
        }
        if (typeof Date.prototype.toISOString !== "function") {
            Date.prototype.toISOString = function() {
                return this.getUTCFullYear() + "-" + pad(this.getUTCMonth() + 1) + "-" + pad(this.getUTCDate()) + "T" + pad(this.getUTCHours()) + ":" + pad(this.getUTCMinutes()) + ":" + pad(this.getUTCSeconds()) + "." + String((this.getUTCMilliseconds() / 1e3).toFixed(3)).slice(2, 5) + "Z";
            };
        }
    }
    function getNodeLocalName(node) {
        var nodeLocalName = node.localName;
        if (nodeLocalName == null) nodeLocalName = node.baseName;
        if (nodeLocalName == null || nodeLocalName == "") nodeLocalName = node.nodeName;
        return nodeLocalName;
    }
    function getNodePrefix(node) {
        return node.prefix;
    }
    function escapeXmlChars(str) {
        if (typeof str == "string") return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"); else return str;
    }
    function unescapeXmlChars(str) {
        return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/");
    }
    function toArrayAccessForm(obj, childName, path) {
        switch (config.arrayAccessForm) {
          case "property":
            if (!(obj[childName] instanceof Array)) obj[childName + "_asArray"] = [ obj[childName] ]; else obj[childName + "_asArray"] = obj[childName];
            break;
        }
        if (!(obj[childName] instanceof Array) && config.arrayAccessFormPaths.length > 0) {
            var idx = 0;
            for (;idx < config.arrayAccessFormPaths.length; idx++) {
                var arrayPath = config.arrayAccessFormPaths[idx];
                if (typeof arrayPath === "string") {
                    if (arrayPath == path) break;
                } else if (arrayPath instanceof RegExp) {
                    if (arrayPath.test(path)) break;
                } else if (typeof arrayPath === "function") {
                    if (arrayPath(obj, childName, path)) break;
                }
            }
            if (idx != config.arrayAccessFormPaths.length) {
                obj[childName] = [ obj[childName] ];
            }
        }
    }
    function fromXmlDateTime(prop) {
        var bits = prop.split(/[-T:+Z]/g);
        var d = new Date(bits[0], bits[1] - 1, bits[2]);
        var secondBits = bits[5].split(".");
        d.setHours(bits[3], bits[4], secondBits[0]);
        if (secondBits.length > 1) d.setMilliseconds(secondBits[1]);
        if (bits[6] && bits[7]) {
            var offsetMinutes = bits[6] * 60 + Number(bits[7]);
            var sign = /\d\d-\d\d:\d\d$/.test(prop) ? "-" : "+";
            offsetMinutes = 0 + (sign == "-" ? -1 * offsetMinutes : offsetMinutes);
            d.setMinutes(d.getMinutes() - offsetMinutes - d.getTimezoneOffset());
        } else if (prop.indexOf("Z", prop.length - 1) !== -1) {
            d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()));
        }
        return d;
    }
    function checkFromXmlDateTimePaths(value, childName, fullPath) {
        if (config.datetimeAccessFormPaths.length > 0) {
            var path = fullPath.split(".#")[0];
            var idx = 0;
            for (;idx < config.datetimeAccessFormPaths.length; idx++) {
                var dtPath = config.datetimeAccessFormPaths[idx];
                if (typeof dtPath === "string") {
                    if (dtPath == path) break;
                } else if (dtPath instanceof RegExp) {
                    if (dtPath.test(path)) break;
                } else if (typeof dtPath === "function") {
                    if (dtPath(obj, childName, path)) break;
                }
            }
            if (idx != config.datetimeAccessFormPaths.length) {
                return fromXmlDateTime(value);
            } else return value;
        } else return value;
    }
    function parseDOMChildren(node, path) {
        if (node.nodeType == DOMNodeTypes.DOCUMENT_NODE) {
            var result = new Object();
            var nodeChildren = node.childNodes;
            for (var cidx = 0; cidx < nodeChildren.length; cidx++) {
                var child = nodeChildren.item(cidx);
                if (child.nodeType == DOMNodeTypes.ELEMENT_NODE) {
                    var childName = getNodeLocalName(child);
                    result[childName] = parseDOMChildren(child, childName);
                }
            }
            return result;
        } else if (node.nodeType == DOMNodeTypes.ELEMENT_NODE) {
            var result = new Object();
            result.__cnt = 0;
            var nodeChildren = node.childNodes;
            for (var cidx = 0; cidx < nodeChildren.length; cidx++) {
                var child = nodeChildren.item(cidx);
                var childName = getNodeLocalName(child);
                if (child.nodeType != DOMNodeTypes.COMMENT_NODE) {
                    result.__cnt++;
                    if (result[childName] == null) {
                        result[childName] = parseDOMChildren(child, path + "." + childName);
                        toArrayAccessForm(result, childName, path + "." + childName);
                    } else {
                        if (result[childName] != null) {
                            if (!(result[childName] instanceof Array)) {
                                result[childName] = [ result[childName] ];
                                toArrayAccessForm(result, childName, path + "." + childName);
                            }
                        }
                        result[childName][result[childName].length] = parseDOMChildren(child, path + "." + childName);
                    }
                }
            }
            for (var aidx = 0; aidx < node.attributes.length; aidx++) {
                var attr = node.attributes.item(aidx);
                result.__cnt++;
                result[config.attributePrefix + attr.name] = attr.value;
            }
            var nodePrefix = getNodePrefix(node);
            if (nodePrefix != null && nodePrefix != "") {
                result.__cnt++;
                result.__prefix = nodePrefix;
            }
            if (result["#text"] != null) {
                result.__text = result["#text"];
                if (result.__text instanceof Array) {
                    result.__text = result.__text.join("\n");
                }
                if (config.escapeMode) result.__text = unescapeXmlChars(result.__text);
                if (config.stripWhitespaces) result.__text = result.__text.trim();
                delete result["#text"];
                if (config.arrayAccessForm == "property") delete result["#text_asArray"];
                result.__text = checkFromXmlDateTimePaths(result.__text, childName, path + "." + childName);
            }
            if (result["#cdata-section"] != null) {
                result.__cdata = result["#cdata-section"];
                delete result["#cdata-section"];
                if (config.arrayAccessForm == "property") delete result["#cdata-section_asArray"];
            }
            if (result.__cnt == 1 && result.__text != null) {
                result = result.__text;
            } else if (result.__cnt == 0 && config.emptyNodeForm == "text") {
                result = "";
            } else if (result.__cnt > 1 && result.__text != null && config.skipEmptyTextNodesForObj) {
                if (config.stripWhitespaces && result.__text == "" || result.__text.trim() == "") {
                    delete result.__text;
                }
            }
            delete result.__cnt;
            if (config.enableToStringFunc && (result.__text != null || result.__cdata != null)) {
                result.toString = function() {
                    return (this.__text != null ? this.__text : "") + (this.__cdata != null ? this.__cdata : "");
                };
            }
            return result;
        } else if (node.nodeType == DOMNodeTypes.TEXT_NODE || node.nodeType == DOMNodeTypes.CDATA_SECTION_NODE) {
            return node.nodeValue;
        }
    }
    function startTag(jsonObj, element, attrList, closed) {
        var resultStr = "<" + (jsonObj != null && jsonObj.__prefix != null ? jsonObj.__prefix + ":" : "") + element;
        if (attrList != null) {
            for (var aidx = 0; aidx < attrList.length; aidx++) {
                var attrName = attrList[aidx];
                var attrVal = jsonObj[attrName];
                if (config.escapeMode) attrVal = escapeXmlChars(attrVal);
                resultStr += " " + attrName.substr(config.attributePrefix.length) + "='" + attrVal + "'";
            }
        }
        if (!closed) resultStr += ">"; else resultStr += "/>";
        return resultStr;
    }
    function endTag(jsonObj, elementName) {
        return "</" + (jsonObj.__prefix != null ? jsonObj.__prefix + ":" : "") + elementName + ">";
    }
    function endsWith(str, suffix) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }
    function jsonXmlSpecialElem(jsonObj, jsonObjField) {
        if (config.arrayAccessForm == "property" && endsWith(jsonObjField.toString(), "_asArray") || jsonObjField.toString().indexOf(config.attributePrefix) == 0 || jsonObjField.toString().indexOf("__") == 0 || jsonObj[jsonObjField] instanceof Function) return true; else return false;
    }
    function jsonXmlElemCount(jsonObj) {
        var elementsCnt = 0;
        if (jsonObj instanceof Object) {
            for (var it in jsonObj) {
                if (jsonXmlSpecialElem(jsonObj, it)) continue;
                elementsCnt++;
            }
        }
        return elementsCnt;
    }
    function parseJSONAttributes(jsonObj) {
        var attrList = [];
        if (jsonObj instanceof Object) {
            for (var ait in jsonObj) {
                if (ait.toString().indexOf("__") == -1 && ait.toString().indexOf(config.attributePrefix) == 0) {
                    attrList.push(ait);
                }
            }
        }
        return attrList;
    }
    function parseJSONTextAttrs(jsonTxtObj) {
        var result = "";
        if (jsonTxtObj.__cdata != null) {
            result += "<![CDATA[" + jsonTxtObj.__cdata + "]]>";
        }
        if (jsonTxtObj.__text != null) {
            if (config.escapeMode) result += escapeXmlChars(jsonTxtObj.__text); else result += jsonTxtObj.__text;
        }
        return result;
    }
    function parseJSONTextObject(jsonTxtObj) {
        var result = "";
        if (jsonTxtObj instanceof Object) {
            result += parseJSONTextAttrs(jsonTxtObj);
        } else if (jsonTxtObj != null) {
            if (config.escapeMode) result += escapeXmlChars(jsonTxtObj); else result += jsonTxtObj;
        }
        return result;
    }
    function parseJSONArray(jsonArrRoot, jsonArrObj, attrList) {
        var result = "";
        if (jsonArrRoot.length == 0) {
            result += startTag(jsonArrRoot, jsonArrObj, attrList, true);
        } else {
            for (var arIdx = 0; arIdx < jsonArrRoot.length; arIdx++) {
                result += startTag(jsonArrRoot[arIdx], jsonArrObj, parseJSONAttributes(jsonArrRoot[arIdx]), false);
                result += parseJSONObject(jsonArrRoot[arIdx]);
                result += endTag(jsonArrRoot[arIdx], jsonArrObj);
            }
        }
        return result;
    }
    function parseJSONObject(jsonObj) {
        var result = "";
        var elementsCnt = jsonXmlElemCount(jsonObj);
        if (elementsCnt > 0) {
            for (var it in jsonObj) {
                if (jsonXmlSpecialElem(jsonObj, it)) continue;
                var subObj = jsonObj[it];
                var attrList = parseJSONAttributes(subObj);
                if (subObj == null || subObj == undefined) {
                    result += startTag(subObj, it, attrList, true);
                } else if (subObj instanceof Object) {
                    if (subObj instanceof Array) {
                        result += parseJSONArray(subObj, it, attrList);
                    } else if (subObj instanceof Date) {
                        result += startTag(subObj, it, attrList, false);
                        result += subObj.toISOString();
                        result += endTag(subObj, it);
                    } else {
                        var subObjElementsCnt = jsonXmlElemCount(subObj);
                        if (subObjElementsCnt > 0 || subObj.__text != null || subObj.__cdata != null) {
                            result += startTag(subObj, it, attrList, false);
                            result += parseJSONObject(subObj);
                            result += endTag(subObj, it);
                        } else {
                            result += startTag(subObj, it, attrList, true);
                        }
                    }
                } else {
                    result += startTag(subObj, it, attrList, false);
                    result += parseJSONTextObject(subObj);
                    result += endTag(subObj, it);
                }
            }
        }
        result += parseJSONTextObject(jsonObj);
        return result;
    }
    this.parseXmlString = function(xmlDocStr) {
        return nlapiStringToXML(xmlDocStr);
    };
    this.asArray = function(prop) {
        if (prop instanceof Array) return prop; else return [ prop ];
    };
    this.toXmlDateTime = function(dt) {
        if (dt instanceof Date) return dt.toISOString(); else if (typeof dt === "number") return new Date(dt).toISOString(); else return null;
    };
    this.asDateTime = function(prop) {
        if (typeof prop == "string") {
            return fromXmlDateTime(prop);
        } else return prop;
    };
    this.xml2json = function(xmlDoc) {
        return parseDOMChildren(xmlDoc);
    };
    this.xml_str2json = function(xmlDocStr) {
        var xmlDoc = this.parseXmlString(xmlDocStr);
        if (xmlDoc != null) return this.xml2json(xmlDoc); else return null;
    };
    this.json2xml_str = function(jsonObj) {
        return parseJSONObject(jsonObj);
    };
    this.json2xml = function(jsonObj) {
        var xmlDocStr = this.json2xml_str(jsonObj);
        return this.parseXmlString(xmlDocStr);
    };
    this.getVersion = function() {
        return VERSION;
    };
}

function EBayRequest() {}

EBayRequest.URL = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll"
};

EBayRequest.eBayUser = {
    zakeusa: {
        id: "zakeusa",
        token: "AgAAAA**AQAAAA**aAAAAA**fTveVA**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wGkYqiD5WCpQmdj6x9nY+seQ**ArECAA**AAMAAA**sSIYUxrt+lndLgpBTfQTkjfqsH3dLa7FYQo/hZPcG5FVIYz1T9zm5PLV+PapUI76XUYoiarR4JLJkOKhb/XFCqC/OFy8WPCIQCMzVxCZX7B4q6qVnckuv5LrUpO7EUoCM1O6XNLw0w8/ZeZGOO7qY69J9dYDhVjVP3uIzJ0So899yg44UzS8nB75QY6Oe5z/3ZznKGHC8dMOgdgmqiDePSfD44YsD92vW0pam9rokRs7D9w0GSv9UxfxrV+Om1S3lk8C3WdCaOtb5eBb2CzgDMdtSp49f8YIwjZul+FO4q+NUiiKdhmbdRyAHOB+itk4A1Y6pe58iummIbcYROfAbgC94dMCgwhRjp17EFYjrdNanlLpZHKG+i5pq89Pmxnq3gf1g18HW487lBEZLCWEpQKPdrwmEJM3PXPSEOdsS4TRoHqluV7vAxqb2RCW8YgQICQ9SdhRTKwuK2mhpv8evaAowhBGbSQ5zU3FECh6ojWieiHALULnXAH3czAZACpJdfQgCirlVW5WocpWfdsoqKrZGG+smKu3tJ5nAVlVPoQnQTviTxzQCttMooooUP37SLe7XMqxIa2X+/TpmcjAvgmPeTUIxPS/s6xMU389OL2TUzYruIth0oCczMPs8RKl3/IPYcawi9EV0wnt+f7VweXZ6DjaT9ZVahdANNUonHsS0E2DMr2IrstlyntmyfRfuGh/QucBnRNQOsuauY8yOsemHmK4C4c/tj0r1c/UVtJucyfAEtqzly7H2me2rlla",
        headers: {
            "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
            "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
            "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
            "X-EBAY-API-SITEID": "0"
        }
    }
};

EBayRequest.prototype.request = function(postXML, header) {
    header["Content-Type"] = "application/xml";
    var eBayResponse = nlapiRequestURL(EBayRequest.URL.production, postXML, header);
    var x2js = new X2JS();
    return x2js.xml_str2json(eBayResponse.getBody());
};

EBayRequest.extend = EBayRequest.prototype.extend = function() {
    var source = arguments[0];
    if (source) {
        for (var prop in source) {
            this[prop] = source[prop];
        }
    }
};

function extend(targetObj) {
    Array.prototype.slice.call(arguments, 1).forEach(function(source) {
        if (source) {
            for (var prop in source) {
                targetObj[prop] = source[prop];
            }
        }
    });
    return targetObj;
}

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
}

function GetMemberMessages(id) {
    this.apiHeaders = {
        "X-EBAY-API-CALL-NAME": "GetMemberMessages",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "907"
    };
    EBayRequest.call(this);
}

inherit(EBayRequest, GetMemberMessages);

GetMemberMessages.prototype.buildPostXML = function() {
    var requestXML = "";
    requestXML += '<?xml version="1.0" encoding="utf-8"?>';
    requestXML += '<GetMemberMessagesRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    requestXML += "<RequesterCredentials>";
    requestXML += "<eBayAuthToken>#token#</eBayAuthToken>";
    requestXML += "</RequesterCredentials>";
    requestXML += '<MailMessageType EnumType="MessageTypeCodeType">All</MailMessageType>';
    requestXML += "</GetMemberMessagesRequest>";
    return requestXML;
};

GetMemberMessages.prototype.request = function(userInfo) {
    var xml = this.buildPostXML();
    xml = xml.replace("#token#", userInfo.token);
    extend(userInfo.headers, this.apiHeaders);
    var response = EBayRequest.prototype.request.call(this, xml, userInfo.headers);
    _log("response", response);
    response.__USERID = userInfo.id;
    var MemberMessageExchange = response.GetMemberMessagesResponse.MemberMessage.MemberMessageExchange;
    MemberMessageExchange.forEach(function(item) {
        item.CreationDate = nlapiDateToString(new Date(item.CreationDate), "datetimetz");
        item.LastModifiedDate = nlapiDateToString(new Date(item.LastModifiedDate), "datetimetz");
        item.Question.Body = item.Question.Body.replace(/\n/g, "<br>");
        if (item.Item) item.Item.SellingStatus.CurrentPrice.__text = accounting.format(item.Item.SellingStatus.CurrentPrice.__text);
    });
    return response;
};

function run(request, response) {
    try {
        if (request.getMethod() == "GET") {
            var action = request.getParameter("action");
            if (action) {
                if (action == "showIndexPage") {
                    response.write(showIndexPage());
                } else {
                    response.write(JSON.stringify(ajaxRequest(request)));
                }
            } else {
                showFormFrame(request, response);
            }
        }
    } catch (e) {
        return response.write(JSON.stringify(processException(e)));
    }
}

function ajaxRequest(request) {
    var params = request.getAllParameters();
    var _params = {};
    for (var param in params) {
        _params[param] = params[param];
    }
    var response = {
        head: {
            all_request_params: _params,
            status: "OK"
        },
        body: {}
    };
    try {
        var action = request.getParameter("action");
        if (action == "GetMemberMessages") {
            response.body.message = "GOT";
            var memberMessages = new GetMemberMessages();
            response.body.result = memberMessages.request(EBayRequest.eBayUser.zakeusa);
        } else if (action == "AddMemberMessageRTQ") {
            response.body.message = "GOT";
        } else {
            response.body.message = "Nothing..";
        }
    } catch (e) {
        return processException(e);
    }
    return response;
}

function showFormFrame(request, response) {
    var form = nlapiCreateForm("eBay Messages", false);
    form.setScript("customscript_ebay_client_script");
    var iframeHtml = form.addField("ebay_messages_frame", "inlinehtml", "eBay Messages Frame");
    iframeHtml.setDefaultValue('<iframe border="0" style="border:none;" src="' + nlapiResolveURL("SUITELET", "customscript_ebay_suitelet", "customdeploy_ebay_suitelet") + '&action=showIndexPage"' + ' width="100%" scrolling="no"></iframe>');
    response.writePage(form);
}

function showIndexPage() {
    var indexPageId = "3048";
    var formHTML = nlapiLoadFile(indexPageId).getValue();
    return formHTML;
}