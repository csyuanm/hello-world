/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Feb 2015     Sansom Li
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
	var shortNameofEbay ='';
	var itemNum = '';
	var macroAccountLinked = '';
	var regularAccountLinked= '';

function clientPageInit(type){

	try{
		nlapiSetFieldDisplay('custpage_field_subcategory1', false);
		nlapiSetFieldDisplay('custpage_field_subcategory2', false);
		nlapiSetFieldDisplay('custpage_field_subcategory3', false);
		nlapiSetFieldDisplay('custpage_field_subcategory4', false);
		nlapiSetFieldDisplay('custpage_field_subcategory5', false);
		nlapiSetFieldDisplay('custpage_field_subcategory6', false);
		

		console.log(cust_button_html);

		jQuery('span#custitem_ebay_categoryid_fs').parent().parent().append(cust_button_html);
	
		
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on page init func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){

	try{
		
		if ( name == 'custitem_listing_account' || name.indexOf('custpage_field_subcategory') > -1 ){
			var ebay_account = nlapiGetFieldValue('custitem_listing_account');
			var site_id = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid');
			console.log(site_id);
			
			site_id = getEbayGlobalSiteID(site_id);
			
			//short name for Ebay
/*			shortNameofEbay = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_shortname');
			if (itemNum != ''){
				nlapiSetFieldValue('itemid',  shortNameofEbay +'-'+ itemNum);
			}*/
			
 var defaultcurr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_default_currency',true);
 	 console.log(defaultcurr);
var sitecountr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid',true);
			console.log(sitecountr);
	var split = sitecountr.split('-');
			var countrycode = nlapiSetFieldValue('custitem_ebay_countrycode',split[1]);
	
			var currencycode = nlapiSetFieldValue('custitem_ebay_currencycode', defaultcurr);
			var context = nlapiGetContext();
			var username = context.getName();
	

 //alert("Hello" + defaultcurr + sitecountr + split[1] );
			
			if ( name == 'custitem_listing_account' )
			{
				
				result = ebayCategoryBrowseStep(site_id, 'custitem_listing_account', 'custpage_field_subcategory1', '0');
				
				if( result ){
					alert("I am here!");
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', false);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}
				
			}
			
			if ( name == 'custpage_field_subcategory1' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory1', 'custpage_field_subcategory2', '1');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory1'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory1'));
					//console.log(JSON.stringify(specifics));
				}		
				
			}
			
			if ( name == 'custpage_field_subcategory2' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory2', 'custpage_field_subcategory3', '2');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory2'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory2'));
					//console.log(JSON.stringify(specifics));
				}			
				
			}
			
			if ( name == 'custpage_field_subcategory3' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory3', 'custpage_field_subcategory4', '3');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory3'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory3'));
					//console.log(JSON.stringify(specifics));
				}
				
			}
			
			if ( name == 'custpage_field_subcategory4' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory4', 'custpage_field_subcategory5', '4');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory4'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4'));
					
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory4'));
					//console.log(JSON.stringify(specifics));
				}
				
			}
			
			if ( name == 'custpage_field_subcategory5' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory5', 'custpage_field_subcategory6', '5');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory5'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4') + ' > ' + nlapiGetFieldText('custpage_field_subcategory5'));
				
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory5'));
					//console.log(JSON.stringify(specifics));
				}
				
			}	
			
			
		}
		

		
		//if ( name == 'custitem_ebay_categoryid' ){
		//	nlapiSetFieldValue('custitem_ebay_category_title', '');
		//}

		
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on field change func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
function clientValidateLine(type){
	if ( type == 'member' ){
		jQuery('body').css('overflow', 'hidden');
		popup_select_pictures = popup_select_pictures.replace('_itemid_', nlapiGetCurrentLineItemValue('member', 'item'));
		jQuery('body').append(popup_select_pictures);
	}
    return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @returns {Boolean} True to continue save, false to abort save
 */
function clientSaveRecord(){
	for ( var i = 1; i <= MAX_SPECIFICS; i++ ){
		if ( jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').css('display') != 'none' )
		{
			//console.log(i + ':' + jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
		}else if ( jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').css('display') != 'none' )
		{
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html());
		}else{
			//console.log(i + ': none');
			//nlapiSetFieldValue('custitem_item_specific_' + i, '');
		}
		var dropdown_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_value');
		if ( dropdown_val != null && dropdown_val != '' )
		{
			//console.log(i + '-drop:' + dropdown_val);
			nlapiSetFieldValue('custitem_item_specific_' + i + '_value', dropdown_val);
		}else{
			var text_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_text_val');
			//console.log(i + '-text_val:' + text_val);
			if ( text_val != null && text_val != '' )
			{
				nlapiSetFieldValue('custitem_item_specific_' + i + '_value', text_val);
			}else{
				//nlapiSetFieldValue('custitem_item_specific_' + i + '_value', '');
			}
		}
	}
	
	
    return true;
}

