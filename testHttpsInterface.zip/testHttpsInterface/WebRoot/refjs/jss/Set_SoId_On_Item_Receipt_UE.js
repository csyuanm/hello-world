/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       25 Oct 2016     Pranjal
 */
var body = '';
var author =  '-5' ;
var recipient  = 'pranjal@webbee.biz';	
var subject = 'ZAKE, Set SoId UE :';

function AfterSubmit(type)
{
	try
	{
		var IRId = nlapiGetFieldValue('custbody_created_from_ir');
		var SOId = nlapiGetRecordId();
		if(defVal(IRId) != '')
		{
			var IrCreatedFrom=nlapiLookupField('itemreceipt', IRId, 'createdfrom.type');
			if(IrCreatedFrom == 'RtnAuth' )
			{
				IRId  = nlapiSubmitField('itemreceipt', IRId, 'custbody_sales_order_no', SOId, true);
				body = 'Item Receipt Updated with Id : '+IRId;
				nlapiLogExecution('DEBUG', 'Body : ', body);
			}	
		}
	}
   catch(ex)
   {
	   body = 'Exception in AfterSubmit : '+ex.name;
	   body += ', Message : '+ex.message;
	   nlapiLogExecution('DEBUG', 'Body : ', body);
	   nlapiSendEmail(author, recipient, subject, body);
   }
}

function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined)
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		body = 'Exception : '+ex,'Message : '+ex.message;
		body += 'Function : defVal ';
	    nlapiLogExecution('DEBUG','Body : ',body);	
	    nlapiSendEmail(author, recipient, subject, body);
	    return '';
	}
}
