document.write(['<style>',
    '    #tdbody_printlabel {',
    '        display: none;',
    '    }',
    '</style>'].join(""));