function remove(dataIn){
  nlapiLogExecution('DEBUG', 'dataIn', JSON.stringify(dataIn));
  var id = nlapiDeleteRecord(dataIn.type, dataIn.id);
  return id;
}
