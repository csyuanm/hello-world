/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       05 Jun 2017     ratul
 *
 */

/**
 * @param {Object} dataIn Parameter object
 * @returns {Object} Output object
 */
function getItem(dataIn) {
	
	try{

		var sku = dataIn.sku;
		nlapiLogExecution('Debug','dataIn.sku',dataIn.sku);
		var filters = [];
		filters.push(new nlobjSearchFilter("custitem_gallany_sku",null,"is",sku));
		
		var columns = [];
		columns.push(new nlobjSearchColumn('itemid'));
		
		var search = nlapiSearchRecord('item',null,filters,columns);
		
		if(search){
			
            if(search.length > 1){
            	return {'statuscode':500};
            }else{
            	var nsId = search[0].getId();
    			nlapiLogExecution('Debug','nsId',nsId);
    			return {'statuscode':"200","nsId":nsId};
            }
			
		}else{
			return {'statuscode':"204"};
		}
	}
	catch(e){
		nlapiLogExecution('Audit','error in item nsid grab',e);
		return {'statuscode':"500"}
	}
	
	
}
