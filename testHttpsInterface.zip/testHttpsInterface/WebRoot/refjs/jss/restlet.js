function deleteItem(obj){
  nlapiDeleteRecord('inventoryitem', obj);
  return 'good';
}
