/**
 /*******************************************************************
*
* Name: Amazon Order Imports
* Script Type: Scheduled
* Version: 0.0.1
*
*
* Author: Govind Sharma
* Purpose:To Import Amazon orders of the Amazon Account(given as Deployement Parameter)
* Date: 13/09/2015
* ******************************************************************* */

var record_act={}
record_act[5]='9500959';
record_act[24]='32918214';
record_act[11]='9501161';
record_act[10]='9501162';
record_act[16]='9501263';
record_act[15]='16219548';
record_act[45]='16219548';
record_act[13]='9501365';
record_act[14]='9501366';
record_act[19]='9501367';
record_act[18]='9501368';
record_act[28]='9501369';
record_act[17]='9502071';
record_act[20]='9502672';
record_act[21]='9502673';
record_act[22]='9502774';
record_act[25]='13440879';
record_act[37]='13440879';
record_act[38]='13440879';
record_act[39]='9502876';
record_act[23]='9502876';
record_act[12]='9502877';
record_act[29]='9502071';
record_act[30]='9502071';
record_act[31]='14395486';
record_act[32]='14395274';
record_act[33]='14393859';
record_act[34]='9502071';

var fromUI='F'

function get_order_item(type) {
		
	var arr={};
	arr['alabama']='AL';
	arr['alaska']='AK';
	arr['arizona']='AZ';
	arr['arkansas']='AR';
	arr['california']='CA';
	arr['colorado']='CO';
	arr['connecticut']='CT';
	arr['delaware']='DE';
	arr['florida']='FL';
	arr['georgia']='GA';
	arr['hawaii']='HI';
	arr['idaho']='ID';
	arr['illinois']='IL';
	arr['indiana']='IN';
	arr['iowa']='IA';
	arr['kansas']='KS';
	arr['kentucky']='KY';
	arr['louisiana']='LA';
	arr['maine']='ME';
	arr['maryland']='MD';
	arr['massachusetts']='MA';
	arr['michigan']='MI';
	arr['minnesota']='MN';
	arr['mississippi']='MS';
	arr['missouri']='MO';
	arr['montana']='MT';
	arr['nebraska']='NE';
	arr['nevada']='NV';
	arr['new hampshire']='NH';
	arr['new jersey']='NJ';
	arr['new mexico']='NM';
	arr['new york']='NY';
	arr['north carolina']='NC';
	arr['north dakota']='ND';
	arr['ohio']='OH';
	arr['oklahoma']='OK';
	arr['oregon']='OR';
	arr['pennsylvania']='PA';
	arr['rhode island']='RI';
	arr['south carolina']='SC';
	arr['south dakota']='SD';
	arr['tennessee']='TN';
	arr['texas']='TX';
	arr['utah']='UT';
	arr['vermont']='VT';
	arr['virginia']='VA';
	arr['washington']='WA';
	arr['west virginia']='WV';
	arr['wisconsin']='WI';
	arr['wyoming']='WY';
	arr['al']='AL';
	arr['ak']='AK';
	arr['az']='AZ';
	arr['ar']='AR';
	arr['ca']='CA';
	arr['co']='CO';
	arr['ct']='CT';
	arr['de']='DE';
	arr['fl']='FL';
	arr['ga']='GA';
	arr['hi']='HI';
	arr['id']='ID';
	arr['il']='IL';
	arr['in']='IN';
	arr['ia']='IA';
	arr['ks']='KS';
	arr['ky']='KY';
	arr['la']='LA';
	arr['me']='ME';
	arr['md']='MD';
	arr['ma']='MA';
	arr['mi']='MI';
	arr['mn']='MN';
	arr['ms']='MS';
	arr['mo']='MO';
	arr['mt']='MT';
	arr['ne']='NE';
	arr['nv']='NV';
	arr['nh']='NH';
	arr['nj']='NJ';
	arr['nm']='NM';
	arr['ny']='NY';
	arr['nc']='NC';
	arr['nd']='ND';
	arr['oh']='OH';
	arr['ok']='OK';
	arr['or']='OR';
	arr['pa']='PA';
	arr['ri']='RI';
	arr['sc']='SC';
	arr['sd']='SD';
	arr['tn']='TN';
	arr['tx']='TX';
	arr['ut']='UT';
	arr['vt']='VT';
	arr['va']='VA';
	arr['wa']='WA';
	arr['wv']='WV';
	arr['wi']='WI';
	arr['wy']='WY';
	
	var currencyCodeArr={};
     /*/ 1 USD USD Yes No Yes (GMT-05:00) Eastern Time (US & Canada)
     2 GBP GBP No No Yes
     3 CAD CAD No No Yes
     4 EUR EUR No No Yes
     5 CNY CNY Yes No Yes (GMT-05:00) Eastern Time (US & Canada)
     6 AUD AUD No No Yes
     7 HKD HKD No No Yes
     8 INR INR No No Yes
     9 MYR MYR No No Yes
     10 PHP PHP No No Yes
     11 PLN PLN No No Yes
     12 RUB RUB No No Yes
     13 SGD SGD No No Yes
     14 CHF CHF No No Yes
     15 JPY JPY No No Yes*/

	currencyCodeArr['USD']="1";
	currencyCodeArr['GBP']="2";
	currencyCodeArr['CAD']="3";
	currencyCodeArr['EUR']="4";
	currencyCodeArr['CNY']="5";
	currencyCodeArr['AUD']="6";
	currencyCodeArr['HKD']="7";
	currencyCodeArr['INR']="8";
	currencyCodeArr['MYR']="9";
	currencyCodeArr['PHP']="10";
	currencyCodeArr['PLN']="11";
	currencyCodeArr['RUB']="12";
	currencyCodeArr['SGD']="13";
	currencyCodeArr['CHF']="14";
	currencyCodeArr['JPY']="15";
	currencyCodeArr['MXN']="16"; 
	var email_author=1659;
	var mymail='zake@webbeeglobal.com';
	var context = nlapiGetContext();
	var mail_cc=['leo@zake.com','johnny@zake.com'];
	var internalid = context.getSetting('SCRIPT', 'custscript_amzn_accountinternalid');
//	var internalid=24;
	if(internalid==9){
		mail_cc=['leo@zake.com','johnny@zake.com','nate@3btech.net','jlawrence@zake.com'];
	}
	
    var count=0;
    var columns = [];
	columns.push(new nlobjSearchColumn('custrecord_amazon_seller_id'));
	columns.push(new nlobjSearchColumn('custrecord_aws_access_key_id'));
	columns.push(new nlobjSearchColumn('custrecord_secret_key'));
	columns.push(new nlobjSearchColumn('custrecord_amazon_enabled_sites'));
	columns.push(new nlobjSearchColumn('custrecord_fba_invoice_form'));
	columns.push(new nlobjSearchColumn('custrecord_mfn_salesorder_form'));
	columns.push(new nlobjSearchColumn('internalid'));
	columns.push(new nlobjSearchColumn('name'));
	columns.push(new nlobjSearchColumn('custrecord_fbm_warehouse'));
	columns.push(new nlobjSearchColumn('custrecord_amz_fba_warehouse'));
	columns.push(new nlobjSearchColumn('custrecord_lastupdatetime'));
	columns.push(new nlobjSearchColumn('custrecord_accounts_receivable_account'));
	columns.push(new nlobjSearchColumn('custrecord_sku_notification_mails'));
	columns.push(new nlobjSearchColumn('custrecord_act_subsidiary')); // Added by AJ on 14 Aug 2016 

	var filters  = [];
	filters.push(new nlobjSearchFilter('custrecord_amazon_seller_id', null,
			'isnotempty'));
	filters.push(new nlobjSearchFilter('internalid',null,'is',internalid));
	var search_result = nlapiSearchRecord('customrecord_amazon_accounts', null,
			filters, columns);
	var token=0;
	var tokencount=0;
	for ( var i = 0; (i < search_result.length)||(token!=0); i++) {
		try{
			if(token!=0){
				i=i-token;
				}
		var sellerId = search_result[i].getValue('custrecord_amazon_seller_id');
		  //added on 13th Aug 2016
   		var columns21 = [];
   		columns21.push(new nlobjSearchColumn('name'));
   		columns21.push(new nlobjSearchColumn('custrecord_amazon_seller_id'));
   		columns21.push(new nlobjSearchColumn('custrecord_aws_access_key_id'));
   		columns21.push(new nlobjSearchColumn('custrecord_secret_key'));
   		columns21.push(new nlobjSearchColumn('custrecord_fbm_warehouse'));
   		columns21.push(new nlobjSearchColumn('custrecord_amz_fba_warehouse'));
   		columns21.push(new nlobjSearchColumn('custrecord_fba_invoice_form'));
   		columns21.push(new nlobjSearchColumn('custrecord_mfn_salesorder_form'));
   		columns21.push(new nlobjSearchColumn('custrecord_amazon_enabled_sites'));
   		columns21.push(new nlobjSearchColumn('custrecord_fba_bin_to_use'));
   		columns21.push(new nlobjSearchColumn('custrecord_accounts_receivable_account'));
   		columns21.push(new nlobjSearchColumn('custrecord_amazon_marketplace_id', 'custrecord_amazon_enabled_sites'));
	    var filters21 = [];
			filters21.push(new nlobjSearchFilter('custrecord_amazon_seller_id', null,
	            'is',sellerId));
	    
	    var search_result21 = nlapiSearchRecord('customrecord_amazon_accounts', null,filters21, columns21);
	    var sellerId21 = search_result21[0].getValue('custrecord_amazon_seller_id');
        var marketplaceArr=[];
        for(var len=0;len<search_result21.length;len++){
        	marketplaceArr[search_result21[len].getValue('custrecord_amazon_marketplace_id')] = search_result21[len].getId();
        } //End added on 13th Aug 2016
					
		var fromTime=search_result[i].getValue('custrecord_lastupdatetime')
		var actname = search_result[i].getValue('name');
		var awsKey = search_result[i].getValue('custrecord_aws_access_key_id');
		var securityKey = search_result[i].getValue('custrecord_secret_key');
		var account_receivable=search_result[i].getValue('custrecord_accounts_receivable_account');
		var site = search_result[i].getText('custrecord_amazon_enabled_sites');
		var site_id=search_result[i].getValue('custrecord_amazon_enabled_sites');
		var bin=search_result[i].getValue('custrecord_fba_bin_to_use');
		var subsidiary = search_result[i].getValue('custrecord_act_subsidiary');// Added by AJ on 14 Aug 2016
		var cc_mail=[];
		var email_cc=search_result[i].getValue('custrecord_sku_notification_mails');
		nlapiLogExecution('DEBUG','email_cc', email_cc)
        nlapiLogExecution('DEBUG','bin', bin)
		if(email_cc){
			cc_mail=email_cc.split(',');
		}
		else{
			cc_mail=['zake@webbeeglobal.com'];
		}
		nlapiLogExecution('DEBUG','cc_mail', cc_mail);

		var cust_form_mfn = search_result[i].getValue('custrecord_mfn_salesorder_form');
		var cust_form_afn = search_result[i].getValue('custrecord_fba_invoice_form');
		var mfn_warehouse = search_result[i].getValue('custrecord_fbm_warehouse');
		var afn_warehouse = search_result[i].getValue('custrecord_amz_fba_warehouse');
		var storefront_ns=search_result[i].getValue('custrecord_storefront_amazon');
		var columns = [];
		columns.push(new nlobjSearchColumn('custrecord_amazon_marketplace_id'));
		columns.push(new nlobjSearchColumn('custrecord_amazon_mws_endpoint'));
		var filters = [];
		filters.push(new nlobjSearchFilter('name', null, 'is', site));
		var search_result2 = nlapiSearchRecord('customrecord_amazon_global_sites', null, filters, columns);
		var marketId = search_result2[0].getValue('custrecord_amazon_marketplace_id');
        var endpoint = search_result2[0].getValue('custrecord_amazon_mws_endpoint');		

		var timestamp = new Date();
		timestamp = timestamp.toISOString();
		timestamp = encodeURIComponent(timestamp);
		nlapiLogExecution('DEBUG','currenttime', timestamp);
		var timestamp1 = new Date();
        timestamp1 .setMilliseconds((timestamp1 .getMilliseconds()-300000));
		timestamp1 = timestamp1.toISOString();
		timestamp1 = encodeURIComponent(timestamp1);
		nlapiLogExecution('DEBUG','currenttime', timestamp1);

		if(token==0){
			nlapiSubmitField('customrecord_amazon_accounts',internalid, 'custrecord_lastupdatetime',timestamp1)
			if(fromTime==''){
				fromTime = new Date();
		        fromTime.setMilliseconds((fromTime.getMilliseconds()-864000000));
				fromTime = fromTime.toISOString();
				fromTime = encodeURIComponent(fromTime);
				}
			    nlapiLogExecution('DEBUG','fromTime',fromTime);
				var queryString = request_string(awsKey,fromTime,marketId,sellerId,timestamp);
			}else{
				var queryString=request_string_lasttoken(awsKey,sellerId,timestamp,nexttoken);
				token=0;
				tokencount++;
				}
		var orderstring = "POST\n"+endpoint+"\n/Orders/2013-09-01\n"+ queryString;
		var hash = CryptoJS.HmacSHA256(orderstring, securityKey);
		var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
		hashInBase64 = encodeURIComponent(hashInBase64); 		 	 	 	
		CheckGovernance();
		var orderresponse = nlapiRequestURL('https://'+endpoint+'/Orders/2013-09-01?'
						+ queryString + "&Signature=" + hashInBase64,
				queryString + "&Signature=" + hashInBase64, null);
//		nlapiLogExecution('DEBUG', 'orderresponse', orderresponse.getBody());
		var orderxml = nlapiStringToXML(orderresponse.getBody());
		if (orderresponse.getBody() != '') {
			var error_list_orders=orderxml.getElementsByTagName('Error');
			nlapiLogExecution('DEBUG', 'error_list_orders', error_list_orders.length);
			if(error_list_orders.length>0){
				nlapiSubmitField('customrecord_amazon_accounts',internalid, 'custrecord_lastupdatetime',fromTime);
				nlapiSendEmail(email_author, 'govind@webbee.biz', 'Error : List Order | '+actname,'timestamp : '+fromTime +"\n"+orderresponse.getBody());
			break;
			}
			var tot_ord = orderxml.getElementsByTagName('Order');
			nlapiLogExecution('DEBUG', 'orders', tot_ord.length);
			for ( var k = 0; k <  tot_ord.length; k++) {
				
			var amazonOrderId = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName(
					'AmazonOrderId').item(0);
			if(!amazonOrderId) {
				amazonOrderId = '';
			}else{
				amazonOrderId = amazonOrderId.textContent;
			}
			if(amazonOrderId !='') {
				nlapiLogExecution('DEBUG','amazonOrderId '+(k+1),amazonOrderId);
				var fulfillmentChannel = orderxml.item(0).getElementsByTagName('Order').item(k)
				.getElementsByTagName('FulfillmentChannel').item(0);
			if(!fulfillmentChannel){
				fulfillmentChannel = '';
			}else{
				fulfillmentChannel = fulfillmentChannel.textContent;
			}
			nlapiLogExecution('DEBUG','sku type', fulfillmentChannel);
			if(fulfillmentChannel =='AFN'){
				fulfillmentChannel=1;
				var warehouse = afn_warehouse;
				var cust_form = cust_form_afn;
				var record = 'invoice';
			}else{
				fulfillmentChannel=2;
				var warehouse = mfn_warehouse;
				var cust_form = cust_form_mfn;
				var record = 'salesorder'
			}
			var chck_ord_dup=searchRecordDup(record,amazonOrderId);
			if(chck_ord_dup!=0){
			var orderStatus = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('OrderStatus').item(0);
			if(!orderStatus){
				orderStatus = '';
			}else{
				orderStatus = orderStatus.textContent;
			}
				count++;
				timestamp = new Date();
				timestamp = timestamp.toISOString();
				timestamp = encodeURIComponent(timestamp);
				var querystring2 = "AWSAccessKeyId=" + awsKey
							+ "&Action=ListOrderItems" + "&AmazonOrderId="
							+ amazonOrderId + "&SellerId=" + sellerId
							+ "&SignatureMethod=HmacSHA256"
							+ "&SignatureVersion=2" + "&Timestamp=" + timestamp
							+ "&Version=2013-09-01";

				var itemString = "POST\n"+endpoint+"\n/Orders/2013-09-01\n"+ querystring2;
				var hasH = CryptoJS.HmacSHA256(itemString, securityKey);
				var hasHInBase64 = CryptoJS.enc.Base64.stringify(hasH);
				hasHInBase64 = encodeURIComponent(hasHInBase64);
				var itemresponse = nlapiRequestURL('https://'+endpoint+'/Orders/2013-09-01?'
									+ querystring2 + "&Signature="+ hasHInBase64, querystring2
									+ "&Signature=" + hasHInBase64, null);
				nlapiLogExecution('DEBUG', 'itemresponse', itemresponse.getBody());
				var itemxml = nlapiStringToXML(itemresponse.getBody());
					//To handel Throtteling error in ListorderItem
				var error=itemxml.item(0).getElementsByTagName('Error');
				nlapiLogExecution('DEBUG', 'error', error.length);
				if(error.length>0){
					var message=itemxml.item(0).getElementsByTagName('Code').item(0).textContent;
					if(message=='RequestThrottled'){
//					nlapiSendEmail(email_author, 'govind@webbee.biz', 'Request Throttled | Zake', 'Order ID : '+amazonOrderId+'\nAccount : '+actname, 'aj@webbeeglobal.com');
					k--;
					continue;
					}	
				}
               var purchaseDate = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('PurchaseDate').item(0);
					if (!purchaseDate){
						purchaseDate = '';
					}else{
						purchaseDate = purchaseDate.textContent;
					}
			   var shipServiceLevel = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('ShipServiceLevel').item(0);
					if(!shipServiceLevel){
						shipServiceLevel = '';
					} else{
						shipServiceLevel = shipServiceLevel.textContent;
					}
			  var buyerName = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('BuyerName').item(0);
					if(!buyerName){
					   buyerName = '';
				       }else{
							buyerName = buyerName.textContent;
				       }
    		  var amount = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('amount').item(0);
					if (!amount){
						amount =0;
					}else{
						amount = amount.textContent;
					}
			  var currencyCode = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('CurrencyCode').item(0);
					if (!currencyCode){
						currencyCode = '';
					}else{
						currencyCode = currencyCode.textContent;
					}
			  var currency = currencyCodeArr[currencyCode]; // Added on 14 Aug 2016 by AJ
                nlapiLogExecution('DEBUG', 'currencyCode '+currency,currencyCode );
			try{
				var stateOrRegion = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('StateOrRegion').item(0);
				if (!stateOrRegion){
					stateOrRegion = '';
				}else{
					stateOrRegion=stateOrRegion.textContent;
				}
				var newstateOrRegion = (stateOrRegion).toLowerCase();
				    newstateOrRegion=arr[newstateOrRegion];
			   if(!newstateOrRegion){
				   newstateOrRegion = stateOrRegion;
					}	
				}catch(e){
			  nlapiSendEmail(email_author, 'govind@webbee.biz', 'State Issue For Order Id :'+amazonOrderId+' | '+actname, e, 'aj@webbeeglobal.com');	
			     }
				stateOrRegion=newstateOrRegion;
			  var city = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('City').item(0);
					if (!city) {
						city = '';
					} else{
						city = city.textContent;
					}
			  var phone = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('Phone').item(0);
					if (!phone) {
						phone = '';
					}else{
						phone = phone.textContent;

					}
			  var countryCode = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName(
							'CountryCode').item(0);
					if (!countryCode) {
						countryCode = '';
					} else{
						countryCode = countryCode.textContent;
					}
			  var postalCode = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('PostalCode').item(0);
					if (!postalCode){
						postalCode = '';
					}else{
						postalCode = postalCode.textContent;
					}
			  var email = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('BuyerEmail').item(0);
					if (!email){
						email = '';
					}else{
						email = email.textContent;
					}
			  var name = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('Name').item(0);
					if (!name){
						name = '';
					}else{
						name = name.textContent;
					}
			  var addressLine1 = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('AddressLine1').item(0);
					if (!addressLine1) {
						addressLine1 = '';
					} else{
						addressLine1 = addressLine1.textContent;
					}

			  var addressLine2 = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName(
							'AddressLine2').item(0);
					if (!addressLine2) {
						addressLine2 = '';
					} else{
						addressLine2 = addressLine2.textContent;
					}
       // Added by AJ on 13 Aug 2016 - to add functionality of selection of marketplace on marketplace id
			  var MarketplaceId = orderxml.item(0).getElementsByTagName('Order').item(k).getElementsByTagName('MarketplaceId').item(0);
					if (!MarketplaceId) {
						MarketplaceId = marketId;
					} else{
						MarketplaceId = MarketplaceId.textContent;
					}
					var newInternalId=marketplaceArr[MarketplaceId];
					internalid = newInternalId && parseInt(newInternalId)>0?newInternalId:internalid;
	   // End add							
		  try{
			var storefront = 'Amazon ' + countryCode + ' ' + actname;
			var storefront_id = getStrorefrontId(internalid);
			if(countryCode=='PR'){
				stateOrRegion='PR'   
				countryCode='US';
			}
			var customer_id = getcustomer(buyerName, name, email, phone,
					countryCode, stateOrRegion, city, addressLine1,
					addressLine2, postalCode, internalid,storefront_id,subsidiary,currency,account_receivable);
			nlapiLogExecution('DEBUG', 'cust_id', customer_id)
			var obj = nlapiCreateRecord(record, {recordmode : 'dynamic'});
			obj.setFieldValue('customform', cust_form);
			obj.setFieldValue('entity', customer_id)
			obj.setFieldValue('otherrefnum', amazonOrderId);
			if(internalid=='35'&&record=='salesorder'){
				obj.setFieldValue("orderstatus", "A"); //CBCO US Order as Pending Approval
			}
			obj.setFieldValue('custbody_storefront_list',storefront_id);
			obj.setFieldValue('custbody_storefront', storefront);
			var is_apo = getAPO(shipServiceLevel, city, stateOrRegion,addressLine1);
			if (is_apo == 'T'&&fulfillmentChannel==1&&subsidiary!=3){
				obj.setFieldValue('shipmethod', 35170);
			}
			obj.setFieldValue('custbody_amazon_is_apo', is_apo);
			obj.setFieldValue('custbody_storefront_order', amazonOrderId);
		    obj.setFieldValue('currency',currency); // Added on 14 Aug 2016 by AJ
			obj.setFieldValue('custbody_orderfrom', internalid);
			obj.setFieldValue('custbody_marketplace', 2);

			if(subsidiary==3){   
				if(fulfillmentChannel==1)
				obj.setFieldValue('location', warehouse);
				
				obj.setFieldValue('custbody_market_ship_serv_lvl', 8);
				obj.setFieldValue('custbody_taiwu_supplementstate', stateOrRegion);
				obj.setFieldValue('custbody_taiwu_supplymentprovince', stateOrRegion);
				obj.setFieldValue('custbody_taiwu_supplementaryphone', phone);
			}else{
				nlapiLogExecution('DEBUG', 'warehouse', warehouse)
				obj.setFieldValue('location', warehouse);
				var svc_level = getServiceLevel(shipServiceLevel, countryCode);
				obj.setFieldValue('custbody_market_ship_serv_lvl', svc_level);
			}				
			if(countryCode!='US'&&countryCode!='CA'&&subsidiary!=3){
				obj.setFieldValue('shipmethod', '35182');
			}
			if (record == 'invoice' && countryCode == '') {
				obj.setFieldValue('shipmethod',  '35311');

			}else if(record == 'invoice'){
				obj.setFieldValue('shipmethod', '35311'); // Added by AJ on 16 Aug

			}
			obj.setFieldValue('memo', 'created by Amazon Connector');
			if(record=='salesorder'&&internalid=='35'){
				obj.setFieldValue('memo', 'Needs Certified BCO warranty card');
				obj.setFieldValue('custbody_internal_note', 'Needs Certified BCO warranty card');
			}
			obj.setFieldValue('totalcostestimate', amount);
			var tot_ord_itm = itemxml.getElementsByTagName('OrderItem');
			var shipping_cost = 0;
			shipping_cost = parseFloat(shipping_cost);
			var item_found = 0;
			var totaltax = 0;
			var discount = 0;
			var wrapPrice = 0;
			var prefered_location1=[];
			for (var j = 0; j < tot_ord_itm.length; j++){
			var quantityOrdered = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName(
						'QuantityOrdered').item(0);
				if (!quantityOrdered) {
					quantityOrdered = '';
				} else{
					quantityOrdered = parseFloat(quantityOrdered.textContent);
				}
				nlapiLogExecution('DEBUG', 'quantityOrdered', quantityOrdered);
			var asin = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('ASIN').item(0);
				if (!asin) {
					asin = '';
				} else{
					asin = asin.textContent;
				}
				nlapiLogExecution('DEBUG', 'asin', asin);

			var seller_sku = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName(
						'SellerSKU').item(0);
				if (!seller_sku) {
					seller_sku = '';
				} else{
					seller_sku = seller_sku.textContent;
				}
				nlapiLogExecution('DEBUG', 'seller_sku', seller_sku);

			var orderItemId = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName(
						'OrderItemId').item(0);
				if (!orderItemId) {
					orderItemId = '';
				} else{
					orderItemId = orderItemId.textContent;
				}
			var promotionDiscount = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('PromotionDiscount').item(0);
				if (!promotionDiscount) {
					promotionDiscount = 0;
				} else{
					promotionDiscount = parseFloat(promotionDiscount.getElementsByTagName('Amount').item(0).textContent);
				}
//				nlapiLogExecution('DEBUG', 'promotionDiscount',promotionDiscount);
			var shippingDiscount = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('ShippingDiscount').item(0);
				if (!shippingDiscount) {
					shippingDiscount = 0;
				} else{
					shippingDiscount = parseFloat(shippingDiscount.getElementsByTagName('Amount').item(0).textContent);
				}
				discount = discount+promotionDiscount + shippingDiscount;
//				nlapiLogExecution('DEBUG', 'discount', discount);

			var itemTax = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('ItemTax').item(0);
				if (!itemTax) {
					itemTax = 0;
				} else {
					itemTax = parseFloat(itemTax.getElementsByTagName('Amount').item(0).textContent);
				}
				totaltax = parseFloat(totaltax + itemTax);
				if (itemTax > 0) {
					var taxable = 1;
				} else {
					var taxable = 0;
				}
//					nlapiLogExecution('DEBUG', 'itemTax', itemTax);
			var giftWrapTax = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('GiftWrapTax').item(0);
				if (!giftWrapTax) {
					giftWrapTax = 0;
				} else {
					giftWrapTax = parseFloat(giftWrapTax.getElementsByTagName('Amount').item(0).textContent);
				}
				totaltax = parseFloat(totaltax + giftWrapTax);
//					nlapiLogExecution('DEBUG', 'giftWrapTax', giftWrapTax);

			var giftWrapPrice = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('GiftWrapPrice').item(0);
				if (!giftWrapPrice){
					giftWrapPrice = 0;
				}else {
					wrapPrice += parseFloat(giftWrapPrice.getElementsByTagName('Amount').item(0).textContent);
				}
//					nlapiLogExecution('DEBUG', 'giftWrapPrice', giftWrapPrice);
			var giftMessageText = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('GiftMessageText').item(0);
				if (!giftMessageText) {
					giftMessageText = '';
				} else {
					giftMessageText = giftMessageText.textContent;
				}
//					nlapiLogExecution('DEBUG', 'GiftMessageText', giftMessageText);
            var itemPrice = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('ItemPrice').item(0);
				if (!itemPrice){
					itemPrice = 0;
				} else{
					itemPrice = parseFloat(itemPrice.getElementsByTagName('Amount').item(0).textContent);
				}	
				nlapiLogExecution('DEBUG', 'itemPrice', itemPrice);

			var shippingPrice = itemxml.item(0).getElementsByTagName('OrderItem').item(j).getElementsByTagName('ShippingPrice').item(0);
				if (!shippingPrice) {
					shippingPrice = 0;
				} else{
					shippingPrice = parseFloat(shippingPrice.getElementsByTagName('Amount').item(0).textContent);
				}
				nlapiLogExecution('DEBUG', 'shippingPrice', shippingPrice);
				shipping_cost = shipping_cost + shippingPrice;
				
			var itemid = getnsid(seller_sku, site, internalid,fulfillmentChannel,asin,site_id,warehouse,subsidiary);
				nlapiLogExecution('DEBUG', 'itemid', itemid);
			if(itemid==0){
				itemid=findIteminKit(seller_sku, internalid, fulfillmentChannel, asin, site_id, warehouse, subsidiary);
			}
			if(itemid==0&&subsidiary==3){
				itemid=getItemTaiwu(seller_sku);
			}
			if (itemid != 0){
				nlapiLogExecution('DEBUG', 'itemid', itemid);
				if(itemid[2]=='F'){
				if(quantityOrdered==0){
					nlapiSendEmail(email_author, mymail, 'Item Canceled | '+actname,'Item SKU : ' + seller_sku
									+ '\n Amazon Order Id: '+ amazonOrderId + '\n Amazon Account : ' + actname,'aj@webbeeglobal.com');
					item_found++;
				}
				else{
				if (quantityOrdered > 1 || itemid[1] > 1) {
					itemPrice = itemPrice/(quantityOrdered * parseFloat(itemid[1]))
					}
				
				if(subsidiary==3&&fulfillmentChannel==2){
				warehouse=nlapiLookupField('item',itemid[0],'preferredlocation');
					if(!warehouse){
						warehouse=nlapiLookupField('item',itemid[0],'location');
					}
				prefered_location1.push(warehouse);
				}
					nlapiLogExecution('DEBUG', 'warehouse1', warehouse);
					nlapiLogExecution('DEBUG', 'subsidiary', subsidiary);
               
			 if(subsidiary!=3||fulfillmentChannel==2){
				obj.selectNewLineItem('item');
				obj.setCurrentLineItemValue('item', 'item', itemid[0]);
				obj.setCurrentLineItemValue('item', 'location', warehouse);
				 obj.setCurrentLineItemValue('item', 'price','-1');
				obj.setCurrentLineItemValue('item', 'rate', itemPrice);
				if (taxable == 1&&subsidiary==1) {
					obj.setCurrentLineItemValue('item', 'taxcode', 10);
				}
				obj.setCurrentLineItemValue('item', 'custcol_gifttext',
						giftMessageText);

				obj.setCurrentLineItemValue('item', 'quantity',
						quantityOrdered * parseFloat(itemid[1]));
				obj.setCurrentLineItemValue('item', 'custcol_combofactor',itemid[1]);
				obj.setCurrentLineItemValue('item',
						'custcol_amazon_itemid', orderItemId);
				obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
				obj.setCurrentLineItemValue('item', 'rate', itemPrice);
				obj.commitLineItem('item');
				item_found++;
				}else{
				var bin=nlapiLookupField('customrecord_amazon_accounts',internalid,'custrecord_fba_bin_to_use');
   				var item_qty=quantityOrdered * parseInt(itemid[1]);
			    var kit_factor=1;
					var item_rec=nlapiLoadRecord('inventoryitem',itemid[0],{recordmode:"dynamic"});
					var line=item_rec.findLineItemValue('binnumber','binnumber',bin);
					nlapiLogExecution("DEBUG",'line',line);
					var fba_bins=item_rec.getLineItemValue('binnumber','locationid',afn_warehouse);
					if(line!=-1){
						var onhand_qty=item_rec.getLineItemValue('binnumber','onhand',line);
						if(onhand_qty>0){
							onhand_qty=parseInt(onhand_qty)
						}else{
							onhand_qty=0;
						}
						nlapiLogExecution("DEBUG",'onhand_qty :'+onhand_qty+' item_qty'+item_qty);
						if(item_qty>onhand_qty){
							transferinventory_ap_us(amazonOrderId,internalid,itemid[0],seller_sku,bin,record_act[internalid],item_qty,onhand_qty,fromUI,kit_factor);
						}	
					}else{
						item_rec.selectNewLineItem('binnumber');
						item_rec.setCurrentLineItemValue('binnumber','binnumber',bin);
						item_rec.commitLineItem('binnumber');
					nlapiSubmitRecord(item_rec,null,true);
					 item_rec=nlapiLoadRecord('inventoryitem',itemid[0],{recordmode:"dynamic"});
					 line=item_rec.findLineItemValue('binnumber','binnumber',bin);
					nlapiLogExecution("DEBUG",'line',line);
					 fba_bins=item_rec.getLineItemValue('binnumber','locationid',afn_warehouse);
					 onhand_qty=item_rec.getLineItemValue('binnumber','onhand',line);
					 if(onhand_qty>0){
							onhand_qty=parseInt(onhand_qty)
						}else{
							onhand_qty=0;
						}
					nlapiLogExecution('DEBUG',"onhand",onhand_qty);
					if(item_qty>onhand_qty)
						transferinventory_ap_us(amazonOrderId,internalid,itemid[0],seller_sku,bin,record_act[internalid],item_qty,onhand_qty,fromUI,kit_factor);
					
					}
					try{
					obj.selectNewLineItem('item');
					obj.setCurrentLineItemValue('item', 'item', itemid[0]);
				    obj.setCurrentLineItemValue('item', 'location', warehouse); // commented by AJ on 12 Aug 2016	
				    obj.setCurrentLineItemValue('item', 'price','-1');
	                obj.setCurrentLineItemValue('item', 'rate', itemPrice);
					if (taxable == 1&&subsidiary==1) {
						obj.setCurrentLineItemValue('item', 'taxcode', 10);
					}
					obj.setCurrentLineItemValue('item', 'custcol_gifttext',giftMessageText);
					nlapiLogExecution('DEBUG', 'quantity',item_qty);
					obj.setCurrentLineItemValue('item', 'quantity',item_qty);
					obj.setCurrentLineItemValue('item', 'custcol_combofactor',itemid[1]);
					obj.setCurrentLineItemValue('item','custcol_amazon_itemid', orderItemId);
					obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
					
						detail=obj.createCurrentLineItemSubrecord('item', 'inventorydetail');
						detail.selectNewLineItem('inventoryassignment');
						detail.setCurrentLineItemValue('inventoryassignment', 'binnumber', bin);
						nlapiLogExecution('DEBUG', 'quantity2',item_qty);
						detail.setCurrentLineItemValue('inventoryassignment', 'quantity', item_qty);
						detail.commitLineItem('inventoryassignment');
						detail.commit();
						
						obj.setCurrentLineItemValue('item', 'rate', itemPrice);
						obj.commitLineItem('item');
					}catch(err_itemementer){
					    	nlapiLogExecution('DEBUG', 'err_itemementer', err_itemementer);
					    	obj.selectNewLineItem('item');
							obj.setCurrentLineItemValue('item', 'item', itemid[0]);
						    obj.setCurrentLineItemValue('item', 'location', warehouse); // commented by AJ on 12 Aug 2016	
						    obj.setCurrentLineItemValue('item', 'price','-1');
			                obj.setCurrentLineItemValue('item', 'rate', itemPrice);
							if (taxable == 1&&subsidiary==1) {
								obj.setCurrentLineItemValue('item', 'taxcode', 10);
							}
							obj.setCurrentLineItemValue('item', 'custcol_gifttext',giftMessageText);
							nlapiLogExecution('DEBUG', 'quantity',item_qty);
							obj.setCurrentLineItemValue('item', 'quantity',item_qty);
							obj.setCurrentLineItemValue('item', 'custcol_combofactor',itemid[1]);
							obj.setCurrentLineItemValue('item','custcol_amazon_itemid', orderItemId);
							obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
					    	obj.setCurrentLineItemValue('item', 'rate', itemPrice);
							obj.commitLineItem('item');
					    }
					
					item_found++;
				           }
						}
			   }else{
				   var kitorder='T';
				obj.setFieldValue('custbody_kitorder', kitorder)
				var kititems=itemid[0];
				nlapiLogExecution('DEBUG', 'kititems', kititems);
				var split_item=[];
				split_item=kititems.split(';')
				var kitflag=0;
				for(var m=0;m<split_item.length;m++){
					var split_item1=[];
					split_item1=split_item[m].split('=');
					var kit_item=split_item1[0];
					var kit_factor=parseInt(split_item1[1]);
					var quantity=kit_factor*quantityOrdered;
					if(quantity>1){
						itemPrice=itemPrice/quantity
					}
					nlapiLogExecution('DEBUG', ' kit_item', kit_item);
					nlapiLogExecution('DEBUG', 'quantity', quantity);
					var filter = new Array();
					filter[0] = new nlobjSearchFilter('name', null, 'is', kit_item);
					var item = nlapiSearchRecord('inventoryitem', null, filter);
					if(item==null){
						nlapiLogExecution('DEBUG', 'Item not found with name '+kit_item);

					}else{
					var item_qty=quantity;
					var bin=nlapiLookupField('customrecord_amazon_accounts',internalid,'custrecord_fba_bin_to_use');

					kit_itemid=item[0].id;
					nlapiLogExecution('DEBUG', ' kit_itemid', kit_itemid);
					nlapiLogExecution('DEBUG', ' itemPrice', itemPrice);
					if(subsidiary==3&&fulfillmentChannel==2)
					{
						warehouse=nlapiLookupField('item',kit_itemid,'preferredlocation');

					if(!warehouse){
						warehouse=nlapiLookupField('item',kit_itemid,'location');

					}
					prefered_location1.push(warehouse);

					}
					if(subsidiary!=3||fulfillmentChannel==2){
						obj.selectNewLineItem('item');
						obj.setCurrentLineItemValue('item', 'item', kit_itemid);
					    obj.setCurrentLineItemValue('item', 'location', warehouse);
					    obj.setCurrentLineItemValue('item', 'quantity',item_qty);
					    obj.setCurrentLineItemValue('item', 'price','-1');
					    if(m==0)
					    obj.setCurrentLineItemValue('item', 'rate',itemPrice);
					    else
					    obj.setCurrentLineItemValue('item', 'rate','0');
					    obj.setCurrentLineItemValue('item','custcol_amazon_itemid', orderItemId);
						obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
					    obj.commitLineItem('item');
						kitflag++;
					}
					else{

						var bin=nlapiLookupField('customrecord_amazon_accounts',internalid,'custrecord_fba_bin_to_use');
					
							var item_rec=nlapiLoadRecord('inventoryitem',kit_itemid,{recordmode:"dynamic"});
							var line=item_rec.findLineItemValue('binnumber','binnumber',bin);
							nlapiLogExecution("DEBUG",'line',line);
							var fba_bins=item_rec.getLineItemValue('binnumber','locationid',afn_warehouse);
							if(line!=-1){
								var onhand_qty=item_rec.getLineItemValue('binnumber','onhand',line);
								if(onhand_qty>0){
									onhand_qty=parseInt(onhand_qty)
								}else{
									onhand_qty=0;
								}
								nlapiLogExecution('DEBUG',"onhand",onhand_qty);
								if(item_qty>onhand_qty){
									transferinventory_ap_us(amazonOrderId,internalid,kit_itemid,seller_sku,bin,record_act[internalid],item_qty,onhand_qty,fromUI,kit_factor);
								}
							}else{
								item_rec.selectNewLineItem('binnumber');
								item_rec.setCurrentLineItemValue('binnumber','binnumber',bin);
								item_rec.commitLineItem('binnumber');
							nlapiSubmitRecord(item_rec,null,true);
							 item_rec=nlapiLoadRecord('inventoryitem',itemid[0],{recordmode:"dynamic"});
							 line=item_rec.findLineItemValue('binnumber','binnumber',bin);
							nlapiLogExecution("DEBUG",'line',line);
							 fba_bins=item_rec.getLineItemValue('binnumber','locationid',afn_warehouse);
							 onhand_qty=item_rec.getLineItemValue('binnumber','onhand',line);
								nlapiLogExecution('DEBUG',"onhand",onhand_qty);
								if(onhand_qty>0){
									onhand_qty=parseInt(onhand_qty)
								}else{
									onhand_qty=0;
								}
								transferinventory_ap_us(amazonOrderId,internalid,kit_itemid,seller_sku,bin,record_act[internalid],item_qty,onhand_qty,fromUI,kit_factor);

							}
							try{								
								obj.selectNewLineItem('item');
								obj.selectNewLineItem('item');
								obj.setCurrentLineItemValue('item', 'item', kit_itemid);
							    obj.setCurrentLineItemValue('item', 'location', warehouse);
							    obj.setCurrentLineItemValue('item', 'quantity',item_qty);
							    obj.setCurrentLineItemValue('item', 'price','-1');
							    if(m==0){
								    obj.setCurrentLineItemValue('item', 'rate',itemPrice);
							    }else{
								    obj.setCurrentLineItemValue('item', 'rate','0');
							    }
							    obj.setCurrentLineItemValue('item','custcol_amazon_itemid', orderItemId);
								obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
								obj.commitLineItem('item');
								nlapiLogExecution('DEBUG', ' item enter ', itemid);
								kitflag++;
								}catch(erritementer){
									obj.selectNewLineItem('item');
									obj.selectNewLineItem('item');
									obj.setCurrentLineItemValue('item', 'item', kit_itemid);
								    obj.setCurrentLineItemValue('item', 'location', warehouse);
								    obj.setCurrentLineItemValue('item', 'quantity',item_qty);
								    obj.setCurrentLineItemValue('item', 'price','-1');
								    if(m==0){
									    obj.setCurrentLineItemValue('item', 'rate',itemPrice);
								    }else{
									    obj.setCurrentLineItemValue('item', 'rate','0');
								    }
								    obj.setCurrentLineItemValue('item','custcol_amazon_itemid', orderItemId);
									obj.setCurrentLineItemValue('item', 'custcol_sellersku',seller_sku);//added  27th jan
									detail=obj.createCurrentLineItemSubrecord('item', 'inventorydetail');
									detail.selectNewLineItem('inventoryassignment');
									detail.setCurrentLineItemValue('inventoryassignment', 'binnumber', bin);
									nlapiLogExecution('DEBUG', 'quantity2',item_qty);
									detail.setCurrentLineItemValue('inventoryassignment', 'quantity', item_qty);
									detail.commitLineItem('inventoryassignment');
									detail.commit();
									obj.commitLineItem('item');
									nlapiLogExecution('DEBUG', ' item enter ', itemid);
									kitflag++;
							}
							
					}
                    }
		          }
					if(kitflag==split_item.length){
						item_found++;
					}
			}	
		}else{
			nlapiLogExecution('DEBUG', 'seller sku '+seller_sku+' not found for '+fulfillmentChannel);
			var missed_record = nlapiCreateRecord("customrecord_amazonmissingorders");
			missed_record.setFieldValue('custrecord_amazonordreid',amazonOrderId);
			missed_record.setFieldValue('custrecord_accountid',internalid);
			missed_record.setFieldValue('custrecord_amazon_account', internalid);
			missed_record.setFieldValue('custrecord_missingreason', 'item sku '+seller_sku+' does not exist');
			nlapiSubmitRecord(missed_record);
			nlapiSendEmail(email_author, mymail,'sku notification','item sku '+seller_sku+' does not exist for Amazon Id: '+amazonOrderId+' | '+actname,cc_mail);
				}
		}

		if (item_found == tot_ord_itm.length) {	
			if (wrapPrice>0) 
			{
			var wrap_item_tiawu='108758';
			var wrap_item='42994';
			obj.selectNewLineItem('item');
			if(subsidiary==3){
			obj.setCurrentLineItemValue('item', 'item', wrap_item_tiawu);
			}else{
			obj.setCurrentLineItemValue('item', 'item', wrap_item);
			}
			obj.setCurrentLineItemValue('item', 'rate', wrapPrice);
			if (giftWrapTax > 0){
			obj.setCurrentLineItemValue('item', 'taxcode', 10);
				}
			obj.commitLineItem('item');
			}
			nlapiLogExecution('DEBUG', 'discount', discount);
			obj.setFieldValue('discountitem', 35169);
			obj.setFieldValue('discountrate', discount * (-1));
			nlapiLogExecution('DEBUG', 'totaltax', totaltax);
			obj.setFieldValue('custbody__amazonordertax', totaltax);
			obj.setFieldValue('custbody_amazonorderdate', purchaseDate);
			var xyz=[];
			    xyz=purchaseDate.split('T');
			    xyz=xyz[0].split('-');
        	var date=Number(xyz[2]);
        	var month=Number(xyz[1]);
        	var year=xyz[0];
        	var trad_date=month+'/'+date+'/'+year;
		    nlapiLogExecution('DEBUG', 'purchaseDate',purchaseDate);
		    nlapiLogExecution('DEBUG', 'trad_date',trad_date);
			obj.setFieldValue('trandate', trad_date);
			obj.setFieldValue('account', account_receivable);
			obj.setFieldValue('shippingcost', shipping_cost);
			nlapiLogExecution('DEBUG', 'about to create record','record creating ' + record);
			if(subsidiary==3){
//			obj.setFieldValue('shipmethod', '66630'); // Added by AJ on 14 Aug 2016
			obj.setFieldValue('custbody_market_ship_serv_lvl', 8);
				var exchangerate = obj.getFieldValue('exchangerate');
	            exchangerate = parseFloat(exchangerate);
	            total = parseFloat(amount);
            obj.setFieldValue('custbody_us_dollar_total', Math.round((exchangerate * total) / 6.6986));
            if(fulfillmentChannel==2){
				for(var m = 1; m < prefered_location1.length; m++){
				        if(prefered_location1[m] !== prefered_location1[0])
				        	prefered_location1[0]= false;
				    }
			if(prefered_location1[0]!=false)
			obj.setFieldValue('location', prefered_location1[0])
				}else{
        	obj.setFieldValue('location',warehouse)
	          }
			}
			var recId = nlapiSubmitRecord(obj);
			nlapiLogExecution('DEBUG', 'recId', recId);
			
		}else{
				nlapiLogExecution('DEBUG', record + ' is not created for '+ amazonOrderId + ' | ' + actname)
			}
		}catch(error){
			nlapiLogExecution('DEBUG','error',error);
			var missed_record = nlapiCreateRecord("customrecord_amazonmissingorders");
			missed_record.setFieldValue('custrecord_amazonordreid',amazonOrderId);
			missed_record.setFieldValue('custrecord_accountid',internalid);
			missed_record.setFieldValue('custrecord_amazon_account',internalid);
			missed_record.setFieldValue('custrecord_missingreason', error);
			var obj=nlapiSubmitRecord(missed_record);
			nlapiSendEmail(email_author,'govind@webbee.biz', 'Err: Orders Import | Id: '+amazonOrderId+' | '+actname,error,'aj@webbeeglobal.com');
			}
		}else{
			nlapiLogExecution('DEBUG', 'skipping duplicate '+record, amazonOrderId);
				}
	    }
				CheckGovernance();

			if(count==25){
				count=0;
				var start = new Date().getTime();
				 for (var t = 0; t < 1e7; t++) {
				    if ((new Date().getTime() - start) > 50000){
				    	break;
				    } 
				  }
				 }
				CheckGovernance();	
			}
		}
		try{
		 if(orderxml){
			var check_nexttoken = orderxml.getElementsByTagName('NextToken');
		 if(check_nexttoken.length>0){
			token++;
			var nexttoken=orderxml.item(0).getElementsByTagName('NextToken').item(0).textContent;
			nexttoken=encodeURIComponent(nexttoken);
		   nlapiLogExecution('DEBUG','nexttoken',nexttoken);
			}
	      }
	    }catch (er) {
	    	nlapiLogExecution('DEBUG','Err: in next token ',er);	
		nlapiSendEmail(email_author,'govind@webbee.biz', 'Err: in next token ',er,'aj@webbeeglobal.com');
		}
		CheckGovernance();
	}catch(err){
		 nlapiLogExecution('DEBUG','err',err);
			nlapiSubmitField('customrecord_amazon_accounts',internalid, 'custrecord_lastupdatetime',fromTime)
			var missed_record = nlapiCreateRecord("customrecord_amazonmissingorders");
			missed_record.setFieldValue('custrecord_amazonordreid','');
			missed_record.setFieldValue('custrecord_accountid',internalid);
			missed_record.setFieldValue('custrecord_missingreason', err);
			missed_record.setFieldValue('custrecord_amazon_account', internalid);
			nlapiSubmitRecord(missed_record);
		 	nlapiSendEmail(email_author,'govind@webbee.biz', 'Err: in order import '+' | '+actname,err,'aj@webbeeglobal.com');
		 }
	}
}
function getcustomer(buyerName,name, email, phone, country, state, city, add1, add2,postalCode,amazon_account,storefront_id,subsidiary,currency,account_receivable) {
	buyerName=buyerName.trim();
	var split = [];
	split = buyerName.split(' ');
	var internal_id;
	var filters = new Array();
	filters[0] = new nlobjSearchFilter('email', null, 'is', email);
	filters[1] = new nlobjSearchFilter('custentity_storefront', null, 'is', storefront_id);
	var columns = new Array();
	columns[0] = new nlobjSearchColumn('internalid');
	columns[1] = new nlobjSearchColumn('addressee');
	columns[2] = new nlobjSearchColumn('zipcode');
	var searchResults = nlapiSearchRecord('customer', null, filters, columns);
	if (searchResults == null) {
		var obj = nlapiCreateRecord('customer', {recordmode : 'dynamic'});
		obj.setFieldValue('isperson', 'T');
		obj.setFieldValue('custentity_storefront', storefront_id);
		nlapiLogExecution('DEBUG', 'split.length', split.length);
		if (split.length == 1) {
			if (split[0] == '') {
				split[0] = 'NotAvailable'
			}
			obj.setFieldValue('firstname', split[0]); // if is person is not
			// an individual
			obj.setFieldValue('lastname', "<>");
		} else if (split.length == 2) {
			nlapiLogExecution('DEBUG', 'lastname', split[1]);
			nlapiLogExecution('DEBUG', 'firstname', split[0]);

if(split[1]=='null'){
	split[1]='Null';
}
			obj.setFieldValue('lastname', split[1]);
			obj.setFieldValue('firstname', split[0]); // if is person
			// is not an
			// individual

		} else if (split.length > 2&&(split.length <= 4)) {
			nlapiLogExecution('DEBUG', 'firstname', split[0]);
			nlapiLogExecution('DEBUG', 'middlename', split[1]);
			nlapiLogExecution('DEBUG', 'lastname', split.slice(2,
					(split.length)).join(' '));

			obj.setFieldValue('lastname', split.slice(2, (split.length)).join(
					' '));
			obj.setFieldValue('middlename', split[1]);
			obj.setFieldValue('firstname', split[0]); // if is person
			// is not an
			// individual
		}
		 else if (split.length > 4) {
				

				obj.setFieldValue('lastname', split.slice((split.length-3),(split.length)).join(' '));
				obj.setFieldValue('middlename', split.slice(1,(split.length-3)).join(' '));
				obj.setFieldValue('firstname', split[0]); // if is person
				// is not an
				// individual
			}
		var random = Math.floor(Math.random() * (9000 - 1000 + 1)) + 1000;

		obj.setFieldValue('entityid', buyerName + " online " + random);
		obj.setFieldValue('subsidiary', subsidiary);
		obj.setFieldValue('currency', currency); // Added on 14 Aug 2016 bt AJ

		obj.setFieldValue('email', email);

		if(account_receivable){
			obj.setFieldValue('receivablesaccount',account_receivable );			
		}
		
		nlapiLogExecution('DEBUG', 'Aphone', phone.length);
		if (phone.match(/[^0]/) && (phone.length >= 8)) {
			obj.setFieldValue('phone', phone);
		}

		// Add first line to sublist
		if (country) {
			obj.selectNewLineItem('addressbook');
			obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T'); // This
			// field
			// is
			// not
			// a
			// subrecord
			// field.
			obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T'); // This
			// field
			// is
			// not
			// a
			// subrecord
			// field.
			obj.setCurrentLineItemValue('addressbook', 'label', add1); // This
			// field is
			// not a
			// subrecord
			// field.
			// obj.setCurrentLineItemValue('addressbook', 'isresidential', 'F');
			// //This field is not a subrecord field.

			// create address subrecord
			var subrecord = obj.createCurrentLineItemSubrecord('addressbook',
					'addressbookaddress');

			// set subrecord fields
			subrecord.setFieldValue('country', country); // Country must be
															// set before
															// setting the other
															// address fields
			subrecord.setFieldValue('addressee', name);
			if (phone.match(/[^0]/) && (phone.length >= 8)) {
				subrecord.setFieldValue('addrphone', phone);
			}
			if(add1)
			{
		    subrecord.setFieldValue('addr1', add1);
		    if(add2)
			subrecord.setFieldValue('addr2', add2);
			}
			else{
			    subrecord.setFieldValue('addr1', add2);
			}
			subrecord.setFieldValue('city', city);
			subrecord.setFieldValue('state', state.slice(0,30));
			subrecord.setFieldValue('zip', postalCode);
			subrecord.commit();

			obj.commitLineItem('addressbook');
		}
		var internal_id = nlapiSubmitRecord(obj);

		return internal_id;
		// nlapiLogExecution('DEBUG','New Customer Created',internal_id);
	} else {
		
		
		nlapiLogExecution('DEBUG', 'Existing Customer');
		internal_id = searchResults[0].getValue(columns[0]);
		if (country) 
		{
		var obj=nlapiLoadRecord('customer',internal_id,{recordmode : 'dynamic'});
		var flag=0;
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG', 'lines',lines);

		obj.setFieldValue('currency', currency); // Added on 14 Aug 2016 bt AJ
		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addressee=obj.getLineItemValue('addressbook','addressee', z);
			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addressee',cust_addressee);

			if(cust_zipcode==postalCode&&cust_addressee==name){
				obj.selectLineItem('addressbook', z);
				obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
				obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
				obj.commitLineItem('addressbook');
				flag++;
			}
		}
		nlapiLogExecution('DEBUG', 'flag',flag);

		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addressee );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
		obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
		obj.setCurrentLineItemValue('addressbook', 'label', add1);
		  var subrecord = obj.createCurrentLineItemSubrecord('addressbook', 'addressbookaddress');

		    //set subrecord fields
		    subrecord.setFieldValue('country', country); //Country must be set before setting the other address fields
		    subrecord.setFieldValue('addressee',name);
			if(phone.match(/[^0]/)&&(phone.length>=8)){
			    subrecord.setFieldValue('addrphone', phone);
				}
			if(add1)
			{
		    subrecord.setFieldValue('addr1', add1);
			subrecord.setFieldValue('addr2', add2);
			}
			else{
			    subrecord.setFieldValue('addr1', add2);
			}
		    subrecord.setFieldValue('city', city);
		    subrecord.setFieldValue('state', state.slice(0,30));
		    subrecord.setFieldValue('zip', postalCode);
			subrecord.commit();	
			obj.commitLineItem('addressbook');
			
		}
		var internal_id = nlapiSubmitRecord(obj, true);
	}
			return internal_id;
	}
}

// *************************************function to get item
// nsid********************************//
function getnsid(seller_sku, site, acctname, skutype,asin,site_id,warehouse,subsidiary) {
	if(acctname==29||acctname==30||acctname==28||acctname==34)
		acctname=17;
	else if(acctname==37||acctname==38||acctname==39||acctname==25)
	acctname=23;
	var sku=seller_sku;
	var ary=[];
	ary=seller_sku.replace("@","|").split("|");
	seller_sku=ary[0];
nlapiLogExecution('DEBUG', 'seller_sku',seller_sku);
	var column = [];
	column.push(new nlobjSearchColumn('custrecord_sites'));
	column.push(new nlobjSearchColumn('custrecord_account_name'));
	column.push(new nlobjSearchColumn('custrecord_custitem'));
	column.push(new nlobjSearchColumn('custrecord_comboquantity'));
	column.push(new nlobjSearchColumn('custrecord_amazon_kit'));
	column.push(new nlobjSearchColumn('custrecord_kitlink'));

	var filter = [];
	
	filter.push(new nlobjSearchFilter('custrecord_account_name', null, 'is',
			acctname));
	if(subsidiary!=3)
	{filter.push(new nlobjSearchFilter('custrecord_skutype', null, 'is',skutype))
	  filter.push(new nlobjSearchFilter('custrecord_sites', null, 'is', site));
	}
	filter
			.push(new nlobjSearchFilter('custrecord_sku', null, 'is',
					sku));
	var search_result1 = nlapiSearchRecord('customrecord_amazon_listings',
			null, filter, column);

	nlapiLogExecution('DEBUG', 'search_result1',search_result1);
	if (search_result1 != null) {
		nlapiLogExecution('DEBUG', 'listing  found');
		var item_id = search_result1[0].getValue('custrecord_custitem');
		var combofactor = search_result1[0]
				.getValue('custrecord_comboquantity');
		var is_kit=search_result1[0].getValue('custrecord_amazon_kit');
		var kit=search_result1[0].getValue('custrecord_kitlink');
		combofactor = combofactor ? combofactor : 1;
		nlapiLogExecution('DEBUG', 'search_result11', item_id + " "
				+ combofactor);
		if(is_kit=='T'){
			item_id=nlapiLookupField('customrecord_kit', kit, 'custrecord_kit_mapping')
		}
		return [ item_id, combofactor ,is_kit];
	} 
	else {
		nlapiLogExecution('DEBUG', 'listing not found');
		if(sku==seller_sku)
			{
			nlapiLogExecution('DEBUG', 'sku==seller_sku');
			return 0;
			}
		else{
			nlapiLogExecution('DEBUG', 'sku!=seller_sku');

				try {
					var search_result2 = nlapiSearchRecord('inventoryitem',null,  [ [ "name", "is", seller_sku ], "OR", [ "custitem_sku_alias", "is", seller_sku ],
								                                                       "OR", [ "itemid", "is", seller_sku ],"OR",[ "externalid", "is", seller_sku ],
								                                                       "OR",[ "custitem_legacy_tong_sku", "is", seller_sku ] ],(new nlobjSearchColumn('internalid').setSort(true)));
								nlapiLogExecution('DEBUG', 'search_result12',search_result2);
								if (search_result2 != null) {
									var itemInternalId = search_result2[0].getId();
									var record = nlapiCreateRecord("customrecord_amazon_listings");
									record.setFieldValue('custrecord_custitem', itemInternalId);// //////////////
									record.setFieldValue('custrecord_isactive', 'T');
									record.setFieldValue('custrecord_account_name',acctname);
									record.setFieldValue('custrecord_sites',site_id);
									record.setFieldValue('custrecord_skutype', skutype);
									record.setFieldValue('custrecord_sku', sku);
									record.setFieldValue('custrecord_itemsku', '');
									record.setFieldValue('custrecord_asin',asin);
									record.setFieldValue('custrecord_warehouse',warehouse);
//									record.setFieldValue('custrecord_itemcondition',params.condition);
									var success = nlapiSubmitRecord(record,null,true);
									nlapiLogExecution('DEBUG', 'new listing',success);

									return  [ itemInternalId, '1','F' ];
							}
								else{
									nlapiLogExecution('DEBUG', 'sku!=seller_sku');
									return 0;
								}
							} 
				catch (e) {
					nlapiLogExecution('DEBUG', 'catch search_result1',e);
					return 0;
				}
		
		
	}

}
	


}
function  findIteminKit(seller_sku, acctname, skutype,asin,site_id,warehouse,subsidiary){
	if(acctname==29||acctname==30||acctname==28||acctname==34)
		acctname=17;
	else if(acctname==37||acctname==38||acctname==39||acctname==25)
	acctname=23;
	var sku=seller_sku;
	var ary=[];
	ary=seller_sku.replace("@","|").split("|");
	nlapiLogExecution('DEBUG', 'ary', ary);
	seller_sku=ary[0];
var columns=new nlobjSearchColumn('custrecord_kit_mapping')
var search=nlapiSearchRecord('customrecord_kit', null, [ ['custrecord_sku_alias','is',seller_sku],"OR",['custrecord_kit_sku','is',seller_sku]], columns);
if(search!=null){
	var kitid=search[0].getId();
	var items=search[0].getValue('custrecord_kit_mapping');

	var record = nlapiCreateRecord("customrecord_amazon_listings");
//	record.setFieldValue('custrecord_custitem', itemInternalId);// //////////////
	record.setFieldValue('custrecord_isactive', 'T');
	record.setFieldValue('custrecord_account_name',acctname);
	record.setFieldValue('custrecord_sites',site_id);
	record.setFieldValue('custrecord_skutype', skutype);
	record.setFieldValue('custrecord_sku', sku);
	record.setFieldValue('custrecord_itemsku', '');
	record.setFieldValue('custrecord_asin',asin);
	record.setFieldValue('custrecord_warehouse',warehouse);
	record.setFieldValue('custrecord_itemcondition',1);
	record.setFieldValue('custrecord_amazon_kit','T');
	record.setFieldValue('custrecord_kitlink',kitid);
	var success = nlapiSubmitRecord(record,null,true);
	nlapiLogExecution('DEBUG', 'new listing',success);
	return [items,'1','T'];
}
else{
	return 0;
}
}
function getItemTaiwu(seller_sku){

	

	nlapiLogExecution('DEBUG', 'seller_sku', seller_sku);
	var ary=[];
	ary=seller_sku.replace("@","|").split("|");
	nlapiLogExecution('DEBUG', 'ary', ary);
	seller_sku=ary[0];
	nlapiLogExecution('DEBUG', 'seller_sku_taiwu', seller_sku);
	var filter = [];
	var search_result1 = nlapiSearchRecord('item',null,  [ [ "name", "is", seller_sku ], "OR", [ "custitem_sku_alias", "is", seller_sku ],
	                                                       "OR", [ "itemid", "is", seller_sku ],"OR",[ "externalid", "is", seller_sku ],
	                                                       "OR",[ "custitem_legacy_tong_sku", "is", seller_sku ] ],(new nlobjSearchColumn('internalid').setSort(true)));

nlapiLogExecution('DEBUG', 'search_result1', search_result1);
	if (search_result1 != null) {
		var item_id = search_result1[0].getId();
		var itemtype=nlapiLookupField('item', item_id, 'recordtype')
		nlapiLogExecution('DEBUG', 'itemtype', itemtype);
		if(itemtype=='kititem'||itemtype=='noninventoryitem'){          //added 5th June - Govind
			return 0;
		}	
		else{
			return [ item_id, '1','F' ];
		}
	} else {
		return 0;
	}



}
function getServiceLevel(amz_svc_level,country) {
	var svc_level = "";
	if(country!='US'&&country!='CA'&&country!=''){
		svc_level=5;
	}
	else{
		if (amz_svc_level.match(/^Std /) || amz_svc_level=="Standard") {
			svc_level = 1;
		} else if (amz_svc_level.match(/^Exp /)) {
			svc_level = 2;
		} else if (amz_svc_level == "SecondDay"||amz_svc_level.match(/^Second /)||amz_svc_level == "Second" ) {
			svc_level = 3;
		} else if (amz_svc_level == "ThirdDay") {
			svc_level = 3;
		} else if (amz_svc_level == "NextDay") {
			svc_level = 4;
		} else {
			svc_level = 6;
		}
	
	}
	nlapiLogExecution('DEBUG', 'a_svc_level', svc_level);
	return svc_level;
}

function getAPO(amz_svc_level,city,stateOrRegion,addr1) {
	var svc_level = "F";
	if (amz_svc_level.match(/APO/)) {
		svc_level = "T";
	}
	if (city.match(/APO/)) {
		svc_level = "T";
	}
	if(addr1.match(/^P.O.Box/)){
		svc_level = "T";
	}
	if(stateOrRegion=="PR"||stateOrRegion=="AE"||stateOrRegion=="AP"||stateOrRegion=="VI"||stateOrRegion=="AS"||stateOrRegion=="GU"||stateOrRegion=="MP"||stateOrRegion=="UM"||stateOrRegion=="Virgin Islands"){
	svc_level = "T";
}
	return svc_level;
}

function searchRecordDup(record_type,value){
	 
	var filters=[]; 
   //filters = new nlobjSearchFilter('otherrefnum',null,'equalto',value);//comment on 6/12 by Govind
   filters = new nlobjSearchFilter('poastext',null,'is',value);
	 var column=[];
	 column.push(new nlobjSearchColumn('otherrefnum'));	 
	 var searchResults = nlapiSearchRecord(record_type, null, filters, column);
	 if(searchResults != null && searchResults.length>=1){
		 var recid=searchResults[0].getId();
		 var b=searchResults.length;
		 var rec_po_no=searchResults[0].getValue('otherrefnum');

		 
		 return 0;		
	}
	 else{
		 return 1;
	 }

}
function request_string(awsKey,fromTime,marketId,sellerId,timestamp){
	var queryString = "AWSAccessKeyId=" + awsKey + "&Action=ListOrders"
	+ "&LastUpdatedAfter=" + fromTime + "&MarketplaceId.Id.1="
	+ marketId + "&OrderStatus.Status.1=Unshipped"
	+ "&OrderStatus.Status.2=PartiallyShipped"
	+ "&OrderStatus.Status.3=Shipped" + "&SellerId=" + sellerId
	+ "&SignatureMethod=HmacSHA256" + "&SignatureVersion=2"
	+ "&Timestamp=" + timestamp + "&Version=2013-09-01";
	return queryString;
	nlapiLogExecution('DEBUG', 'qs1', queryString);
}
function request_string_lasttoken(awsKey,sellerId,timestamp,nexttoken){
	var querystring='AWSAccessKeyId='+awsKey
		+'&Action=ListOrdersByNextToken'
		+'&NextToken='+nexttoken
		+'&SellerId='+sellerId
		+'&SignatureMethod=HmacSHA256'
		+'&SignatureVersion=2'
		+'&Timestamp='+timestamp
		+'&Version=2013-09-01';
	return querystring;
	nlapiLogExecution('DEBUG', 'qs1', queryString);

}
function getStrorefrontId(internalid){
	var arrStorefront={};
	arrStorefront[1]=2;
	arrStorefront[5]=65;
	arrStorefront[8]=3;
	arrStorefront[9]=22;
	arrStorefront[10]=24;
	arrStorefront[11]=25;
	arrStorefront[12]=27;//WonderMall
	arrStorefront[13]=28;//Globalsellinc CA
	arrStorefront[14]=26;//Globalsellinc US	
	arrStorefront[15]=37;//Giddytime US
	arrStorefront[16]=38;//Giddytime CA
	arrStorefront[17]=29;//Love Shine Forever UK	
	arrStorefront[18]=30;//Flowers Love US
	arrStorefront[19]=31;//Flowers Love CA
	arrStorefront[20]=33;//	MightyHand Amazon CA
	arrStorefront[21]=32;//MightyHand Amazon U.S. 
	arrStorefront[22]=39;//Populars Amazon UK
	arrStorefront[23]=34;//Save in a Snap UK
	arrStorefront[24]=36;//Also Popular US
	arrStorefront[25]=35;//Save in a Snap EU
	arrStorefront[26]=47;
	arrStorefront[28]=54;
	arrStorefront[29]=56;
	arrStorefront[30]=58;
	arrStorefront[31]=62;
	arrStorefront[32]=64;
	arrStorefront[33]=63;
	arrStorefront[34]=60;
	arrStorefront[35]=61;
	arrStorefront[36]=74;
	arrStorefront[37]=66;
	arrStorefront[38]=67;
	arrStorefront[39]=68;
	arrStorefront[40]=73;
	arrStorefront[41]=69;
	arrStorefront[42]=72;
	arrStorefront[43]=71;
	arrStorefront[44]=70;
	arrStorefront[45]=77;
	arrStorefront[46]=79;
	arrStorefront[47]=81;
	arrStorefront[48]=82;
	arrStorefront[49]=83;
	arrStorefront[50]=84;
	arrStorefront[51]=85;
	arrStorefront[52]=86;
	var storefront_id=arrStorefront[internalid]
	return storefront_id;
}
function CheckGovernance() {
	var mymail='govind@webbee.biz';
	var mail_cc='aj@webbeeglobal.com';
    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
    	
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
	 	nlapiSendEmail(email_author,'aj@webbeeglobal.com', 'Err: in CheckGovernance() ',ex);

    }
}