function updateOrderInfo(info) {

    nlapiLogExecution('debug', 'info', JSON.stringify(info));

    if (info == null || info.internalid == '') {
        //return info ;
        return 0;
    }

    var salesOrder = nlapiLoadRecord('salesorder', info.internalid);
    if (salesOrder == null) {
        return 1;
    }


    salesOrder.setFieldValue('custbody_tracked', "T");
    var id = nlapiSubmitRecord(salesOrder, true);

    return 2;
}