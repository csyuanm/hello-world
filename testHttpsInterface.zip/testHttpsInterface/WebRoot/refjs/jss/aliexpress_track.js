function getShipItem(info){
  	if (info == null || info.salesOrderId == null) {
		return false;
	}
   var shipment = new Shipment(info.salesOrderId);
   return  shipment.getShippingLabelDetails();


}