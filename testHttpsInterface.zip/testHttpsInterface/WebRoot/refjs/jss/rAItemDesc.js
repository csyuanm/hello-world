/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       02 Jun 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function setRaItemDesc(type){
	try{
		
		if(type == "create"){
			var items = [];
			var count = nlapiGetLineItemCount('item');
			var id = nlapiGetRecordId();
			nlapiLogExecution('Debug','RA id',id);
			nlapiLogExecution('Debug','count',count);
			for(var i =1;i<=count;i++){
				var itemDes = '';
                var item = nlapiGetLineItemValue('item','item',i);
                var itemType = nlapiLookupField('item',item,'recordtype');
                nlapiLogExecution('Debug','itemType ',itemType);
                if(itemType != 'discountitem' || itemType != 'otherchargeitem' || itemType != 'serviceitem')
                  itemDes = nlapiGetLineItemValue('item','description',i);
				
				if(itemDes)
                  items.push(itemDes);
				
				
				
			}
			
			var desc = items.join(' , ');
			nlapiLogExecution('Debug','desc',desc);
			
			nlapiSubmitField('returnauthorization',id,'custbody_ra_items',desc);
			
			nlapiLogExecution('Debug','done ',"true");
		}
	}catch(e){
		nlapiLogExecution('Debug','error in afterSubmit function ',e);
	}
	
}
