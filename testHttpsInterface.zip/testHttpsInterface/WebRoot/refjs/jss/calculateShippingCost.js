function UPSxml(shipToName, shipToPhoneNumber, shipToAddressLine, shipToCity,
                shipToPostalCode, shipToCountryCode, serviceCode, packageTypeCode,
                unitOfMeasurement, weight, residential) {
    var url = 'https://onlinetools.ups.com/ups.app/xml/Rate';
    var XML = "";
    XML += '<?xml version="1.0"?><AccessRequest xml:lang="en-US"><AccessLicenseNumber>1CF3D7AB6CD541A8</AccessLicenseNumber><UserId>zakeusa</UserId><Password>Keepout1</Password></AccessRequest><?xml version="1.0"?><RatingServiceSelectionRequest xml:lang="en-US"><Request><TransactionReference><CustomerContext>Rating and Service</CustomerContext><XpciVersion>1.0</XpciVersion></TransactionReference><RequestAction>Rate</RequestAction><RequestOption>Rate</RequestOption></Request><Shipment><Description>Rate Description</Description><Shipper><Name>abc</Name><PhoneNumber>1234567890</PhoneNumber><ShipperNumber>X865V0</ShipperNumber><Address><AddressLine1>3431 William Richardson dr</AddressLine1><City>south bend</City><StateProvinceCode>IN</StateProvinceCode><PostalCode>46628</PostalCode><CountryCode>US</CountryCode></Address></Shipper><ShipTo><CompanyName>';
    XML += shipToName;
    XML += '</CompanyName>';
    if (residential == true) {
        XML += '<ResidentialAddress/>';
    }
    XML += '<PhoneNumber>';
    XML += shipToPhoneNumber;
    XML += '</PhoneNumber><Address><AddressLine1>';
    XML += shipToAddressLine;
    XML += '</AddressLine1><City>';
    XML += shipToCity;
    XML += '</City><PostalCode>';
    XML += shipToPostalCode;
    XML += '</PostalCode><CountryCode>';
    XML += shipToCountryCode;
    XML += '</CountryCode></Address></ShipTo><ShipFrom><CompanyName>abc</CompanyName><AttentionName>abc</AttentionName><PhoneNumber>1234567890</PhoneNumber><FaxNumber>1234567890</FaxNumber><Address><AddressLine1>3431 William Richardson dr</AddressLine1><City>south bend</City><StateProvinceCode>IN</StateProvinceCode><PostalCode>46628</PostalCode><CountryCode>US</CountryCode></Address></ShipFrom><Service><Code>';
    XML += serviceCode;
    XML += '</Code></Service><PaymentInformation><Prepaid><BillShipper><AccountNumber>Ship Number</AccountNumber></BillShipper></Prepaid></PaymentInformation><Package><PackagingType><Code>';
    XML += packageTypeCode;
    XML += '</Code><Description>Customer Supplied</Description></PackagingType><Description>Rate</Description><PackageWeight><UnitOfMeasurement><Code>';
    XML += unitOfMeasurement;
    XML += '</Code></UnitOfMeasurement><Weight>';
    XML += weight;
    XML += '</Weight></PackageWeight></Package><RateInformation><NegotiatedRatesIndicator/></RateInformation></Shipment></RatingServiceSelectionRequest>';
    nlapiLogExecution("debug", "UPS XML", XML);

    var response = nlapiRequestURL(url, XML);
    nlapiLogExecution("debug", "feild values", response.getBody());

    var xml = nlapiStringToXML(response.getBody());
    var shippingPrice = nlapiSelectValue(
        xml,
        '/RatingServiceSelectionResponse/RatedShipment/NegotiatedRates/NetSummaryCharges/GrandTotal/MonetaryValue');
    nlapiLogExecution("debug", "shippingPrice", shippingPrice);

    return parseFloat(shippingPrice);
}

function USPSxml(service, zipOrigination, zipDestination, weightinOunces, size,
                 width, length, height) {

    var zipDestinationList = zipDestination.split("-");
    zipDestination = zipDestinationList[0];
    var XML = '';
    XML += '<RateV4Request USERID="4503BTEC1282" ><Revision/><Package ID="1ST"><Service>';
    XML += service;
    XML += '</Service><ZipOrigination>';
    XML += zipOrigination;
    XML += '</ZipOrigination><ZipDestination>';
    XML += zipDestination;
    XML += '</ZipDestination><Pounds>0</Pounds><Ounces>';
    XML += weightinOunces;
    XML += '</Ounces><Container>NONRECTANGULAR</Container><Size>';
    XML += size;
    XML += '</Size><Width>'
    XML += width;
    XML += '</Width><Length>';
    XML += length;
    XML += '</Length><Height>';
    XML += height;
    XML += '</Height><Girth>55</Girth></Package></RateV4Request>'; //

    var url = 'http://production.shippingapis.com/ShippingAPI.dll?API=RateV4&XML='
        + escape(XML);

    nlapiLogExecution('DEBUG', 'USPS xml created : ', XML);
    var response = nlapiRequestURL(url);
    nlapiLogExecution('DEBUG', 'USPSResponse : ', response.getBody());

    var xml = nlapiStringToXML(response.getBody());
    var shippingPrice = nlapiSelectValue(xml,
        '/RateV4Response/Package/Postage/Rate');
    var shippingPriceCommercial = nlapiSelectValue(xml,
        '/RateV4Response/Package/Postage/CommercialRate');
    shippingPrice = shippingPriceCommercial ? shippingPriceCommercial : shippingPrice;
    if(shippingPrice)
    	shippingPrice=parseFloat(shippingPrice)
    return shippingPrice;
}
function calculateShipping(salesOrderId) {
	mail='govind@webbee.biz';
	cc='aj@webbeeglobal.com';
    try {
    
		var mail_cc=['josh@3btech.net','matt@3btech.net','nate@3btech.net'];

        var obj = nlapiLoadRecord('salesorder', salesOrderId);
        var status = obj.getFieldValue('orderstatus');
    	var clac_shipping=obj.getFieldValue('custbody_donot_change_shipping');
		if(clac_shipping=='F')
		{
        var shipname = obj.getFieldValue('shipattention');
        var shipcity = obj.getFieldValue('shipcity');
        var shipaddress = obj.getFieldValue('shipaddr1');
        var shipaddress2 = obj.getFieldValue('shipaddr2');
        if (!shipaddress2) {
            shipaddress2 = '';
        }
        var shipaddress3 = obj.getFieldValue('shipaddr3');
        if (!shipaddress3) {
            shipaddress3 = '';
        }
        var amazon_ordId = obj.getFieldValue('otherrefnum');
        var shipzip = obj.getFieldValue('shipzip');
        var shipphone = obj.getFieldValue('shipphone');
        var shipstate = obj.getFieldValue('shipstate');
        var shipcountry = obj.getFieldValue('shipcountry');
        var shipcost = obj.getFieldValue('shippingcost');


        var shippingService = obj.getFieldValue('custbody_market_ship_serv_lvl');
        var notMatched = false;
        var calculateweight = calculateTotalWeight(salesOrderId);
        var weight_in_oz = parseFloat(calculateweight[0]);
        nlapiLogExecution('debug', 'weight up', weight_in_oz);
        var unit_of_measurement = calculateweight[1];
        nlapiLogExecution('debug', 'unit_of_measurement', unit_of_measurement);
        nlapiLogExecution('DEBUG', 'status : ', status);
        nlapiLogExecution('DEBUG', 'shipaddress :', shipaddress);
        nlapiLogExecution('DEBUG', 'shipaddress2 :', shipaddress2);
        nlapiLogExecution('DEBUG', 'shipaddress3 : ', shipaddress3);
        nlapiLogExecution('DEBUG', 'shippingService :', shippingService);
        nlapiLogExecution('DEBUG', 'shipcountry: ', shipcountry);
        nlapiLogExecution('DEBUG', 'shipcity: ', shipcity);
        nlapiLogExecution('DEBUG', 'shipzip: ', shipzip);
        nlapiLogExecution('DEBUG', 'shipcost: ', shipcost);
        try{
            var isResidential = getAddressType(shipcity, shipaddress, shipzip, shipstate);
    		if (isResidential == true) {
    			var residential_flag = 'T';
    		} else {
    			var residential_flag = 'F';
    		}}
    		catch(e){
    			var isResidential = false;
    			var residential_flag = 'F';
    		}
        nlapiLogExecution('DEBUG', 'isResidential : ' + isResidential);

        if ((shippingService == '1') && weight_in_oz <= 14) {
			var column = [];
		    column.push(new nlobjSearchColumn('internalid').setSort(true)); 
		    column.push(new nlobjSearchColumn('custrecord_firstclassparcelcost'));
		    column.push(new nlobjSearchColumn('custrecord_firtsclassmailcost').setSort(false));
		    	var filter = [];
			     filter.push(new nlobjSearchFilter('custrecord_weightupto',null,'lessthanorequalto',(weight_in_oz+1)));
		    	var search = nlapiSearchRecord('customrecord_weightfirstclass',null, filter, column);
		    	if(search!=null){
		    			var firstclassparcel_cost = search[0]
		    					.getValue('custrecord_firstclassparcelcost');
		    			var firstclassmail_cost = search[0]
		    					.getValue('custrecord_firtsclassmailcost');
		    			
		    		}
		    	else{
		    		var firstclassparcel_cost =0;
		    		var firstclassmail_cost =0;
		    		nlapiSendEmail(1659, 'govind@webbee.biz',
		    				'Alert | Auto Approve | Std Order: '
		    						+ amazon_ordId, 'No Cost is calculated for criteria : Standard ShipService & weight='+weight_in_oz, 'aj@webbeeglobal.com');
		    	}
			}
        var uspspriority = '35170';
        var uspspriorityinternational = '35178';
        var uspsprioritycommercial = '35170';
        var uspsfirstclass = '8';
        var uspsfirstclassCommercial = '8';

        var uspsfirstclassCommercialMailLessThan14 = '35175';

        var upsNextDayAirSaver = '35173';
        var upsNextDaySaver = 35173;
        var upsSecondDayAir = 35171;
        var upsThirdDay = 35174;
        var upsground = 4;

        var uspspriorityforxml = 'Priority Commercial';
        var uspsprioritycommercialforxml = 'Priority Commercial';
        var uspsfirstclassforxml = 'First Class Commercial';
        var uspsfirstclassCommercialforxml = 'First Class Commercial';
        var upsNextDayAirSaverforxml = '13';
        var upsNextDaySaverforxml = '13';
        var upsSecondDayAirforxml = '02';
        var upsThirdDayforxml = '12';
        var upsgroundforxml = '03';

        var upsshipcarrier = 'ups';
        var uspsshipcarrier = 'noups';
        var isEnvelope = calculateweight[2];
        if (!shippingService || shippingService == "") {
            nlapiLogExecution('ERROR',
                'Error: returning due to no shipservice level variable ',
                "Error: returning due to no shipservice level variable");
            return true;

        }

        nlapiLogExecution('debug', 'status for condition', status);
        nlapiLogExecution('debug', 'shipaddress type for condition', shipaddress);
        nlapiLogExecution('debug', 'shipcountry type for condition', shipcountry);
        nlapiLogExecution('debug', 'ship service type for condition',
            shippingService);

        // status = 'A';


        if (shipaddress && shipaddress != null) {
            nlapiLogExecution('debug', 'i am in second if');

            if (shipcountry == 'US') {
            	var is_apo=check_apo(shipaddress);
            if(is_apo=='T'){
            	  
                       var service = uspspriorityforxml;
                       obj.setFieldValue('shipmethod', uspspriority);
                   
                   
                   var zipOrigination = '46628';
                   var zipDestination = shipzip;
                   var weightinOunces = weight_in_oz;
                   var size = 'LARGE';
                   var width = 6;
                   var length = 3;
                   var height = 8;
                   var uspsrate = USPSxml(service, zipOrigination,
                       zipDestination, weightinOunces, size, width,
                       length, height);
                   var shipcostchange=uspsrate;
            }
            else
            {	
            	if((weight_in_oz * 0.062500)>70){

					
					var shipToName = shipname;
					var shipToPhoneNumber = shipphone;
					var shipToAddressLine = shipaddress;
					var shipToCity = shipcity;
					var shipToPostalCode = shipzip;
					var shipToCountryCode = shipcountry;
					var serviceCode = upsgroundforxml;
					var packageTypeCode = '02';
					var unitOfMeasurement = 'LBS';
					var weight = weight_in_oz * 0.062500; // for ounce
					var residential = isResidential;
					var upsrate = UPSxml(shipToName, shipToPhoneNumber,
							shipToAddressLine, shipToCity,
							shipToPostalCode, shipToCountryCode,
							serviceCode, packageTypeCode,
							unitOfMeasurement, weight, residential);
					if (shippingService == 3)
					{obj.setFieldValue('shipmethod', upsSecondDayAir);}
					else if(shippingService==2){
						{obj.setFieldValue('shipmethod', upsThirdDay);}

					}
					else if(shippingService==1)
					{obj.setFieldValue('shipmethod', upsground);}
					nlapiLogExecution('debug', 'ups rate',upsrate);

					if(upsrate>0)
					return upsrate;
				
            	}
            	else{
            	
                nlapiLogExecution('debug', 'i am in third if');

                if (shippingService == 2 && shippingService == 0) {
                    if (residential_flag == 'T') {
                        var service = uspspriorityforxml;
                    } else {
                        var service = uspsprioritycommercialforxml;
                    }
                    var zipOrigination = '46628';
                    var zipDestination = shipzip;
                    var weightinOunces = weight_in_oz;
                    var size = 'LARGE';
                    var width = 6;
                    var length = 3;
                    var height = 8;
                    var shipcostchange = USPSxml(service, zipOrigination,
                        zipDestination, weightinOunces, size, width,
                        length, height);
                    obj.setFieldValue('shipmethod', uspspriority);

                }
                else if (shippingService == '1') {
                    if (weight_in_oz <= 14) {
                        if (weight_in_oz <= 3.5 && (isEnvelope == 'T')) {
                            var service = uspsfirstclassCommercialforxml;
                            obj.setFieldValue('shipmethod', uspsfirstclassCommercial);
                            var zipDestination = shipzip;
                            var weightinOunces = weight_in_oz;
                            var size = 'LARGE';
                            var width = 6;
                            var length = 3;
                            var height = 8;
                            var shipcostchange = firstclassmail_cost;
                            nlapiLogExecution("debug", "Setting USPS ", uspsfirstclassletter);
                        }
                        else {
                            var service = uspsfirstclassCommercialforxml;
                            obj.setFieldValue('shipmethod',
                                uspsfirstclassCommercial);
                            var zipOrigination = '46628';
                            var zipDestination = shipzip;
                            var weightinOunces = weight_in_oz;
                            var size = 'LARGE';
                            var width = 6;
                            var length = 3;
                            var height = 8;
                            var shipcostchange = firstclassparcel_cost;
                        }
                    } else if (weight_in_oz > 14) {
                        if (residential_flag == 'T') {
                            var service = uspspriorityforxml;
                            obj.setFieldValue('shipmethod', uspspriority);
                        } else {
                            var service = uspsprioritycommercialforxml;
                            obj.setFieldValue('shipmethod',
                                uspsprioritycommercial);
                        }
                        var zipOrigination = '46628';
                        var zipDestination = shipzip;
                        var weightinOunces = weight_in_oz;
                        var size = 'LARGE';
                        var width = 6;
                        var length = 3;
                        var height = 8;
                        var uspsrate = USPSxml(service, zipOrigination,
                            zipDestination, weightinOunces, size, width,
                            length, height);
                        var shipToName = shipname;
                        var shipToPhoneNumber = shipphone;
                        var shipToAddressLine = shipaddress;
                        var shipToCity = shipcity;
                        var shipToPostalCode = shipzip;
                        var shipToCountryCode = shipcountry;
                        var serviceCode = upsgroundforxml;
                        var packageTypeCode = '02';
                        var unitOfMeasurement = 'LBS';
                        var weight = weight_in_oz * 0.062500; // for ounce
                        var residential = isResidential;
                        var upsrate = UPSxml(shipToName, shipToPhoneNumber,
                            shipToAddressLine, shipToCity,
                            shipToPostalCode, shipToCountryCode,
                            serviceCode, packageTypeCode,
                            unitOfMeasurement, weight, residential);
                        if (uspsrate != null && upsrate != null) {
                            upsrate = parseFloat(upsrate);
                            uspsrate = parseFloat(uspsrate);
                        }
                        if (upsrate < uspsrate) {
                            nlapiLogExecution("debug", 'upsrate', upsrate);
                            obj.setFieldValue('shipmethod', upsground);
                            shipcostchange = upsrate;
                        } else {
                            nlapiLogExecution("debug", 'uspsrate', uspsrate);

                            shipcostchange = uspsrate;

                        }
                    }
                } else if (shippingService == '4') {
                    var shipToName = shipname;
                    var shipToPhoneNumber = shipphone;
                    var shipToAddressLine = shipaddress;
                    var shipToCity = shipcity;
                    var shipToPostalCode = shipzip;
                    var shipToCountryCode = shipcountry;
                    var serviceCode = upsNextDaySaverforxml;
                    var packageTypeCode = '02';
                    var unitOfMeasurement = 'LBS';
                    var weight = weight_in_oz * 0.062500; // for ounce
                    var residential = isResidential;
                    var shipcostchange = UPSxml(shipToName, shipToPhoneNumber,
                        shipToAddressLine, shipToCity, shipToPostalCode,
                        shipToCountryCode, serviceCode, packageTypeCode,
                        unitOfMeasurement, weight, residential);
                    obj.setFieldValue('shipmethod', upsNextDaySaver);
                } 
                
             
                else if (shippingService == '5') { 
                	 var weightinOunces = weight_in_oz;
                	if (weightinOunces >15) {
                    var service = uspspriorityforxml;
                    obj.setFieldValue('shipmethod', uspspriorityinternational);
                } else {
                    var service = uspspriorityforxml;
                    obj.setFieldValue('shipmethod',
                    		uspspriorityinternational);
                }
                var zipOrigination = '46628';
                var zipDestination = shipzip;
                var size = 'LARGE';
                var width = 6;
                var length = 3;
                var height = 8;
                var shipcostchange = USPSxml(service, zipOrigination,
                    zipDestination, weightinOunces, size, width,
                    length, height);}
                
               
                else if (shippingService == '3') {
                    var shipToName = shipname;
                    var shipToPhoneNumber = shipphone;
                    var shipToAddressLine = shipaddress;
                    var shipToCity = shipcity;
                    var shipToPostalCode = shipzip;
                    var shipToCountryCode = shipcountry;
                    var serviceCode = upsSecondDayAirforxml;
                    var packageTypeCode = '02';
                    var unitOfMeasurement = 'LBS';
                    var weight = weight_in_oz * 0.062500; // for ounce
                    var residential = isResidential;
                    var shipcostchange = UPSxml(shipToName, shipToPhoneNumber,
                        shipToAddressLine, shipToCity, shipToPostalCode,
                        shipToCountryCode, serviceCode, packageTypeCode,
                        unitOfMeasurement, weight, residential);
                    obj.setFieldValue('shipmethod', upsSecondDayAir);
                } else if (shippingService == '2') {
                    if (residential_flag == 'T') {
                        var service = uspspriorityforxml;
                    } else {
                        var service = uspsprioritycommercialforxml;
                    }
                    var shipToName = shipname;
                    var shipToPhoneNumber = shipphone;
                    var shipToAddressLine = shipaddress;
                    var shipToCity = shipcity;
                    var shipToPostalCode = shipzip;
                    var shipToCountryCode = shipcountry;
                    var serviceCode = upsThirdDayforxml;
                    var packageTypeCode = '02';
                    var unitOfMeasurement = 'LBS';
                    var weight = weight_in_oz / 16; // for ounce
                    var residential = isResidential;
                    var upsrate = UPSxml(shipToName, shipToPhoneNumber,
                        shipToAddressLine, shipToCity, shipToPostalCode,
                        shipToCountryCode, serviceCode, packageTypeCode,
                        unitOfMeasurement, weight, residential);
                    var zipOrigination = '46628';
                    var zipDestination = shipzip;
                    var weightinOunces = weight_in_oz;
                    var size = 'LARGE';
                    var width = 6;
                    var length = 3;
                    var height = 8;
                    var uspsrate = USPSxml(service, zipOrigination,
                        zipDestination, weightinOunces, size, width,
                        length, height);
                    if (upsrate < uspsrate) {
                        obj.setFieldValue('shipmethod', upsThirdDay);
                        shipcostchange = upsrate;
                    } else {
                        obj.setFieldValue('shipmethod', uspspriority);
                        shipcostchange = uspsrate;
                    }
                }
                else if (shippingService == '7'){
					var url=nlapiResolveURL('RECORD', 'salesorder',salesOrderId);
					url='https://system.na1.netsuite.com'+url;
				    nlapiSendEmail(1659, 'govind@webbee.biz', 'Local Pickup Notification | Zake', 'Shipping method is Customer Pickup for this Salesorder\n '+url, mail_cc);
					
					obj.setFieldValue('shipmethod', customer_pickup);

				}


                else {
                    nlapiLogExecution("debug", "Not changing SO Status",
                        "Setting condition false");
                    notMatched = true;
                }
           

            }
            }
            if (notMatched == false) {
                nlapiLogExecution('debug', 'shpiexpence', shipcostchange);
                if (shipcostchange == undefined||shipcostchange=='NaN') {
                    nlapiSendEmail(1659, 'govind@webbee.biz', 'auto approve ', 'Shipping Expence is undefined for Sales Order Id: ' + salesOrderId, 'aj@webbeeglobal.com');

                    shipcostchange = 0;
                }
                obj.setFieldValue('custbody_shipping_expense', shipcostchange);
                obj.setFieldValue('custbody_shippedcalculated', 'T');
                nlapiSubmitRecord(obj);
                return shipcostchange;
            }
            }
        }
        else{
			return 0;
		}
    }
		else{
			return 0;
		}
    }
    catch (err) {
        nlapiSendEmail(1659, 'govind@webbee.biz', 'Err: in Zake Auto Approve 2 for Sales Order Id: ' + salesOrderId, err, 'aj@webbeeglobal.com');
        return 'ERROR';
    }

}
function calculateTotalWeight(so_id) {
    var obj = nlapiLoadRecord('salesorder', so_id);
    var lines = obj.getLineItemCount('item');


    var totalWeight = 0;

    for (var i = 1; i <= lines; i++) {
    	try{
        var itemid = obj.getLineItemValue('item', 'item', i);
        var item = nlapiLoadRecord('inventoryitem', itemid);
        var weight = item.getFieldValue('weight');
        var is_envelope = item.getFieldValue('custitem_fc_envelope_capable')
        nlapiLogExecution('DEBUG', 'is_envelope: ', is_envelope);

        nlapiLogExecution('DEBUG', 'weight: ', weight);

        var unit_of_measurement = item.getFieldValue('weightunit');
        nlapiLogExecution('DEBUG', 'unit_of_measurement : ', unit_of_measurement);
        if (unit_of_measurement == 1) // lbs
        {
            weight = weight * 16;
        } else if (unit_of_measurement == 3) // kg
        {
            weight = weight * 35.274;
        } else if (unit_of_measurement == 4) // gms
        {
            weight = weight * 0.035274;
        }

        var quantity = obj.getLineItemValue('item', 'quantity', i);
        var weightTimesQuantity = weight * quantity;

        totalWeight = totalWeight + weightTimesQuantity;

        nlapiLogExecution('DEBUG', 'Id' + itemid + 'Weight : ' + weight
        + 'Total Weight ' + totalWeight + ' Quantity : ' + quantity);
    	}
    	catch (e) {
            nlapiSendEmail(1659, mail, 'Err: in Zake Auto Approve | Item Type', 'Sales Order Id :'+so_id+'\n'+e, cc);
		}}
    var calculateweight = [totalWeight, unit_of_measurement, is_envelope];
//    nlapiSubmitRecord(item);
    nlapiLogExecution('DEBUG', 'calculateweight: ', calculateweight);
    return calculateweight;

}

function getAddressType(city, street, zipcode, state) {


    var customer = new Array();


    var url = 'https://api.smartystreets.com/street-address?auth-id=81662d0d-4945-4c3a-84fc-62fb8f2d0ff7&auth-token=sTZeYEyqBQZWbR8lims4&street='
        + escape(street) + '&city=' + escape(city) + '&state=' + state;
    var response = nlapiRequestURL(url);
    if (response.getBody().indexOf('"rdi":"Residential"') > 1) {
        return true;
    } else {
        return false;
    }
}
function check_apo(shipaddress)
{
	var is_apo='F';
	if(shipaddress.match(/^PO\W/)||shipaddress.match(/^P.O\W/)||shipaddress.match(/^P O\W/))
	{is_apo='T';}
	return is_apo;
}