function run() {

    // custscript_csv_file
    var csvFileId = nlapiGetContext().getSetting('script', 'custscript_csv_file');

    // 这张表的Vlookup 过后的一张表
    var file = nlapiLoadFile(csvFileId);
    var str = file.getValue(); // mapping.csv
    // 解析的CSV 文件的最后一个 鼠标位置一定是要在 最后一行的末尾， 否则出错
    var papacsv = Papa.parse(str, {
        header: true
    });
    if (papacsv.errors.length) {
        throw nlapiCreateError('CSV_ERROR', 'csv errors ' + JSON.stringify(papacsv.errors));
    }
    var csv = papacsv.data;

    var custscript_bins_test_size = nlapiGetContext().getSetting('script', 'custscript_bins_test_size');
    if (custscript_bins_test_size) {
        csv = csv.slice(0, parseInt(custscript_bins_test_size));
    }
    var custscript_bin_location = nlapiGetContext().getSetting('script', 'custscript_bin_location');
    var location = custscript_bin_location;

    var group = arr_to_chunk(csv, 1000);
    for (var i = 0; i < group.length; i++) {
        var cc = group[i];
        createInventoryAdjustment(cc, location);
        checkGovernance();
    }

    //process('customsearch1098', 34); // 杨美
    //process('customsearch1098', 35); // 义乌
    // process('customsearch1098');
    //clear2bins();
}


function createInventoryAdjustment(csv, location) {

    var obj = nlapiCreateRecord('inventoryadjustment', {recordmode: 'dynamic'});

    obj.setFieldValue('subsidiary', Subsidiaries.TaiwuInternational);  //Taiwu International 太武国际
    obj.setFieldValue('account', 356); // Inventory Adjustments
    obj.setFieldValue('memo', location + 'createInventoryAdjustment === ' + nlapiDateToString(new Date(), 'datetimetz'));

    for (var i = 0; i < csv.length; i++) {
        var line_data = csv[i];

        _log('line_data', line_data);

        // 可用库存数量根据 Onhand 的数量来调整

        var real_quantity = parseInt(line_data['可用库存']);

        try {
            // 每个Inventory 行的设置
            obj.selectNewLineItem('inventory');
            obj.setCurrentLineItemValue('inventory', 'item', line_data.NS_Item_ID);
            obj.setCurrentLineItemValue('inventory', 'location', location); // : 杨美仓库 or 义乌仓库

            var quantityonhand = obj.getCurrentLineItemValue('inventory', 'quantityonhand');
            quantityonhand = parseInt(quantityonhand);
            var adjustQuantity = real_quantity - quantityonhand;
            _log('adjustQuantity', adjustQuantity);

            if (adjustQuantity == 0) {
                continue;
            }

            obj.setCurrentLineItemValue('inventory', 'adjustqtyby', adjustQuantity);

            var subrecord = obj.createCurrentLineItemSubrecord('inventory', 'inventorydetail');

            subrecord.selectNewLineItem('inventoryassignment');
            // subrecord.setCurrentLineItemValue('inventoryassignment', 'receiptinventorynumber', 'testserial');
            subrecord.setCurrentLineItemValue('inventoryassignment', 'quantity', adjustQuantity);
            subrecord.setCurrentLineItemValue('inventoryassignment', 'binnumber', line_data.NS_BIN_ID);
            subrecord.commitLineItem('inventoryassignment');

            subrecord.commit();

            obj.commitLineItem('inventory');
        } catch (e) {
            processException(e);
        }

    }


    var id = nlapiSubmitRecord(obj);
    _log('Inv Adjust 创建成功', id);

}

// 消灭一个 Item的2个bins， quantity 设置为 0
function clear2bins() {

    var search = nlapiLoadSearch(null, 'customsearch1197');
    var columns = search.getColumns();
    search = search.runSearch();
    search = search.getResults(0, 1000);

    //var obj = nlapiCreateRecord('inventoryadjustment', {recordmode: 'dynamic'});
    //
    //obj.setFieldValue('subsidiary', Subsidiaries.TaiwuInternational);  //Taiwu International 太武国际
    //obj.setFieldValue('account', 356); // Inventory Adjustments
    //obj.setFieldValue('memo', '消灭一个 Item的2个bins， quantity 设置为 0 ' + nlapiDateToString(new Date(), 'datetimetz'));

    var specificSearch = nlapiLoadSearch(null, 'customsearch1244');
    var c = specificSearch.getColumns();
    var f = specificSearch.getFilters();
    var ff = [].concat(f);

    for (var i = 0; i < search.length; i++) {
        var searchResult = search[i];

        var __id = searchResult.getValue(columns[1]);
        _log('__id', __id);

        ff.push(new nlobjSearchFilter('internalid', null, 'is', __id));
        var s = nlapiSearchRecord('inventoryitem', null, ff, c);

        s.forEach(function (ss) {
            _audit(ss.getId(), ss.getValue('binnumber' + '---' + ss.getValue('internalid', 'binnumber')))
        });

        checkGovernance()
    }


    _audit('size', search.length);
}

function process(ssId, location) {

    // Item search
    var search = nlapiLoadSearch(null, ssId);
    //search.addFilters([
    //    new nlobjSearchFilter('location', null, 'is', location)
    //]);
    search = search.runSearch();
    search = search.getResults(0, 1000);

    //[0] = {nlobjSearchColumn} itemid
    //[1] = {nlobjSearchColumn} externalid
    //[2] = {nlobjSearchColumn} binnumber

    var obj = nlapiCreateRecord('inventoryadjustment', {recordmode: 'dynamic'});

    obj.setFieldValue('subsidiary', Subsidiaries.TaiwuInternational);  //Taiwu International 太武国际
    obj.setFieldValue('account', 356); // Inventory Adjustments
    //obj.setFieldValue('department', 2);
    //obj.setFieldValue('class', 2);
    obj.setFieldValue('memo', '太武国际 情况Bins quantity === ' + nlapiDateToString(new Date(), 'datetimetz'));
    //obj.setFieldValue('adjlocation', 33);

    for (var i = 0; i < search.length; i++) {
        var searchResult = search[i];

        _log('__id', searchResult.getId());
        var binonhandavail = searchResult.getValue('binonhandavail');
        binonhandavail = 0 - parseInt(binonhandavail);

        var warehouse = searchResult.getValue('location', 'binOnHand');

        try {
            // 每个Inventory 行的设置
            obj.selectNewLineItem('inventory');
            obj.setCurrentLineItemValue('inventory', 'item', searchResult.getId());
            obj.setCurrentLineItemValue('inventory', 'location', warehouse); // : 杨美仓库 or 义乌仓库
            obj.setCurrentLineItemValue('inventory', 'adjustqtyby', binonhandavail);

            var subrecord = obj.createCurrentLineItemSubrecord('inventory', 'inventorydetail');

            subrecord.selectNewLineItem('inventoryassignment');
            // subrecord.setCurrentLineItemValue('inventoryassignment', 'receiptinventorynumber', 'testserial');
            subrecord.setCurrentLineItemValue('inventoryassignment', 'quantity', binonhandavail);
            subrecord.setCurrentLineItemValue('inventoryassignment', 'binnumber', searchResult.getValue('binnumber', 'binOnHand'));
            subrecord.commitLineItem('inventoryassignment');

            subrecord.commit();

            obj.commitLineItem('inventory');
        } catch (e) {
            processException(e);
        }

        //if(i == 10) break;

    }


    var id = nlapiSubmitRecord(obj);

    _auditUsage();

    if (search.length == 1000) {
        checkGovernance();
        return process(ssId, location)
    }

}