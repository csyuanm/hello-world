if (typeof this.alert == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function parseException(e) {
    var code, message;
    var userMessage = null;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = e.getCode() || "nlobjError";
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + e.getStackTrace().join(", ");
            userMessage = e.getDetails();
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (userMessage == null) userMessage = message;
    var context = nlapiGetContext();
    var sname = context.getCompany() + "@Subsidiary" + context.getSubsidiary() + ": " + " " + context.getEmail() + " " + context.getDeploymentId();
    return {
        code: "[" + code + "] " + sname,
        ERROR_CODE: code,
        message: message,
        userMessage: userMessage
    };
}

function processException(e, info) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "\r\n" + info;
    }
    if (nlapiGetContext().getEnvironment() == "SANDBOX") {
        nlapiSendEmail(41133, "allan@zakeusa.com", code, message);
    } else {
        nlapiSendEmail(530, "allan@zakeusa.com", code, message);
    }
    _log(code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

var LogFile = {
    content: "",
    writeLog: function(title, detail) {
        var message = "[" + nlapiDateToString(new Date(), "datetimetz") + "] ---> " + title + " ---> " + detail;
        this.content += message + "\r\n";
    },
    getLog: function() {
        return this.content;
    },
    saveLog: function() {
        if (__RecordLogFlag) {
            var file = nlapiCreateFile(__LogFileName, "PLAINTEXT", this.getLog());
            file.setFolder(1285);
            file.setIsOnline(true);
            var fileId = nlapiSubmitFile(file);
        }
    }
};

var __RecordLogFlag = false;

var __LogFileName = "EbayLatestLog.txt";

function _nlapiLogExecution(logType, title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (typeof console == "undefined") {
            if (detail) {
                if (typeof detail == "object") {
                    if (format) {
                        nlapiLogExecution(logType, "[" + typeof detail + "] " + title, JSON.stringify(detail, undefined, 4));
                    } else {
                        nlapiLogExecution(logType, "[" + typeof detail + "] " + title, JSON.stringify(detail));
                    }
                } else {
                    nlapiLogExecution(logType, "[" + typeof detail + "] " + title, detail);
                }
            } else {
                nlapiLogExecution(logType, "[" + typeof detail + "] " + title, detail);
            }
            if (__RecordLogFlag) {
                if (typeof detail == "object") {
                    LogFile.writeLog(title, JSON.stringify(detail, null, 4));
                } else {
                    LogFile.writeLog(title, detail);
                }
            }
        } else {
            if (typeof title == "object") {
                console.log(title);
                if (detail) {
                    console.log(detail);
                }
            } else {
                if (typeof detail == "object") {
                    console.log(JSON.stringify(detail));
                } else {
                    console.log(title + ": " + detail);
                }
            }
        }
    }
}

function _log(title, detail) {
    var logType = "debug";
    _nlapiLogExecution(logType, title, detail);
}

function _audit(title, detail) {
    _nlapiLogExecution("AUDIT", title, detail);
}

function _log_email(title, detail) {
    if (nlapiGetContext().getEnvironment() == "SANDBOX") {
        title = "Email: " + title;
        _log(title, detail);
        nlapiSendEmail(41133, "allan@zakeusa.com", title, detail);
    } else {
        nlapiSendEmail(-5, "allan@zakeusa.com", title, detail);
    }
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

Array.prototype.remove = function(value) {
    var a = this;
    var index = a.indexOf(value);
    if (index > -1) {
        a.splice(index, 1);
    }
};

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
    children.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function createTextFile(name, content, folderId) {
    folderId = folderId || 80473;
    var file = nlapiCreateFile(name + ".txt", "PLAINTEXT", content);
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function _renderPage(html, obj) {
    for (var o in obj) {
        var k = "{{" + o + "}}";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function _renderPage2(html, obj) {
    for (var o in obj) {
        var k = "#" + o + "#";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    var joinname = join + "." + name;
                    record[joinname] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function __nlapiSearchRecordX(type, id, filters, columns) {
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            record["__id"] = search_record.getId();
            record["__type"] = search_record.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var value = search_record.getValue(column);
                var text = search_record.getText(column);
                if (value && text) {
                    record[name] = {
                        value: value,
                        text: text
                    };
                } else {
                    record[name] = value;
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecordX", list);
    return list;
}

function __nlapiSearchRecord2(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    return {
        columnLabels: columnLabels,
        list: __nlapiSearchRecordX(type, id, filters, columns)
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        var spendTime = Math.round((new Date().getTime() - this.startTime) / 1e3) + "s";
        _log("debug - [Profiling]", spendTime);
        return spendTime;
    }
};

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(url ? url : location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var IS_NS_SANDBOX = false;

var NS_DOMAIN = "system.na1.netsuite.com";

if (nlapiGetContext().getEnvironment() == "SANDBOX") {
    IS_NS_SANDBOX = true;
    NS_DOMAIN = "system.sandbox.netsuite.com";
}

var Subsidiaries = {
    ZakeUSAHolding: 2,
    Swagway: 4,
    TaiwuInternational: 3,
    ZakeInternational: 1
};

function logparams(request) {
    _log("request.getMethod()----", request.getMethod());
    var params = request.getAllParameters();
    var paramlist = [];
    for (var param in params) {
        paramlist.push({
            parameter: param,
            value: params[param]
        });
    }
    _log("---logparams---", paramlist);
}

function checkGovernance() {
    if (nlapiGetContext().getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < 200) {
        var state = nlapiYieldScript();
        if (state.status == "FAILURE") {
            throw nlapiCreateError("YIELD_SCRIPT_ERROR", "Failed to yield script, exiting<br/>Reason = " + state.reason + "<br/>Size = " + state.size + "<br/>Information = " + state.information);
        } else if (state.status == "RESUME") {
            nlapiLogExecution("debug", "checkGovernance-------------", nlapiGetContext().getRemainingUsage());
            nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        }
    } else {
        nlapiGetContext().setPercentComplete((1e4 - nlapiGetContext().getRemainingUsage()) / 100);
    }
}

function rescheduled(params) {
    var context = nlapiGetContext();
    if (context.getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < 200) {
        var status = null;
        if (params) {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
        } else {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        }
        if (status == "QUEUED") {
            _audit("Reschedule for usage reset. and len is " + len);
        }
    }
}

var MarketplaceShipService = {
    ToBeDetermined: 6,
    Standard: 1,
    ThirdDaySelect: 2,
    SecondDayAir: 3,
    NextDay: 4,
    InternationalShippingFromUS: 5
};

var MarketplaceShipName = {
    AliExpress: 1,
    Amazon: 2,
    eBay: 3,
    Wish: 4,
    _3BBestbuy: 5,
    _3BNewegg: 6,
    Rakuten: 7,
    PCDirect: 8,
    _3Btech: 9,
    Swagway: 10
};

function client_log(title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 4);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
        } else {
            if (typeof title == "object") title = JSON.stringify(title);
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            console.log(message);
        }
    }
}

function $nlapiGetFieldValue(name) {
    return jQuery("#" + name + "_fs_lbl_uir_label");
}

function post_to_url(path, params, method) {
    method = method || "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    form.setAttribute("target", "_blank");
    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }
    }
    document.body.appendChild(form);
    form.submit();
}

function clientException(e) {
    if (typeof NProgress != "undefined") {
        NProgress.done(true);
    }
    alert(e.toString());
}

function parseDataToJSON(data) {
    try {
        if (typeof data == "string") {
            data = data.replace(/(<!--(?:(?!-->).)*-->)/g, "").replace(/\r\n|\n/g, "").trim();
            data = JSON.parse(data);
        }
    } catch (e) {
        alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

function openNewTab(url) {
    window.open(url, "_blank");
    window.focus();
}

function loadCSS(filename) {
    var fileref = document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function loadJavaScript(filename) {
    var fileref = document.createElement("script");
    fileref.setAttribute("type", "text/javascript");
    fileref.setAttribute("src", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function parseToJSON(data) {
    try {
        if (typeof data == "string") {
            data = data.replace(/(<!--(?:(?!-->).)*-->)/g, "").replace(/\r\n|\n/g, "").trim();
            data = JSON.parse(data);
        }
    } catch (e) {
        if (typeof this.alert == "function") alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

function parseToJSON2(data) {
    if (typeof data == "object") return data;
    try {
        if (typeof data == "string") {
            data = JSON.parse(data);
        }
    } catch (e) {
        if (typeof this.alert == "function") alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

var PageOverlay = {
    __overlay: jQuery("<div class='zake-overlay'><img src='/core/media/media.nl?id=16957&c=277620&h=ea47479825c0844fc16b' /></div>"),
    showOverlay: function() {
        jQuery(document.body).append(PageOverlay.__overlay);
        PageOverlay.__overlay.css({
            "background-color": "#EEE",
            "-moz-opacity": "0.6",
            opacity: "0.6",
            filter: "alpha(opacity=60)",
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "z-index": "1000"
        });
        PageOverlay.__overlay.show();
    },
    removeOverlay: function() {
        PageOverlay.__overlay.remove();
    }
};

var NProgressInitFlag = false;

function NProgressInit() {
    loadCSS("https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css");
    loadJavaScript("https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.js");
    NProgressInitFlag = true;
}

function initNProgress() {
    loadCSS("https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css");
    loadJavaScript("https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.js");
    NProgressInitFlag = true;
}

var SL_MPL_URL = "/app/site/hosting/scriptlet.nl?script=186&deploy=1";

NProgressInit();

function search() {
    var h = "https://" + NS_DOMAIN;
    var initURL = h + "/app/site/hosting/scriptlet.nl?script=186&deploy=1&compid=277620&whence=";
    var _url = initURL + "&custpage_mpl_category=" + nlapiGetFieldValue("custpage_mpl_category") + "&custpage_mpl_allow_reprinting=" + nlapiGetFieldValue("custpage_mpl_allow_reprinting");
    var custpage_mpl_ff_select = nlapiGetFieldValue("custpage_mpl_ff_select");
    console.log(custpage_mpl_ff_select);
    if (custpage_mpl_ff_select) {
        if (isNaN(parseInt(custpage_mpl_ff_select))) {
            _url += "&custpage_mpl_ff_select=" + custpage_mpl_ff_select;
        } else {
            custpage_mpl_ff_select = parseInt(custpage_mpl_ff_select);
            if (custpage_mpl_ff_select) {
                _url += "&custpage_mpl_ff_select=" + custpage_mpl_ff_select;
            }
        }
    }
    window.location = _url;
}

var $inpt_custpage_mpl_ff_select2 = jQuery("#inpt_custpage_mpl_ff_select2");

var title_init = $inpt_custpage_mpl_ff_select2.attr("title");

function onFieldChangeFn() {
    var now_title = $inpt_custpage_mpl_ff_select2.attr("title");
    if (title_init != now_title) {
        search();
    }
}

function onPageInit() {
    if (jQuery("#custpage_mpl_print").length) {
        jQuery("#custpage_mpl_listdir4").trigger("click");
    } else {
        jQuery("#custpage_mpl_listdir3").trigger("click");
    }
}

function print() {
    var ffCount = nlapiGetLineItemCount("custpage_mpl_list");
    var ffSelectedList = [];
    for (var line = 1; line <= ffCount; line++) {
        var checked = nlapiGetLineItemValue("custpage_mpl_list", "mpl_checkbox", line);
        var ffid = nlapiGetLineItemValue("custpage_mpl_list", "mpl_ffid_hidden", line);
        if (checked == "T") {
            ffSelectedList.push(ffid);
        }
    }
    if (ffSelectedList.length) {
        console.log(JSON.stringify(ffSelectedList));
        jQuery.ajax({
            url: SL_MPL_URL,
            data: {
                action: "print",
                ffSelectedList: JSON.stringify(ffSelectedList),
                custpage_mpl_category: nlapiGetFieldValue("custpage_mpl_category"),
                inpt_custpage_mpl_category: nlapiGetFieldValue("inpt_custpage_mpl_category").toUpperCase()
            },
            success: function(data) {
                console.log(data);
                PageOverlay.removeOverlay();
                NProgress.done(true);
                data = parseToJSON2(data);
                if (data.mpl_id) {
                    post_to_url(SL_MPL_URL, {
                        action: "showMPLPDF2",
                        mpl_id: data.mpl_id
                    });
                    window.setTimeout(function() {
                        window.location.reload();
                    }, 1e3);
                } else {
                    alert("Not to created the PDF file YET!");
                }
            },
            beforeSend: function() {
                PageOverlay.showOverlay();
                NProgress.start();
            }
        });
    } else {
        alert("Please select records for print.");
    }
}

window.page_unload = null;