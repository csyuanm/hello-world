/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       03 Apr 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */

var bcc = 'ratul@webbee.biz';
			var cc = 'caleb@zake.com';
			var storeEmail = 'support@swagtron.com';

function mailToCustomer(type) {
	
	try{
	var email_tmpl_id = '143';//170
	var email_tmpl = nlapiLoadRecord('emailtemplate', email_tmpl_id);
	var email_subject_tmpl = email_tmpl.getFieldValue('subject');
	var email_body_tmpl = email_tmpl.getFieldValue('content');
	var renderer = nlapiCreateTemplateRenderer();
	
	renderer.setTemplate(email_subject_tmpl);
    
	
	 var search = nlapiLoadSearch('transaction','2278');
	 
	 var columns = search.getColumns();
	 
	 var startIndx = 0;
	 var endIndx = 500;
	 var i = 0;
	 
	 var resultSet = search.runSearch();
	 var result = resultSet.getResults(startIndx,endIndx);
	
	 while(result.length != null && i < result.length){
		    
		 
		   checkGovernance();
		   var recId = result[i].getId();
		   nlapiLogExecution('Debug','recId',recId);
		   var trackingNos = result[i].getValue(columns[1]);
		   nlapiLogExecution('Debug','trackingNos',trackingNos);
		   
		   if(trackingNos){
			   
			   var customerId = result[i].getValue(columns[2]);
			   nlapiLogExecution('Debug','customerId',customerId);
			   
			   var custEmail = result[i].getValue(columns[3]);
			   var custName = result[i].getValue(columns[4]);
			   
			   var createdFrm = result[i].getValue(columns[0]);
			   var po = nlapiLookupField('salesorder',createdFrm,'otherrefnum');
			   
			   var email_subject = renderer.renderToString();
				//email_subject.replace("{{order}}",po);
				renderer.setTemplate(email_body_tmpl);
				var email_body = renderer.renderToString();
				email_body = email_body.replace("{{TRACKING_NUM}}",trackingNos).replace("{{STOREFRONT_EMAIL}}",storeEmail);
//				email_body = email_body.replace("{{customer}}",custName).replace("{{order}}",po).replace("{{trackingNo}}",trackingNos).replace("{{href}}",href).replace("{{storeEmail}}",storeEmail);

				var rec = {};
				rec.entity = '13087';
				
				nlapiSendEmail('3888120', 'aj@webbeeglobal.com',email_subject,email_body,cc,bcc,rec);
			    //nlapiSubmitField('itemfulfillment',recId,'custbody_email_sent_cust','T')
			   
		   }
		   
		 
		 
		 i++;
			
	     if(i == 1){
	         break;
	     }
		if(i >= result.length){
			startIndx = endIndx;
			endIndx += 500;
			result = resultSet.getResults(startIndx,endIndx);
			i = 0;
		}
		 
		 
	 }
	}catch(e){
		nlapiLogExecution('Debug','error in sc',e);
	}
	 
}



function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}





