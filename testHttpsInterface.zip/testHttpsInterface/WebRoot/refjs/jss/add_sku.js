/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Dec 2015     Govind
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
 
function clientValidateLine(type){
	
	var subsidiary=nlapiGetFieldValue('subsidiary');
	var role=nlapiGetRole();
	var form=nlapiGetFieldValue('customform');
	nlapiLogExecution('DEBUG','subsidiary',subsidiary);
	
	if(subsidiary != 3&&form!=115) {
		var account=nlapiGetFieldValue('custbody_amznaccount');
		nlapiLogExecution('DEBUG','account',account);
		if (account != '') {		
			var item_id= nlapiGetCurrentLineItemValue('item', 'item');
			nlapiLogExecution('DEBUG','itemid',item_id);
			if (item_id) {
				var base_price_field={};
				base_price_field[1163]='custitem_amazon_bco_fba_bp';
				base_price_field[1170]='custitem_amazon_bcoca_fba_bp';
				base_price_field[1174]='custitem_amazon_bco_uk_bp';
				base_price_field[1175]='custitemamazon_cbco_us_bp';
				base_price_field[1179]='custitem_amazon_bco_fr_bp';
				base_price_field[1180]='custitem_amazon_bco_de_bp';
				base_price_field[1181]='custitem_amazon_bco_it_bp';
				base_price_field[1182]='custitem_amazon_bco_es_bp';
				base_price_field[1190]='custitem_amazon_dn_fba_bp';
				base_price_field[1193]='custitem_amazon_sg_fba_bp';
				base_price_field[1194]='custitem_amazon_gallany_fba_bp';
				
				if (role=='1163'||role=='1170'||role=='1174'||role=='1175'||
					role=='1179'||role=='1180'||role=='1181'||role=='1182'||
					role=='1190'||role=='1193'||role=='1194') {
					var fbaprice=check_null(nlapiLookupField('item', item_id,base_price_field[role]));
					if(fbaprice > 0||role=='1163'){
						var column=[];
					    column.push(new nlobjSearchColumn('custrecord_sku')); 

						var filters=[];
					 	filters.push(new nlobjSearchFilter('custrecord_custitem',null,'is',item_id));
					 	filters.push(new nlobjSearchFilter('custrecord_account_name',null,'is',account));
					 	filters.push(new nlobjSearchFilter('custrecord_skutype',null,'is',1));  
					 	filters.push(new nlobjSearchFilter('isinactive',null,'is','F'));  
						
						var search_listing = nlapiSearchRecord('customrecord_amazon_listings', null,filters, column);
						if(search_listing != null) {
							var sellersku=search_listing[0].getValue('custrecord_sku');
							var listingid=search_listing[0].getId();
							nlapiLogExecution('DEBUG','sku',sellersku);
							nlapiLogExecution('DEBUG','listingid',listingid);
								nlapiSetCurrentLineItemValue('item', 'custcol_sellersku', sellersku);
								return true;
						} else {	
							alert("This Item is not listed on Amazon.");
							return false;
						}
					} else {
						alert("This Item cannot be inserted");
						return false;
					}
				}
				else {
					var column=[];
				    column.push(new nlobjSearchColumn('custrecord_sku')); 

					var filters=[];
				 	filters.push(new nlobjSearchFilter('custrecord_custitem',null,'is',item_id));
				 	filters.push(new nlobjSearchFilter('custrecord_account_name',null,'is',account));
				 	filters.push(new nlobjSearchFilter('custrecord_skutype',null,'is',1));  
				 	filters.push(new nlobjSearchFilter('isinactive',null,'is','F'));  

					var search_listing = nlapiSearchRecord('customrecord_amazon_listings', null,filters, column);
					if (search_listing != null) {
						var sellersku=search_listing[0].getValue('custrecord_sku');
						var listingid=search_listing[0].getId();
						nlapiLogExecution('DEBUG','sku',sellersku);
						nlapiLogExecution('DEBUG','listingid',listingid);
						nlapiSetCurrentLineItemValue('item', 'custcol_sellersku', sellersku);
						return true;
					} else {	
						alert("This Item is not listed on Amazon.");
						return false;
					}
				}
			}
		} else {
			alert('Please Select AMAZON ACCOUNT First !!');
    		return false;
		}
	} else {
		return true;
	}
}

function matchwarehouse(type,name) {
	var id=nlapiGetRecordId();	
	var subsidiary=nlapiGetFieldValue('subsidiary');
	var role=nlapiGetRole();
	nlapiLogExecution('DEBUG','subsidiary',subsidiary);
	if ( subsidiary != 3 ) {
		var shipmentid=nlapiGetFieldValue('custbody_shipmentid');
//		alert(shipmentid)
		if(shipmentid){
//			alert(shipmentid)
			var filter_t=[];
			if(id)
	        {filter_t.push(new nlobjSearchFilter('internalId', null, 'noneof',id));}
			filter_t.push(new nlobjSearchFilter('custbody_shipmentid', null, "is", shipmentid))
			var search_t=nlapiSearchRecord('transferorder', null, filter_t);
			if(search_t!=null){
				alert("Transfer Order already exist for Shipment ID : "+shipmentid);
				return false;
			}
			
		}
		if (role=='1163'||role=='1170'||role=='1174'||role=='1175'||role=='1179'||role=='1180'||
			       role=='1181'||role=='1182'||role=='1190'||role=='1193'||role=='1194') {
			return true;
		} 
		else {
			var amazon_account=nlapiGetFieldValue('custbody_amznaccount');
			var to_location=nlapiGetFieldValue('transferlocation');
			var from_location=nlapiGetFieldValue('location');
			if(amazon_account==1){
				if((to_location==12)||(from_location==12)){
					return true;
				}
				else{
					alert('Destination or Source is Wrong.');
					return false;
				}
			} else if(amazon_account==8) {
				if((to_location==11)||(from_location==11)){
					return true;
				}
				else{
					alert('Destination or Source is Wrong.');
					return false;
				}	
			}
			return true;
		}
	} else {
		return true;
	}
}

function check_null(value){
	if(value>0)
		value=parseFloat(value);
	else
		value=0;
	return value;
	
}

function pageInit(name){
  try{
  if(name == 'create'){
    var obj={};
    obj[1163]=8; //BCO US
    obj[1170]=36;//BCO CA
    obj[1174]=40;//BCO UK
    obj[1175]=35;//CBCO US
    obj[1179]=43;//BCO FR
    obj[1180]=41;//BCO DE
    obj[1181]=44;//BCO IT
    obj[1182]=42;//BCO ES
    obj[1190]=9;//Shop A bit
    obj[1193]=1;//SG
    obj[1194]=26;//Gallany
    var role = nlapiGetRole()
    if(role=='1163'||role=='1170'||role=='1174'||role=='1175'||role=='1179'||role=='1180'||
       role=='1181'||role=='1182'||role=='1190'||role=='1193'||role=='1194'){
      
      var current = nlapiGetFieldValue('customform');
      nlapiLogExecution('Debug','current form ',current);
      if(current != '278')
      nlapiSetFieldValue('customform','278',false,true);
      nlapiDisableField('customform',true);
      nlapiSetFieldValue('custbody_amznaccount',obj[role]);
      nlapiDisableField('custbody_amznaccount',true);
      nlapiSetFieldValue('shipcarrier','nonups',false,true);
      nlapiSetFieldValue('shipmethod','44216');

     
      //nlapiSetFieldValue('subsidiary','3');
    }
    else{
    	var form = nlapiGetFieldValue('customform');
    	if(form=115){
    		  nlapiSetFieldValue('custbody_storefront_list', '7', false, true);
    		  nlapiSetFieldValue('custpage_fulfill', 'T');
    		  nlapiSetFieldValue('custbody_marketplace', '16', false, true);
    		  nlapiSetFieldValue('orderstatus', 'B', false, true);
    		  nlapiSetFieldValue('shipcarrier','nonups',false,true);
    	      nlapiSetFieldValue('shipmethod','35311');
    	}
    }
    
    return true;
  }
  return true;
  }catch(e){
    nlapiLogExecution('Audit','error in page init ',e);
  } 
}
function locations(type,name){
	var role=nlapiGetRole();
	if(role=='1163'||role=='1170'||role=='1174'||role=='1175'||role=='1179'||role=='1180'||
	   role=='1181'||role=='1182'||role=='1190'||role=='1193'||role=='1194'){
		if(name=='custpage_transferlocation'){
			var location=nlapiGetFieldValue(name);
			nlapiSetFieldValue('transferlocation', location,true);
		}
		else if(name=='custpage_location'){
				var location=nlapiGetFieldValue(name);
				nlapiSetFieldValue('location', location,true);	
		}

	}
	
}
