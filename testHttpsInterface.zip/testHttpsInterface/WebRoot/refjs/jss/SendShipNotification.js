/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Aug 2017     Admin
 *
 */

/**
 * @returns {Void} Any or no return value
 */
function workflowAction() {
	try{
	var recId=nlapiGetRecordId();
	nlapiLogExecution('DEBUG', 'recId', recId);
	var if_rec=nlapiLoadRecord('itemfulfillment', recId)
	var tracking_no=nlapiGetFieldValue('trackingnumbers');
	nlapiLogExecution('DEBUG', 'tracking_no', tracking_no);
	var storefront=nlapiGetFieldText('custbody_storefront_list');
	var sale_order=nlapiGetFieldText('createdfrom');
	var sales_orderid=nlapiGetFieldValue('createdfrom');
	var so_rec=nlapiLoadRecord('salesorder', sales_orderid, {recordmode:"dynamic"})
	tracking_no=so_rec.getFieldValue('linkedtrackingnumbers');
	nlapiLogExecution('DEBUG', 'tracking_no', tracking_no);

	var customer=nlapiGetFieldValue('entity');
	var email=nlapiLookupField('customer', customer, 'email');
	var name=nlapiGetFieldText('entity');
	arr=[];
	  arr=name.split(' ');
	  arr.splice(0, 1);
	  name=arr.join(' ');
	
	
	
	var email_templateid='143';
	var senderId = '152613';
	var email_tmpl = nlapiLoadRecord('emailtemplate', email_templateid);
    var email_subject = email_tmpl.getFieldValue('subject');
    var email_body  = email_tmpl.getFieldValue('content');
	var renderer = nlapiCreateTemplateRenderer();
	renderer.addRecord('record', if_rec );
	renderer.setTemplate( email_subject );
	 email_subject = renderer.renderToString();
	renderer.setTemplate(email_body);
	 email_body = renderer.renderToString();
	email_subject=email_subject.replace("order#",sale_order);
	email_body=email_body.replace("order#",sale_order);
	email_body=email_body.replace("{{TRACKING_NUM}}",tracking_no);
	email_body=email_body.replace("Hello!","Hello! "+name);
	email_body=email_body.replace("{{STOREFRONT_EMAIL}}",'support@swagtron.com');
	
	var records = new Object();
	records['itemfulfillment'] = recId;
	
	var url='https://system.na1.netsuite.com'+nlapiResolveURL('RECORD', 'itemfulfillment', recId);
	nlapiSendEmail( senderId, 'govind@webbee.biz', storefront+email_subject, email_body, null, null );
//	nlapiSetFieldValue('custbody_customer_notified', 'T', false)
	}
	catch(e){
		nlapiLogExecution('DEBUG', 'error', e);
	}

}
