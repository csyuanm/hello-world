var titles = [
  "Instant payment received",
  "You got paid!",
  "Your eCheck payment cleared",
  "Notification of payment received",
  "Refund issued",
  "Return closed",
  "Your case has been closed",
  "Claim This closed",
  "You agreed to cancel an order",
  "The order was canceled",
  "You canceled an order",
  "buyer shipped",
  "Your Feedback revision request has been sent",
  "Twitter",
  "tweeted",
  "You accepted a return",
  "You sent a return shipping label",
  "Return approved",
  "Return was closed by the buyer"
];

function cleaner(){
  for(var i = 0; i < titles.length; i++){
    var title = titles[i];
    var filter = new Array();
    filter[0] = new nlobjSearchFilter('title', null, 'contains', title);
    filter[1] = new nlobjSearchFilter('status', null, 'noneof', 5);
    var search = nlapiSearchRecord('supportcase', null, filter);
    if(search == null){
      continue;
    }
    for(var i2 = 0; i2 < search.length; i2++){
      nlapiLogExecution('DEBUG', 'i2', i2);
      var sc = search[i2];
      var rec = nlapiLoadRecord('supportcase', sc.id);
      rec.setFieldValue('status', 5);
      var submited = nlapiSubmitRecord(rec);
      nlapiLogExecution('DEBUG', 'Record ID', submited);
    };
  };
}
