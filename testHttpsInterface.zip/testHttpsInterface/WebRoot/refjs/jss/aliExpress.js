//获取aliexpress订单列表
function getAliExpressList() {

	var columns = new Array();
	columns[0] = new nlobjSearchColumn('custrecord_ali_client_id');
	columns[1] = new nlobjSearchColumn('custrecord_ali_token');
	columns[2] = new nlobjSearchColumn('custrecord_ali_secret_key');
	columns[3] = new nlobjSearchColumn('custrecord_ali_refresh_token');
   columns[4] = new nlobjSearchColumn('name');
	var aliList = nlapiSearchRecord('customrecord_aliexpress_accounts', null,null, columns);
	return aliList;
}