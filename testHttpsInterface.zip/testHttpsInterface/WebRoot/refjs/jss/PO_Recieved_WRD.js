/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       11 Oct 2017     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function SendEmail(type){
	try{
	var rec_id=nlapiGetRecordId();
	var url=nlapiResolveURL('RECORD', 'itemreceipt', rec_id);
	var search=nlapiLoadSearch('transaction', 2974);
	search.addFilter(new nlobjSearchFilter('internalid', null, 'anyof',rec_id));
	var columns=search.getColumns();
	var runsearch=search.runSearch();
	var result=runsearch.getResults(0, 1000);
	if(result.length>0){
		var info='<table border=1><tr><th>Date</th><th>Item Description</th><th>Quantity in Transaction Units</th><th>Created From</th>'+
		'</th><th>Item</th></th><th>Base Price</th></th><th>Online Price</th></th><th>Last Purchase Price</th>'+
		'</th><th>Purchase Price</th></th><th>LEGACY 3B SKU</th></th><th>Location</th></th><th>Storefront List</th></tr>';
		for(var i=0;i<result.length;i++){
			var Date=result[i].getValue(columns[0]);
			var Item_Description=result[i].getValue(columns[1]);
			var Quantity_in_Transaction_Units=result[i].getValue(columns[2]);
			var Created_From=result[i].getText(columns[3]);
			var Item=result[i].getText(columns[4]);
			var Base_Price=result[i].getValue(columns[5]);
			var Online_Price=result[i].getValue(columns[6]);
			var Last_Purchase_Price=result[i].getValue(columns[7]);
			var Purchase_Price=result[i].getValue(columns[8]);
			var LEGACY_3B_SKU=result[i].getValue(columns[9]);
			var Location=result[i].getText(columns[10]);
			var Storefront_List=result[i].getText(columns[11]);
			info+='<tr><td>'+Date+'</td><td>'+Item_Description+'</td><td>'+Quantity_in_Transaction_Units
			      +'</td><td>'+Created_From+'</td><td>'+Item+'</td><td>'+Base_Price
			      +'</td><td>'+Online_Price+'</td><td>'+Last_Purchase_Price
			      +'</td><td>'+Purchase_Price+'</td><td>'+LEGACY_3B_SKU+'</td><td>'+Location+'</td><td>'+Storefront_List+'</td></tr>'
		}
		info+='</table>'
		nlapiLogExecution('DEBUG', 'info', info);
		nlapiSendEmail(1659, ['mikej@zake.com','joshua.kee@zake.com','patricia.sea@zake.com','nick@zake.com','tom.str@zake.com'], 'Received From '+ Created_From, 'View Record : '+'https://system.na1.netsuite.com'+url+'\n\n'+info,null,'govind@webbee.biz');
	}
}catch(e){
	nlapiLogExecution('DEBUG', 'err', e);
}
}
