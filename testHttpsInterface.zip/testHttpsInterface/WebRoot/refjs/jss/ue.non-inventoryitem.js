function afterSubmit(type) {

    nlapiLogExecution('debug', 'type', nlapiGetRecordType());
    nlapiLogExecution('debug', 'id', nlapiGetRecordId());
    //if (nlapiGetFieldValue('subsidiary') == 3) { // Taiwu
    //    nlapiLogExecution('debug', type, nlapiGetFieldValue('itemid'));
    //    if (type == 'create') {
    //        var parent = nlapiGetFieldValue('parent');
    //        if (!parent) {
    //            var itemid = nlapiGetFieldValue('itemid');
    //            if (itemid == 'AutoCreate') {
    //                var id = nlapiGetNewRecord().getId();
    //                nlapiLogExecution('debug', 'id', id);
    //                nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(), 'itemid', id, true);
    //            }
    //        }
    //    }
    //}
}