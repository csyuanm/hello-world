/**
 * https://system.na1.netsuite.com/app/common/scripting/script.nl?id=824
 * @param request
 * @param response
 *
 LIBRARY SCRIPT FILE
 xml2json.min.js
 SSUtils.js
 EbayUtils.js
 ShippingUtils.js
 CarrierSystem.js
 SC_Lib_Shenzhen_GetNSShipItem.js
 EMS-ePacket.js
 SC_BatchBillAndFulfill_Shenzhen.js
 ue.SalesOrder.js
 */
function run(request, response) {

    var action = request.getParameter('action');
    var soId = request.getParameter('soId');
    _log(action, soId);
    if (action) {
        var trackCode = nlapiLookupField('salesorder', soId, 'custbody_sz_carrier_trackingnumber');
        if (action == 'GetAPACShippingPackageStatus') {
            var apacshipping = new APACShipping(soId);
            var apacResponse = apacshipping.GetAPACShippingPackageStatus(trackCode);
            response.write(JSON.stringify(apacResponse, null, 2));
        } else if (action == 'ConfirmAPACShippingPackage') {
            var apacshipping = new APACShipping(soId);
            apacshipping.ConfirmAPACShippingPackage(trackCode);
            nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
        } else if (action == 'bill') {
            var orderstatus = request.getParameter('orderstatus');
            _log('orderstatus', orderstatus);

            var custbody_delay_bill = nlapiLookupField('salesorder', soId, 'custbody_delay_bill');
            if (orderstatus == 'H' && custbody_delay_bill == 'F') {
                _openSORec(soId);
                _processSalesOrderBill(soId);
                _closeSORec(soId);
            } else {
                _processSalesOrderBill(soId);
            }

            nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
        } else if (action == 'closeSO') {
            closeSalesOrder(request, response);
        } else if (action == 'removeInvoice') {
            _deleteInvoice(soId);
            nlapiSubmitField('salesorder', soId, 'custbody_taiwu_bill_status_code', 8, true);
            nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
        } else if (action == 'openOrder') {
            _openSORec(soId);
            nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
        } else if (action == 'markOverweight') {
            nlapiSubmitField('salesorder', soId, 'custbody_taiwu_fulfill_status_code', 5);
            nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
        } else if (action == 'deleteSubOrders') {
            var subOrderSearch = nlapiSearchRecord('salesorder', null, [
                new nlobjSearchFilter('mainline', null, 'is', 'T'),
                new nlobjSearchFilter('custbody_parent_sales_order', null, 'is', soId),
                new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'noneof', '12')
            ], [
                new nlobjSearchColumn('statusref')
            ]);

            if (subOrderSearch != null) {
                subOrderSearch = subOrderSearch.map(function (sr) {
                    return {
                        id: sr.getId(),
                        statusref: sr.getValue('statusref')
                    }
                });

                if (subOrderSearch.every(function (item) {
                        return item.statusref == 'pendingFulfillment';
                    })) {

                    subOrderSearch.forEach(function (item) {

                        //var ful = nlapiSearchRecord('itemfulfillment', null, [
                        //    new nlobjSearchFilter('createdfrom', null, 'is', item.id),
                        //    new nlobjSearchFilter('mainline', null, 'is', 'T')
                        //]);
                        //if (ful != null) {
                        //    ful.forEach(function (fulSR) {
                        //        nlapiDeleteRecord('itemfulfillment', fulSR.getId());
                        //    });
                        //}

                        nlapiDeleteRecord('salesorder', item.id);
                    });
                }

                _openSORec(soId);
                nlapiSetRedirectURL("RECORD", 'salesorder', soId);
            } else {
                response.write('删除不了，可能子单已经生成包裹了， 需要仓库处理！');
            }

        } else if (action == 'pendingApproval') {
            nlapiSubmitField('salesorder', soId, 'orderstatus', 'A', true);
            _deleteFF(soId);
            _deleteInvoice(soId); // 这个估计是因为有_前缀 IDE 认为是私有方法而不能引用
            nlapiSetRedirectURL("RECORD", 'salesorder', soId);
        } else if (action == 'createWishRA') {
            // 1, 退货RA 2，退款RA
            var returnauthorization = nlapiTransformRecord('salesorder', soId, 'returnauthorization');
            returnauthorization.setFieldValue('custbody_ra_type', 1);
            returnauthorization.setFieldValue('memo', '退货RA，生成好之后请注意检查Line item是否正确，收货之后会自动的关闭RA， 请注意！');
            var returnauthorizationId = nlapiSubmitRecord(returnauthorization, true);
            nlapiSetRedirectURL("RECORD", 'returnauthorization', returnauthorizationId);
        }
    } else {
        // 没有Action 就是Fulfill 订单了
        var status = nlapiLookupField('salesorder', soId, 'status');
        if (status == 'pendingBilling') {

            response.write('已经发货了！ 不用处理订单折腾了！');
            return;

            //var ful = nlapiSearchRecord('itemfulfillment', null, [
            //    new nlobjSearchFilter('createdfrom', null, 'is', soId),
            //    new nlobjSearchFilter('mainline', null, 'is', 'T')
            //]);
            //if (ful != null) {
            //    ful.forEach(function (fulSR) {
            //        nlapiDeleteRecord('itemfulfillment', fulSR.getId());
            //    });
            //}
        }
        _processSalesOrderFulfill(soId);

        nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
    }


}

function _deleteInvoiceSearch(invoiceSearch) {
    if (invoiceSearch != null) {
        if (invoiceSearch.length == 1) {

            var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                new nlobjSearchFilter('appliedtotransaction', null, 'anyof', [invoiceSearch[0].getId()])
            ], [
                new nlobjSearchColumn('total'),
                new nlobjSearchColumn('total', 'appliedToTransaction')
            ]);

            if (pmtSearch != null) {
                nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId());

                //if (pmtSearch[0].getValue('total') == pmtSearch[0].getValue('total', 'appliedToTransaction')) {
                //    _log('删除Pmt', pmtSearch[0].getId());
                //    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId())
                //}
            }

            nlapiDeleteRecord('invoice', invoiceSearch[0].getId());
        } else {
            _log_email(invoiceSearch.length + ' invoiceSearch found', soId);
            return false;
        }
    }

    return true;
}

/**
 * Suitelet 关闭订单专用
 * @param request
 * @param response
 */
function closeSalesOrder(request, response) {
    try {

        var soId = request.getParameter('soId');
        var obj = nlapiLookupField('salesorder', soId, [
            'custbody_marketplace',
            'custbody_order_type',
            'custbody_parent_sales_order'
        ]);

        var market = obj.custbody_marketplace;

        var invoiceSearch = nlapiSearchRecord('invoice', null, [
            new nlobjSearchFilter('createdfrom', null, 'is', soId),
            new nlobjSearchFilter('mainline', null, 'is', 'T')
        ]);

        if (market == MarketplaceShipName.eBay) {
            var custbody_delay_bill = nlapiLookupField('salesorder', soId, 'custbody_delay_bill');
            if (custbody_delay_bill == 'F') {
                if (invoiceSearch == null) {
                    response.write('这个订单还不能关闭啊， 因为还没有结算！ 请返回到这个订单， 然后上面有个“结算订单” 请点击一下， 然后再在点击“关闭订单” 就好了， 麻烦您了！');
                    return;
                }
            } else {
                _deleteInvoiceSearch(invoiceSearch);
            }
        } else {
            _deleteInvoiceSearch(invoiceSearch);
        }

        //var soId = nlapiGetRecordId();
        var filters = new Array();
        filters.push(new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational));
        filters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
        filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
        var columns = new Array();
        columns.push(new nlobjSearchColumn('status'));
        columns.push(new nlobjSearchColumn('tranid'));
        var ifList = nlapiSearchRecord('itemfulfillment', null, filters, columns);
        _log('ifList', ifList);
        if (ifList != null) {
            if (ifList.length == 1) {
                //for (var i = 0; i < ifList.length; i++) {
                //    var ifStatus = ifList[i].getValue('status');
                //    _log('ifStatus', ifStatus);
                //    if (ifStatus !== 'packed') {
                //        response.write('订单关闭失败， 包裹 ' + ifList[i].getValue('tranid') + ' Is ' + ifStatus);
                //        return;
                //    }
                //}
                for (var j = 0; j < ifList.length; j++) {
                    var id = ifList[j].getId();
                    nlapiDeleteRecord('itemfulfillment', id);
                    //alert(list[i].getValue('tranid') + ' - 已删除');
                }
            } else {
                _log_email(ifList.length + ' found', soId);
            }
        }
        // 不要关闭Invoice 因为有的Invoice 可能关联 收款 和CM
        //_closeInv(soId);
        //_closeSORec(soId);

        var soRec = nlapiLoadRecord('salesorder', soId);
        for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
            soRec.setLineItemValue('item', 'isclosed', i, 'T');
        }
        if (!obj.custbody_parent_sales_order) {
            soRec.setFieldValue('custbody_order_type', 1);
        }
        nlapiSubmitRecord(soRec, true);

        nlapiSetRedirectURL("RECORD", 'salesorder', request.getParameter('soId'));
    } catch (e) {

        response.write(processException(e).message);
    }

}

function _closeSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'T');
    }
    nlapiSubmitRecord(soRec, true);
}

function _openSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'F');
    }
    soRec.setFieldValue('custbody_delay_bill', 'F');
    nlapiSubmitRecord(soRec, true);
}
