/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       30 Mar 2017     ratul
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
     
	if(request.getMethod() == "GET"){
		
		//var caseId = request.getParameter('cust_case');
		
		//var rec = nlapiLoadRecord('supportcase',caseId,{'recordmode':'dynamic'});
		
		var customer = '13862773'//rec.getFieldValue('company');
		
		var custRec = nlapiLoadRecord('lead',customer,{'recordmode':'dynamic'});
		var addresse = custRec.getLineItemValue('addressbook','addressee_initialvalue',1);
		var addr1 = custRec.getLineItemValue('addressbook','addr1_initialvalue',1);
		var city = custRec.getLineItemValue('addressbook','city_initialvalue',1);
		var country = custRec.getLineItemValue('addressbook','country_initialvalue',1);
		
		var state = custRec.getLineItemValue('addressbook','dropdownstate_initialvalue',1);
		
		
		
		nlapiLogExecution('Debug','addresse',addresse);
		nlapiLogExecution('Debug','addr1',addr1);
		nlapiLogExecution('Debug','city',city);
		nlapiLogExecution('Debug','country',country);
		nlapiLogExecution('Debug','state',state);
		
		
		
		
	}
	
}
