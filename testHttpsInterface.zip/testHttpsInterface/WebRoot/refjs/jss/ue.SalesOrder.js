function _isTestUser() {
    return nlapiGetUser() == 530;
}
function isTheRoles() {
    var role = nlapiGetRole();
    role = parseInt(role);

    //Edit 	1134 	Taiwu Accounting 	  	Custom 	Accounting Center
    //Edit 	1133 	Taiwu Accounting Manager 	  	Custom 	Accounting Center
    //Edit 	1132 	Taiwu Accounting Senior Manager 	  	Custom 	Accounting Center
    //Edit 	1141 	Taiwu Amazon Customer Service 	  	Custom 	Shipping Center
    //Edit 	1127 	Taiwu Amazon Sales 	  	Custom 	Sales Center
    //Edit 	1131 	Taiwu Art Manager 	  	Custom 	Sales Center
    //Edit 	1130 	Taiwu Art Personnel 	  	Custom 	Sales Center
    //Edit 	1138 	Taiwu Customer Service 	  	Custom 	Shipping Center
    //Edit 	1139 	Taiwu Customer Service Manager 	  	Custom 	Shipping Center
    //Edit 	1126 	Taiwu Department Manager 	  	Custom 	Sales Center
    //Edit 	1114 	Taiwu Director of Sales 	  	Custom 	Sales Center
    //Edit 	1125 	Taiwu eBay Sales 	  	Custom 	Sales Center
    //Edit 	1136 	Taiwu Product Sourcing 	  	Custom 	Sales Center
    //Edit 	1128 	Taiwu Purchasing Manager 	  	Custom 	Sales Center
    //Edit 	1137 	Taiwu Purchasing 太武采购跟单 	  	Custom 	Sales Center
    //Edit 	1178 	Taiwu Purchasing 太武采购跟单 - New 	  	Custom 	Sales Center
    //Edit 	1202 	Taiwu Purchasing 太武采购跟单 - New 2 	  	Custom 	Sales Center
    //Edit 	1124 	Taiwu Warehouse Manager 	  	Custom 	Shipping Center
    //Edit 	1123 	Taiwu Warehouse Pick/Pack 	  	Custom 	Shipping Center
    //Edit 	1122 	Taiwu Warehouse Receiving 	  	Custom 	Shipping Center
    return [
            3,
            1134,
            1141,
            1127,
            1138,
            1139,
            1126,
            1114,
            1125,
            1123
        ].indexOf(role) != -1;
}
/**
 * beforeLoad
 * @param type
 * @param form
 * @param request
 */
function beforeLoad(type, form, request) {

    var envContext = nlapiGetContext().getExecutionContext();
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();

    try {
        //var envContext = nlapiGetContext().getExecutionContext();
        //var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("beforeLoad____________ id: " + id + " recType: " + recType + " type: " + type);

        if (type == 'view') {
            // for client debug
            form.setScript('customscript_ssu');
        }


        var subsidiary = nlapiGetFieldValue('subsidiary');
        if (subsidiary == Subsidiaries.TaiwuInternational) {

            //  form.setScript('customscript_itemfulfillment_client');
            //_log('status', nlapiGetFieldValue('shipstatus'));
            // 42548	First Class Envelop

            //var fields = [
            //    'custbody_tw_fulfillment_status',
            //    'custbody_taiwu_fulfill_status_code',
            //    'custbody_taiwu_bill_status_code'
            //];
            //
            //if (fields && Array.isArray(fields) && fields.length) {
            //    fields.forEach(function (field) {
            //        nlapiGetField(field).setDisplayType('inline');
            //    });
            //}

            if (type == 'view' && envContext == 'userinterface' && isTheRoles()) {

                form.setScript('customscript_client_so');
                form.setScript('customscript_cs_button_action');
                var orderstatus = nlapiGetFieldValue('orderstatus');
                var market = nlapiGetFieldValue('custbody_marketplace');
                var carrier = nlapiGetFieldValue('custbody_sz_carrier');
                var trackingnumber = nlapiGetFieldValue('custbody_sz_carrier_trackingnumber');
                var custbody_order_type = nlapiGetFieldValue('custbody_order_type');
                var custbody_out_of_stock = nlapiGetFieldValue('custbody_out_of_stock');
                var fulfillment_status = nlapiGetFieldValue('custbody_tw_fulfillment_status');
                if (carrier == '3' || carrier == '4') { // 亚太的
                    if (trackingnumber) {
                        //包裹当前状态，可用值：
                        //0 待交运
                        //4 揽收拒绝
                        //5 投递成功
                        //6 投递失败
                        //7 卖家自送
                        //8 上门揽收
                        //9 订单取消
                        //10 运输中
                        if (['B', 'D', 'E'].contains(orderstatus)) {
                            form.addButton("custpage_view_apac_status", "Get APACShipping Package Status", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=GetAPACShippingPackageStatus&soId=" + id + "'");

                            if (nlapiGetFieldValue('custbody_shipconfirm') == 'T') {
                                form.addButton("custpage_view_apac_confirm", "重新交运", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=ConfirmAPACShippingPackage&soId=" + id + "'");
                            } else {
                                // form.addButton("custpage_view_apac_confirm", "交运确认", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=ConfirmAPACShippingPackage&soId=" + id + "'");
                            }
                        }


                    }

                    if (orderstatus == 'B' || orderstatus == 'D') {
                        //if (custbody_out_of_stock == 'T' && market == MarketplaceShipName.eBay) {
                        if (market == MarketplaceShipName.eBay) {
                            if (fulfillment_status == 3) {
                                if (nlapiGetFieldValue('custbody_tracking_number_sync') == 'T') {
                                    form.addButton("custpage_bufa_xiaoliwu", "补发EUB小礼物",
                                        "bufaGift()");
                                }
                                //if (_isTestUser()) {

                                //}
                            }
                        }
                    }

                }

                // http://www.17track.net/zh-cn/track?nums=GYLAB000040097YQ
                if (trackingnumber) {
                    form.addButton("custpage_view_tracking", "物流跟踪", "openNewTab('http://www.17track.net/zh-cn/track?nums=" + trackingnumber + "')");
                }

                var fulStatus = nlapiGetFieldValue('custbody_taiwu_fulfill_status_code');

                var ffSearch = nlapiSearchRecord('itemfulfillment', null, [new nlobjSearchFilter('createdfrom', null, 'is', id)]);
                if (orderstatus == 'B' || orderstatus == 'D') {
                    if (ffSearch == null ||
                        nlapiGetFieldValue('custbody_shiping_changed') == 'T' ||
                        nlapiGetFieldValue('custbody_taiwu_fulfill_status_code') != 12) {
                        //if (nlapiGetFieldValue('custbody_zake_haschildorder') == 'F') { // 不是拆单的
                        if (!['H', 'C'].contains(nlapiGetFieldValue('orderstatus'))) {
                            form.setScript('customscript_cs_button_action');
                            if (nlapiGetFieldValue('custbody_out_of_stock') == 'T') {
                                form.addButton("custpage_fulfill_order", "处理订单(缺货)", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&soId=" + id + "'"); //.setDisabled(true);
                            } else {
                                form.addButton("custpage_fulfill_order", "处理订单", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&soId=" + id + "'");
                            }
                        }
                        //}
                        // form.addButton("custpage_fulfill_order", "处理订单", "window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&soId=" + id + "'");
                        //if (![2, 5].contains(statusCode)) {
                        //}
                    }
                }


                // Pending Fulfillment or Partially Fulfilled
                if (orderstatus == 'B' || orderstatus == 'D') {
                    form.addButton('custpage_closesalesorder',
                        '关闭订单',
                        "closeSalesOrder()");

                    if (fulStatus == 3 || fulStatus == 8 || fulStatus == 12 || !fulStatus) {
                        form.addButton("custpage_mark_overweight", "标记超重",
                            "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&" + serializeURL({
                                action: 'markOverweight',
                                soId: id
                            }) + "'");
                    }

                    if (ffSearch == null) {
                        if (custbody_order_type == 4) {
                            if (market == MarketplaceShipName.Wish || market == MarketplaceShipName.eBay) {
                                form.addButton("custpage_cancel_merge_order", "取消合单",
                                    "var userConfirm = confirm('合单即将被取消，请确认是否继续？'); if (userConfirm) { hitButton(); window.location='/app/site/hosting/scriptlet.nl?script=956&deploy=2&" + serializeURL({
                                        action: 'cancelMerge',
                                        soId: id
                                    }) + "'}");
                            }
                        }

                    }

                    form.addButton("custpage_pending_approval", "返回审批状态",
                        "var userConfirm = confirm('订单即将返回至审批状态，请确认是否继续？'); if (userConfirm) { hitButton(); window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&" + serializeURL({
                            action: 'pendingApproval',
                            soId: id
                        }) + "'}");

                }

                if (orderstatus == 'A') {
                    // https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=956&deploy=2&action=search&custpage_merge_customer=16822147
                    if (market == MarketplaceShipName.Wish || market == MarketplaceShipName.eBay) {
                        form.addButton("custpage_merge_order", "合单",
                            "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=956&deploy=2&" + serializeURL({
                                action: 'search',
                                custpage_merge_customer: nlapiGetFieldValue('entity')
                            }) + "'");
                    }
                }


                if (orderstatus == 'H') {
                    form.addButton("custpage_open_order", "开启订单",
                        "openSalesOrder()");
                }

                var invSearch = nlapiSearchRecord('invoice', null, [
                    new nlobjSearchFilter('createdfrom', null, 'is', nlapiGetRecordId()),
                    new nlobjSearchFilter('mainline', null, 'is', 'T')
                ]);
                if (invSearch == null) {
                    if (nlapiGetFieldValue('custbody_delay_bill') == 'F') {
                        if (orderstatus == 'B' || orderstatus == 'D' || orderstatus == 'F') {
                            if (market == MarketplaceShipName.eBay) {
                                form.addButton("custpage_fulfill_order", "结算订单",
                                    "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=bill&" + serializeURL({
                                        soId: id,
                                        orderstatus: orderstatus
                                    }) + "'");
                            } else {
                                form.addButton("custpage_fulfill_order", "结算订单",
                                    "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=958&deploy=1&" + serializeURL({
                                        billId: id
                                        // orderstatus: orderstatus
                                    }) + "'");
                            }
                        }

                    }
                } else {
                    form.addButton("custpage_remove_invoice", "删除发票",
                        "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=removeInvoice&" + serializeURL({
                            soId: id
                            // orderstatus: orderstatus
                        }) + "'");
                }


                //if (statusCode == 12 && nlapiGetFieldValue('custbody_tw_fulfillment_status') == '3') {
                //    // TODO: 把出库状态显示在 上面Pending Fulfillment 旁边
                //}

                var parentSalesOrder = nlapiGetFieldValue('custbody_parent_sales_order');

                if (!parentSalesOrder) {
                    if (fulStatus == '2' || fulStatus == '5'
                        || nlapiGetFieldValue('custbody_script_memo') == '未知的Location'
                        || nlapiGetFieldValue('custbody_out_of_stock') == "T") {
                        if (market == MarketplaceShipName.eBay) {
                            if (orderstatus == 'A' || orderstatus == 'B' || orderstatus == 'D') {
                                form.addButton("custpage_split_order", "拆单",
                                    "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=956&deploy=1&" + serializeURL({
                                        action: 'split',
                                        order_id: id
                                    }) + "'");
                            } else if (orderstatus == 'H') {
                                //if (custbody_order_type == 3) {
                                //    form.addButton("custpage_cancel_split_order", "取消分单",
                                //        "var userConfirm = confirm('这个订单的所有分单即将被关闭，主单被打开，请确认是否继续？'); if (userConfirm) { hitButton(); window.location='/app/site/hosting/scriptlet.nl?script=956&deploy=1&" + serializeURL({
                                //            action: 'cancelSplit',
                                //            soId: id
                                //        }) + "'}");
                                //}
                            }
                        }
                    }
                }


                //if (nlapiGetUser() == 530) {
                if (!nlapiGetFieldValue('custbody_parent_sales_order')) {
                    form.addButton("custpage_bufa_order", "补发单",
                        "bufaSalesOrder()");
                }
                //}

                //if (envContext == 'userinterface') {

                if (orderstatus == 'H') {
                    var subOrderSearch = nlapiSearchRecord('salesorder', null, [
                        new nlobjSearchFilter('mainline', null, 'is', 'T'),
                        new nlobjSearchFilter('custbody_parent_sales_order', null, 'is', id)
                    ], [
                        new nlobjSearchColumn('statusref')
                    ]);

                    if (subOrderSearch != null) {
                        subOrderSearch = subOrderSearch.map(function (sr) {
                            return {
                                statusref: sr.getValue('statusref')
                            }
                        });

                        if (subOrderSearch.every(function (item) {
                                return item.statusref == 'pendingFulfillment';
                            })) {
                            form.addButton("custpage_cancel_merge_order", "删除所有子单",
                                "var userConfirm = confirm('该订单的所有子单即将被删除，请确认是否继续？'); if (userConfirm) { hitButton(); window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&" + serializeURL({
                                    action: 'deleteSubOrders',
                                    soId: id
                                }) + "'}");
                        }
                    }
                }

                //}
                // : doing here...
                if (market == MarketplaceShipName.Wish) {
                    //if (nlapiGetUser() == 530) {
                    // Wish 退货
                    if (orderstatus == 'F' || orderstatus == 'G') {
                        form.addButton("custpage_pending_approval", "Wish退货",
                            "var userConfirm = confirm('订单即将生成一个Wish RA退货记录， 确定继续吗'); if (userConfirm) { hitButton(); window.location='/app/site/hosting/scriptlet.nl?script=824&deploy=1&" + serializeURL({
                                action: 'createWishRA',
                                soId: id
                            }) + "'}");
                    }
                    //}
                }

            } else if (type == 'copy') {         // All for same as NEW

                if (envContext == 'userinterface') {
                    var custbody_parent_sales_order = nlapiGetFieldValue('custbody_parent_sales_order');
                    if (custbody_parent_sales_order) {
                        throw new UIException('不能从子订单上面Copy啊！！')
                    }
                    restAsNew('Copy to new sales order');
                    // shipping
                    nlapiSetFieldValue('shippingcost', '');

                    nlapiSetFieldValue('custbody_tracked', 'F');

                    form.addButton('custpage_btn_fen', '标识分单', 'markSplitSalesOrder()');
                    form.addButton('custpage_btn_bu', '标识补发', 'markReshipSalesOrder()');
                }

            }

        }

        _log("beforeLoad____________end");
    } catch (e) {
        processException(e, [id, envContext, nlapiGetRole()].join(', '));
    }

}

function restAsNew(msg) {

    nlapiSetFieldValue('custbody_script_memo', 'Rest as new..' + msg);
    // nlapiSetFieldValue('custbody_tracked', 'F');
    nlapiSetFieldValue('custbody_tracking_number_sync', 'F');      // Ebay 不要清空！需要再次上传

    nlapiSetFieldValue('custbody_out_of_stock', 'F');

    nlapiSetFieldValue('custbody_tw_fulfillment_status', null);
    nlapiSetFieldValue('custbody_taiwu_fulfill_status_code', null);
    nlapiSetFieldValue('custbody_taiwu_bill_status_code', null);

    nlapiSetFieldValue('custbody_sz_carrier', null);
    nlapiSetFieldValue('custbody_ship_method_sz', null);
    nlapiSetFieldValue('custbody_sz_carrier_trackingnumber', '');
    nlapiSetFieldValue('custbody_carrier_shipment_number', '');

    nlapiSetFieldValue('custbody_automated_processed', 'F');

    //nlapiSetFieldValue('custbody_api_data', '');
    nlapiSetFieldValue('custbody_carrier_api_request', '');
    nlapiSetFieldValue('custbody_carrier_api_response', '');

    nlapiSetFieldValue('custbody_shippinglabel_info', '');
    nlapiSetFieldValue('custbody_zake_fulfillmentjson', '');
    nlapiSetFieldValue('custbody_zake_haschildorder', 'F');

}

/**
 * beforeSubmit
 * @param type
 */
function beforeSubmit(type) {

    try {

        var envContext = nlapiGetContext().getExecutionContext();
        _log('envContext', envContext);
        var subsidiary = nlapiGetFieldValue('subsidiary'); //nlapiGetContext().getSubsidiary();

        if (subsidiary == Subsidiaries.TaiwuInternational) {

            if (type == 'create') {

                //if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.AliExpress) {
                //    var backOrderFlag = false;
                //    var linecount = nlapiGetLineItemCount("item");
                //    for (var ln = 1; ln <= linecount; ln++) {
                //        var quantitybackordered = nlapiGetLineItemValue("item", "quantitybackordered", ln);
                //        var isclosed = nlapiGetLineItemValue("item", "isclosed", ln);
                //        if (isclosed == 'T') continue;
                //        quantitybackordered = parseInt(quantitybackordered);
                //        if (quantitybackordered > 0) { // 只有一个 Item 是Backorder 我们就停下来
                //            backOrderFlag = true;
                //            break;
                //        }
                //    }
                //    _log('backOrderFlag', backOrderFlag);
                //    if (backOrderFlag) {
                //        nlapiSetFieldValue('custbody_out_of_stock', 'T');
                //    } else {
                //        nlapiSetFieldValue('custbody_out_of_stock', 'F');
                //    }
                //}

                // custcol_average_cost
                var linecount = nlapiGetLineItemCount("item");

                //var items = [];
                var locationitems = [];
                for (var ln = 1; ln <= linecount; ln++) {
                    // var location = nlapiGetLineItemValue("item", "location", ln);
                    //items.push(nlapiGetLineItemValue("item", "item", ln));

                    var itemtype = nlapiGetLineItemValue('item', 'itemtype', ln);
                    if (itemtype == 'InvtPart') {
                        locationitems.push({
                            item: nlapiGetLineItemValue("item", "item", ln),
                            location: nlapiGetLineItemValue("item", "location", ln)
                        })
                    }

                }

                if (locationitems.length) {
                    //if (nlapiGetFieldValue('location')) {
                    var costSearch = nlapiSearchRecord('inventoryitem', null, [
                        new nlobjSearchFilter('inventorylocation', null, 'anyof', locationitems.map(function (item) {
                            return item.location;
                        })),
                        new nlobjSearchFilter('internalid', null, 'anyof', locationitems.map(function (item) {
                            return item.item;
                        }))
                    ], [
                        new nlobjSearchColumn('location'),
                        new nlobjSearchColumn('locationaveragecost')
                    ]);

                    if (costSearch != null) {
                        costSearch = costSearch.map(function (sr) {
                            return {
                                item: sr.getId(),
                                location: sr.getValue('location'),
                                locationaveragecost: sr.getValue('locationaveragecost')
                            }
                        });
                        _log('costSearch-' + type, costSearch);
                        var count = nlapiGetLineItemCount("item");
                        for (var linenum = 1; linenum <= count; linenum++) {

                            var itemtype = nlapiGetLineItemValue('item', 'itemtype', ln);
                            if (itemtype == 'InvtPart') {
                                var itemid = nlapiGetLineItemValue('item', 'item', linenum);
                                var itemlocation = nlapiGetLineItemValue('item', 'location', linenum);
                                var match = costSearch.find(function (item) {
                                    return item.item == itemid && item.location == itemlocation;
                                });
                                if (match) {
                                    nlapiSetLineItemValue('item', 'custcol_average_cost', linenum, match.locationaveragecost);
                                } else {
                                    _log_email('订单木有Location', nlapiGetFieldValue('otherrefnum'));
                                }
                            }

                        }
                    }
                    //} else {
                    //    _log_email('订单木有Location', nlapiGetFieldValue('otherrefnum'));
                    //}
                }

                _updateLineInfo();
            }

            else if (type == 'edit') {
                var envContext = nlapiGetContext().getExecutionContext();
                if (envContext == 'userinterface') {
                    if (_watchLineItem()) {
                        restAsNew('换SKU了');
                    }

                    // =: 换地址也要Rest as NEW - 不管事， 得换到client
                    //if (_isChanged('shipaddress')) {
                    //    _log_email('SO ' + nlapiGetRecordId() + ' address is changed', 'TODO:换地址也要Rest as NEW\r\n' +
                    //    //+ nlapiGetOldRecord.getFieldValue('shipaddress') + '\r\n' +
                    //    nlapiGetFieldValue('shipaddress'));
                    //}
                }


                // 如果跟踪单号有变化Sync for false and re-upload
                // custbody_sz_carrier_trackingnumber
                //if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.eBay) {
                //
                //    var orderType = nlapiGetFieldValue('custbody_order_type');
                //    if (orderType == 1) {
                //        var watchFields = [
                //            'custbody_sz_carrier_trackingnumber'
                //        ];
                //
                //        var oldRecord = nlapiGetOldRecord();
                //        var is_changed = false;
                //
                //        for (var j = 0; j < watchFields.length; j++) {
                //            var field = watchFields[j];
                //            var oldValue = oldRecord.getFieldValue(field);
                //            var currentValue = nlapiGetFieldValue(field);
                //            if (!oldValue) oldValue = null;
                //            if (!currentValue) currentValue = null;
                //            if (oldValue !== currentValue) {
                //                is_changed = true;
                //                break;
                //            }
                //        }
                //
                //        if (is_changed) {
                //
                //            // ebay 有变化的话 再次上传一次。
                //            nlapiSetFieldValue('custbody_tracking_number_sync', 'F');
                //        }
                //    }
                //
                //}

                var trackingChanged = false;
                var field = 'custbody_sz_carrier_trackingnumber';
                var oldRecord = nlapiGetOldRecord();
                var oldValue = oldRecord.getFieldValue(field);
                var currentValue = nlapiGetFieldValue(field);
                if (!oldValue) oldValue = null;
                if (!currentValue) currentValue = null;
                if (oldValue !== currentValue) {
                    trackingChanged = true;
                }
                if (trackingChanged) {
                    if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.eBay) {
                        var orderType = nlapiGetFieldValue('custbody_order_type');
                        if (orderType == 1) {
                            // ebay 有变化的话 再次上传一次。
                            nlapiSetFieldValue('custbody_tracking_number_sync', 'F');
                        }
                    }
                }
                if (nlapiGetFieldValue('custbody_tw_fulfillment_status') == 3) {
                    if (!currentValue) {
                        nlapiSetFieldValue('custbody_tw_fulfillment_status', 11);
                    }
                }

                //var custbody_order_type = nlapiGetFieldValue('custbody_order_type');
                //if (custbody_order_type == '1' || custbody_order_type == '' || custbody_order_type == null) { // 正常单
                //    if (_isChanged(['total'])) {
                //        throw new UIException('订单金额前后的总价不相等， 可能你换了SKU， 但是 SKU 的价格标记错误， 请修正！');
                //    }
                //}

                _updateLineInfo();
            }

        } else if (subsidiary == Subsidiaries.ZakeInternational) {
            if (envContext == 'userinterface') {
                if (type == 'approve') {

                    nlapiSetFieldValue('custbody_approved_manually', 'T');

                    // 2065	Michael J Woods	Michael J Woods	574-968-3344	mikew@3btech.net
                    // 6767	Matthew C Kreiger	Matthew C Kreiger		matt@3btech.net
                    //var userId = nlapiGetContext().getUser();
                    //if ([520, 2065, 6767].contains(userId)) {
                    //    nlapiSetFieldValue('custbody_approved_manually', 'T');
                    //} else {
                    //    throw new UIException('ZAKE_APPROVE_EXCEPTION', 'You do not have permission to approve this sales order');
                    //}
                }
            }

            // Is drop ship order

            if (type == 'create' || type == 'edit') {
                // test
                //if (nlapiGetUser() == '530') {

                var isDropship = false;
                var linecount = nlapiGetLineItemCount('item');
                var line = 1;
                //var iteminfo = [];
                for (; line <= linecount; line++) {
                    var poid = nlapiGetLineItemValue('item', 'poid', line);
                    if (poid) {
                        isDropship = true;
                        break;
                    }
                }

                _log('isDropship', isDropship);
                if (isDropship) {
                    nlapiSetFieldValue('custbody_is_dropship_so', "T");
                }

                // }
            }
        }


    } catch (e) {
        processException(e, nlapiGetRecordId() + type);
    }

}

function _updateLineInfo() {
    //if (!nlapiGetFieldValue('custbody_total_weight') || isNaN(parseFloat(nlapiGetFieldValue('custbody_total_weight')))) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    _log("ue.so id: " + id + " recType: " + recType + " type: " + type);

    var linecount = nlapiGetLineItemCount('item');
    var line = 1;
    var items = [];
    for (; line <= linecount; line++) {
        items.push({
            item: nlapiGetLineItemValue('item', 'item', line),
            itemtype: nlapiGetLineItemValue('item', 'itemtype', line),
            quantity: nlapiGetLineItemValue('item', 'quantity', line),
            custcol_item_weight: nlapiGetLineItemValue('item', 'custcol_item_weight', line),
            custcol_weightunit: nlapiGetLineItemValue('item', 'custcol_weightunit', line)
        });
    }

    // [{"itemtype":"InvtPart","quantity":"1","custcol_item_weight":"533","custcol_weightunit":"g"},{"itemtype":"InvtPart","quantity":"1","custcol_item_weight":"100","custcol_weightunit":"g"},{"itemtype":"OthCharge","quantity":"1","custcol_item_weight":null,"custcol_weightunit":null}]

    var iteminfo = items.filter(function (item) {
        return item.itemtype == 'InvtPart';
    });

    _log('iteminfo -1', iteminfo);

    if (iteminfo.length) {

        // TODO: 后续的weight unit 都带上来了 再改进这里
        var itemSearch = nlapiSearchRecord('item', null, [
            new nlobjSearchFilter('internalid', null, 'anyof', iteminfo.map(function (item) {
                return item.item;
            }))
        ], [
            new nlobjSearchColumn('weight'),
            new nlobjSearchColumn('weightunit')
        ]);

        if (itemSearch != null) {

            itemSearch = itemSearch.map(function (sr) {
                return {
                    id: sr.getId(),
                    weight: sr.getValue('weight'),
                    weightunit: sr.getText('weightunit'),
                    weight_gram: getWeightGram(sr.getValue('weight'), sr.getText('weightunit'))
                };
            });

            iteminfo.forEach(function (item) {
                var match = itemSearch.find(function (it) {
                    return it.id == item.item;
                });
                if (match) {
                    item.custcol_item_weight = match.weight_gram;
                } else {
                    _log_email('没找到啊', JSON.stringify(item));
                }
            });


            _log('iteminfo -2', iteminfo);

            var totalWeight = 0;
            iteminfo.forEach(function (item) {
                totalWeight += parseInt(item.quantity) * parseFloat(item.custcol_item_weight);
            });

            //// 1 lb = 453.59237 克
            //if (iteminfo[0].custcol_weightunit == 'lb') {
            //    totalWeight = 453.59237 * parseFloat(totalWeight)
            //}
            totalWeight = _mathround(totalWeight);

            nlapiSetFieldValue('custbody_total_weight', totalWeight.toString());
        } else {
            _log_email('ue so 搜索为空', JSON.stringify(iteminfo));
        }

    } else {
        _log_email('noneof iteminfo for id: ' + id, JSON.stringify(items));
    }

    var _total = nlapiGetFieldValue('total');
    var custbody_order_total = nlapiGetFieldValue('custbody_order_total');
    if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.eBay) {
        _total = custbody_order_total || nlapiGetFieldValue('total');
    }
    if (_total) {
        //var _total = nlapiGetFieldValue('total');
        _total = parseFloat(_total);
        var currencyCode = nlapiGetFieldText('currency');
        if (currencyCode != "USD") {
            var exchangerate = nlapiGetFieldValue('exchangerate');
            exchangerate = parseFloat(exchangerate);
            var usdTotal = _mathround((exchangerate * _total) / 6.6986);
            //salesOrder.setFieldValue('custbody_ebay_so_total', usdTotal);
            nlapiSetFieldValue('custbody_us_dollar_total', usdTotal);
        } else {
            nlapiSetFieldValue('custbody_us_dollar_total', _total);
        }
    }
}

function _watchingFieldsIfNeedDeleteFulfillment() {

    // 只有有一个Item是有变化的话， 就。。。
    // 考虑Rest
    var watchFields = [
        'location',
        'custbody_sz_carrier',
        'custbody_ship_method_sz',
        'custbody_sz_carrier_trackingnumber'
    ];

    var is_changed = _isChanged(watchFields);
    //_audit('is_changed', is_changed);
    //
    //if (is_changed) {
    //    _deleteFF(nlapiGetRecordId());
    //    nlapiSubmitField('salesorder', nlapiGetRecordId(), 'custbody_taiwu_fulfill_status_code', 8, true);
    //}
    _log(nlapiGetRecordId() + '_watchingFieldsIfNeedDeleteFulfillment', is_changed);
    return is_changed;
}

function _isChanged(watchFields) {

    if (!Array.isArray(watchFields)) {
        watchFields = [watchFields];
    }

    var oldRecord = nlapiGetOldRecord();
    var is_changed = false;

    for (var j = 0; j < watchFields.length; j++) {
        var field = watchFields[j];
        var oldValue = oldRecord.getFieldValue(field);
        var currentValue = nlapiGetFieldValue(field);
        if (!oldValue) oldValue = null;
        if (!currentValue) currentValue = null;
        if (oldValue !== currentValue) {
            is_changed = true;
            break;
        }
    }

    return is_changed;
}

function _watchLineItem() {

    var newItems = [];
    var linecount = nlapiGetLineItemCount('item');
    var line = 1;
    //var iteminfo = [];
    for (; line <= linecount; line++) {
        var itemtype = nlapiGetLineItemValue('item', 'itemtype', line);
        if (itemtype == 'InvtPart' || itemtype == 'Kit') {
            newItems.push(nlapiGetLineItemValue('item', 'item', line));
        }
    }

    var oldItems = [];
    var oldRecord = nlapiGetOldRecord();
    var oCount = oldRecord.getLineItemCount('item');
    for (var ln = 1; ln <= oCount; ln++) {
        var itemtype = oldRecord.getLineItemValue('item', 'itemtype', ln);
        if (itemtype == 'InvtPart' || itemtype == 'Kit') {
            oldItems.push(oldRecord.getLineItemValue('item', 'item', ln));
        }
    }

    _log('newItems', newItems);
    _log('oldItems', oldItems);

    if (JSON.stringify(oldItems) != JSON.stringify(newItems)) {
        _log('换了SKU了啊');

        return true;
        //_restSO(id);
    }

    return false;
}

/**
 * Utils: 删除包裹item fulfillment
 * @param id
 * @private
 */
function _deleteFF(id) {
    // 重新来过！
    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', id),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);
    if (ffSearch != null) {
        if (ffSearch.length == 1) {
            nlapiDeleteRecord('itemfulfillment', ffSearch[0].getId());
        } else {
            _log_email('找到了多个包裹 SO: ' + id, id);
        }
    }
}

/**
 * Utils: 删除Invoice 发票
 * @param soId
 * @private
 */
function _deleteInvoice(soId) {
    // 如果有Payment 删除 Payment

    var filters = new Array();
    filters.push(new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational));
    filters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var columns = new Array();
    columns.push(new nlobjSearchColumn('status'));
    columns.push(new nlobjSearchColumn('tranid'));
    var invList = nlapiSearchRecord('invoice', null, filters, columns);

    if (invList != null) {
        _log('invList', invList.length);
        if (invList.length == 1) {
            for (var i = 0; i < invList.length; i++) {
                var id = invList[i].getId();

                var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                    new nlobjSearchFilter('appliedtotransaction', null, 'anyof', [id])
                ], [
                    new nlobjSearchColumn('total'),
                    new nlobjSearchColumn('total', 'appliedToTransaction')
                ]);

                if (pmtSearch != null) {
                    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId());

                    //if (pmtSearch[0].getValue('total') == pmtSearch[0].getValue('total', 'appliedToTransaction')) {
                    //    _log('删除Pmt', pmtSearch[0].getId());
                    //    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId())
                    //}
                }

                nlapiDeleteRecord('invoice', id);
            }
        } else {
            _log_email('SO for multi invoice', soId);
        }

    }
}

/**
 * afterSubmit
 * @param type
 */
function afterSubmit(type) {
    var id = nlapiGetRecordId();
    var subsidiary = nlapiGetFieldValue('subsidiary');
    if (subsidiary == Subsidiaries.TaiwuInternational) {

        if (nlapiGetFieldValue('custbody_order_type') == 3) {// 3 分单
            var parentSOId = nlapiGetFieldValue('custbody_parent_sales_order');
            if (parentSOId) {
                nlapiSubmitField('salesorder', parentSOId, 'custbody_order_type', 3, true);
            }
        }

        if (type == 'edit') {

            var custbody_order_type = nlapiGetFieldValue('custbody_order_type');
            _log('custbody_order_type', custbody_order_type);

            if (_isChanged(['custbody_order_type'])) {
                var invSearch = nlapiSearchRecord('invoice', null, [
                    new nlobjSearchFilter('mainline', null, 'is', 'T'),
                    new nlobjSearchFilter('createdfrom', null, 'is', nlapiGetRecordId())
                ]);
                if (invSearch != null) {
                    invSearch.forEach(function (inv) {
                        nlapiSubmitField('invoice', inv.getId(), 'custbody_order_type', custbody_order_type);
                    })
                }
            }

            var orderstatus = nlapiGetFieldValue('orderstatus');
            if (orderstatus == 'B' || orderstatus == 'D') {

                var ff_is_deleted = false;
                if (_watchLineItem()) { // 如果SKU 有更换的话
                    _deleteFF(id);
                    _deleteInvoice(id); // 删除 Invoice
                    nlapiSubmitField('salesorder', nlapiGetRecordId(), 'custbody_taiwu_fulfill_status_code', 8);
                    ff_is_deleted = true;
                }
                if (!ff_is_deleted && _watchingFieldsIfNeedDeleteFulfillment()) {
                    _deleteFF(id);
                    nlapiSubmitField('salesorder', nlapiGetRecordId(), 'custbody_taiwu_fulfill_status_code', 8);
                }
            } else if (orderstatus == 'G' || orderstatus == 'H') { // Sales Order:Closed	 SalesOrd:H
                if (_isChanged(['total'])) {
                    _deleteInvoice(id); // 删除 Invoice
                }
                if (orderstatus == 'H') {
                    _deleteFF(id);
                    nlapiSubmitField('salesorder', nlapiGetRecordId(), 'custbody_taiwu_fulfill_status_code', 8);
                }
            }
        }
    }
}
