var CONNECTOR_CONFIG = null;

// 有其他网站进入来的是， 写网站自己的 CONNECTOR_CONFIG
var CONFIG_LIST = [{

    name: 'HB',

    url: 'https://hautebrush.com', // Your store url (required)
    consumerKey: 'ck_d71fb5a1e1cf13235db5e41cb56765bbae233c96', // Your API consumer key (required)
    consumerSecret: 'cs_6c352a7494f2813af6df6b52e9ba31b886180e13',

    _auth: 'Basic Y2tfZDcxZmI1YTFlMWNmMTMyMzVkYjVlNDFjYjU2NzY1YmJhZTIzM2M5Njpjc182YzM1MmE3NDk0ZjI4MTNhZjZkZjZiNTJlOWJhMzFiODg2MTgwZTEz',

    deploymentId: 'customdeploy_hbconnector',
    timeFileName: 'lastCatchTime.txt',

    path: 'SuiteScripts/Hautebrush.com/',
    folderId: 369098, // 369098	Hautebrush.com

    // Hautebrush.com
    marketplace: 13

}];