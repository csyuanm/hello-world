/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       05 Jan 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){
   
	if(name == "custrecord_is_kit"){
	    //alert('Its a kit Relation.')
	if (nlapiGetFieldValue('custrecord_is_kit') == 'F') {
		  nlapiSetFieldValue('custrecord_kit_item', '');
		  return true;
		} else {
		  var kit_sku = nlapiGetFieldValue('custrecord_newegg_item_sku');  
		  nlapiLogExecution('DEBUG', 'kit_sku', kit_sku);
		  var ary = [];
		  ary = kit_sku.replace("@", "|").split("|");
		  kit_sku = ary[0];
		  if (kit_sku) {
		    var search = nlapiSearchRecord('customrecord_kit', null, [
		      ["custrecord_kit_sku", 'is', kit_sku]
		    ]);
		    if (search != null) {
		      nlapiSetFieldValue('custrecord_kit_item', search[0].id);
		      return true;
		    } else {
		      alert('No Kit Record found for SKU inserted');
		      nlapiSetFieldValue('custrecord_is_kit', 'F', false);
		      return true;
		    }
		  } else {
		    alert('Please Enter values of SKU before check me');
		    nlapiSetFieldValue('custrecord_is_kit', 'F', false);
		    return true;
		  }
		}
	}
}


function clientSaveRecord(){
	
	var sku = nlapiGetFieldValue('custrecord_newegg_item_sku');
	if(!sku){
		alert('Please provide a item SKU');
		return false
	}
	var acc = nlapiGetFieldValue('custrecord_newegg_item_acc');
	nlapiLogExecution('Debug','sku',sku)
	
	var filter = [];
	if(acc)
	filter.push(new nlobjSearchFilter('custrecord_newegg_item_acc',null,'anyof',acc));
	if(sku)
	filter.push(new nlobjSearchFilter('custrecord_newegg_item_sku',null,'is',sku));
    var recordId = nlapiGetRecordId();
    if(recordId)
      filter.push(new nlobjSearchFilter('internalId', null, 'noneof',recordId));
	var search = nlapiSearchRecord('customrecord_newegg_listings',null,filter);
	
	if(search){
		nlapiLogExecution('Debug','search length',search.length);
		var id = search[0].getId();
		
		alert('Listing exists with sku '+sku+' .Record id '+id);
		
		return false;
		
		
	}
	
    var item = nlapiGetFieldValue('custrecord_newegg_item');
    //alert('type of item '+typeof item + ' : '+ item)
    nlapiLogExecution('Debug','item',item)
    var isKit = nlapiGetFieldValue('custrecord_is_kit');
    nlapiLogExecution('Debug','isKit',isKit)
    if(item == "" && isKit == "F"){
    	alert('You must select an item (or) a kit');
    	return false
    }
	
    
    
	return true;
	

    
}


function dup(){
	
	if(name == "custrecord_is_kit"){
			
			if(nlapiGetFieldValue('custrecord_is_kit') == "T"){
				alert('kit true!!')
				
				var sku = nlapiGetFieldValue('custrecord_newegg_item_sku');
				nlapiLogExecution('Debug','sku',sku)
				
				var filter = [];
				filter.push(new nlobjSearchFilter('custrecord_kit_sku',null,'is',sku));
				var search = nlapiSearchRecord('customrecord_kit',null,filter);
				
				if(search){
					
					var id = search[0].getId();
					
					nlapiSetFieldValue('custrecord_is_kit',"T");
					nlapiSetFieldValue('custrecord_kit_item',id);
					
				}
			}
			
			
		}
	
}






