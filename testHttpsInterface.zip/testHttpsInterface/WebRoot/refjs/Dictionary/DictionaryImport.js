/**
 * Created by Chengli on 2016/1/10.
 * object for {
 * s: "", // SKU
 * q: ""  // Quantity
 * }
 */


function run() {

    // custscript_dc_command
    var dc_command = nlapiGetContext().getSetting('SCRIPT', 'custscript_dc_command');
    if (dc_command == 'import') {
        var accountId = 15; // Claimthis
        var fileId = '223188';
        var csvFile = nlapiLoadFile(fileId);
        var content = csvFile.getValue();

        var csvLines = new CSV(content).parse();
        csvLines.shift();
        var len = csvLines.length;

        var group = {};

        for (var i = 0; i < len; i++) {

            var line = csvLines[i];

            var ebaySKU = line[0];
            var nsSKU = line[1];
            var qty = line[2];

            if (group.hasOwnProperty(ebaySKU)) {
                group[ebaySKU] = [group[ebaySKU]];
                group[ebaySKU].push({
                    s: nsSKU,
                    q: qty
                });
            } else {
                group[ebaySKU] = {
                    s: nsSKU,
                    q: qty
                }
            }

        }

        for (var s in group) {
            var account_dictionary = nlapiCreateRecord('customrecord_ebay_account_dictionary');
            account_dictionary.setFieldValue('custrecord_ead_account', accountId);

            if (ebaySKU) {
                account_dictionary.setFieldValue('custrecord_ead_ebay_sku', s);
                account_dictionary.setFieldValue('custrecord_ead_ns_mapping', JSON.stringify(group[s]));
            }

            nlapiSubmitRecord(account_dictionary);

            checkGovernance()
        }
    } else if (dc_command == 'processing') {
        processDictionary()
    }

}

function processDictionary() {
    var search = nlapiSearchRecord('customrecord_ebay_account_dictionary', null, null, [
        new nlobjSearchColumn('custrecord_ead_ns_mapping')
    ]);
    if (search) {
        for (var i = 0; i < search.length; i++) {
            var searchResult = search[i];
            // custrecord_ead_ns_mapping
            var ns_mapping = searchResult.getValue('custrecord_ead_ns_mapping');
            ns_mapping = JSON.parse(ns_mapping);
            _log('ns_mapping', ns_mapping);
            var ns_mapping2 = cloneObj(ns_mapping);

            var ebayDictionary = nlapiLoadRecord('customrecord_ebay_account_dictionary', searchResult.getId());
            if (Array.isArray(ns_mapping)) {
                ebayDictionary.setFieldValue('custrecord_ead_combo', 'T');
                var issues = false;
                for (var j = 0; j < ns_mapping.length; j++) {

                    var columns = new Array();
                    columns[0] = new nlobjSearchColumn('internalid');
                    columns[1] = new nlobjSearchColumn('itemid');
                    columns[2] = new nlobjSearchColumn('description');

                    var filters = new Array();
                    filters[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', ns_mapping[j].s.trim());
                    filters[1] = new nlobjSearchFilter('isinactive', null, 'is', 'F');

                    var itemsearch = nlapiSearchRecord('item', null, filters, columns);

                    if (itemsearch != null) {
                        if (itemsearch.length == 1) {
                            ns_mapping[j].i = itemsearch[0].getId()
                        } else {
                            issues = true;
                            break;
                        }
                    } else {
                        issues = true;
                        break;
                    }

                }

                if (issues) {
                    continue;
                } else {
                    ebayDictionary.setFieldValue('custrecord_ead_ns_mapping2', JSON.stringify(ns_mapping));
                }

            } else {
                if (parseInt(ns_mapping.q) == 1) {
                    ebayDictionary.setFieldValue('custrecord_ead_combo', 'F');
                } else {
                    ebayDictionary.setFieldValue('custrecord_ead_combo', 'T');
                }

                var columns = new Array();
                columns[0] = new nlobjSearchColumn('internalid');
                columns[1] = new nlobjSearchColumn('itemid');
                columns[2] = new nlobjSearchColumn('description');

                var filters = new Array();
                filters[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', ns_mapping.s.trim());
                filters[1] = new nlobjSearchFilter('isinactive', null, 'is', 'F');

                var itemsearch = nlapiSearchRecord('item', null, filters, columns);

                if (itemsearch != null) {
                    if (itemsearch.length == 1) {
                        ns_mapping.i = itemsearch[0].getId();
                        ebayDictionary.setFieldValue('custrecord_ead_ns_mapping2', JSON.stringify(ns_mapping));
                    } else {
                        continue;
                    }
                } else {
                    continue;
                }

            }

            nlapiSubmitRecord(ebayDictionary);
        }
    }
}