/**
	* Module Description
	* 
	* Version    Date            Author           Remarks
	* 1.00       10 Nov 2016     Anurag
	*
	* @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
	* @returns {Void}
 

	Objectives
	Deliver an Automated Purchase Order System that allows purchasing department to place purchases
	orders automatically.
	* Enable inventory control from one location within Netsuite.
	* Support ability to change preferred stock levels from within the Order Item screen.
	* Support ability to set a new preferred vendor from within the Order Item screen.
	* Support ability to set a temporary vendor from within the Order Item screen.
	* Support ability to set rate from within the Order Item screen.
	* Support ability to roll up locations.

*/
var itemInformation ={};
var folderId= '1081724' ; //'1081724';	
var status=0;
 
function OrderItemsscheduled(type) {
	
	var existFile = nlapiCreateFile('poIds.txt','PLAINTEXT',JSON.stringify({'data':[]}));
	existFile.setFolder('1081724');
	existFile.setIsOnline(true);
	var updatedFile = nlapiSubmitFile(existFile);
 
    var context = nlapiGetContext();   
    var StriptParamData = JSON.parse(context.getSetting('SCRIPT', 'custscriptjsondata'));
    
    var file = nlapiLoadFile(StriptParamData[0]);	
    var role = StriptParamData[1];
    nlapiLogExecution('EMERGENCY', 'role', role);
    
    
    if(role ==1019){
    	// If role is of zake warehouse manager then set the status of the purchase order approved  	
    	// Purchase Order:Pending Supervisor Approval	 1
    	// Purchase Order:Pending Receipt	 2  	 
    	status=2;  	
    }
    
	var fileContents = JSON.parse(file.getValue());
    
    var parent_data = fileContents.dataArrayParet;
    var dataArraySublist = fileContents.dataArraySublist;
    
    nlapiLogExecution('DEBUG', 'parent_data', JSON.stringify(parent_data));
    nlapiLogExecution('DEBUG', 'dataArraySublist', JSON.stringify(dataArraySublist));
    
	   
    for(var i =0; i<dataArraySublist.length; i++){
    	
    	var vendor = dataArraySublist[i].vendor;
    	var selectItem = dataArraySublist[i].selectItems; 
    	
    	var data ={
    			
		    'selectItem' : dataArraySublist[i].selectItems,
		    'itemid' : dataArraySublist[i].itemID,
		    'location' : dataArraySublist[i].location,
		    'classItem' : dataArraySublist[i].classItem,  
		    'description' : dataArraySublist[i].description,
		    'department' : dataArraySublist[i].department,		
		    'currency' : dataArraySublist[i].currency,		
		    'selectVendor' : dataArraySublist[i].Prefvendor,
		    'vendor' : dataArraySublist[i].vendor,
		    'available' : dataArraySublist[i].available,
		    'backordered' : dataArraySublist[i].backordered,
		    'onorder' : dataArraySublist[i].onOrder,
		    'reorderpoint' : dataArraySublist[i].reorder,
		    'preferredstocklevel'  : dataArraySublist[i].prefStock,
		    'quantity'  : dataArraySublist[i].quantity,
		    'rate'  : dataArraySublist[i].rate,
		    'totalfc' : dataArraySublist[i].totalFc,
		    'rrate' : dataArraySublist[i].rateFc,
		    'ttotal' : dataArraySublist[i].total		    
    	};    	    
	
	    if(selectItem == "T"){
	    	
	    	if(!itemInformation[vendor]){
	    		itemInformation[vendor] =[];
			}			
	    	itemInformation[vendor].push(data);	
	    
	    }    
	 	   	
    }
    createPurchaseOrder();
	
}


function createPurchaseOrder(){
	
	var poArray = [];
	for(i in itemInformation){
		
		var vendor = i;
		var ItemDetails = itemInformation[i];
		
		var record = nlapiCreateRecord('purchaseorder',{'recordmode':'dynamic'});
		
		record.setFieldValue('entity',vendor);	 //searchVendor(vendor)
		
		if(status !=0){
			record.setFieldValue('approvalstatus', status);
		}		
		
		nlapiLogExecution('Debug','Line No 106 ',vendor);
		//nlapiLogExecution('Debug','location to be entered ',ItemDetails.location);
		//new // need to set location if needed later.
		//record.setFieldValue('location',ItemDetails[].location);
		
		for(var k=0; k<ItemDetails.length; k++){
			
			
			nlapiLogExecution('Debug','Line No 99 ','Line No 99 ');
			
			record.selectNewLineItem('item');	
			record.setCurrentLineItemValue('item','item',ItemDetails[k].itemid);
			//new
			record.setCurrentLineItemValue('item','vendorname',vendor);
			
			nlapiLogExecution('Debug','Line No 104 ',ItemDetails[k].itemid);
			
			nlapiLogExecution('Debug','Line No 106 ','Line No 106');
			
			record.setCurrentLineItemValue('item','quantity',parseInt(ItemDetails[k].quantity));
			record.setCurrentLineItemValue('item','rate',ItemDetails[k]['rate']);
			
			record.setCurrentLineItemValue('item', 'amount', ItemDetails[k]['rate']*parseInt(ItemDetails[k].quantity));
			
			record.commitLineItem('item');	
			
			var itemEdited = setFields(ItemDetails[k].itemid, ItemDetails[k].selectVendor, ItemDetails[k].vendor, ItemDetails[k].location, ItemDetails[k].preferredstocklevel,ItemDetails[k].reorderpoint,ItemDetails[k].rate);
			
			nlapiLogExecution('AUDIT','price and quantity ',ItemDetails[k]['rate'] + ' ' +parseInt(ItemDetails[k].quantity));
			nlapiLogExecution('AUDIT','itemEdited ',itemEdited);
		}
		
		nlapiLogExecution('Debug','Line No 115 ','Line No 115 ');
		
		var id = nlapiSubmitRecord(record,false,true);
		poArray.push(id);
		nlapiLogExecution('AUDIT','Purchase Order Id ',id);
	}	
	
	var file = nlapiCreateFile('poIds.txt','PLAINTEXT',JSON.stringify({'data':poArray}));
	file.setFolder('1081724');
	file.setIsOnline(true);
	var fileId = nlapiSubmitFile(file);
	nlapiLogExecution('AUDIT','Purchase file id ',fileId);
	 
}


function  setFields(itemid, selectVendor, vendor, location, preferredstocklevel, reorderpoint,rate){	
	
	nlapiLogExecution('Debug','Line No 116 ','Line No 116 ');
	
	
	var type = nlapiLookupField('item',itemid,'recordtype');//searchItem(itemid);
	
	var record = nlapiLoadRecord(type,itemid);
	
	var locationName = nlapiLookupField('location',location,'name');	
	var linenum = record.findLineItemValue('locations', 'location_display',locationName);
			    
	nlapiLogExecution('DEBUG', 'location line', linenum);
	 
    if(linenum != -1){
        record.setLineItemValue('locations', 'preferredstocklevel', linenum, preferredstocklevel);
        record.setLineItemValue('locations', 'reorderpoint', linenum, reorderpoint);               
    }			    
	
    nlapiLogExecution('Debug','selectVendor',selectVendor);
    
	if(selectVendor =='T'){
		// set new prffered vendor 		
		record.setLineItemValue('itemvendor', 'vendor', 1, vendor);
		record.setLineItemValue('itemvendor', 'preferredvendor', 1, 'T');
		nlapiLogExecution('Debug','rate',rate);
		record.setLineItemValue('itemvendor', 'purchaseprice', 1, rate);
	}
	nlapiLogExecution('Debug','Line No 134 ','Line No 134 ');
	// set rate	
	var id = nlapiSubmitRecord(record,false,true);
	
	return id;		
}


