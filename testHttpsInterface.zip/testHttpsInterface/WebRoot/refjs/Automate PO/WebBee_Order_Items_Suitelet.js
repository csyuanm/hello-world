/**
WebBee_Order_Items_Suitelet.js      
19th October 2016     Pranjal 
21st Nov 2016   Anurag
 */

//Library File
//suiteletLib.js

var body = '';
var totalItems = 0;
var resultSet = null;
var columns = [];
var folderId='1081724';		

// create the purchase order form UI
var dataArrayParet='';


function createUI(){
	
	try{
		
	    var FIndex = defVal(request.getParameter('findex'));
	    var TIndex = defVal(request.getParameter('toindex'));
	    
	    var locationId = defVal(request.getParameter('custpage_param1'));
	   
	    
	    var vendorId = defVal(request.getParameter('custpage_param2'));

	    
	    var parentId = defVal(request.getParameter('custpage_param3'));
	    
	    
	    var subsidiaryId = defVal(request.getParameter('custpage_param4'))

	    if(FIndex == "" && TIndex == ""){
	    	totalItems = GetITEMS(locationId,vendorId,parentId,subsidiaryId);
	    }
	    else{
            var loadedFile = nlapiLoadFile('1793122');      //'1297684');
		    
		    var content = JSON.parse(loadedFile.getValue());
		    totalItems = content.length;
	    }
	  
		var form = nlapiCreateForm("Process Order Items");
		form.setScript(811);//774
		
		
		
		//form.addField('custpage_minimunqty', 'integer', 'Minimum Quantity')//.setDefaultValue(minimumQuantityDefault);
		form.addField('custpage_tobeprinted', 'checkbox', 'To Be Printed').setDisplayType('disabled')//.setDefaultValue(toBePrintedDefault);
		form.addField('custpage_tobemailed', 'checkbox', 'To Be Mailed').setDisplayType('disabled')//.setDefaultValue(toBeMailedDefault);
		form.addField('custpage_tobefaxed', 'checkbox', 'To Be Faxed').setDisplayType('disabled')//.setDefaultValue(toBeFaxedDefault);
		form.addField('custpage_total', 'float', 'Total').setDefaultValue(parseFloat(0).toFixed(2));//.setDisplayType('entry')
		form.addButton('custpage_mark',"Mark All","mark();")
		form.addButton('custpage_unmark',"Unmark All","unmark();");
		form.addButton('custpage_back',"Back To Filter","back();");
		//form.addButton('custpage_resetall',"Reset All","resetAll();")
		form.addButton('custpage_resettotal',"Reset total","resetTotal();")
		var sublist = form.addSubList("custpage_orditemslist", 'list', 'Order Items'); //staticlist
		 
		sublist.addField('custpage_selectitem','checkbox', 'Select');
		sublist.addField('custpage_itemid','select','Item','inventoryitem').setDisplayType('inline');	
		sublist.addField('custpage_description','textarea', 'Description').setDisplayType('inline');
		sublist.addField('custpage_location','select','Location','location').setDisplayType('normal');
		
		sublist.addField('custpage_selectvendor','checkbox', 'Preferred Vendor'); // select preffered vendor
	    sublist.addField('custpage_vendors', 'select', 'Vendor', 'vendor').setDisplayType('normal');	    				
		sublist.addField('custpage_currency', 'select', 'Currency','currency');
		
		
		sublist.addField('custpage_available', 'integer', 'Available').setDisplayType('inline');
		
		sublist.addField('custpage_backordered', 'integer', 'Back Ordered').setDisplayType('inline');
		sublist.addField('custpage_onorder', 'integer', 'On Order').setDisplayType('inline');
		sublist.addField('custpage_preferredstocklevel', 'integer', 'Preferred Stock Level').setDisplayType('entry');
		sublist.addField('custpage_reorderpoint', 'integer', 'Reorder Point').setDisplayType('entry');
  	    sublist.addField('custpage_quantity', 'float', 'Quantity').setDisplayType('entry');
  	    
        sublist.addField('custpage_rate', 'text', 'Rate (Foreign Currency)').setDisplayType('entry');
	    sublist.addField('custpage_totalfc', 'text', 'Total (Foreign Currency)').setDisplayType('entry');
        sublist.addField('custpage_rrate', 'text', 'Rate').setDisplayType('entry');
				
		//sublist.addField('custpage_department','select','Department','department').setDisplayType('inline');
		sublist.addField('custpage_class','select', 'Class','classification').setDisplayType('inline');		
		
		//sublist.addField('custpage_unit', 'text', 'Unit').setDisplayType('inline');		
		
		
   	   
		sublist.addField('custpage_ttotal', 'text', 'Total').setDisplayType('entry')//.setDefaultValue(parseFloat(0)); // total
		
		form.addField('custpage_pagefrom', 'select', 'Page').setDisplayType('disabled')//.setDefaultValue(pageDefault);
		form.addResetButton('Reset Form');
		form.addSubmitButton('Commit');		
		
		
		

	    AddPageLimit(form);
	    AddItemsToList(sublist,FIndex,TIndex);
	    

	    response.writePage(form);	
	}
	catch(e){
		nlapiLogExecution('Debug','exception in createUI',e)
	}
	    
}




function addStatus(items){
	
	var form = nlapiCreateForm('Order status');
	
	var status = form.addSubList('custpage_status_list','list','status of PO');
	status.addField('custpage_item_id','text','Item');
	status.addField('custpage_status_line','text','status')
	for(var i = 0;i<items.length;i++){
		status.setLineItemValue('custpage_item_id',i+1,items[i].slice(0,100));
		status.setLineItemValue('custpage_status_line',i+1,"started");
	}
	form.setScript(811);
	form.addButton('custombutton', 'Refresh', "refresh1();");
	
	response.writePage(form);
	
}




function ProcessOrderItems(request, response)
{
   try
   {		 
	   
	if (request.getMethod() == 'GET' )
	   {
		   createUI();
		   
	   }else{
		   		   
		   var dataArraySublist=[];
		   var dataArrayParent=[];
		   
		   var currentLocation = request.getParameter('custpage_locationlist'); // location list
		   var currentVendor = request.getParameter('custpage_vendorlist'); // vendor list
		   var includeItemswithNoPrfVendor = request.getParameter('custpage_incitemnoprefvendor'); // include items with no preffered vendor
		   var includeItemsWhereVendIsnotPrf = request.getParameter('custpage_incitemvendornopref'); // include items where vendor is not preffered
		   var parentItems = request.getParameter('custpage_parentitems'); // parent items
		   var minimumQuantity = request.getParameter('custpage_minimunqty'); // minimum quantity
		   var toBePrinted = request.getParameter('custpage_tobeprinted'); // to be printed
		   
		   var toBeMailed = request.getParameter('custpage_tobemailed'); // to be mailed
		   var toBeFaxed = request.getParameter('custpage_tobefaxed'); // to be Faxed
		   var total = request.getParameter('custpage_total'); // total		   
		   var page = request.getParameter('custpage_pagefrom'); // total
		      
		   var count = request.getLineItemCount('custpage_orditemslist');
		   nlapiLogExecution('DEBUG', 'count',count);
		   
		   var items = []
		   
		   for(var k=1; k<=count; k++){
			   nlapiLogExecution('DEBUG', '95','95');
			   			  
			   if(request.getLineItemValue('custpage_orditemslist','custpage_selectitem',k) == "T"){
                   var data={	
					  
					   "selectItems" : request.getLineItemValue('custpage_orditemslist','custpage_selectitem',k),
					   "location" : request.getLineItemValue('custpage_orditemslist','custpage_location',k),
					  // "department" : request.getLineItemValue('custpage_orditemslist','custpage_department',k),
					   "classItem" : request.getLineItemValue('custpage_orditemslist','custpage_class',k),
					   "itemID" : request.getLineItemValue('custpage_orditemslist','custpage_itemid',k),
					   "description" : request.getLineItemValue('custpage_orditemslist','custpage_description',k),
					   
					   "Prefvendor" : request.getLineItemValue('custpage_orditemslist','custpage_selectvendor',k),
					   "vendor" : request.getLineItemValue('custpage_orditemslist','custpage_vendors',k),
					   "currency" : request.getLineItemValue('custpage_orditemslist','custpage_currency',k),
					   "available" : request.getLineItemValue('custpage_orditemslist','custpage_available',k),
					   "backordered" : request.getLineItemValue('custpage_orditemslist','custpage_backordered',k),
					   
					   "onOrder" : request.getLineItemValue('custpage_orditemslist','custpage_onorder',k),
					   "reorder" : request.getLineItemValue('custpage_orditemslist','custpage_reorderpoint',k),
					   "prefStock" : request.getLineItemValue('custpage_orditemslist','custpage_preferredstocklevel',k),
					   "quantity" : request.getLineItemValue('custpage_orditemslist','custpage_quantity',k),
					   "rateFc" : request.getLineItemValue('custpage_orditemslist','custpage_rate',k),
					   "totalFc" : request.getLineItemValue('custpage_orditemslist','custpage_totalfc',k),
					   
					   "rate" : request.getLineItemValue('custpage_orditemslist','custpage_rrate',k),
					   "total" : request.getLineItemValue('custpage_orditemslist','custpage_ttotal',k) 
					   
			  		}
                   items.push(data.description);
				   dataArraySublist.push(data);
			   }
			  
		   nlapiLogExecution('DEBUG', 'Item id',request.getLineItemValue('custpage_orditemslist','custpage_itemid',k));
  		   nlapiLogExecution('DEBUG', 'Item location',request.getLineItemValue('custpage_orditemslist','custpage_location',k));
  		   nlapiLogExecution('DEBUG', 'Item vendor',request.getLineItemValue('custpage_orditemslist','custpage_vendors',k));
		  
		   }
		   
		   dataArrayParent.push(currentLocation,currentVendor,includeItemswithNoPrfVendor,includeItemsWhereVendIsnotPrf,parentItems,minimumQuantity,toBePrinted,toBeMailed,toBeFaxed,total,page);
		   		   
		  
		   var file = nlapiCreateFile('data.txt', 'PLAINTEXT', JSON.stringify({"dataArraySublist":dataArraySublist,"dataArrayParet":dataArrayParent}));
		   file.setFolder(folderId);
		   file.setIsOnline(true);
		   fileID = nlapiSubmitFile(file); 
		   
		   // get user context and role
		   
		   var context = nlapiGetContext()
		   var role = context.getRole();
		   nlapiLogExecution('Debug','remaining usage...>>>><<<',context.getRemainingUsage())
		   var params = [];
		   params['custscriptjsondata'] = JSON.stringify([fileID,role]);
		   
		   
		   var scriptId = 'customscript_webbee_purchase_order_shedu';
		   var deployId = 'customdeploy_purchase_order_auto_schedul';
		   
		   nlapiScheduleScript(scriptId, deployId, params);
		   
		   nlapiLogExecution('DEBUG', 'Item Data',JSON.stringify({"dataArraySublist":dataArraySublist,"dataArrayParet":dataArrayParent}));
		   
		  
		   addStatus(items);
	   } 
	   	  
	   
   }
   catch(ex)
   {
	   body = 'Exception in ListOrderItems : '+ex.name;
	   body += ', Message : '+ex.message;
	   nlapiLogExecution('DEBUG', 'Body : ', body);
   }
}


 
function AddPageLimit(form)
{
   try
   {
	   var key = '';
	   var value = '';
       var ofValue = totalItems;
	   var pageField =  form.getField('custpage_pagefrom');
	   if(totalItems > 0)
	   {
		   pageField.setDisplayType('normal');
		   if(totalItems <= 150)
		   {
			   key = '0to'+totalItems;
			   value = 'From 1'+' to '+totalItems + " of "+ofValue;
			   pageField.addSelectOption(key,value);   
		   }   
		   else
		   {
			   var findex = 0;
			   var toIndex = 150;		 
			   totalItems -= 150; 
			   do
			    {
				   key = findex+'to'+toIndex;
				   value = 'From '+(findex+1)+' to '+toIndex + " of "+ofValue;
				   pageField.addSelectOption(key,value);   
				   findex = toIndex;
				   if(totalItems > 150)
				   {
					   toIndex += 150;
					  totalItems -= 150; 
				   }	   
				   else
					{
					   toIndex += totalItems;
					   key = findex+'to'+toIndex;
					   value = 'From '+(findex+1)+' to '+toIndex+ " of "+ofValue;
					   pageField.addSelectOption(key,value);   
					   break ;
					}    
			    }while(totalItems>0 );	  
		    }   		   
	   }   
   }
   catch(ex)
   {
	   body = 'Exception in AddPageLimit : '+ex.name;
	   body += ', Message : '+ex.message;
	   nlapiLogExecution('DEBUG', 'Body : ', body);
   }
}



function defVal(value)
{	
	    if(value == null || value == undefined ||  value == 'NaN')
	    value = '';	    
	    return value;
	
}








