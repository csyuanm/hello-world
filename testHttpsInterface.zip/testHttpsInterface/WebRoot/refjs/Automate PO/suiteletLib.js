/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       07 Feb 2017     ratul
 *
 */
var orderfile;

function GetITEMS(locationId,vendorId,parentId,subsidiaryId)
{
	try
	{
		var totalItems = 0;
		var fromIndex = 0;
		var toIndex = 150;
		var filebody = [];
		
		
		var loadedFile = nlapiLoadFile('1820375');    //'1297996');
	    
	    var content = JSON.parse(loadedFile.getValue());
	    nlapiLogExecution('Audit','content length',content.length);
	    
	    var filteredData = [];
	    
		if(locationId != ''){
			for(var i = 0;i<content.length;i++){
				if(content[i]['columns']['location'])
				var loc = content[i].columns.location.internalid
				if(loc === locationId){
					filteredData.push(content[i]);
				}
			}
			nlapiLogExecution('Audit','location filteredData  length',filteredData.length);
		}else{
			filteredData = content;
		}
	    nlapiLogExecution('Audit','default filteredData  length',filteredData.length);
	    //nlapiLogExecution('Audit','default filteredData  ',JSON.stringify(filteredData));
	    
	    var vendorData = [];
		if(vendorId != ''){
			nlapiLogExecution('Audit','vendorId',vendorId);
			for(var j = 0;j<filteredData.length;j++){
				if(filteredData[j]['columns']['vendor'])
				var x = filteredData[j].columns.vendor.internalid;
				nlapiLogExecution('Audit','x',x);
				if(x === vendorId){
					vendorData.push(filteredData[j]);
				}
			}
			nlapiLogExecution('Emergency','vendor filteredData  length',vendorData.length);
		}else{
			vendorData = filteredData;
		}
		
		var finalData = [];
		
		if(subsidiaryId != ''){
			for(var k = 0;k<vendorData.length;k++){
				if(vendorData[k]['columns']['subsidiary'])
			    var subs = vendorData[k].columns.subsidiary.internalid;
				if(subs === subsidiaryId){
					finalData.push(filteredData[k]);
				}
			}
			nlapiLogExecution('Audit','subsidiary filteredData  length',filteredData.length);
		}else{
			finalData = vendorData;
		}
		
	    
		var parentData = [];

		if(parentId != ''){
			for(var l = 0;l<finalData.length;l++){
				if(finalData[l]['columns']['parent'])
			    var subs = finalData[l].columns.parent.internalid;
				if(subs === parentId){
					parentData.push(finalData[l]);
				}
			}
			nlapiLogExecution('Audit','subsidiary filteredData  length',parentData.length);
		}else{
			parentData = finalData ;
		}



		totalItems = parentData.length;
		//var fileResult = resultSet.getResults(0,1000);
		var file = nlapiCreateFile('filteredData.txt',"PLAINTEXT",JSON.stringify(parentData));
		file.setFolder('1081724');
		orderfile = nlapiSubmitFile(file);

		return totalItems;
	    
		
		
		
	}
	catch(ex)
	{
		   body = 'Exception in GetITEMS : '+ex.name;
		   body += ', Message : '+ex.message;
		   nlapiLogExecution('DEBUG', 'Body : ', body);
	}
}


 
var name = "";
var parent = "";
var vendor = "";

var location = "";
var availableQty = "0";
var backOrd = "0";

var onOrd = "0";
var reOrdPoint = "0";
var prefStkLvl = "0";

var description = "";

var class1 = "";
var qty = "1";//defVal(parseFloat(prefStkLvl-availableQty)); 
var costrate = "";
var costtotal = "0";
var currency = "1";



function AddItemsToList(sublist,FIndex,TIndex)
{
	try
	{
//		if(totalItems > 0)
//		{   
		    var loadedFile = nlapiLoadFile('1820578');
		    
		    var content = JSON.parse(loadedFile.getValue());
		    
		    nlapiLogExecution('Emergency','content in AddItems',content.length);
		    
		    var Results	;
		    if(FIndex != '' && TIndex != ''){
		    	Results = content.slice(FIndex,TIndex);
		    }
		    else{
		    	Results = content.slice(0,150);
		    }
		    //nlapiLogExecution('Audit','result length page',Results.length);
		    if(Results != null && Results.length > 0)
		    {
		    	for(var i=0; i < Results.length ; i++)
				{ 
		    		try{
		    		 nlapiLogExecution('Audit','<<-->>',"<<<--->>")
		    		 if(Results[i]['id'])
					  itemId = Results[i].id;
		    		 nlapiLogExecution('Audit','itemId',itemId)
		    		 
		    		 if(Results[i]['columns']['itemid'])
					  name = Results[i].columns.itemid;
					 nlapiLogExecution('Audit','name',name)
					 
					 if(Results[i].columns['parent'])
					  parent = defVal(Results[i].columns.parent.internalid);
					 nlapiLogExecution('Audit','parent',parent)
					 
//					 if(Results[i].columns['othervendor'])
//					 vendor = defVal(Results[i].columns.othervendor.internalid);
//					 nlapiLogExecution('Audit','vendor',vendor)
					//var department = Results[i].getValue(columns[3]);
					 if(Results[i].columns['vendor'])
					  vendor = defVal(Results[i].columns.vendor.internalid);
					 //nlapiLogExecution('Audit','vendor',vendor)
					 
					 
					 
					 if(Results[i].columns['location'])
					  location = defVal(Results[i].columns.location.internalid);
					 //nlapiLogExecution('Audit','location',location);
					 
					 if(Results[i].columns['quantityavailable'])
					  availableQty = defVal(new Number(Results[i].columns.quantityavailable));
					 //nlapiLogExecution('Audit','availableQty',availableQty);
					 
					 if(Results[i].columns['quantitybackordered'])
					  backOrd = defVal(new Number(Results[i].columns.quantitybackordered));
					 //nlapiLogExecution('Audit','backOrd',backOrd);
					 
					 if(Results[i].columns['quantityonorder'])
					  onOrd = defVal(new Number(Results[i].columns.quantityonorder));
					 //nlapiLogExecution('Audit','onOrd',onOrd);
					 
					 if(Results[i].columns['reorderpoint'])
					  reOrdPoint = defVal(new Number(Results[i].columns.reorderpoint));
					// nlapiLogExecution('Audit','reOrdPoint',reOrdPoint)
					 
					 if(Results[i].columns['preferredstocklevel'])
					  prefStkLvl = defVal(new Number(Results[i].columns.preferredstocklevel));
					 //nlapiLogExecution('Audit','prefStkLvl',prefStkLvl);
					 
					 if(Results[i].columns['purchasedescription'])
					  description = defVal(Results[i].columns.purchasedescription);
					 //nlapiLogExecution('Audit','description',description)
					 
					 if(description == ""){
						 if(Results[i].columns['displayname'])
						 description = defVal(Results[i].columns.displayname);
					 }
					 
					 if(Results[i].columns['currency'])
				      currency = defCurr(Results[i].columns.currency.internalid)		 
					 //nlapiLogExecution('Audit','currency',currency);
					 
					 if(Results[i].columns['class'])
					  class1 = Results[i]["columns"]["class"].internalid;
					  qty = new Number("1");// Math.round(parseFloat(prefStkLvl)-parseFloat(availableQty)).toFixed(0);//
					  costrate = defVal(parseFloat(Results[i].columns.cost).toFixed(2));
					 
					 if(costrate == ""){
						 if(Results[i].columns['lastpurchaseprice'])
						 costrate = defVal(parseFloat(Results[i].columns.lastpurchaseprice).toFixed(2));
					 }
					 
					  costtotal = defVal(parseFloat(costrate*qty).toFixed(2));
				    //nlapiLogExecution('Emergency','costtotal type',typeof costtotal);
					
					sublist.setLineItemValue('custpage_selectitem',i+1 , 'F');
					sublist.setLineItemValue('custpage_itemid',i+1 ,itemId);
					sublist.setLineItemValue('custpage_location',i+1 ,location);
					if(defVal(class1) != '')
					sublist.setLineItemValue('custpage_class',i+1 ,class1);
					sublist.setLineItemValue('custpage_description',i+1, description);
					sublist.setLineItemValue('custpage_vendors',i+1 ,vendor);
					
					sublist.setLineItemValue('custpage_currency',i+1 ,currency);
					
					sublist.setLineItemValue('custpage_available',i+1 ,availableQty);
					sublist.setLineItemValue('custpage_backordered',i+1 ,backOrd);
					sublist.setLineItemValue('custpage_onorder',i+1 ,onOrd);
					sublist.setLineItemValue('custpage_reorderpoint',i+1 , reOrdPoint);
					sublist.setLineItemValue('custpage_preferredstocklevel',i+1, prefStkLvl);
					sublist.setLineItemValue('custpage_quantity',i+1 , qty);
					sublist.setLineItemValue('custpage_rate',i+1 , costrate);	
					sublist.setLineItemValue('custpage_totalfc',i+1 , costtotal);
					sublist.setLineItemValue('custpage_rrate',i+1 , costrate);
					sublist.setLineItemValue('custpage_ttotal',i+1 , costtotal);
					
					
					 name = "";
					 parent = "";
					 vendor = "";

					 location = "";
					 availableQty = "0";
					 backOrd = "0";

					 onOrd = "0";
					 reOrdPoint = "0";
					 prefStkLvl = "0";

					 description = "";

					 class1 = "";
					 qty = "1";//defVal(parseFloat(prefStkLvl-availableQty)); 
					 costrate = "";
					 costtotal = "";
					 currency = "1";
			   }
		       catch(e){
		    	   nlapiLogExecution('Emergency','error in item fetching',e)
		       }
		       
				}
		    }	
		//}
	}
   catch(ex)
   {
	   body = 'Exception in AddItemsToList : '+ex.name;
	   body += ', Message : '+ex.message;
	   nlapiLogExecution('DEBUG', 'Body : ', body);
   }
}


function defVal(value)
{	
	 
	    if(value == null || value == undefined ||  value == 'NaN')
	    value = '';	    
	    return value;
	 
}

function defCurr(value){
	
	if(value == null || value == undefined ||  value == 'NaN')
	value = '1';	    
	return value;
	
}























//var itemSearch = nlapiSearchRecord("item",null,
//		[
//		   [[["quantitybackordered","greaterthan","0"]],"OR",[["formulanumeric: {locationquantityavailable}-{preferredstocklevel}","lessthanorequalto","0"]],"OR",[["formulanumeric: {locationquantityavailable}-{reorderpoint}","lessthanorequalto","0"]]], 
//		   "AND", 
//		   ["locationquantityavailable","greaterthanorequalto","0"]
//		], 
//		[
//		   new nlobjSearchColumn("itemid",null,null).setSort(false), 
//		   new nlobjSearchColumn("parent",null,null), 
//		   new nlobjSearchColumn("othervendor",null,null), 
//		   new nlobjSearchColumn("department",null,null), 
//		   new nlobjSearchColumn("location",null,null), 
//		   new nlobjSearchColumn("quantityavailable",null,null), 
//		   new nlobjSearchColumn("quantitybackordered",null,null), 
//		   new nlobjSearchColumn("quantityonorder",null,null), 
//		   new nlobjSearchColumn("reorderpoint",null,null), 
//		   new nlobjSearchColumn("preferredstocklevel",null,null), 
//		   new nlobjSearchColumn("purchasedescription",null,null), 
//		   new nlobjSearchColumn("unitstype",null,null), 
//		   new nlobjSearchColumn("cost",null,null)
//		]
//		);

//1614








