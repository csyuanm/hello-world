/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       22 Feb 2017     ratul
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
     
	if(request.getMethod() == "GET"){
		
		var form = nlapiCreateForm("Process Order Items");
		var locField = form.addField('custpage_locationlist', 'select', 'Location', 'location').setMandatory(false);
		var vendorField = form.addField('custpage_vendorlist', 'select', 'Vendor', 'vendor').setMandatory(false);
		var parentField = form.addField('custpage_parentitems', 'select', 'Parent Item', 'inventoryitem');
		var subsidiary = form.addField('custpage_subsidiary', 'select', 'Subsidiary', 'subsidiary');
		form.setScript(811);
		form.addButton('custpage_openform', 'Submit', "openSuitelet();");
		form.addButton('custpage_openform', 'Default', "openSuitelet();");
		//form.addSubmitButton('Submit');
		
		response.writePage(form);
		
	}else{
		
	}
	
}


