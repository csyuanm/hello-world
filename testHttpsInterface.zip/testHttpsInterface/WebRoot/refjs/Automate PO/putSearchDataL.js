/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       03 Mar 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
	var fromIndex = 0;
	var toIndex = 500;
	var filebody = [];
	var ItemSearch = nlapiLoadSearch('item', '2059');
	ItemSearch.addColumn(new nlobjSearchColumn('class'));
	resultSet = ItemSearch.runSearch();				
    columns = ItemSearch.getColumns();
	var results = resultSet.getResults(fromIndex,toIndex);			
	var i = 0;
	
	while(results != null && results.length > 0)
	{   
		checkGovernance();
		//totalItems += results.length;
		filebody.push(results[i]);
		
		i++;
		if(i == results.length){
			fromIndex = toIndex;
		    toIndex += 500;
		    results = resultSet.getResults(fromIndex,toIndex);
		    i = 0;
		}

	    	
	}
	
	var file = nlapiCreateFile('orderResultSC.txt',"PLAINTEXT",JSON.stringify(filebody));
	file.setFolder('1081724');
	var orderfile = nlapiSubmitFile(file);
	nlapiLogExecution('Audit','orderfile',orderfile);
	
}








function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}
