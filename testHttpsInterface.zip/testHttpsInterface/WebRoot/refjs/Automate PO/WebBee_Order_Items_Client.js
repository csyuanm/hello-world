/**
 *WebBee_Order_Items_Client.js
 * 19th October  2016     Pranjal
 */


var body = '';
var PageURL = '/app/site/hosting/scriptlet.nl?script=809&deploy=1&r=T&machine=custpage_orditemslist';//773
var FullURL = 'https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=809&deploy=1';//773
var ChangeFields = ['custpage_locationlist','custpage_vendorlist','custpage_parentitems'];

var initLocation,
    initVendor,
    initParent,
    initMinQ;
var locationArr = [],
vendorArr = [],
preferredSLArr = [],
quantityArr = [],
rateFCArr = [],
rateArr = [],
reorderArr = [];


var initQuantity;
var initRateFC;
var initRate;

function OnPageInit()
{
	try
	{
		initLocation = nlapiGetFieldValue('custpage_locationlist');
		initVendor = nlapiGetFieldValue('custpage_vendorlist');	
		initParent = nlapiGetFieldValue('custpage_parentitems');			
		initMinQ = nlapiGetFieldValue('custpage_minimunqty');
		
		var count = nlapiGetLineItemCount('custpage_orditemslist');
		for(var j = 1;j<=count;j++){
			
			var itemLoc = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_location', j);
			var itemVen = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_vendors', j)
			var itemPSL = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_preferredstocklevel', j)
			var itemQty = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_quantity', j)
			
			var itemRateFC = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_rate', j)
			var itemRate = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_rrate', j)
			var itemReorder = nlapiGetLineItemValue("custpage_orditemslist", 'custpage_reorderpoint', j)
			
			locationArr.push(itemLoc);
			vendorArr.push(itemVen);
			preferredSLArr.push(itemPSL);			
			quantityArr.push(itemQty);
			
			rateFCArr.push(itemRateFC);
			rateArr.push(itemRate);
			reorderArr.push(itemReorder);
			
		}
		
		nlapiLogExecution('Debug','locationArr',JSON.stringify(locationArr));
		nlapiLogExecution('Debug','quantityArr',JSON.stringify(quantityArr));
		nlapiLogExecution('Debug','reorderArr',JSON.stringify(reorderArr));
		nlapiLogExecution('Debug','rateArr',JSON.stringify(rateArr));
		
	   alert('Hello');
	}
   catch(ex)
   {
	   body = 'Exception in OnPageInit : '+ex.name;
	   body += ', Message : '+ex.message;
	   alert(body);
   }
}

function OnFieldChange(type, name, linenum)
{
	try
	{   
		
		if(type == "custpage_orditemslist"){
	    	
	    	var field = nlapiGetLineItemValue(type, name, linenum);
	    	if(field < 0 ){
	    		alert('You cannot enter negative value');
	    		nlapiSetLineItemValue(type, name , linenum, '');
	    		return false;
	    	}
	    	
	    }
		
		var locationId = nlapiGetFieldValue(ChangeFields[0]);
		var vendorId = nlapiGetFieldValue(ChangeFields[1]);
		var parentId =  nlapiGetFieldValue(ChangeFields[2]);
		var fromto = defVal(nlapiGetFieldValue('custpage_pagefrom')).split('to');
		if(name == 'custpage_pagefrom')
		{
			if(fromto != null && fromto.length == 2)
            {	
				var params = '&findex='+fromto[0]+'&toindex='+fromto[1];
				document.getElementById('server_commands').src =  PageURL+params;
            }
		}
		
		
//		if(ChangeFields.indexOf(name) != -1)
//		{
//			var params = '&locationId='+locationId;
//			params += '&vendorId='+vendorId;
//			params += '&parentId='+parentId;
//		    window.location = FullURL+params;
//		}
				
		
		if(type == 'custpage_orditemslist')
	    {
			if(name =='custpage_vendors'){
				
				var itemId = nlapiGetLineItemValue(type, 'custpage_itemid', linenum);
				var vendor = nlapiGetLineItemValue(type, 'custpage_vendors', linenum);
				
//			alert(searchItem(itemId));
//			alert(searchVendor(vendor));
				var itemSubs = nlapiLookupField('item',itemId,'subsidiary');
				var vendorSubs = nlapiLookupField('vendor',vendor,'subsidiary');
				if( itemSubs != vendorSubs){
					alert('Subsidiary of Vendor and Item do not match.');
					nlapiSetLineItemValue(type, name , linenum, '');
				}
				
			}	
	    }
		
				
		if(type == 'custpage_orditemslist')
	    {
			if(name == "custpage_quantity"){
				var quantity = nlapiGetLineItemValue(type, 'custpage_quantity', linenum);								
				var rate = nlapiGetLineItemValue(type, 'custpage_rrate', linenum);						
				var costtotal =  parseFloat(quantity*rate).toFixed(2);			
				
				nlapiSetLineItemValue(type, 'custpage_ttotal' , linenum, costtotal);
				
				if(nlapiGetLineItemValue(type,'custpage_selectitem', linenum) =='T'){
					var totalSum = nlapiGetFieldValue('custpage_total');
					if(quantity > initQuantity){
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)+parseFloat((quantity-initQuantity)*rate));
					}else{
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)-parseFloat((initQuantity-quantity)*rate));
					}
				}
            }
			
			
	    }	
		
		if(type == 'custpage_orditemslist')
	    {	
			if(name == "custpage_quantity"){
				var quantity = nlapiGetLineItemValue(type, 'custpage_quantity', linenum);								
				var rate = nlapiGetLineItemValue(type, 'custpage_rate', linenum);						
				var costtotal =  parseFloat(quantity*rate).toFixed(2);			
				
				nlapiSetLineItemValue(type, 'custpage_totalfc' , linenum, costtotal);			
			}
	    }
		
		if(type == 'custpage_orditemslist'){
			
			if(name == "custpage_rate"){
				var quantity = nlapiGetLineItemValue(type, 'custpage_quantity', linenum);								
				var rate = nlapiGetLineItemValue(type, 'custpage_rate', linenum);						
				var costtotal =  parseFloat(quantity*rate).toFixed(2);			
				
				nlapiSetLineItemValue(type, 'custpage_totalfc' , linenum, costtotal);
				
				if(nlapiGetLineItemValue(type,'custpage_selectitem', linenum) =='T'){
					var totalSum = nlapiGetFieldValue('custpage_total');
					if(rate > initRateFC){
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)+parseFloat((rate-initRateFC)*quantity));
					}else{
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)-parseFloat((initRateFC-rate)*quantity));
					}
				}
			}
			
		}
		
		if(type == 'custpage_orditemslist'){
			
			if(name == "custpage_rrate"){
				var quantity = nlapiGetLineItemValue(type, 'custpage_quantity', linenum);								
				var rate = nlapiGetLineItemValue(type, 'custpage_rrate', linenum);						
				var costtotal =  parseFloat(quantity*rate).toFixed(2);			
				
				nlapiSetLineItemValue(type, 'custpage_ttotal' , linenum, costtotal);
				
				if(nlapiGetLineItemValue(type,'custpage_selectitem', linenum) =='T'){
					var totalSum = nlapiGetFieldValue('custpage_total');
					if(rate > initRate){
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)+parseFloat((rate-initRate)*quantity));
					}else{
						nlapiSetFieldValue('custpage_total',parseFloat(totalSum)-parseFloat((initRate-rate)*quantity));
					}
				}
			}
			
		}
		
		
		if(type == 'custpage_orditemslist')
	    {
			if(name != "custpage_selectvendor" || name != "custpage_selectvendor" || name != "custpage_preferredstocklevel") {
				if(name =='custpage_selectitem'){								
					
					if(nlapiGetLineItemValue(type,'custpage_selectitem', linenum) =='T'){
						 
					    var totalSum = nlapiGetFieldValue('custpage_total');
						if(totalSum !='' && totalSum !=null){
							nlapiSetFieldValue('custpage_total',parseFloat(totalSum) + parseFloat(nlapiGetLineItemValue(type, 'custpage_ttotal', linenum)));
						}
					   else{
							nlapiSetFieldValue('custpage_total',parseFloat(nlapiGetLineItemValue(type, 'custpage_ttotal', linenum)));
						}
					}else{
						 
						var totalSum = nlapiGetFieldValue('custpage_total');
						if(totalSum !='' && totalSum !=null){
							nlapiSetFieldValue('custpage_total',parseFloat(totalSum) - parseFloat(nlapiGetLineItemValue(type, 'custpage_ttotal', linenum)));
						}
					}				
					
				}
			}
			
	    }
			
		
		
	}
   catch(ex)
   {
	   body = 'Exception in OnFieldChange : '+ex.name;
	   body += ', Message : '+ex.message;
	   alert(body);
   }
}


function defVal(value)
{	
	
    if(value == null || value == undefined)
    value = '';	    
    return value;
	
	
}

function clientSaveRecord()
{

    return true;
}

function clientValidateField(type, name, linenum)
{   
	if(name == "custpage_quantity"){
	  initQuantity = nlapiGetLineItemValue(type,'custpage_quantity', linenum);
	}
	
	if(name == "custpage_rate"){
	  initRateFC = nlapiGetLineItemValue(type,'custpage_rate', linenum);
	}
	if(name == "custpage_rrate"){
		  initRate = nlapiGetLineItemValue(type,'custpage_rrate', linenum);
	}
	if(name == "custpage_ttotal"){
		var val1 = nlapiGetLineItemValue(type,'custpage_rrate', linenum);
		alert('the value of this ',val1);
	}
	return true;
}

function clientLineInit(type) {
     
}


function clientValidateLine(type){
 
    return true;
}


 

function refresh1(){
	
	
	var url = nlapiResolveURL('SUITELET', 'customscript_po_result', 'customdeploy_po_result_deploy');
    window.location = url;
	
}

function back(){
	
	var url = nlapiResolveURL('SUITELET', 'customscript_po_start_page', 'customdeploy_po_start_page_deploy');
    window.location = url;
	
}

function mark (){
	var count = nlapiGetLineItemCount('custpage_orditemslist');
	
	var totalSum = parseFloat(0);

	for(var i = 1;i<=count;i++){
		nlapiSetLineItemValue('custpage_orditemslist','custpage_selectitem',i,"T");
		nlapiSetLineItemValue('custpage_orditemslist','custpage_selectvendor',i,"T");
		totalSum += parseFloat(nlapiGetLineItemValue("custpage_orditemslist", 'custpage_ttotal', i))
	}
	nlapiSetFieldValue('custpage_total',totalSum);
}

function unmark(){
	var count = nlapiGetLineItemCount('custpage_orditemslist');
	
	for(var i = 1;i<=count;i++){
		nlapiSetLineItemValue('custpage_orditemslist','custpage_selectitem',i,"F")
		nlapiSetLineItemValue('custpage_orditemslist','custpage_selectvendor',i,"F");
	}
	var totalSum = parseFloat(0);
	nlapiSetFieldValue('custpage_total',totalSum);
}

function resetTotal(){
	
	nlapiSetFieldValue('custpage_total',parseFloat(0));
	unmark();
	
}

function resetAll(){
	
	nlapiSetFieldValue('custpage_total',parseFloat(0));
	
	nlapiSetFieldValue('custpage_locationlist',initLocation);
	nlapiSetFieldValue('custpage_vendorlist',initVendor);	
	nlapiSetFieldValue('custpage_parentitems',initParent);			
    nlapiSetFieldValue('custpage_minimunqty',initMinQ);
    
    var count = nlapiGetLineItemCount('custpage_orditemslist');
    for(var j = 1;j<=count;j++){
    	
    	nlapiSetLineItemValue('custpage_orditemslist','custpage_selectitem',j,"F")
		nlapiSetLineItemValue('custpage_orditemslist','custpage_selectvendor',j,"F");
    	
    	nlapiSetLineItemValue("custpage_orditemslist", 'custpage_location', j,locationArr[j-1]);
    	nlapiSetLineItemValue("custpage_orditemslist", 'custpage_vendors', j,vendorArr[j-1])
		nlapiSetLineItemValue("custpage_orditemslist", 'custpage_preferredstocklevel', j,preferredSLArr[j-1])
		nlapiSetLineItemValue("custpage_orditemslist", 'custpage_quantity', j,quantityArr[j-1])
		
		nlapiSetLineItemValue("custpage_orditemslist", 'custpage_rate', j,rateFCArr[j-1])
		nlapiSetLineItemValue("custpage_orditemslist", 'custpage_rrate', j,rateArr[j-1])
		nlapiSetLineItemValue("custpage_orditemslist", 'custpage_reorderpoint', j,reorderArr[j-1])
		
		
    	
    }
    
	
}



function openSuitelet(){
	
	
	var loc = nlapiGetFieldValue('custpage_locationlist');
	var vendor = nlapiGetFieldValue('custpage_vendorlist');
	var parent = nlapiGetFieldValue('custpage_parentitems');
	var subsidiaries = nlapiGetFieldValue('custpage_subsidiary');
	var url = nlapiResolveURL('SUITELET', 'customscript_webbee_purchase_order_autom', 'customdeploy_webbee_purchase_order_deplo');
    url += '&custpage_param1=' + loc + '&custpage_param2='+vendor+'&custpage_param3='+parent + '&custpage_param4='+subsidiaries;
    
    window.location = url;
	
}















