/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       08 Feb 2017     ratul
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function suitelet(request, response){
   
	if(request.getMethod() == "GET"){
	    
		
//		var dataArr = request.getParameter('custpage_param1');
//		
//		dataArr = dataArr.split('_');
        var fileId = "1820580" //"SuiteScript/webbeeAnurag/poIds.txt";
		
		var file = nlapiLoadFile(fileId);
		var content = JSON.parse(file.getValue());
		
		//nlapiLogExecution('Debug','content',content);
		
		var dataArr = content.data;
		nlapiLogExecution('Debug','poArray',JSON.stringify(dataArr));
		
		var form = nlapiCreateForm('Result');
		
		var sublist = form.addSubList('custpage_po_result','list','created po');
		var urlView = sublist.addField('view','url','Action').setLinkText("View");
		sublist.addField('custpage_po_id','text','created Po');
		sublist.addField('custpage_po_status','text','status');
		//sublist.addField('custpage_po_amount','text','amount');
		
		if(dataArr.length != null){
			for(var i = 0;i<dataArr.length;i++){
				var recId = dataArr[i];
				var status = nlapiLookupField('purchaseorder',recId,"status")
				//var total = nlapiLookupField('purchaseorder',recId,"total")
				var url = nlapiResolveURL('RECORD','purchaseorder',recId);
				
				if(status){
					
					sublist.setLineItemValue('view',i+1,url);
					sublist.setLineItemValue('custpage_po_id',i+1,"PO"+recId);
					sublist.setLineItemValue('custpage_po_status',i+1,status);
					//sublist.setLineItemValue('custpage_po_amount',i+1,total);
				}
				
			}
		}
		form.setScript(811);
		form.addButton('custombutton', 'Refresh', "refresh1();");
		response.writePage(form)
		 
	
	}
}
