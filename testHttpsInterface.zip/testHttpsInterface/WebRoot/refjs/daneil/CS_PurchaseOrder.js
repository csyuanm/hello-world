/*****************************************************
 *File Name   : CS_PurchaseOrder.js
 *Description : Client script on purchase order
 *Created By  : Daniel Cai
 *Created On  : 27-Dec-2016
 * 继续: Allan Hou
 *****************************************************/

function saveRecord() {
    var subsidiary = nlapiGetFieldValue('subsidiary');
    if (subsidiary == 3) {

        var employee = nlapiGetFieldValue('employee');
        if (!employee) {
            alert('PO必须选择 Employee！');
            return false;
        }

        var location = nlapiGetFieldValue('location');
        //var arr = [74, 35, 34];
        if (location) {
            if (location == 74 ||
                location == 35 ||
                location == 34 ||

                location == 77 ||
                location == 75 ||

                location == 88 ||
                location == 59 ||
                location == 87) {
                return true;
            } else {
                alert('Location不对，请review！');
                return false;
            }
        } else {
            alert('没有选择Location！');
            return false;
        }


    }

    return true;

}

function po_page_init(type) {
    try {
        var subId = nlapiGetFieldValue('subsidiary');
        if (subId == 3) {
            if (type == 'edit') {
                var lineCount = nlapiGetLineItemCount('item');
                for (var i = 1; i <= lineCount; i++) {
                    nlapiSetLineItemValue('item', 'custcol_taiwu_arrived', i, 0);
                }

                // warehouse dept
                var role = nlapiGetRole();
                if (role == 1124 ||
                    role == 1123 ||
                    role == 1122 ||
                    role == 1211) {
                    nlapiDisableLineItemField('item', 'rate', true);
                    nlapiDisableLineItemField('item', 'amount', true);
                    nlapiDisableLineItemField('item', 'tax1amt', true);
                    nlapiDisableLineItemField('item', 'grossamt', true);
                }

            }
        } else if (subId == 8) {
            var department = nlapiGetFieldValue('department');
            if (!department) {
                nlapiSetFieldValue('department', nlapiGetDepartment());
            }

        }
    } catch (ex) {
        alert('Error');
        alert(ex);
        alert(ex.getDetails());
    }
}

function fieldChanged(type, name, linenum) {
    //var subId = nlapiGetFieldValue('subsidiary');
    //console.log(subId);
    //if (subId == 8) {
    //    if (!type) {
    //        if (name == 'entity') {
    //        }
    //    }
    //
    //}
}
function isNull(str) {
    if (str == null || str == '') return true;
    else return false;
}