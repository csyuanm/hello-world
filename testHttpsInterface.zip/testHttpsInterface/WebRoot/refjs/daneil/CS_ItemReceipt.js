/*****************************************************
 *File Name   : CS_ItemReceipt.js
 *Description : client script on item receipt
 *Created By  : Daniel Cai
 *Created On  : 27-Dec-2016
 * revised: Allan Hou
 *****************************************************/

function receipt_page_init(type) {
    try {
        console.log(type);
        var subId = nlapiGetFieldValue('subsidiary');
        if (subId == 3) {
            var lineCount = nlapiGetLineItemCount('item');
            //alert('lineCount: ' + lineCount);
            for (var i = 1; i <= lineCount; i++) {
                nlapiSelectLineItem('item', i);
                var arriveQty = nlapiGetCurrentLineItemValue('item', 'custcol_taiwu_arrived');
                var receiveQty = nlapiGetCurrentLineItemValue('item', 'quantity');
                //alert(arriveQty + ', ' + receiveQty);
                if (arriveQty == 0 || isNull(arriveQty)) {
                    nlapiSetCurrentLineItemValue('item', 'itemreceive', 'F');
                    continue;
                }
                if (arriveQty - receiveQty != 0) {
                    nlapiSetCurrentLineItemValue('item', 'quantity', arriveQty);
                }
            }
        }
    }
    catch (ex) {
        alert('Error');
        alert(ex);
        alert(ex.getDetails());
    }
}

function receipt_save_record(type) {
    try {
        var subId = nlapiGetFieldValue('subsidiary');
        if (subId == 3) {

            var createFrom = nlapiGetFieldText('createdfrom');
            if (createFrom.indexOf('PO') < 1) return true;

            var lineCount = nlapiGetLineItemCount('item');
            for (var i = 1; i <= lineCount; i++) {
                var select = nlapiGetLineItemValue('item', 'itemreceive', i);
                if (select == 'T') {
                    var arriveQty = nlapiGetLineItemValue('item', 'custcol_taiwu_arrived', i);
                    var receiveQty = nlapiGetLineItemValue('item', 'quantity', i);
                    if (arriveQty - receiveQty < 0) {
                        var itemName = nlapiGetLineItemValue('item', 'itemname', i);
                        alert('第' + i + '行：入库数量多于到达数量！' + itemName);
                        return false;
                    }
                }
            }
        }
        return true;
    }
    catch (ex) {
        alert('Error');
        alert(ex);
        alert(ex.getDetails());
    }
}

function isNull(str) {
    if (str == null || str == '') return true;
    else return false;
}