/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       13 Sep 2016     Admin
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function GetAliOrderSchedule(){
	nlapiLogExecution('DEBUG', 'start');
	var fromUI='F';
	fromCsv='T';
	var filter=[];
	filter.push(new nlobjSearchFilter('custrecord_from_csv_ali', null, 'is', 'T'));
	filter.push(new nlobjSearchFilter('custrecord_create_aliorder', null, 'is', 'F'));
	var col=[];
	col.push(new nlobjSearchColumn('custrecord_aliorder_id'));
	col.push(new nlobjSearchColumn('custrecord_ali_act'));
	var search=nlapiSearchRecord('customrecord2592', null, filter, col);
	if(search!=null){
		var length=search.length;
		nlapiLogExecution('DEBUG', 'search.length', length);
		for(var i=0,j=1;i<length;i++){
			try{
			var recordid=search[i].getId();
			var ali_order_id=search[i].getValue('custrecord_aliorder_id');
			var ali_account_id=search[i].getValue('custrecord_ali_act')
			nlapiLogExecution('DEBUG', 'ali_order_id '+ali_order_id+' ali_account_id '+ali_account_id);
			var rec=getAliOrder(ali_order_id,ali_account_id,fromUI,fromCsv);
			nlapiLogExecution('DEBUG', 'rec', rec);
			if(rec>0){
				 nlapiSubmitField('customrecord2592', recordid, ['custrecord_salesorder','custrecord_create_aliorder','custrecord_ali_act'],[rec,'T',ali_account_id]);
			}
		}
		catch(e){
			nlapiLogExecution('DEBUG', 'error', e);
			 nlapiSubmitField('customrecord2592', recordid, ['custrecord_order_missing_reason','custrecord_ali_act'],[e,ali_account_id]);

		}
		}
	}

}
function changePhoneno(type,form){
	var order_missing_reason=nlapiGetFieldValue('custrecord45');
	var order_created=nlapiGetFieldValue('custrecord_create_aliorder');
	if(order_missing_reason&&order_missing_reason.indexOf("phone")!=(-1)&&order_created=='F'){
		var phone_field =  form.addField("custpage_new_phone",'text',"New Phone No.");
	}
}
function getAliOrderrAfterSubmit(){
	
	var obj=nlapiGetContext();
	var context=obj.getExecutionContext();
	if(context=='userinterface'){
		try{
    var recordid=nlapiGetRecordId();
    var record=nlapiGetRecordType();
	var ali_account=nlapiGetFieldValue('custrecord_ali_act');
	var Order_id=nlapiGetFieldValue('custrecord_aliorder_id');
	
	var create_order=nlapiGetFieldValue('custrecord_create_aliorder')
	nlapiLogExecution('DEBUG', 'ali_account', ali_account);
	nlapiLogExecution('DEBUG', 'Order_id', Order_id);
	var fromUI='T'
		if(create_order=='T')
	      {
			var ns_rec=getAliOrder(Order_id,ali_account,fromUI);
	         nlapiLogExecution('DEBUG', 'ns_rec', ns_rec);
	         if(ns_rec==0)
	        	 nlapiSubmitField(record, recordid, 'custrecord_create_aliorder', 'F') 
	        else
	        	nlapiSubmitField(record, recordid, 'custrecord_salesorder', ns_rec);
	       }
	}		

	catch(e){
		nlapiLogExecution('DEBUG', 'err', e);
		var rec=nlapiLoadRecord(record,recordid);
		rec.setFieldValue('custrecord_create_aliorder', 'F');
		nlapiSubmitRecord(rec);
//		throw nlapiCreateError('Alert', 'Salesorder not created\nError:'+e);
	}
}

}
function getAliOrder(Order_id,ali_account,fromUI,fromCsv) {
	if(fromUI=='T'){
	    
	    phone = nlapiGetFieldValue('custpage_new_phone');
	  }
	  nlapiLogExecution('DEBUG', 'phone 2', phone);
	var storefront=[];
    storefront[1]=41;//Deal Barn
    storefront[2]=49;//Globalsellinc
    storefront[3]=52;//Zake International Inc
    storefront[4]=53;//zhouwuinc
    var recordType='salesorder';
    var searchorder=searchRecordDup(Order_id,ali_account);
    nlapiLogExecution('DEBUG', 'searchorder', searchorder);
    if(searchorder==0)
    {
	var fields=['name','custrecord_warehouse_ali_so','custrecord_ali_token','custrecord_ali_client_id',
	            'custrecord_ali_secret_key','custrecord_ali_soform','custrecord_ali_acnt_subsidairy',
	            'custrecord_ali_acnt_currency','custrecord_storefront_ali'];
	var columns=nlapiLookupField('customrecord_aliexpress_accounts', ali_account, fields);
	var token=columns.custrecord_ali_token;
	var appkey=columns.custrecord_ali_client_id;
	var secretekey=columns.custrecord_ali_secret_key;
	var custom_form=columns.custrecord_ali_soform;
	var subsidiary=columns.custrecord_ali_acnt_subsidairy;
	var currency=columns.custrecord_ali_acnt_currency;
	var storefront_id=columns.custrecord_storefront_ali;
	var location=columns.custrecord_warehouse_ali_so;
	var ali_account_name=columns.name;
	nlapiLogExecution('DEBUG', 'custrecord_storefront_ali',storefront_id );
    var code_arr={ 'orderId':Order_id,
            'access_token':token};
    var arr=[];
    for(var x in code_arr){
    	arr.push(x+code_arr[x]);
    }
    arr.sort();
    var data=arr.join('');
    data='param2/1/aliexpress.open/api.findOrderById/'+appkey+data
    nlapiLogExecution('DEBUG', 'data', data);
    var sha1=hex_hmac_sha1(secretekey,data);
    sha1=sha1.toUpperCase();
    nlapiLogExecution('DEBUG', 'sha1', sha1);
	var url='http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.findOrderById/'+appkey+'?orderId='+Order_id+'&access_token='+token+'&_aop_signature='+sha1;
    nlapiLogExecution('DEBUG', 'url', url);

	var find_order=nlapiRequestURL(url);
	var order=find_order.getBody();
    nlapiLogExecution('DEBUG', 'order', order);
//    if(fromUI=='T')
//    nlapiSendEmail(1659, 'govind@webbee.biz', 'order json '+Order_id, order);
   
var get_order=JSON.parse(order);
if(get_order)
{
var memo=get_order.memo;
var zipcode=get_order.receiptAddress.zip;
var phone=get_order.receiptAddress.mobileNo;

var state=(get_order.receiptAddress.province);
var add1=GetValue(get_order.receiptAddress.detailAddress);
var add2=GetValue(get_order.receiptAddress.address2);
var countryCode=GetValue(get_order.receiptAddress.country);
var city=GetValue(get_order.receiptAddress.city);
var firstName=get_order.buyerInfo.firstName;
var lastName=get_order.buyerInfo.lastName;
var buyer_id=get_order.buyerloginid;
var buyerName=get_order.buyerSignerFullname;
var totalitems=get_order.childOrderList;
var total=parseFloat(get_order.orderAmount.amount);
var contact_person=get_order.receiptAddress.contactPerson;
var shipcost=get_order.logisticsAmount.amount;

//var state1=GetValue(state);
//state1=state1.split(' ');
var landline='';
var stateOrRegion=state;
nlapiLogExecution('DEBUG', 'memo', memo);
nlapiLogExecution('DEBUG', 'phone', phone);
if(!phone)
{
phone=get_order.receiptAddress.phoneCountry+'-'+get_order.receiptAddress.phoneArea+'-'+get_order.receiptAddress.phoneNumber;
landline=phone;
}
if(get_order.receiptAddress.phoneNumber)
	landline=get_order.receiptAddress.phoneCountry+'-'+get_order.receiptAddress.phoneArea+'-'+get_order.receiptAddress.phoneNumber;
nlapiLogExecution('DEBUG', 'phone', phone);
nlapiLogExecution('DEBUG', 'stateOrRegion', stateOrRegion);
nlapiLogExecution('DEBUG', 'stateOrRegion1', get_order.receiptAddress.province);

}
  if(fromUI=='T'){
    
    phone = nlapiGetFieldValue('custpage_new_phone');
  }
  nlapiLogExecution('DEBUG', 'phone 2', phone);

var customer_id= getcustomer(buyer_id,buyerName,firstName,lastName, phone,
		countryCode, stateOrRegion, city, add1,
		add2, zipcode,storefront_id, ali_account,subsidiary,currency,contact_person);
nlapiLogExecution('DEBUG', 'customer_id', customer_id);
if(fromCsv=='T'){
	recordType='invoice';
	custom_form='409';
}
var obj=nlapiCreateRecord(recordType, {recordmode : 'dynamic'});
obj.setFieldValue('customform', custom_form);
obj.setFieldValue('entity', customer_id)
obj.setFieldValue('otherrefnum', Order_id);
obj.setFieldValue('custbody_storefront_order', Order_id);
obj.setFieldValue('custbody_storefront_list',storefront_id);
obj.setFieldValue('custbody_marketplace', 1);
if(Order_id=='86399701585548'||Order_id=='86468072071782'||
   Order_id=='504020262322386'||Order_id=='504018743382225'){
	obj.setFieldValue('custbody_tracked', 'T');
}
obj.setFieldValue('custbody_ali_account', ali_account);
obj.setFieldValue('memo', 'created by AliExpress connector');
if(memo)
obj.setFieldValue('custbody_customer_memo', memo.slice(0,300));
obj.setFieldValue('custbody_taiwu_supplementstate', state);
obj.setFieldValue('custbody_taiwu_supplymentprovince', state);
if(landline!='')
obj.setFieldValue('custbody_taiwu_supplementaryphone', landline);
else
obj.setFieldValue('custbody_taiwu_supplementaryphone', phone);

var flag=0;
nlapiLogExecution('DEBUG', 'totalitems', totalitems.length);
var prefered_location1=[];
var logistic_types=[];
for(var i=0;i<totalitems.length;i++){
	var sku=totalitems[i].skuCode;
	var productId=totalitems[i].productId;
	var quantityOrdered=totalitems[i].productCount;
	var item_price=totalitems[i].productPrice.amount;
	var ali_product_id=totalitems[i].productId;
	if(sku=='17-2125_2'){
		sku='817-2125_2';
	}
	var itemid=searchListeditem(ali_account,sku);
	var logistictype=totalitems[i].logisticsType;
	nlapiLogExecution('DEBUG', 'logistictype', logistictype);
	logistic_types.push(logistictype);
	nlapiLogExecution('DEBUG', 'logistictype', logistictype);
	if(itemid==0)
		{
		itemid=SearchItem(sku);
		if(fromUI!='T')
		nlapiSendEmail(1659, 'govind@webbee.biz', 'Sku Notification | Aliexpress Listing', 'Item sku '+sku+' does not exist for AliExpress Order Id: '+Order_id+' | '+ali_account_name,'aj@webbeeglobal.com')
            if(itemid==0)
            	itemid=findIteminKit(sku);
		}
	nlapiLogExecution('DEBUG', 'itemid', itemid);
	
	if(itemid!=0){
	if(itemid[1]=='F'){
//		if(fromUI=='T')
//			itemid='104957';
		location=nlapiLookupField('item',itemid[0],'preferredlocation')
		if(!location)
			location=nlapiLookupField('item',itemid[0],'location');
		prefered_location1.push(location)
		nlapiLogExecution('DEBUG', 'sku', sku);
		nlapiLogExecution('DEBUG', 'itemid', itemid[0]);
		nlapiLogExecution('DEBUG', 'productId', productId);
		nlapiLogExecution('DEBUG', 'quantityOrdered', quantityOrdered);
		if(fromCsv=='T'){
			var bin='8244';
			var rec_ia=nlapiLoadRecord('inventoryadjustment','18089160',{recordmode:"dynamic"});
			var bin='8244';
			rec_ia.selectNewLineItem('inventory');
			rec_ia.setCurrentLineItemValue('inventory', 'item',itemid[0]);
			rec_ia.setCurrentLineItemValue('inventory', 'adjustqtyby', quantityOrdered);
			rec_ia.setCurrentLineItemValue('inventory', 'location', '34');
			var detail=rec_ia.createCurrentLineItemSubrecord('inventory', 'inventorydetail');
			detail.selectNewLineItem('inventoryassignment');
			detail.setCurrentLineItemValue('inventoryassignment', 'binnumber', bin);
			detail.setCurrentLineItemValue('inventoryassignment', 'quantity', quantityOrdered);
			detail.commitLineItem('inventoryassignment');
			detail.commit();
		    rec_ia.commitLineItem('inventory');
			var ia_id=	nlapiSubmitRecord(rec_ia);
			nlapiLogExecution('DEBUG', 'inventoryadjustment created',ia_id);
		obj.selectNewLineItem('item');
		obj.setCurrentLineItemValue('item', 'item', itemid[0]);
		obj.setCurrentLineItemValue('item', 'location', location);
		obj.setCurrentLineItemValue('item', 'rate', item_price);
		obj.setCurrentLineItemValue('item', 'quantity',quantityOrdered);
		obj.setCurrentLineItemValue('item','custcol_ali_item_id', ali_product_id.toString());
//		 var detail=obj.createCurrentLineItemSubrecord('item', 'inventorydetail');
//			detail.selectNewLineItem('inventoryassignment');
//			detail.setCurrentLineItemValue('inventoryassignment', 'binnumber', bin);
//			nlapiLogExecution('DEBUG', 'quantity2',quantityOrdered);
//			detail.setCurrentLineItemValue('inventoryassignment', 'quantity', quantityOrdered);
//			detail.commitLineItem('inventoryassignment');
//			detail.commit();
		obj.commitLineItem('item');
		flag++;
		}
		else{
			obj.selectNewLineItem('item');
			obj.setCurrentLineItemValue('item', 'item', itemid[0]);
			obj.setCurrentLineItemValue('item', 'location', location);
			obj.setCurrentLineItemValue('item', 'rate', item_price);
			obj.setCurrentLineItemValue('item', 'quantity',quantityOrdered);
			obj.setCurrentLineItemValue('item','custcol_ali_item_id', ali_product_id.toString());
			obj.commitLineItem('item');
			flag++;
		}
	}
	else{
		obj.setFieldValue('custbody_kitorder', 'T');
		var kititems=itemid[0];
		nlapiLogExecution('DEBUG', 'kititems', kititems);

		var split_item=[];
		split_item=kititems.split(';')
		var kitflag=0;
		for(var m=0;m<split_item.length;m++){
			var split_item1=[];
			split_item1=split_item[m].split('=');
			var kit_item=split_item1[0];
			var quantity=(parseInt(split_item1[1]))*quantityOrdered;
			if(quantity>1){
				item_price=(item_price/quantity)*quantityOrdered;
			}
			nlapiLogExecution('DEBUG', ' kit_item', kit_item);
			nlapiLogExecution('DEBUG', 'quantity', quantity);
	
			var filter = new Array();
			filter[0] = new nlobjSearchFilter('name', null, 'is', kit_item);
			var item = nlapiSearchRecord('inventoryitem', null, filter);
			if(item==null)
				{
				nlapiLogExecution('DEBUG', 'Item not found with name '+kit_item);

//				throw nlapiCreateError('Alert', 'Item not found with name '+kit_item);
				}
			else
			{
				var item_qty=quantity;
				kit_itemid=item[0].id;
				nlapiLogExecution('DEBUG', ' kit_itemid', kit_itemid);
				nlapiLogExecution('DEBUG', ' itemPrice', item_price);

				location=nlapiLookupField('item',kit_itemid,'preferredlocation');

				if(!location){
					location=nlapiLookupField('item',kit_itemid,'location');

				}
				prefered_location1.push(location);

				
				obj.selectNewLineItem('item');
				obj.selectNewLineItem('item');
				obj.setCurrentLineItemValue('item', 'item', kit_itemid);
			    obj.setCurrentLineItemValue('item', 'location', location);
			    obj.setCurrentLineItemValue('item', 'quantity',item_qty);
			    if(m==0)
			    obj.setCurrentLineItemValue('item', 'rate',item_price);
			    else
			    obj.setCurrentLineItemValue('item', 'rate','0');
				obj.setCurrentLineItemValue('item','custcol_ali_item_id', ali_product_id.toString());
				obj.commitLineItem('item');
				nlapiLogExecution('DEBUG', ' item enter ', itemid);
				kitflag++;
		}
		}
		if(kitflag==split_item.length)
			flag++;
	}
	
}
	else{

		if(fromUI!='T')
		{
			var search_miss=nlapiSearchRecord('customrecord2592', null, ["custrecord_aliorder_id","is",Order_id]);
			if(search_miss==null)
		{var missed_record = nlapiCreateRecord("customrecord2592");
		missed_record.setFieldValue('custrecord_aliorder_id',Order_id);
		missed_record.setFieldValue('custrecord_ali_act',ali_account);
		missed_record.setFieldValue('custrecord45', 'Item sku '+sku+' does not exist');
		nlapiSubmitRecord(missed_record);
	    }
			nlapiSendEmail(1659, 'govind@webbee.biz', 'Sku Notification | Aliexpress', 'Item sku '+sku+' does not exist for AliExpress Order Id: '+Order_id+' | '+ali_account_name,'aj@webbeeglobal.com')

		}
		else
			{
			nlapiLogExecution('DEBUG', 'Item sku '+sku+' does not exist');
			}
		
	}
	

	
}

nlapiLogExecution('DEBUG', 'flag', flag);
if(flag==totalitems.length){
	for(var g = 1; g < prefered_location1.length; g++)
    {
        if(prefered_location1[g] !== prefered_location1[0])
        	prefered_location1[0]= false;
    }
	if(prefered_location1[0]!=false)
	obj.setFieldValue('location', prefered_location1[0])
	var exchangerate = obj.getFieldValue('exchangerate');
           exchangerate = parseFloat(exchangerate);
           obj.setFieldValue('custbody_us_dollar_total', Math.round((exchangerate * total) / 6.6986));
   var  logistic_type=unique_values(logistic_types);
	nlapiLogExecution('DEBUG', 'logistic_type', logistic_type.toString());
   obj.setFieldValue('shipmethod', '66630');
   obj.setFieldValue('shippingcost', shipcost);
   
   obj.setFieldValue('custbody_zake_alilogistictype',logistic_type.toString());
	var rec=nlapiSubmitRecord(obj);
	nlapiLogExecution('DEBUG', 'rec', rec);
	return rec;

}
else{
	if(fromUI!='T'&&fromCsv!='T')
		{
		nlapiSendEmail(1659, 'govind@webbee.biz', 'Order not created  | Aliexpress', 'Item inserted in Netsuite not equal to item orderd for AliExpress Order Id: '+Order_id+' | '+ali_account_name,'aj@webbeeglobal.com')
		var search_miss=nlapiSearchRecord('customrecord2592', null, ["custrecord_aliorder_id","is",Order_id]);
		if(search_miss==null)
	      {
	var missed_record = nlapiCreateRecord("customrecord2592");
	missed_record.setFieldValue('custrecord_aliorder_id',Order_id);
	missed_record.setFieldValue('custrecord_ali_act',ali_account);
	missed_record.setFieldValue('custrecord45', 'Item inserted in Netsuite not equal to item orderd');
	nlapiSubmitRecord(missed_record);
    }
		}
	return 0;
}

}
	else{
		nlapiLogExecution('DEBUG', 'Skipping Duplicate Order '+Order_id)
		return searchorder;
	}
}


function searchRecordDup(value,ali_account){
	 var mrktplcid=1;
	var filters=[]; 
	  
	filters[0] = new nlobjSearchFilter('otherrefnum',null,'equalto',value);
	filters[1] = new nlobjSearchFilter('custbody_ali_account',null,'anyof',ali_account);
	filters[2] = new nlobjSearchFilter('custbody_marketplace',null,'is',mrktplcid);
	 var column=[];
	 column.push(new nlobjSearchColumn('otherrefnum'));	 
	 var searchResults = nlapiSearchRecord('transaction', null, filters, column);
	 if(searchResults != null && searchResults.length>=1){
		 var recid=searchResults[0].getId();
		 var b=searchResults.length;
		 var rec_po_no=searchResults[0].getValue('otherrefnum');

		 
		 return recid;		
	}
	 else{
		 return 0;
	 }
}
function SearchItem(sku){
	nlapiLogExecution('DEBUG', 'seller_sku', sku);
	var ary=[];
	ary=sku.replace("@","|").split("|");
	nlapiLogExecution('DEBUG', 'ary', ary);
	sku=ary[0];
	nlapiLogExecution('DEBUG', 'seller_sku_taiwu', sku);
	var search_result1 = nlapiSearchRecord('item',null,  [ [ "name", "is", sku ], "OR", [ "custitem_sku_alias", "is", sku ], "OR", [ "itemid", "is", sku ],"OR", [ "externalid", "is", sku ], "OR", [ "custitem_legacy_tong_sku", "is", sku ] ]);

	if (search_result1 != null) {
		  nlapiLogExecution('DEBUG', 'search_result1', search_result1.length);

		if(search_result1.length==1)
		var item_id = search_result1[0].getId();
		else
			var item_id = search_result1[(search_result1.length)-1].getId();
		var itemtype=nlapiLookupField('item', item_id, 'recordtype')
		nlapiLogExecution('DEBUG', 'itemtype', itemtype);
		if(itemtype=='kititem'||itemtype=='noninventoryitem'){          //added 5th June - Govind
			return 0;
		}	
		else{
			return [item_id,'F'];
		}
			
	} else {
		return 0;
	}
}
function searchListeditem(account,sku){
	nlapiLogExecution('DEBUG', 'search in listing');
	var column=[];
	column.push(new nlobjSearchColumn('custrecord_iskit_ali'));
	column.push(new nlobjSearchColumn('custrecord_ali_kit'));
	column.push(new nlobjSearchColumn('custrecord_aliexp_item'));
	var filters=[];
    filters.push(new nlobjSearchFilter('custrecord_aliexp_account', null, 'anyof',account));
    filters.push(new nlobjSearchFilter('isinactive', null, 'is','F'));
    filters.push(nlobjSearchFilter('custrecord_ali_sku', null, 'is',sku));
	var search=nlapiSearchRecord('customrecord_aliexpress_listing', null,filters, column);
	if(search!=null){
		nlapiLogExecution('DEBUG', 'search', search.length);
		nlapiLogExecution('DEBUG', 'searchid', search[0].getId());
		var itemnsid=search[0].getValue('custrecord_aliexp_item');
		var iskit=search[0].getValue('custrecord_iskit_ali');
		var kit=search[0].getValue('custrecord_ali_kit');
		if(iskit=='T'){
			itemnsid=nlapiLookupField('customrecord_kit', kit, 'custrecord_kit_mapping')
		}
		return [itemnsid,iskit];
	}
	else
		return 0;
}
function  findIteminKit(seller_sku){
	var sku=seller_sku;
	var ary=[];
	ary=seller_sku.replace("@","|").split("|");
	nlapiLogExecution('DEBUG', 'ary', ary);
	seller_sku=ary[0];
var columns=new nlobjSearchColumn('custrecord_kit_mapping')
var search=nlapiSearchRecord('customrecord_kit', null, [ ['custrecord_sku_alias','is',seller_sku],"OR",['custrecord_kit_sku','is',seller_sku]], columns);
if(search!=null){
	var kitid=search[0].getId();
	var items=search[0].getValue('custrecord_kit_mapping');

	return [items,'T'];
}
else{
	return 0;
}
}
function getcustomer(buyer_id,buyerName,firstName,lastName, phone,
		countryCode, stateOrRegion, city, add1,
		add2, zipcode,storefront_id, ali_account,subsidiary,currency,contact_person){
	if(!contact_person)
		contact_person=buyerName;
	if(!add1)
		add1='';
	if(!add2)
		add2='';
	var cust_name=firstName.trim()+' '+lastName;
//	if(lastName.length>0){
//		lastName=lastName.trim();
//	}
//    if(!lastName){
//    	lastName='<>'
//    }
	cust_name=cust_name.trim();
	var split = [];
	split = cust_name.split(' ');
	nlapiLogExecution('DEBUG', 'lastName', lastName);
	if(countryCode=='UK')
		countryCode='GB';
	else if(countryCode=='SRB')
		  countryCode='RS';
	else if(countryCode=='MNE')
		  countryCode='ME';
	else if(countryCode=='ZR')
		  countryCode='CD';
	else if(countryCode=='KS')
		  countryCode='XK';
	var internal_id;
	var filters = new Array();
	filters[0] = new nlobjSearchFilter('custentity_aliexp_buyerid', null, 'is', buyer_id);
	filters[1] = new nlobjSearchFilter('custentity_storefront', null, 'is', storefront_id);

	var columns = new Array();
	columns[0] = new nlobjSearchColumn('internalid');
	columns[1] = new nlobjSearchColumn('addressee');
	columns[2] = new nlobjSearchColumn('zipcode');
	var searchResults = nlapiSearchRecord('customer', null, filters, columns);
	if (searchResults == null) {
		var obj = nlapiCreateRecord('customer', {
			recordmode : 'dynamic'
		});
		obj.setFieldValue('isperson', 'T');
		obj.setFieldValue('custentity_storefront', storefront_id);
		if (split.length == 1) {
			if (split[0] == ''){
				split[0] = 'NotAvailable'
			}
			obj.setFieldValue('firstname', split[0]);
			obj.setFieldValue('lastname', "<>");
		  }
		else if (split.length == 2){
            if(split[1]=='null'){
	             split[1]='Null';
                  }
			obj.setFieldValue('lastname', split[1].slice(0,32));
			obj.setFieldValue('firstname', split[0]);
		} 
		else if (split.length > 2&&(split.length <= 4)) {
			nlapiLogExecution('DEBUG', 'firstname', split[0]);
			nlapiLogExecution('DEBUG', 'middlename', split[1]);
			nlapiLogExecution('DEBUG', 'lastname', split.slice(2,(split.length)).join(' '));
			obj.setFieldValue('lastname', split.slice(2, (split.length)).join(' '));
			obj.setFieldValue('middlename', split[1]);
			obj.setFieldValue('firstname', split[0]); 
		}
		else if (split.length > 4) {
		     obj.setFieldValue('lastname', split.slice((split.length-3),(split.length)).join(' '));
			 obj.setFieldValue('middlename', split.slice(1,(split.length-3)).join(' '));
			 obj.setFieldValue('firstname', split[0]);
			}
		var random = Math.floor(Math.random() * (9000 - 1000 + 1)) + 1000;

		obj.setFieldValue('entityid', buyerName + " online " + random);
		obj.setFieldValue('subsidiary', subsidiary);
		obj.setFieldValue('custentity_aliexp_buyerid', buyer_id);
		obj.setFieldValue('currency', currency); 	
		if(phone)
		{
			nlapiLogExecution('DEBUG', 'Aphone', phone.length);
		if (phone.match(/[^0]/) && (phone.length >= 0)) {
			obj.setFieldValue('phone', phone.slice(0,22));
		}
	
		}
		// Add first line to sublist
		if (countryCode) {
			obj.selectNewLineItem('addressbook');
			obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
			obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T'); 
			obj.setCurrentLineItemValue('addressbook', 'label', add1.slice(0,150)); 
			var subrecord = obj.createCurrentLineItemSubrecord('addressbook',
					'addressbookaddress');
			subrecord.setFieldValue('country', countryCode); 
			subrecord.setFieldValue('addressee', contact_person);
			if(phone){if (phone.match(/[^0]/) && (phone.length >= 0)) {
				subrecord.setFieldValue('addrphone', phone);
			}}
			subrecord.setFieldValue('addr1', add1.slice(0,150));
			if(add2)
			subrecord.setFieldValue('addr2', add2);
			subrecord.setFieldValue('city', city.slice(0,50));
			subrecord.setFieldValue('state', stateOrRegion.slice(0,30));
			subrecord.setFieldValue('zip', zipcode);
			subrecord.commit();
			obj.commitLineItem('addressbook');
		}
		var internal_id = nlapiSubmitRecord(obj);

		return internal_id;
		// nlapiLogExecution('DEBUG','New Customer Created',internal_id);
	} else {
		
		nlapiLogExecution('DEBUG', 'Existing Customer');
		internal_id = searchResults[0].getValue(columns[0]);
		var obj=nlapiLoadRecord('customer',internal_id,{recordmode : 'dynamic'});
		var flag=0;
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG', 'lines',lines);

		obj.setFieldValue('currency', currency); 
		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addressee=obj.getLineItemValue('addressbook','addressee', z);
			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addressee',cust_addressee);

			if(cust_zipcode==zipcode&&cust_addressee==contact_person){
				obj.selectLineItem('addressbook', z);
				obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
				obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
				obj.commitLineItem('addressbook');
				flag++;
			}
		}
		nlapiLogExecution('DEBUG', 'flag',flag);

		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addressee );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
		obj.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
		obj.setCurrentLineItemValue('addressbook', 'label', add1.slice(0,150));
		  var subrecord = obj.createCurrentLineItemSubrecord('addressbook', 'addressbookaddress');

		    //set subrecord fields
		    subrecord.setFieldValue('country', countryCode); //Country must be set before setting the other address fields
		    subrecord.setFieldValue('addressee',contact_person);
		    if(phone){
			if(phone.match(/[^0]/)&&(phone.length>=0)){
			    subrecord.setFieldValue('addrphone', phone);
				}
		    }
		    subrecord.setFieldValue('addr1', add1.slice(0,150));
		    if(add2)
		    subrecord.setFieldValue('addr2', add2);
		    subrecord.setFieldValue('city', city.slice(0,50));
		    subrecord.setFieldValue('state', stateOrRegion.slice(0,30));
		    subrecord.setFieldValue('zip', zipcode);
			subrecord.commit();	
			obj.commitLineItem('addressbook');
			
		}
		var internal_id = nlapiSubmitRecord(obj, true);
			return internal_id;
	}

	
}

function unique_values(a) {
	var r = new Array();
	o: for (var i = 0, n = a.length; i < n; i++) {
		for (var x = 0, y = r.length; x < y; x++) {
			if (r[x] == a[i]) {
				continue o;
			}
		}
		r[r.length] = a[i];
	}
	return r;
}
function GetValue(value){
	if(!value){
		value='';
	}
//	else{
//		var b=[];
//		b=value.split(',');
//		value=b[0];
//	}
	return value;
}