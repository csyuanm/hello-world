/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       25 Nov 2016     Admin
 *
 */

/**
 * @param {Object} dataIn Parameter object
 * @returns {Object} Output object
 */
function Create_Ali_listing() {
	try{
	var obj=nlapiGetContext();
	var products=obj.getSetting('SCRIPT', 'custscript_aliproducts_ids');

	var ali_act_id=obj.getSetting('SCRIPT', 'custscript_ali_act_id');
     var productIds=[];
     if(products)
    	 productIds= products.split(',');
		var fields = [ 'custrecord_createdatestart', 'custrecord_ali_token',
		   			'custrecord_ali_client_id', 'custrecord_ali_secret_key','name' ];
		   	var columns = nlapiLookupField('customrecord_aliexpress_accounts',ali_act_id, fields);
		   	var actname=columns.name;
		   	var token = columns.custrecord_ali_token;
		   	var appkey = columns.custrecord_ali_client_id;
		   	var secretekey = columns.custrecord_ali_secret_key;	
		   	nlapiLogExecution('DEBUG', 'productIds.length', productIds.length);
		   	var k=0;
		   	var t=0;
		   	var notlisted=[];
		   	table='ProductId,SkuCode,SkuId,NSID,Remark,\n'
		 for(var j=0;j<productIds.length;j++){
			 CheckGovernance();
			 var productid=productIds[j]
			 nlapiLogExecution('DEBUG', 'productid', productid);
		   	var code_arr = {
		   			'productId' : productid,
		   			'access_token':token
		   		};
		   	var arr = [];
			for ( var x in code_arr) {
				arr.push(x + code_arr[x]);
			}
			arr.sort();
			var data = arr.join('');
			data = 'param2/1/aliexpress.open/api.findAeProductById/' + appkey
					+ data;
			var sha1 = hex_hmac_sha1(secretekey, data);
			sha1 = sha1.toUpperCase();
			var url ='http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.findAeProductById/'
				+ appkey
				+'?productId='+productid
				+'&access_token='+token+'&_aop_signature='+sha1;
//			nlapiLogExecution('DEBUG', 'url', url);

			var find_product = nlapiRequestURL(url);
			var product = find_product.getBody();
//			nlapiLogExecution('DEBUG', 'product', product);
			if(product)
			{
				product = JSON.parse(product);
				var variants=product.aeopAeProductSKUs;
				if(variants){
				for(var i=0;i<variants.length;i++){
					var sku=variants[i].skuCode;
					var skuId=variants[i].id;
					var qty=variants[i].ipmSkuStock;
					nlapiLogExecution('DEBUG', 'sku', sku);
//					nlapiLogExecution('DEBUG', 'skuId', skuId);
					var search_result2 = nlapiSearchRecord('item',null,  [ [ "name", "is", sku ], "OR", [ "custitem_sku_alias", "is", sku ] ]);
                    if(search_result2!=null)
    		       {     t++;
                    	nlapiLogExecution('DEBUG', 'itemid', search_result2[0].id);
                   var new_listingId=createlisting(search_result2[0].id,ali_act_id,sku,skuId,productid,qty)
                   if(new_listingId[0]!=0)
                   table+=productid+','+sku+','+skuId+','+new_listingId[0]+','+new_listingId[1]+',\n'
                   else{
                	   notlisted.push[productid];
                	table+=productid+','+sku+','+skuId+',Not Created,'+new_listingId[1]+',\n'
                   }
    	    	    }
                    else{
                    	table+=productid+','+sku+','+skuId+',Not Created,Item Sku not found,\n'
                    	nlapiLogExecution('DEBUG', 'item not found');
                    	notlisted.push[productid];
                    	
                    }
				k++;
				}
				}
				
			}

	
	
}
		 var file=nlapiCreateFile(actname+'_listing.csv', 'CSV', table);
		 nlapiSendEmail(1659, 'govind@webbee.biz', 'Aliexpress Listing | '+actname, 'File Attached',null, null, null, file);
		 nlapiLogExecution('DEBUG', 'total items : '+k+' Found in NS : '+t)
		 notlisted=checkDuplicates(notlisted);
		 nlapiLogExecution('DEBUG', 'notlisted', notlisted.toString());
		 obj.setSetting('SCRIPT', 'custscript_aliproducts_ids', notlisted.toString());
}
	catch(e){
	nlapiLogExecution('DEBUG', 'err', e);
}
}
function createlisting(itemInternalId,ali_act_id,sku,skuId,productId,qty)
{
	try{
		var filters=[];
		filters.push(new nlobjSearchFilter("custrecord_aliexp_account", null, "anyof",ali_act_id))
		filters.push(new nlobjSearchFilter("custrecord_ali_productid", null, "is",productId))
		filters.push(new nlobjSearchFilter("custrecord_ali_sku", null, "is",sku))
		var searchlistng=nlapiSearchRecord('customrecord_aliexpress_listing', null,filters);
if(searchlistng==null)	
	{
var record = nlapiCreateRecord("customrecord_aliexpress_listing");
	record.setFieldValue('custrecord_aliexp_item', itemInternalId);
	record.setFieldValue('custrecord_aliexp_account',ali_act_id);
	record.setFieldValue('custrecord_ali_sku', sku);
	record.setFieldValue('custrecord_ali_skuid', skuId);
	record.setFieldValue('custrecord_ali_productid',productId);
	record.setFieldValue('custrecord_present_qty',qty);
	var success = nlapiSubmitRecord(record,null,true);
	nlapiLogExecution('DEBUG', 'new listing',success);
	return [success,"NewListing"];
	}
else{
	nlapiSubmitField('customrecord_aliexpress_listing', searchlistng[0].id, 'custrecord_ali_skuid', skuId);
	nlapiSubmitField('customrecord_aliexpress_listing', searchlistng[0].id, 'custrecord_present_qty', qty)
	return [searchlistng[0].id,"Existed"];
}
}
catch(e){
	return [0,e];
}
}
function checkDuplicates(a) {
	var r = new Array();
	o: for (var i = 0, n = a.length; i < n; i++) {
		for (var x = 0, y = r.length; x < y; x++) {
			if (r[x] == a[i]) {
				continue o;
			}
		}
		r[r.length] = a[i];
	}
	return r;
}
function CheckGovernance() {
	var mymail='govind@webbee.biz';
	var mail_cc='aj@webbeeglobal.com';
    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
    	
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
	 	nlapiSendEmail(1659,'aj@webbeeglobal.com', 'Err: in CheckGovernance() ',ex);

    }
}