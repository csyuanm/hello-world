/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       16 Sep 2016     Admin
 *
 */

/**
 * @param {String}
 *            type Context Types: scheduled, ondemand, userinterface, aborted,
 *            skipped
 * @returns {Void}
 */
function getOrders(type) {
	var obj = nlapiGetContext();
	var ali_account_id = obj.getSetting('SCRIPT', 'custscript_aliaccount_nsid');
	var access_token=generateToken(ali_account_id);
	if(access_token==0)
		return;
	var fields = [ 'custrecord_createdatestart', 'custrecord_ali_token',
			'custrecord_ali_client_id', 'custrecord_ali_secret_key','name' ];
	var columns = nlapiLookupField('customrecord_aliexpress_accounts',
			ali_account_id, fields);
	var actname=columns.name;
	var token = columns.custrecord_ali_token;
	var appkey = columns.custrecord_ali_client_id;
	var secretekey = columns.custrecord_ali_secret_key;
	var last_import_date = columns.custrecord_createdatestart;
	var today = new Date();
	today .setMilliseconds((today.getMilliseconds()-86400000));
	today = today.toISOString();
	var date = [];
	date = today.split('.');
	date = date[0];
	date = date.split('T');
	var time = date[1];
	date = date[0];
	date = date.split('-')
	var current_date = date[1] + '/' + date[2] + '/' + date[0] + ' ' + time;
	nlapiLogExecution('DEBUG', 'current_date', current_date);
	if (last_import_date == '') {
		var since_date = new Date();
		 since_date .setMilliseconds((since_date .getMilliseconds()-4000000000));
		since_date = since_date.toISOString();
		 date = [];
		date = since_date.split('.')
		date = date[0];
		date = date.split('T');
	    time = date[1];
		date = date[0];
		date = date.split('-')
		last_import_date = date[1] + '/' + date[2] + '/' + date[0] + ' ' + time;
	}
	nlapiLogExecution('DEBUG', 'last_import_date', last_import_date);
	var page = 1;
	var flag=1;
	while(flag>0){
	var code_arr = {
		'page' : page,
		'pageSize' : '50',
//		'createDateStart' : last_import_date,
		'orderStatus' : 'WAIT_SELLER_SEND_GOODS',
		 'access_token':token
	};
	var arr = [];
	for ( var x in code_arr) {
		arr.push(x + code_arr[x]);
	}
	arr.sort();
	var data = arr.join('');
	data = 'param2/1/aliexpress.open/api.findOrderListSimpleQuery/' + appkey
			+ data;
//	nlapiLogExecution('DEBUG', 'data', data);
	var sha1 = hex_hmac_sha1(secretekey, data);
	sha1 = sha1.toUpperCase();
//	nlapiLogExecution('DEBUG', 'sha1', sha1);
//	var url ='http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.findOrderListSimpleQuery/'
//			+ appkey
//			+ '?&page='
//			+ page
//			+ '&pageSize=50&createDateStart='
//			+ encodeURIComponent(last_import_date)
//			+ '&orderStatus=WAIT_SELLER_SEND_GOODS&access_token='
//			+token+'&_aop_signature=' + sha1;
	var url ='http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.findOrderListSimpleQuery/'
		+ appkey
		+ '?&page='
		+ page
		+ '&pageSize=50&orderStatus=WAIT_SELLER_SEND_GOODS&access_token='
		+token+'&_aop_signature=' + sha1;
	nlapiLogExecution('DEBUG', 'url', url);

	var find_orders = nlapiRequestURL(url);
	var orders = find_orders.getBody();
	nlapiLogExecution('DEBUG', 'order', orders);
	if(orders)
	{
		var get_order = JSON.parse(orders);
		var totalorders=get_order.totalItem;
		nlapiLogExecution('DEBUG', 'totalorders', parseInt(totalorders));
		if(parseInt(totalorders)>=0){
			var totalorder_page=get_order.orderList;
		if(totalorder_page)
		{  
			totalorders=totalorder_page.length;
			page+=1;
		
		}
		else{
			totalorders=0;
			flag=0;
		}
		nlapiLogExecution('DEBUG', 'page', page);
		nlapiLogExecution('DEBUG', 'totalorders', totalorders);
		
			 nlapiSubmitField('customrecord_aliexpress_accounts', ali_account_id, 'custrecord_createdatestart',current_date);
			for(var i=0;i<totalorders;i++){
				try{
				var ali_order_id=get_order.orderList[i].orderId;
				ali_order_id=ali_order_id.toString();
				nlapiLogExecution('DEBUG', 'ali_order_id', ali_order_id);
				var rec=getAliOrder(ali_order_id,ali_account_id);
				CheckGovernance();
				
				}
				catch(err){
					var search_miss=nlapiSearchRecord('customrecord2592', null, ["custrecord_aliorder_id","is",ali_order_id]);
					if(search_miss==null){
					var missed_record = nlapiCreateRecord("customrecord2592");
					missed_record.setFieldValue('custrecord_aliorder_id',ali_order_id);
					missed_record.setFieldValue('custrecord_ali_act',ali_account_id);
					missed_record.setFieldValue('custrecord45',err);
					nlapiSubmitRecord(missed_record);
				}
				
				 	nlapiSendEmail(1659,'govind@webbee.biz', 'Err: in Ali order import of order id '+ali_order_id+' | '+actname,err,'aj@webbeeglobal.com');

				}
			}
			
		}
	}
}
	
}

function CheckGovernance() {
	var mail_cc='aj@webbeeglobal.com';
    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
    	
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
	 	nlapiSendEmail(1659,'aj@webbeeglobal.com', 'Err: in CheckGovernance() ',ex);

    }
}
