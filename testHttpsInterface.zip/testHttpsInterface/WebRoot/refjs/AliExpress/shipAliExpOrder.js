/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       16 Sep 2016     Admin
 *
 */

/**
 * @param {String}
 *            type Context Types: scheduled, ondemand, userinterface, aborted,
 *            skipped
 * @returns {Void}
 */
function ShipAliExpOrder(type) {
	 var filter=[];
	   filter.push(new nlobjSearchFilter('custrecord_automate_shipping_ali', null,'is','T'));

	var search_result = nlapiSearchRecord('customrecord_aliexpress_accounts', null,
			filter, null);
	for ( var k = 0; k< search_result.length; k++) {
		var ali_account_id=search_result[k].getId();
		var fields = [ 'custrecord_createdatestart', 'custrecord_ali_token',
		   			'custrecord_ali_client_id', 'custrecord_ali_secret_key' ];
		nlapiLogExecution('DEBUG', 'ali_account_id', ali_account_id);
		   	var column = nlapiLookupField('customrecord_aliexpress_accounts',
		   			ali_account_id, fields);
		   	var token = column.custrecord_ali_token;
		   	var appkey = column.custrecord_ali_client_id;
		   	var secretekey = column.custrecord_ali_secret_key;
	var search = nlapiLoadSearch('transaction', 'customsearch_ship_orders_2');
	search.addFilter(new nlobjSearchFilter('custbody_ali_account',null,'anyof',ali_account_id));

	var columns = search.getColumns();
	var resultSet = search.runSearch();
	var results = resultSet.getResults(0, 1000);
	nlapiLogExecution('DEBUG', 'results.length', results.length);
var shipped='';
var unshipped='';
	if (results.length > 0) {
		for (var i = 0; i <results.length; i++) {
			try{
			CheckGovernance();
			var order_id = results[i].getValue(columns[11]);
			var tracking_number = results[i].getValue(columns[4]);
			var tracking_provider = results[i].getValue(columns[5]);
			var id = results[i].getValue(columns[9]);
			var carrier=results[i].getValue(columns[12]);
			nlapiLogExecution('DEBUG', 'id', id);
			if(carrier!=7)
			{
			var code_arr = {
				'serviceName' : tracking_provider,
				'logisticsNo' : tracking_number,
				'sendType' : 'all',
				'outRef':order_id,
				'access_token' : token
			};
			var arr = [];
			for ( var x in code_arr) {
				arr.push(x + code_arr[x]);
			}
			arr.sort();
			var data = arr.join('');
			data = 'param2/1/aliexpress.open/api.sellerShipment/' + appkey
					+ data;
//			nlapiLogExecution('DEBUG', 'data', data);
			var sha1 = hex_hmac_sha1(secretekey, data);
			sha1 = sha1.toUpperCase();
			var url = 'http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.sellerShipment/'+appkey+'?serviceName='
					+ tracking_provider
					+ '&logisticsNo='
					+ tracking_number
					+ '&sendType=all&outRef='
					+ order_id
					+ '&access_token='
					+ token + '&_aop_signature=' + sha1;
			nlapiLogExecution('DEBUG', 'url responce', url);
			var ship_order = nlapiRequestURL(url);
			nlapiLogExecution('DEBUG', 'url responce', ship_order.getBody());
			var status=(JSON.parse(ship_order.getBody())).success;
			nlapiLogExecution('DEBUG', 'status', status);
			if (status==true) 
				{
				shipped+=order_id+',';
				nlapiLogExecution('DEBUG', 'status', status);
				nlapiSubmitField('salesorder', id, 'custbody_tracked', 'T');
				}
			else
				{
				var errorCode=(JSON.parse(ship_order.getBody())).error_code;
				nlapiLogExecution('DEBUG', 'errorCode', errorCode);
				unshipped+=order_id+',';
				if(errorCode!='401')
				nlapiSubmitField('salesorder', id, 'custbody_tracked', 'T');
				nlapiSendEmail(1659, 'govind@webbee.biz', 'Order Not Shipped | AliExpress', 'AliExpress Order Id : '+order_id+'\n'+ship_order.getBody(), 'aj@webbeeglobal.com') ;
				}

			
		}}
			catch(e){
				nlapiSendEmail(1659, 'govind@webbee.biz', 'Error | AliExpress Tracking', 'AliExpress Order Id : '+order_id+'\n'+e, 'aj@webbeeglobal.com') ;
			}}

	}
	nlapiLogExecution('DEBUG', 'shipped', shipped);
	nlapiLogExecution('DEBUG', 'unshipped', unshipped);
	}
}
function CheckGovernance() {
	var mymail='govind@webbee.biz';
	var mail_cc='aj@webbeeglobal.com';
    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
    	
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
	 	nlapiSendEmail(1659,'aj@webbeeglobal.com', 'Err: in CheckGovernance() ',ex);

    }
}
