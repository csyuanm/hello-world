/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Sep 2016     Admin
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function generateToken(value) {
	var headers=new Array();
	headers['Content-Type'] = "application/json";
	var post='{}';
	var filters=[];
	filters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
	if(value)
	filters.push(new nlobjSearchFilter('internalid', null, 'is', value));
	var columns=[];
	columns.push(new nlobjSearchColumn('custrecord_ali_client_id'));
	columns.push(new nlobjSearchColumn('name'));
	columns.push(new nlobjSearchColumn('custrecord_ali_secret_key'));
	columns.push(new nlobjSearchColumn('custrecord_ali_refresh_token'));
	var search=nlapiSearchRecord('customrecord_aliexpress_accounts', null, filters, columns);
	if(search!=null){
		nlapiLogExecution('DEBUG', 'search.length', search.length)
		for(var i=0;i<search.length;i++){
			var act_name=search[i].getValue('name');
			var client_id=search[i].getValue('custrecord_ali_client_id');
			var secret_key=search[i].getValue('custrecord_ali_secret_key');
			var refresh_token=search[i].getValue('custrecord_ali_refresh_token');
			var ali_account_id=search[i].getId();
			var url='https://gw.api.alibaba.com/openapi/http/1/system.oauth2/getToken/'+client_id+'?grant_type=refresh_token&client_id='+client_id+'&client_secret='+secret_key+'&refresh_token='+refresh_token;
			nlapiLogExecution('DEBUG', 'ali_account_id', ali_account_id)
			nlapiLogExecution('DEBUG', 'url', url)

			var gettoken=nlapiRequestURL(url, post, headers);
		    nlapiLogExecution('DEBUG', 'gettoken', gettoken.getBody())
		    var data_json=JSON.parse(gettoken.getBody());
		    if(data_json)
		    {var token=data_json.access_token;
		    if(token){
		    	nlapiSubmitField('customrecord_aliexpress_accounts',ali_account_id,'custrecord_ali_token',token);
		    return 1;
		    }
		    else{
		    	nlapiSendEmail(1659, 'govind@webbee.biz', 'Issue | Aliexpress Token | '+act_name, gettoken.getBody(), 'aj@webbeeglobal.com');
		    return 0;
		    }
		}}
		
	}

}
function getToken(dataIn){
	if(dataIn.id){
var token =nlapiLookupField('customrecord_aliexpress_accounts',dataIn.id, 'custrecord_ali_token')
return{Token:token}
	}
	else{
		return{error:"enter account id"}
	}
}