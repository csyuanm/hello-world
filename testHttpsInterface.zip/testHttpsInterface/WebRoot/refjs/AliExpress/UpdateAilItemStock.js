/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       16 Sep 2016     Admin
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function update_itemStock(type) {
	
	var obj = nlapiGetContext();
	var ali_account_id = obj.getSetting('SCRIPT', 'custscript_aliaccount_id');
	var fields = [ 'custrecord_createdatestart', 'custrecord_ali_token',
			'custrecord_ali_client_id', 'custrecord_ali_secret_key','name' ];
	var columns = nlapiLookupField('customrecord_aliexpress_accounts',
			ali_account_id, fields);
	var actname=columns.name;
	var token = columns.custrecord_ali_token;
	var appkey = columns.custrecord_ali_client_id;
	var secretekey = columns.custrecord_ali_secret_key;
	var searchlistng=getActiveAllListings(ali_account_id)
	nlapiLogExecution('DEBUG', 'searchlistng', JSON.stringify(searchlistng));
   for(var j in searchlistng)
   {
   var productId=j;
   var skus=searchlistng[j];
//   nlapiLogExecution('DEBUG', 'skus.length', skus.length);
	for(i=0;i<skus.length;i++)
	{
	var skuId_obj=skus[i];
	for(t in skuId_obj){
		skuId=t;
	var stock=skuId_obj[t];
	var code_arr = {
			'productId' : productId,
			'skuId' : skuId,
			'ipmSkuStock' : stock,
			 'access_token':token
		};
	var arr = [];
	for ( var x in code_arr) {
		arr.push(x + code_arr[x]);
	}
	arr.sort();
	var data = arr.join('');
//	nlapiLogExecution('DEBUG', 'data', data);
	data='param2/1/aliexpress.open/api.editSingleSkuStock/'+appkey+data
//	nlapiLogExecution('DEBUG', 'data', data);
    var sha1=hex_hmac_sha1(secretekey,data);
    sha1=sha1.toUpperCase();
//    nlapiLogExecution('DEBUG', 'sha1', sha1);	
	var url='http://gw.api.alibaba.com:80/openapi/param2/1/aliexpress.open/api.editSingleSkuStock/'+appkey+'?productId='+productId+'&skuId='+encodeURIComponent(skuId)+'&ipmSkuStock='+stock+'&access_token='+token+'&_aop_signature='+sha1
    nlapiLogExecution('DEBUG', 'url', url);

	var update_stock=nlapiRequestURL(url);
	var responce=update_stock.getBody();
    nlapiLogExecution('DEBUG', 'responce', responce);
	}}}
}
function getActiveAllListings(ali_account_id){
	var satrtIndex=0;
	var endIndex=1000;
	var column = [];
	column.push(new nlobjSearchColumn('custrecord_ali_productid'));
	column.push(new nlobjSearchColumn('custrecord_ali_skuid'));
	column.push(new nlobjSearchColumn('custrecord_present_qty'));
	column.push(new nlobjSearchColumn('custrecord_aliexp_item'));
	var filter = [];
	filter.push(new nlobjSearchFilter('custrecord_aliexp_account',null, 'is', ali_account_id));
	filter.push(new nlobjSearchFilter('isinactive',null, 'is', 'F'));
	var search_result1 = nlapiCreateSearch('customrecord_aliexpress_listing', filter, column);
	var resultSet = search_result1.runSearch();
	var results = resultSet.getResults(satrtIndex, endIndex);
	if (results.length > 0) {
		var j=0;
		var items={};
		while (results != null && j < results.length) {
			CheckGovernance();
			var listing_id=results[j].id;
			var productid=results[j].getValue('custrecord_ali_productid');
			var skuId = results[j].getValue('custrecord_ali_skuid');
			var present_qty=results[j].getValue('custrecord_present_qty');
			var item_id=results[j].getValue('custrecord_aliexp_item');
			var warehouse=nlapiLookupField('item', item_id, 'preferredlocation', true);
			if(!warehouse)
				warehouse=nlapiLookupField('item', item_id, 'location', true);
//			nlapiLogExecution('DEBUG', 'sku', skuId);
//			nlapiLogExecution('DEBUG', 'item_id', item_id);
			if(warehouse)
			{
//				nlapiLogExecution('DEBUG', 'warehouse', warehouse);
				var Column=[];
				Column.push(new nlobjSearchColumn('formulanumeric',null,'max').setFormula("DECODE({inventorylocation.name},'"+warehouse+"',{locationquantityavailable})")); 
			    var Filters=[];
				Filters.push(new nlobjSearchFilter('internalid',null,'is',item_id));
				var searchitem=nlapiSearchRecord('item',null,Filters,Column);			                                                         var id=searchitem[0].getValue(Column[0]);
			    var ns_quantity = searchitem[0].getValue(Column[0]);
//				  nlapiLogExecution('DEBUG', 'ns_quantity', ns_quantity);
				if(ns_quantity>0)
					ns_quantity=parseInt(ns_quantity)
					else
						ns_quantity=0;
				if(present_qty!=ns_quantity)
					{
					nlapiSubmitField('customrecord_aliexpress_listing', listing_id, 'custrecord_present_qty',ns_quantity)
				    var sku2={};
			        sku2[skuId]=parseInt(ns_quantity);
			        if(!items[productid])
				      {
			           items[productid]=[];
			           items[productid].push(sku2);
				      }
			       else
				       items[productid].push(sku2);
			        }
			}
			j++;
			if(j==results.length){
				satrtIndex+=1000;
				endIndex+=1000;
				 results = resultSet.getResults(satrtIndex,endIndex);
				 j=0;
			}
		}
	}
	
	return items;
}
function CheckGovernance() {
	var mymail='govind@webbee.biz';
	var mail_cc='aj@webbeeglobal.com';
    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
    	
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);
	 	nlapiSendEmail(1659,'aj@webbeeglobal.com', 'Err: in CheckGovernance() ',ex);

    }
}