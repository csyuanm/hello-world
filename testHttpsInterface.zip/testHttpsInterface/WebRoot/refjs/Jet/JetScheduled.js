/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Apr 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 
 *
 *
 *{
  "alt_order_id": "025348699398",
  "buyer": {
    "name": "Snowball",
    "phone_number": "212-212-7167"
  },
  "customer_reference_order_id": "987953880651",
  "fulfillment_node": "06220582219c400dab6c1dc5bc2baaa5",
  "has_shipments": false,
  "hash_email": "094288741461@customer.jet.com",
  "jet_request_directed_cancel": false,
  "merchant_order_id": "a525148358a44e59a2541e9da564ad43",
  "order_detail": {
    "request_shipping_method": "FedEx Ground",
    "request_shipping_carrier": "USPS",
    "request_service_level": "Scheduled (freight)",
    "request_ship_by": "2017-04-22T10:13:09.2569128Z",
    "request_delivery_by": "2017-04-23T10:13:09.2569128Z"
  },
  "order_items": [
    {
      "order_item_id": "04306ab7c2af45b0945526b93c912d41",
      "merchant_sku": "MAc",
      "request_order_quantity": 1,
      "request_order_cancel_qty": 0,
      "item_tax_code": "",
      "item_price": {
        "item_tax": null,
        "item_shipping_cost": 1,
        "item_shipping_tax": null,
        "base_price": 50
      },
      "product_title": "USWK0012 2.4G Wireless Mini Keyboard for MAC book",
      "url": "http://www.jet.com/api/merchant_skus/MAc"
    }
  ],
  "order_placed_date": "2017-04-21T10:12:09.2569128Z",
  "order_totals": {
    "item_price": {
      "item_tax": null,
      "item_shipping_cost": 1,
      "item_shipping_tax": null,
      "base_price": 50
    }
  },
  "order_transmission_date": "2017-04-21T10:13:09.2569128Z",
  "reference_order_id": "044865304097",
  "shipping_to": {
    "recipient": {
      "name": "Santa's Little Helper",
      "phone_number": "212-212-1785"
    },
    "address": {
      "address1": "77 Oak street",
      "address2": "",
      "city": "Altitude",
      "state": "MS",
      "zip_code": "38829"
    }
  },
  "status": "ready"
}
 *
 *
 *
 *
 *
 *
 *
 */

var arr=[];

function jetOrderDetails() {
	
	var filter =[];
	var columns = [];
	columns.push(new nlobjSearchColumn('name'));
	columns.push(new nlobjSearchColumn('custrecord_jet_access_token'));
	columns.push(new nlobjSearchColumn('custrecord_jet_warehouse_location'));
	var jetAccRcd = nlapiSearchRecord('customrecord_jet_accounts', null, filter, columns);
	nlapiLogExecution('DEBUG', 'jetAccRcd', jetAccRcd.length);
	for(var i=0;i<jetAccRcd.length;i++){
    var actname=jetAccRcd[i].getValue('name');
	var tokenId = jetAccRcd[i].getValue('custrecord_jet_access_token');
	var accnt_id=jetAccRcd[i].getId();
	var warehouse=jetAccRcd[i].getValue('custrecord_jet_warehouse_location');
	nlapiLogExecution('DEBUG', 'tokenId', tokenId);
	nlapiLogExecution('DEBUG', 'accnt_id', accnt_id);

	var header1={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	var orderLinks ='https://merchant-api.jet.com/api/orders/ready';
	var orderResponse = nlapiRequestURL(orderLinks, null, header1);
	orderResponse = orderResponse.getBody();
	nlapiLogExecution('DEBUG', 'orderResponse', orderResponse);
	orderResponse = JSON.parse(orderResponse);
	
	
//	var obj={
//			  "order_urls": [
//			                 "/orders/withoutShipmentDetail/a525148358a44e59a2541e9da564ad43"
//			               ]
//			             }
	var orderUrls = orderResponse.order_urls;
	for(var i=0;i<orderUrls.length;i++)
	{
		getDetails(orderUrls[i],header1,accnt_id);
	}
	
	}
	
}	

function getDetails(url,header,accnt_id,fromUI,orderID)
{

	try{
		if(fromUI!='T'){
	var orderDetailsLink = 'https://merchant-api.jet.com/api'+url;
	
	var id;
	var orderDetailsResponse = nlapiRequestURL(orderDetailsLink, null, header);
	orderDetailsResponse = orderDetailsResponse.getBody();
	var dataIn = JSON.parse(orderDetailsResponse);
	nlapiLogExecution('DEBUG', 'orderDetail', JSON.stringify(orderDetailsResponse));
	var po = dataIn.reference_order_id.toString();
	 var isPremier = false;
	}else{
		po= orderID;
	}
	    nlapiLogExecution('DEBUG', 'orderid', po);
        var warehouse=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'custrecord_jet_warehouse_location');
        var actname=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'name');
	    var marketPl = 24;//Jet
	    var storfront = 76;//JET-76//75-sandbox
	    var exists = checkExists(po,marketPl,storfront);
		if (exists != null) {
			var obj = {
				id : exists,
				type : 'salesOrder',
				status : 'exists',
				storefront: storfront,
				market: marketPl
			};
			
			return exists;
		}else{
			var orderDetailsLink = 'https://merchant-api.jet.com/api'+url;
			
			var id;
			var orderDetailsResponse = nlapiRequestURL(orderDetailsLink, null, header);
			orderDetailsResponse = orderDetailsResponse.getBody();
			var dataIn = JSON.parse(orderDetailsResponse);
			nlapiLogExecution('DEBUG', 'orderDetail', JSON.stringify(orderDetailsResponse));
			
			var custID = getCustID(dataIn);
		      nlapiLogExecution('Debug','customerId:',custID);
		      //-------------------------------------
		      var items = dataIn.items;//------------------
		        var rec = nlapiCreateRecord('salesorder',{recordmode:"dynamic"});
		        rec.setFieldValue('entity', custID);  // set customer
		        rec.setFieldValue('custbody_storefront_list', '76'); // set storefront-76
		        rec.setFieldValue('custbody_marketplace', '24'); // set marketplace
		        rec.setFieldValue('subsidiary', 1); // 1 = zake international
		        rec.setFieldValue('memo', 'Import from Jet'); // mark as order that came from JET
//		         rec.setFieldValue('custbody_order_report_id', dataIn.reportid);
		        rec.setFieldValue('otherrefnum', po); // set po #
		        rec.setFieldValue('custbody_storefront_order', po); // set storefront OrderId #
		        rec.setFieldValue('custbody_customer_email', dataIn.hash_email); // set email
		        rec.setFieldValue('custbody_merchant_order_id', dataIn.merchant_order_id); //merchant Order Id
		        

		        	 rec.setFieldValue('shipaddressee', dataIn.shipping_to.recipient.name.slice(0,30));

		        	 nlapiLogExecution('DEBUG','line 170','170');
		        rec.setFieldValue('shipaddr1', dataIn.shipping_to.address.address1);
		        rec.setFieldValue('shipaddr2', dataIn.shipping_to.address.address2);
		        rec.setFieldValue('shipcity', dataIn.shipping_to.address.city);
		        rec.setFieldValue('shipstate', dataIn.shipping_to.address.state);
		        rec.setFieldValue('shipzip', dataIn.shipping_to.address.zip_code);
			

		        rec.setFieldValue('location', '2')
		       nlapiLogExecution('DEBUG','line 186','186')
		        var items = dataIn.order_items;
		        var shippingCost=0;
		        for(var i=0;i<items.length;i++)
		        {
		        	shippingCost +=items[i].item_price.item_shipping_cost;
		        }
		       
		        nlapiLogExecution('DEBUG','Shipping cost',shippingCost);
		        var merchantSku = dataIn.order_items.merchant_sku;
		        
		        
		        

		        var tax = isTaxable(items);
		        if(tax){
		            rec.setFieldValue('istaxable', 'T');
//		            rec.setFieldValue('taxrate', 7); // indiana tax-------------
		        }
		        
		        nlapiLogExecution('DEBUG', 'After is Taxable',tax);
		        var keep = 0;


                    var flag=0;
            		var itemArr = items;
            		nlapiLogExecution('DEBUG', 'arr',JSON.stringify(itemArr));
            		for(var k=0;k<itemArr.length;k++){
            			nlapiLogExecution('DEBUG','in for loop',k);
            			var merchantSku = itemArr[k].merchant_sku;
            			nlapiLogExecution('DEBUG', 'merchantSku',merchantSku);
            			var findItem=searchItem(merchantSku,accnt_id);
            			 if(findItem!=0){
                            nlapiLogExecution('DEBUG','record found',findItem);
            				 var itemId=findItem[0];
            				 var is_kit=findItem[1];
            				 if(is_kit=='F'){
            			var qty = itemArr[k].request_order_quantity;
            			var prc = itemArr[k].item_price.base_price;
            			var orderId = itemArr[k].order_item_id;
            			
        		        nlapiLogExecution('DEBUG', 'itemId',itemId);
            			
            			rec.selectNewLineItem('item');
            			rec.setCurrentLineItemValue('item', 'item', itemId);
            			rec.setCurrentLineItemValue('item', 'quantity', qty);
            			rec.setCurrentLineItemValue('item', 'rate', prc);
            			rec.setCurrentLineItemValue('item', 'custcol_order_item_id', orderId);
            			rec.setCurrentLineItemValue('item', 'custcol_merchant_sku', merchantSku);
					    obj.setCurrentLineItemValue('item', 'location', warehouse);
            			rec.commitLineItem('item');
            			flag++;
	    			 }else{
					obj.setFieldValue('custbody_kitorder', 'T')
					var kititems=itemId;
					nlapiLogExecution('DEBUG', 'kititems', kititems);
					var split_item=[];
					split_item=kititems.split(';')
					var kitflag=0;
					for(var m=0;m<split_item.length;m++){
						var split_item1=[];
						split_item1=split_item[m].split('=');
						var kit_item=split_item1[0];
						var quantity=(parseInt(split_item1[1]))*qty;
						if(quantity>1){
							prc=prc/quantity
						}
						nlapiLogExecution('DEBUG', ' kit_item', kit_item);
						nlapiLogExecution('DEBUG', 'quantity', quantity);
						var filter = new Array();
						filter[0] = new nlobjSearchFilter('name', null, 'is', kit_item);
						var item = nlapiSearchRecord('inventoryitem', null, filter);
						if(item==null){
							nlapiLogExecution('DEBUG', 'Item not found with name '+kit_item);

						}else{
						var item_qty=quantity;

						kit_itemid=item[0].id;
						nlapiLogExecution('DEBUG', ' kit_itemid', kit_itemid);
						nlapiLogExecution('DEBUG', ' itemPrice', prc);

							obj.selectNewLineItem('item');
							obj.setCurrentLineItemValue('item', 'item', kit_itemid);
						    obj.setCurrentLineItemValue('item', 'location', warehouse);
						    obj.setCurrentLineItemValue('item', 'quantity',item_qty);
						    obj.setCurrentLineItemValue('item', 'price','-1');
						    if(m==0)
						    obj.setCurrentLineItemValue('item', 'rate',prc);
						    else
						    obj.setCurrentLineItemValue('item', 'rate','0');
						    rec.setCurrentLineItemValue('item', 'custcol_order_item_id', orderId);
                			rec.setCurrentLineItemValue('item', 'custcol_merchant_sku', merchantSku);
						    obj.commitLineItem('item');
							kitflag++;
						
	                    }
			          }
						if(kitflag==split_item.length){
							flag++;
						}
	    			  }
            	   }else{
            		    	   nlapiLogExecution('DEBUG','record not found',po);
            		   		if(fromUI!='T'){
		            		   	var search_miss=nlapiSearchRecord('customrecord_jet_missing_order', null, ["custrecord_jet_order_id","is",dataIn.reference_order_id.toString()]);
		            		   	if(search_miss==null)
		            		   	{
		            		   		var missed_record = nlapiCreateRecord("customrecord_jet_missing_order");
		            		   	missed_record.setFieldValue('custrecord_jet_order_id',po);
		            		   	missed_record.setFieldValue('name',po);
		            		   	missed_record.setFieldValue('custrecord_jet_accnt',accnt_id);
		            		   	missed_record.setFieldValue('custrecord_order_missing_reason_jet', 'item Sku : '+merchantSku+ ' not Found');
		            		   	missed_record.setFieldValue('custrecord_order_url',url);
		            		   	nlapiSubmitRecord(missed_record);
		            		       }
		            			nlapiSendEmail(1659, 'govind@webbee.biz','Jet sku notification','item sku '+merchantSku+' does not exist for Order Id: '+po+' | '+actname,'aj@webbeglobal.com');

		            		       }else{
		            		    	   return "error";
		            		       } }}
		                		if(flag>0){
		                		   	
		                			id = nlapiSubmitRecord(rec,null,true);
		                			nlapiLogExecution('DEBUG','salesOrderId',id);
		                			acknowledgeOrder(id,dataIn);
		                			nlapiSendEmail(1659, 'govind@webbee.biz', 'Sales order created with nsid '+id,JSON.stringify(dataIn));
		                		   	
		                			if(fromUI=='T')
		                			return id;
		                		}
		                	

		        	
      		
		                		
		  }
	
	}
	catch(e)
	{
	if(fromUI!='T')	{var search_miss=nlapiSearchRecord('customrecord_jet_missing_order', null, ["custrecord_jet_order_id","is",dataIn.reference_order_id.toString()]);
	if(search_miss==null)
	{var missed_record = nlapiCreateRecord("customrecord_jet_missing_order");
	missed_record.setFieldValue('custrecord_jet_order_id',dataIn.reference_order_id.toString());
	missed_record.setFieldValue('name',dataIn.reference_order_id.toString());
	
	missed_record.setFieldValue('custrecord_jet_accnt',accnt_id);
	missed_record.setFieldValue('custrecord_order_missing_reason_jet', e);
	nlapiSubmitRecord(missed_record);
    }
		nlapiLogExecution('DEBUG', 'getDetails err', e.name+'-'+e);
		nlapiSendEmail(1659, 'kulveer@webbee.biz', 'Err : Jet Order Import '+dataIn.reference_order_id.toString(),e);
	}else{
 	   return "error";
    
	}}
	

}
function searchItem(merchantSku,jet_account){
	var filter=[];
    filter.push(new nlobjSearchFilter('custrecord_sku_id',null, 'is',merchantSku));
    filter.push(new nlobjSearchFilter('custrecord_jet_account',null, 'anyof',jet_account))
    var column=[];
    column.push(new nlobjSearchColumn('custrecord_jet_item'));
    column.push(new nlobjSearchColumn('custrecord_is_jet_kit'));
    column.push(new nlobjSearchColumn('custrecord_related_kit_jet'));

    var rcd = nlapiSearchRecord('customrecord_jet_listing',null, filter, column);
   if(rcd!=null){
	   var itemid=rcd[0].getValue('custrecord_jet_item');
	   var is_kit=rcd[0].getValue('custrecord_jet_item');
	   var related_kit=rcd[0].getValue('custrecord_jet_item');
	   if(is_kit=='T'){
		   itemid=nlapiLookupField('customrecord_kit', related_kit, 'custrecord_kit_mapping');
	   }
		   return [itemid,is_kit];
	  
   }else{
	   return 0;
   }
}
function isTaxable(items){  // checks sales tax
	var done = false;
	items.forEach(function(item, i){
		if (item.item_price.item_tax != null) {
			done = true;
		}
	});
	return done;
}

function getCustID(dataIn) {  // checks if customer exists.  If it doesn't creates the customer
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.hash_email);
	var x = nlapiSearchRecord('customer', null, filter);
	if (x == null) {
		var id = createCustomer(dataIn);
		nlapiLogExecution('DEBUG','Old customer',id);
		return id;
	} 
	else {
		var id = x[0].id;
		nlapiLogExecution('DEBUG','New Customer',id);
		
		nlapiLogExecution('DEBUG', 'Existing Customer',id);
		var obj=nlapiLoadRecord('customer',id,{recordmode : 'dynamic'});
		var flag=0;
		
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG','lines',lines);		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addr1=obj.getLineItemValue('addressbook','addr1', z);

			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addr1',cust_addr1);

			if(cust_zipcode==dataIn.shipping_to.address.zip_code&&cust_addr1==dataIn.shipping_to.address.address1){
				flag++;
			}
         

		}
		nlapiLogExecution('DEBUG','flag',flag);
		
		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addr1 );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping_to.address.address1);
		var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');

			subrecord.setFieldValue('country', 'US');
		//updated on 11.04.2017
        subrecord.setFieldValue('attention', dataIn.shipping_to.recipient.name);
          
   	if (dataIn.shipping_to.recipient.phone_number.match(/[^0]/) && (dataIn.shipping_to.recipient.phone_number.length >= 8)) {
			subrecord.setFieldValue('addrphone', dataIn.shipping_to.recipient.phone_number);
		}
		if(dataIn.shipping_to.address1)
		{
	    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address1);
		subrecord.setFieldValue('addr2', dataIn.shipping_to.address.address2);
		}
		else{
		    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address2);
		}
		subrecord.setFieldValue('city', dataIn.shipping_to.address.city);
		subrecord.setFieldValue('state', dataIn.shipping_to.address.state);
		subrecord.setFieldValue('zip', dataIn.shipping_to.address.zip_code);
		subrecord.commit();
		obj.commitLineItem('addressbook');
			
		}
	    var submited =  nlapiSubmitRecord(obj, null,true);
	
		return submited;
	}
}

function createCustomer(dataIn) {
	
	try{
	var phone= dataIn.shipping_to.recipient.phone_number;
	nlapiLogExecution('DEBUG', 'creating Customer',phone);
	var cust = nlapiCreateRecord('customer');
	cust.setFieldValue('isperson', 'T');
	cust.setFieldValue('subsidiary', 1); // 1 = zake international//---------------
    if(dataIn.buyer.name.length > 32){
    	dataIn.buyer.name = dataIn.buyer.name.slice(0,30);
    }
  
	var name = (dataIn.buyer.name).split(' ');
	if(name.length>1){
		cust.setFieldValue('firstname',name[0]);
		lastName = name[(name.length)-1];
		cust.setFieldValue('lastname',lastName);
	}
	else
		cust.setFieldValue('firstname', dataIn.buyer.name);
	
	
	nlapiLogExecution('DEBUG','after last name');
	cust.setFieldValue('email', dataIn.hash_email);
	cust.setFieldValue('phone', dataIn.buyer.phone_number.slice(0,22));

	cust.selectNewLineItem('addressbook');
	cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
	nlapiLogExecution('DEBUG', 'Before address1', 'Before');
	nlapiLogExecution('DEBUG', 'address is',dataIn.shipping_to.recipient.name);
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping_to.address.address1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.shipping_to.address.country)
		subrecord.setFieldValue('country', 'US');
	else
	subrecord.setFieldValue('country', arr[dataIn.shipping_to.address.country]);
	
    //updated on 11.04.2017
  subrecord.setFieldValue('attention', dataIn.shipping_to.recipient.name.slice(0,30));
//  if(dataIn.shipping.company){
//    subrecord.setFieldValue('addressee', dataIn.shipping.company);
//  }else{
//    subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
//  }
  
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping_to.address.address1)
	{
    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address1);
	subrecord.setFieldValue('addr2', dataIn.shipping_to.address.address2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address2);
	}
	subrecord.setFieldValue('city', dataIn.shipping_to.address.city);
	subrecord.setFieldValue('state', dataIn.shipping_to.address.state);
	subrecord.setFieldValue('zip', dataIn.shipping_to.address.zip_code);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	
	
	var id = nlapiSubmitRecord(cust,null,true);
	nlapiLogExecution('DEBUG', 'new customer', id)
	return id;
}
catch(ex)
{
	
	var body =  'Exception : '+ex.name;
	body += '\n Function : createCustomer()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err createCustomer',body);	
    nlapiLogExecution('DEBUG',body);
}
	
	
}

function checkExists(po,market,storefront){  // checks to see if a sales order with that po# exists in NS.
	nlapiLogExecution('DEBUG', 'In check Exist', po);
	var filter = new Array();
//	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', po);
	
	filter[0] = new nlobjSearchFilter('custbody_storefront_order', null, 'is', po);
	filter[1] = new nlobjSearchFilter('custbody_marketplace', null, 'is', market);
	filter[2] = new nlobjSearchFilter('custbody_storefront_list', null, 'is', storefront);
	var x = nlapiSearchRecord('salesorder', null, filter);
	nlapiLogExecution('DEBUG', 'x',x);
	if (x != null) {
		return x[0].id;
		
	} else {
		return null; // if it does exists returns internal id of existing order for logging
	}
   
}

function jetToken(type) {

	var filters=[];
	var columns =[];
	columns.push(new nlobjSearchColumn('custrecord_user_id'));
	columns.push(new nlobjSearchColumn('custrecord_jet_secret_key'))
	var accountRecord = defVal(nlapiSearchRecord('customrecord_jet_accounts', null, filters, columns)); 

	if(accountRecord !=''){
	for(var i=0;i<accountRecord.length;i++){
		
		try{
	var user = accountRecord[i].getValue(columns[0]);
	var pass = accountRecord[i].getValue(columns[1]);
	
	nlapiLogExecution('DEBUG', 'user-pass', user+'-'+pass);
	
	if(accountRecord !='')
	nlapiLogExecution('DEBUG', 'token generate length', accountRecord.length);
	
	var tokenUrl = 'https://merchant-api.jet.com/api/token';
	var cred = '{"user": "'+user+'","pass": "'+pass+'"}';
	var header1 = {
			"Content-Type" : "application/json"
	};
	
	var tokenResponse = nlapiRequestURL(tokenUrl,cred, header1);
	
	var tokenBody = tokenResponse.getBody();
	nlapiLogExecution('DEBUG', 'token Body', tokenBody);

	tokenBody = JSON.parse(tokenBody);
	
	var tokenId = tokenBody.id_token;
	nlapiLogExecution('DEBUG', 'token Id', tokenId);
	var id = accountRecord[i].getId();
	nlapiSubmitField('customrecord_jet_accounts', id, 'custrecord_jet_access_token',tokenId);
	
		}
    	catch(ex)
    	{
    	
    		var body =  'Exception : '+ex.name;
    		body += '\n Function : jetToken()';
    		body += '\n Message : '+ex.message;
    	
    		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err jetToken',body);	
    	    nlapiLogExecution('DEBUG',body);
    	}
    	
		}
}	
}


function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;
	
		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet defVal() err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}



//-------------------------------------------------
/*			acknowledge Order					*/

function acknowledgeOrder(soId,dataIn)
{
		
	try{
	nlapiLogExecution('DEBUG', 'acknowledgeOrder Start','Start');
	var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
	var shipmentItems = [];
	var header2={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	

			dataIn = JSON.stringify(dataIn);
			nlapiLogExecution('DEBUG', 'dataIn',dataIn);
			dataIn = JSON.parse(dataIn);
			var totalItems = dataIn.order_items;
			nlapiLogExecution('DEBUG','SoId',soId);
			
			var orderItems=[];
			nlapiLogExecution('DEBUG','total Items',totalItems);
			for(var j=0;j<totalItems.length;j++)
			{
				try{
				var merchantSku = totalItems[j].merchant_sku;
    			var qty = totalItems[j].request_order_quantity;
    			var orderId = totalItems[j].order_item_id;
				nlapiLogExecution('AUDIT','j',j);

				nlapiLogExecution('DEBUG','orderId',orderId)
				nlapiLogExecution('DEBUG','qty',qty);
				var accItems={
						"order_item_acknowledgement_status": "fulfillable",
						"order_item_id": orderId
				};
				orderItems.push(accItems);
				
				var shipitem ={
				          "merchant_sku": merchantSku,
				          "response_shipment_sku_quantity": Number(qty)
				        };
				nlapiLogExecution('DEBUG', 'push', 'Push');
				shipmentItems.push(shipitem);
				
			}
			catch(ex)
			{
				var body =  'Exception : '+ex.name;
				body += '\n Function : acknowledgeOrder() for loop';
				body += '\n Message : '+ex.message;
			
				nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err acknowledgeOrder',body);	
			    nlapiLogExecution('DEBUG',body);
			}
			
			}
				
			var acknowledgementStatus = {
					  "acknowledgement_status": "accepted", //this order will moved to the 'acknowledged' status
					  "order_items": orderItems
					}
			
			var ackLink = nlapiLookupField('salesorder',soId,'custbody_merchant_order_id');
			var acknowledgeLink = "https://merchant-api.jet.com/api/orders/"+ackLink+"/acknowledge"
			
			nlapiLogExecution('DEBUG','Link',acknowledgeLink);
			
			acknowledgementStatus = JSON.stringify(acknowledgementStatus);
			nlapiLogExecution('DEBUG','ackStatus',acknowledgementStatus);
			var ackStatus =nlapiRequestURL(acknowledgeLink,acknowledgementStatus,header2,'PUT');

			nlapiSubmitField('salesorder',soId,'custbody_acknowledgement_sent_on_jet','T');
		
			nlapiLogExecution('DEBUG', 'ackStatus',ackStatus.getBody());
			
			shipmentItems=[];
			orderItems=[];
			
			
}
catch(ex)
{
	var body = 'SoId ='+soId+' Exception : '+ex.name;
	body += '\n Function : acknowledgeOrder()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err acknowledgeOrder',body);	
    nlapiLogExecution('DEBUG',body);
}
}
		
//	}
		
		
//}

var method = {
		35171: {service: "UPS 2nd Day Air", carrier: "UPS"},
		35174: {service: "UPS 3 Day Select", carrier: "UPS"},
		35173: {service: "UPS Next Day Air Saver", carrier: "UPS"},
		4: {service: "UPS Ground", carrier: "UPS"},
		8: {service: "USPS First Class Mail", carrier: "USPS"},
		35179: {service: "USPS Priority Mail", carrier: "USPS"},
		35178: {service: "USPS Priority Mail", carrier: "USPS"},
		35170: {service: "USPS Priority Mail", carrier: "USPS"},
	  	
	}

function shipOrder()
{
	nlapiLogExecution('DEBUG','start', 'start');
	var soId;
	try{
		var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
		var header2={
				
				"Content-Type" : "application/json",
				"Authorization" : "bearer "+tokenId};
		
//		var soRcd = nlapiLoadRecord('salesorder','4278729')
		
		var search = nlapiLoadSearch('transaction','2713');
		
		
		
		var columns = search.getColumns();
		var resultSet = search.runSearch();
		
		var from = 0;
		var to = 1000;
		var itemFulfilRcd = resultSet.getResults(from, to);
		var i=0;
		while (itemFulfilRcd != null &&  i<itemFulfilRcd.length) {
			try{
				
				
				var IfId = defVal(itemFulfilRcd[i].getId());
				var createdFrom = defVal(itemFulfilRcd[i].getValue(columns[0]));
				var trackingNumber = defVal(itemFulfilRcd[i].getValue(columns[1]));
				
				var shipMethod = Number(defVal(itemFulfilRcd[i].getValue(columns[2])));
				var shipCarrier = defVal(itemFulfilRcd[i].getValue(columns[3]))
		
				
				var itemFullfilRcdLoad = nlapiLoadRecord('itemfulfillment',IfId);
				var timeGet = itemFullfilRcdLoad.getDateTimeValue('custbody_last_modified_form','Europe/London');
				
				nlapiLogExecution('DEBUG', 'timeGet',timeGet);
				
				nlapiLogExecution('DEBUG','IFID= CreatedFrom =Tracking numbers=shipMethod',IfId+'='+createdFrom+'='+trackingNumbers+'='+shipMethod);
				

				nlapiLogExecution('DEBUG','length',itemFulfilRcd.length);
				nlapiLogExecution('DEBUG','IFID',itemFulfilRcd[i].getId());
				
//				var ifId = itemFulfilRcd[i].getId();
				soId = createdFrom;
				
				var soRcd = nlapiLoadRecord('salesorder', soId);
				var totalItems = soRcd.getLineItemCount('item');
				nlapiLogExecution('DEBUG','soId && tottalItems',soId+'='+totalItems)
				
				var shipTimeSend;
				
				var shipmentItems=[];
				for(var j=1;j<=totalItems;j++)
				{
					var orderId = soRcd.getLineItemValue('item','custcol_order_item_id',j);
					var merchantSku = soRcd.getLineItemValue('item','custcol_merchant_sku',j);

					
					var qty = soRcd.getLineItemValue('item','quantity',j)
					var shipitem ={
				          "merchant_sku": merchantSku,
				          "response_shipment_sku_quantity": Number(qty)
				        };
				nlapiLogExecution('DEBUG', 'push', 'Push');
				shipmentItems.push(shipitem);
					
				}
				
				nlapiLogExecution('DEBUG','shipitem json',JSON.stringify(shipitem))
//				var soFields =  nlapiLookupField('salesorder', soId,['custbody_merchant_order_id','actualshipdate','shipdate']);

				var merchantId =  nlapiLookupField('salesorder', soId,'custbody_merchant_order_id');
				var shipdate = timeGet.split(' ');
				shipdate = shipdate[0];
				
				
				
				 
				nlapiLogExecution('DEBUG', 'trackingNumber&merchantId&shipdate', trackingNumber+'-'+merchantId+'-'+shipdate);
				 shipdate = shipdate.split('/');
			var mmShipdate= Number(shipdate[0]);
			if(mmShipdate<10)
				mmShipdate = '0'+mmShipdate;
			var ddShipdate = Number(shipdate[1]);
			if(ddShipdate <10)
				ddShipdate = '0'+ddShipdate
			var yyShipdate = shipdate[2];
			var date = yyShipdate+'-'+mmShipdate+'-'+ddShipdate;
			nlapiLogExecution('DEBUG','date',date);
					
			if(shipCarrier != 'UPS')
			{
				shipCarrier = 'USPS'
			}

			
			var shipcarrierObj;
			
			if(method[shipMethod])
			{
				shipcarrierObj = method[shipMethod];
				shipCarrier = shipcarrierObj.service;
			}
			
				
			
			nlapiLogExecution('DEBUG',' shipcarrier',shipCarrier);
			
			
			
		
			
			
			var shipTime = timeGet.split(' ');
			var amPm = shipTime[2];
			amPm = amPm.toUpperCase();
			if(amPm == 'PM')
			{
				shipTime = shipTime[1];
				var time= shipTime.split(':');
nlapiLogExecution('DEBUG','shipTime',JSON.stringify(shipTime));
				var hrTime = Number(time[0]);
				hrTime = hrTime+12;
				var minTime = Number(time[1]);
				if(minTime<10)
					minTime = "0"+minTime;
				
				var secTime = Number(time[2]);
				if(secTime <10)
					secTime = "0"+secTime;
				
				shipTimeSend = hrTime+":"+minTime+":"+secTime;
nlapiLogExecution('DEBUG','shipTimeSend',JSON.stringify(shipTimeSend));

			 }else{
				 
			 
			
			 shipTime = shipTime[1];
			 shipTime = shipTime.split(':');
			
nlapiLogExecution('DEBUG','shipTime',JSON.stringify(shipTime));

			var hhtime= Number(shipitem[0]);
			var mmtime= Number(shipitem[1]);
			var sstime= Number(shipitem[2]);
			if(hhtime<10)
				hhtime = "0"+hhtime;
			if(mmtime<10)
				mmtime = "0"+mmtime;
			if(sstime <10)
				sstime = "0"+sstime;
			
			shipTimeSend=hhtime+":"+mmtime+":"+sstime;
			 }
			
			var dateSend = date+"T"+shipTimeSend+"Z";


				nlapiLogExecution('DEBUG','dateSend',dateSend);
				
			
			
			var shipOrder ={
					  "shipments": [
					    {
					      "shipment_tracking_number": trackingNumber,
					      "response_shipment_date": dateSend,
//					      "response_shipment_method": "ups_ground",
//					      "expected_delivery_date": "2014-06-11T18:00:00.0000000-04:00",
//					      "ship_from_zip_code": "12061",
//					      "carrier_pick_up_date": "2014-06-11T18:00:00.0000000-04:00",
					      "carrier": shipCarrier,
					      "shipment_items": shipmentItems
					    }
					  ]
					}
			
			shipOrder = JSON.stringify(shipOrder);
			var shipLink ="https://merchant-api.jet.com/api/orders/"+merchantId+"/shipped";
			
			nlapiLogExecution('DEBUG','Link && shipOrder',shipLink+'='+shipOrder);
			var shipOrderRes = nlapiRequestURL(shipLink,shipOrder,header2,'PUT');
			
			if(defVal(shipOrderRes.getBody()) == '')
			{
				nlapiSubmitField('itemfulfillment',IfId, 'custbody_tracking_number_sync','T');
			}
			nlapiLogExecution('DEBUG','shipOrderRes',shipOrderRes.getBody());
			nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet Order Send on jet','Request send-'+shipOrder);
			nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet Order Shipped shipOrder()','Response get-'+shipOrderRes.getBody());	
			shipmentItems=[];
		
				
				
				
				i++;
				 if (i >= itemFulfilRcd.length) 
			     {
			      nlapiLogExecution('DEBUG', 'i', i);

			      from+=1000;
			      to+=1000;
			      itemFulfilRcd = resultSet.getResults(from, to);
			      i = 0;
			  
			      nlapiLogExecution('DEBUG', 'results.length', itemFulfilRcd.length);

			     }
			
				}
				catch (e) {
					i++;
					nlapiLogExecution('DEBUG','while catch',e);
				}
					
			}
		
		
		
		

		
}
catch(ex)
{
	var soId = 'SoId = '+soId;
	var body =  soId+' Exception : '+ex.name;
	body += '\n Function : shipOrder()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err shipOrder',body);	
    nlapiLogExecution('DEBUG',body);
}	
}



//-----------------------------------------------------------------
/*			Inventory Price Update					*/

function updateInventory()
{

	var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
	var shipmentItems = [];
	var header2={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	
	var accountId = 1;
	var fulfillmentId = '06220582219c400dab6c1dc5bc2baaa5';

	var search = nlapiCreateSearch('customrecord_jet_listing');
	search.addFilter(new nlobjSearchFilter('custrecord_jet_account',null, 'is',accountId));
	
	
	search.addColumn(new nlobjSearchColumn('custrecord_sku_id'));
	search.addColumn(new nlobjSearchColumn('custrecord_jet_item'));
	search.addColumn(new nlobjSearchColumn('custrecord_is_overwrite'));
	search.addColumn(new nlobjSearchColumn('custrecord_overwrite_quantity'));
	search.addColumn(new nlobjSearchColumn('custrecord_price'));
	search.addColumn(new nlobjSearchColumn('custrecord_jet_primary_warehou'));
	
	
	
	var startIndx = 0;
	var endIndx = 500;
	var i = 0;
    
	var resultSet = search.runSearch();
	var result = resultSet.getResults(startIndx,endIndx);
	if(result !=null){
	nlapiLogExecution('Debug','result length',result.length);
    while(result.length != null && i < result.length){	
    	try{
		checkGovernance();
	
		var recId= result[i].getId();
		var sku=result[i].getValue('custrecord_sku_id');
		var itemId = result[i].getValue('custrecord_jet_item');
		var isOverwrite=result[i].getValue('custrecord_is_overwrite');
		var overwriteQuantity = result[i].getValue('custrecord_overwrite_quantity');
		var price = Number(result[i].getValue('custrecord_price'));
		var warehouseId = result[i].getValue('custrecord_jet_primary_warehou');
		nlapiLogExecution('DEBUG','ID && recId && ItemId',warehouseId+'-'+recId+'='+itemId);
		nlapiLogExecution('DEBUG','overwriteQuantity',overwriteQuantity);
		
		var priceObj;
		var inventoryObj;
		if(isOverwrite == 'T')
		{
			var qty = nlapiLookupField('customrecord_jet_listing',recId,'custrecord_overwrite_quantity');
			priceObj ={
					"price": Number(price),
					"fulfillment_nodes": [
					{
						"fulfillment_node_id": fulfillmentId,
						"fulfillment_node_price": Number(price)
					}
					]
			}
			inventoryObj =	{
				"fulfillment_nodes": [
				                      {
				                    	  "fulfillment_node_id": fulfillmentId,
				                    	  "quantity": Number(overwriteQuantity)
				                      }
				                      ]
		}
		}
		else
		{
		
			
	        
			if(itemId){
			var item = nlapiLoadRecord('inventoryitem', itemId);

			
			var warehouseQty = Number(warehouseId)+1;

			

			item = JSON.stringify(item);
			item = JSON.parse(item);
			var qty = item.locations;

			qty = qty[warehouseQty].quantityavailable;

			nlapiLogExecution('DEBUG', 'qty', qty);
			 nlapiLogExecution('DEBUG', 'itemID', itemId);
//			
				priceObj ={
						"price": price,
						"fulfillment_nodes": [
						{
							"fulfillment_node_id": fulfillmentId,
							"fulfillment_node_price": price
						}
						]
				}
				inventoryObj =	{
					"fulfillment_nodes": [
					                      {
					                    	  "fulfillment_node_id": fulfillmentId,
					                    	  "quantity": Number(qty)
					                      }
					                      ]
			}
		}
		
		
    	}
		i++;
		
		var priceUpdateLink = 'https://merchant-api.jet.com/api/merchant-skus/'+sku+'/price';
		priceObj = JSON.stringify(priceObj);
		var priceResponse = nlapiRequestURL(priceUpdateLink, priceObj, header2,'PUT');
		var priceStatus =priceResponse.getBody();
		if(priceStatus =='')
		{priceStatus = 'Success'}
		
		
		var inventoryUpdateLink ='https://merchant-api.jet.com/api/merchant-skus/'+sku+'/Inventory';
		inventoryObj = JSON.stringify(inventoryObj);
		var inventoryResponse = nlapiRequestURL(inventoryUpdateLink,inventoryObj, header2,'PUT');
		
		var inventoryStatus =inventoryResponse.getBody();
		if(inventoryStatus =='')
		{inventoryStatus = 'Success'}
    	
		nlapiLogExecution('DEBUG', 'price && inventory Update', priceStatus+'-'+inventoryStatus);
    	}
    	catch(ex)
    	{
    		i++;
    		var body =  'Exception : '+ex.name;
    		body += '\n Function : updateInventory()';
    		body += '\n Message : '+ex.message;
    	
    		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err updateInventory',body);	
    	    nlapiLogExecution('DEBUG',body);
    	}
    	
    	
    	
    	
    }
}
	
	
}
function CreateMissedOrder(type){
	try{
		var obj=nlapiGetContext();
	var context=obj.getExecutionContext();
	if(context=='userinterface'){
	var check=nlapiGetFieldValue('custrecord_create_order_jet');
	var id=nlapiGetRecordId();
	var recordType=nlapiGetRecordType();
	var fromUI='T';
	if(check=='T'){
	var accnt_id = nlapiGetFieldValue('custrecord_jet_accnt');
	var jetOrderId = nlapiGetFieldValue('custrecord_jet_order_id');
	nlapiLogExecution('DEBUG', 'accnt_id', accnt_id);
	nlapiLogExecution('DEBUG', 'jetOrderId',  jetOrderId);
	var url=nlapiGetFieldValue('custrecord_order_url');
	var tokenId=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'custrecord_jet_access_token');
var header={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	//custrecord_rltd_transaction_jet
	var flag=getDetails(url,header,accnt_id,fromUI,jetOrderId);
	if(flag=="error"){
		obj=nlapiLoadRecord(recordType, id);
		obj.setFieldValue('custrecord_create_order_jet', 'F');
		nlapiSubmitRecord(obj, false, true);
	}
	else{
		obj=nlapiLoadRecord(recordType, id)
		obj.setFieldValue('custrecord_rltd_transaction_jet', flag);
		nlapiSubmitRecord(obj, false, true);
	}
    }
}}
	catch(e){
		nlapiLogExecution('DEBUG', 'error',  e);
	}
}







function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}