	/**
	 * Module Description
	 * 
	 * Version    Date            Author           Remarks
	 * 1.00       11 Apr 2017     Admin
	 *
	 */
	
	/**
	 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
	 * @appliedtorecord recordType
	 * 
	 * @param {String} type Sublist internal id
	 * @param {String} name Field internal id
	 * @param {Number} linenum Optional line item number, starts from 1
	 * @returns {Void}
	 */
	
	
	
var primWareArr=[];
primWareArr[1]='3B USA';
primWareArr[30]='3B USA : L.A. Warehouse';
primWareArr[29]='3B USA : South Bend';
primWareArr[2]='3B USA : South Bend : South Bend Primary';
primWareArr[72]='3B USA : South Bend : South Bend Primary : 3B LA Warehouse';
primWareArr[102]='3B USA : South Bend : South Bend Primary : FBA-BCO CA';
primWareArr[97]='3B USA : South Bend : South Bend Primary : FBA-BCO DE';
primWareArr[100]='3B USA : South Bend : South Bend Primary : FBA-BCO ES';
primWareArr[81]='3B USA : South Bend : South Bend Primary : FBA-CBCO';
primWareArr[82]='3B USA : South Bend : South Bend Primary : FBA-Gallany';
primWareArr[11]='3B USA : South Bend : South Bend Primary : FBA-USA Betterchoice';
primWareArr[12]='3B USA : South Bend : South Bend Primary : FBA-USA SavannahGoods';
primWareArr[104]='3B USA : South Bend : South Bend Primary : FBA-USA SavannahGoods : Reserved';
primWareArr[107]='3B USA : South Bend : South Bend Primary : FBA-USA SavannahGoods : TEST - SG FBA SELLABLE';
primWareArr[105]='3B USA : South Bend : South Bend Primary : FBA-USA SavannahGoods : Unsellable Inventory';
primWareArr[53]='3B USA : South Bend : South Bend Primary : FBA-USA ShopABit';
primWareArr[27]='3B USA : South Bend : South Bend Primary : SB Vendor Warranty';
primWareArr[49]='3B USA : South Bend : South Bend Primary : Scrap Hold';
primWareArr[8]='3B USA : South Bend : South Bend Primary : South Bend-Vendor Receiving';
primWareArr[48]='3B USA : South Bend : South Bend Primary : Tech Repair Hold';
primWareArr[51]='3B USA : South Bend : South Bend Primary : Vorden Return Buffer Zone';
primWareArr[52]='3B USA : South Bend : South Bend Primary : Wholesale Hold';
primWareArr[19]='3B USA : South Bend : South Bend Primary : William R CS Return Buffer Zone';
primWareArr[50]='3B USA : South Bend : South Bend Primary : William Richardson';
primWareArr[60]='3B USA : South Bend : South Bend Primary : WRD Voucher Hold';
primWareArr[32]='ChinaTaiwu';
primWareArr[33]='ChinaTaiwu : Taiwu';
primWareArr[73]='ChinaTaiwu : Taiwu : Ebayæµ·å¤–ä»“';
primWareArr[84]='ChinaTaiwu : Taiwu : Ebayæµ·å¤–ä»“ : 4PX';
primWareArr[85]='ChinaTaiwu : Taiwu : Ebayæµ·å¤–ä»“ : USAE';
primWareArr[86]='ChinaTaiwu : Taiwu : Ebayæµ·å¤–ä»“ : USAW';
primWareArr[36]='ChinaTaiwu : Taiwu : FBA äºšé©¬é€Šä»“åº“';
primWareArr[74]='ChinaTaiwu : Taiwu : FBAä¸­è½¬ä»“';
primWareArr[35]='ChinaTaiwu : Taiwu : ä¹‰ä¹Œä»“';
primWareArr[40]='ChinaTaiwu : Taiwu : ä¹‰ä¹Œä»“ : ä¹‰ä¹Œä¸�è‰¯å“�ä»“';
primWareArr[88]='ChinaTaiwu : Taiwu : ä¹‰ä¹Œä»“ : ä¹‰ä¹Œè€—æ��ä»“';
primWareArr[79]='ChinaTaiwu : Taiwu : ä¹‰ä¹Œä»“ : ç›˜ç‚¹ä»“(ä¹‰ä¹Œ)';
primWareArr[77]='ChinaTaiwu : Taiwu : ä¹‰ä¹Œæ˜¥èŠ‚å¤‡è´§';
primWareArr[76]='ChinaTaiwu : Taiwu : æ�¨ç¾ŽFBAæ˜¥èŠ‚ä¸­è½¬(æ…Žç”¨)';
primWareArr[34]='ChinaTaiwu : Taiwu : æ�¨ç¾Žä»“';
primWareArr[38]='ChinaTaiwu : Taiwu : æ�¨ç¾Žä»“ : æ·±åœ³ä¸�è‰¯å“�ä»“';
primWareArr[87]='ChinaTaiwu : Taiwu : æ�¨ç¾Žä»“ : æ·±åœ³æ ·å“�ä»“';
primWareArr[59]='ChinaTaiwu : Taiwu : æ�¨ç¾Žä»“ : æ·±åœ³è€—æ��ä»“';
primWareArr[78]='ChinaTaiwu : Taiwu : æ�¨ç¾Žä»“ : ç›˜ç‚¹ä»“(æ·±åœ³)';
primWareArr[75]='ChinaTaiwu : Taiwu : æ�¨ç¾Žæ˜¥èŠ‚å¤‡è´§';
primWareArr[89]='PRO USA';
primWareArr[93]='PRO USA : Dropship';
primWareArr[92]='PRO USA : PRO';
primWareArr[94]='PRO USA : RRMA';

var productCodeTypeArr=['','GTIN-14','EAN','ISBN-10','ISBN-13','UPC'];
var variationRelationArr=['','Variation','Accessory'];
var mapImplArr=['','103','102','101'];

	function GetAttributes(type, name, linenum){
	
		try{
		if(name=='custrecord_jet_cat_l0' )
		{ 
			
			for(var j=0;j<=19;j++){
				
				var att_id_field='custrecord_attribute_id'+(j+1);
				var att_name_field='custrecord_attribute_name'+(j+1);
				var att_values_field='custrecord_attribute_values'+(j+1);
				nlapiSetFieldValue(att_id_field,'', false);
				nlapiSetFieldValue(att_name_field,'', false);
				nlapiSetFieldValue(att_values_field,'' , false);
			}
			if(nlapiGetFieldValue('custrecord_jet_cat_l0')){
	
			var category = nlapiGetFieldValue('custrecord_jet_cat_l0');
			var categoryNodeId = nlapiLookupField('customrecord_jet_categories', category, 'custrecord_jet_node_id')
		
			var id=categoryNodeId;
			if(categories.categories[id]){
				
				nlapiSetFieldValue('custrecord_browse_node_id',id,false);
				
				var length=categories.categories[id].length;
				if(length>20)
					length=20;
				for(var i=0;i<length;i++){
					try{
					var att_id_field='custrecord_attribute_id'+(i+1);
					var att_name_field='custrecord_attribute_name'+(i+1);
					var att_values_field='custrecord_attribute_values'+(i+1);
					nlapiSetFieldValue(att_id_field,categories.categories[id][i].attribute_id , false);
					nlapiSetFieldValue(att_name_field,categories.categories[id][i].attribute_name , false);
					nlapiSetFieldValue(att_values_field,categories.categories[id][i].attribute_values , false);
					}
					catch(e)
					{
						nlapiLogExecution('DEBUG', 'attribute catch'+i,e);
					}
				
				}
	
			}
			else{
			alert("Attributes not found for category entered");
			}
		}
	  }else if(name == 'custrecord_jet_item'){
				var itemId = nlapiGetFieldValue('custrecord_jet_item');
				
				var itemFields = nlapiLookupField('inventoryitem', itemId, ['custitem_title','storedisplayimage','salesdescription','manufacturer','weight']);
				var title = itemFields.custitem_title;
	//			var brand = itemFields.custitem_inhouse_brand;
				var image = itemFields.storedisplayimage;
				var desc = itemFields.salesdescription;
				var manufacturer =itemFields.manufacturer;
				var weight = itemFields.weight;
	
				var weightUnit  = nlapiLookupField('inventoryitem', itemId, 'weightunit');
				if(weightUnit ==1){
					weightUnit='lb';
				}else if(weightUnit == 2){
					weightUnit='oz';
				}else if(weightUnit == 3){
					weightUnit='kg';
				}else if(weightUnit == 4){
					weightUnit='g';
				}
				weight = weight+' '+weightUnit;
				nlapiLogExecution('DEBUG', 'weight',weight);
				
				nlapiSetFieldValue('custrecord_title',title);
	//			nlapiSetFieldValue('custrecord_brand', brand);
				nlapiSetFieldValue('custrecord_img_url', image);
				nlapiSetFieldValue('custrecord_product_description', desc);
				nlapiSetFieldValue('custrecord_manufacturer', manufacturer);
				nlapiSetFieldValue('custrecord_shipping_weight', weight);
				
		 }else if(name=='custrecord_is_jet_kit'){
			 var sku = nlapiGetFieldValue('custrecord_sku_id');

		        
				if(nlapiGetFieldValue('custrecord_is_jet_kit')=='F'){
					nlapiSetFieldValue('custrecord_related_kit_jet', '');
					return true;
				}
			else{
				var kit_sku=nlapiGetFieldValue('custrecord_sku_id');
				nlapiLogExecution('DEBUG', 'kit_sku', kit_sku);
				var ary=[];
				ary=kit_sku.replace("@","|").split("|");
//				kit_sku=ary[0];
				if(kit_sku){
					var search=nlapiSearchRecord('customrecord_kit',null, [["custrecord_kit_sku",'is',kit_sku],"OR",["custrecord_kit_sku",'is',ary[0]]]);
					if(search!=null){
						nlapiSetFieldValue('custrecord_related_kit_jet', search[0].id);
						return true;
					}
					else
					{
						alert('No Kit Record found for SKU ID entered');
					   nlapiSetFieldValue('custrecord_is_jet_kit', 'F',false);
						return true;
						}
				}
				else{
					alert('Please Enter SKU ID before check me');
					nlapiSetFieldValue('custrecord_is_jet_kit', 'F',false);
					return true;
				}
				
			}
		 }
		}catch(e)
		{
			nlapiLogExecution('DEBUG', 'NAme err', e.name+'-'+e);
		}
			
			
				
		
	}
	
	
	function uniqueSku()
	{
		var id = nlapiGetRecordId();
		
		var sku = nlapiGetFieldValue('custrecord_sku_id');
		var jetAccount = defVal(nlapiGetFieldValue('custrecord_jet_account'));
		var upcCode = defVal(nlapiGetFieldValue('custrecord_product_codes'));
		var asin = defVal(nlapiGetFieldValue('custrecord_asin_code'));
		var item=nlapiGetFieldValue('custrecord_jet_item');
		var is_kit=nlapiGetFieldValue('custrecord_is_jet_kit')

		if(upcCode =='' && asin =='')
		{
			alert("Please Enter ASIN");
			return(false);
		}
		if(!item&&is_kit=='F'){
			alert('Item need to be inserted if you are not lisitng a "Kit"');
			return false;
		}
		var filters = [];
		if(id)       
		{
		filters.push(new nlobjSearchFilter('internalId', null, 'noneof',id));}
		filters.push(new nlobjSearchFilter('custrecord_sku_id', null, 'is', sku));
		filters.push(new nlobjSearchFilter('custrecord_jet_account', null,'anyof', jetAccount));
		

		var columns =[];
		var record = nlapiSearchRecord('customrecord_jet_listing', null, filters,columns);
		if(record !=null)
		{
			alert("Enter Unique SKU Id");
			return(false);
		}
		else{
			
			return(true);
		}
		
	}
	
	
	function ListOnJEt()
	{
		
		try{
//			alert('163')
			try{
//			nlapiSetFieldValue('custpage_sent_checkbox', 'T');
//			alert('166')
			var id = nlapiGetRecordId();
			var type = nlapiGetRecordType();
			var rcd = nlapiLoadRecord(type, id);
//			rcd.getFieldValue('custrecord_map_price')
//			alert(JSON.stringify(rcd))
//			rcd = JSON.parse(rcd);
		
			var sku = rcd.getFieldValue('custrecord_sku_id');
			var itemId = defVal(rcd.getFieldValue('custrecord_jet_item'));
//			alert('174')
			var warehouseId = primWareArr[rcd.getFieldValue('custrecord_jet_primary_warehou')];
//			alert(warehouseId);
//			alert(rcd.getFieldValue('custrecord_map_price'));
			var jetAccount = defVal(rcd.getFieldValue('custrecord_jet_account'));
		
//			alert('176')
			if(jetAccount =='')
			{
				alert('select Jet Account');
				
			}else{
			var tokenId = nlapiLookupField('customrecord_jet_accounts', jetAccount, 'custrecord_jet_access_token');
			
//			alert('184')
			if(sku == null || sku =='')
			{
				alert('Enter SKU ID');
				return false;
			}
			
			var header2={
					
					"Content-Type" : "application/json",
					"Authorization" : "bearer "+tokenId};
			
			var merchantSkuLink = 'https://merchant-api.jet.com/api/merchant-skus/'+sku;
			
			
			
//			alert('198');
			
			var title = rcd.getFieldValue('custrecord_title');
			var browserNodeId = Number(rcd.getFieldValue('custrecord_browse_node_id'));
			var productcode = defVal(rcd.getFieldValue('custrecord_product_codes'));
			var productCodeType = productCodeTypeArr[rcd.getFieldValue('custrecord_product_code_type')];
			var multiPackQuantity = Number(rcd.getFieldValue('custrecord_multipack_quantity'));
			var brand = rcd.getFieldValue('custrecord_brand');
			var manufacture = rcd.getFieldValue('custrecord_manufacturer');
			var partNumber = rcd.getFieldValue('custrecord_part_number');
			
			var description =  rcd.getFieldValue('custrecord_product_description');
//			var bullets = defVal(rcd.getFieldValue('custrecord_bullets'));
			var bullets=[];
			var shippingWeight = Number(rcd.getFieldValue('custrecord_shipping_weight'));//.split(' ');
			var mapPrice  = Number(rcd.getFieldValue('custrecord_map_price'));
			var mapImpl = mapImplArr[rcd.getFieldValue('custrecord_map_implementation')];
//			var productTaxCode = rcd.getFieldText('custrecord_product_tax_code');
			var imgUrl = rcd.getFieldValue('custrecord_img_url');
			
			
			var price = Number(rcd.getFieldValue('custrecord_price'));
//			var fulfillmentId = rcd.getFieldValue('custrecord_fulfillment_node_id');
			var fulfillmentId = '06220582219c400dab6c1dc5bc2baaa5';
				
			var fulfillmentPrice = Number(rcd.getFieldValue('custrecord_fulfillment_node_price'));
			
//			var quantity = Number(rcd.getFieldValue('custrecord_quantity'));
			
			var overQtyCheck = rcd.getFieldValue('custrecord_is_overwrite');
			var overQty = Number(rcd.getFieldValue('custrecord_overwrite_quantity'));
			
			var variationRelation = variationRelationArr[rcd.getFieldValue('custrecord_relationship')];
			var variationRefinements = defVal(rcd.getFieldValue('custrecord_variation_refinements'));
			var childsku = defVal(rcd.getFieldValue('custrecord_child_sku'));
			
			var archivedCheck = rcd.getFieldValue('custrecord_is_archived');
			var asin = defVal(rcd.getFieldValue('custrecord_asin_code'));
			
			
			var altImg=[];
			for(var i=1 ;i<=8;i++)
			{
				var imageNsid = 'custrecord_imageurl'+i;

				var imageVal = defVal(rcd.getFieldValue(imageNsid));
//					alert(imageVal)
				if(imageVal !=''){
				nlapiLogExecution('DEBUG','After imageVal1',imageNsid);
//							var file = nlapiLoadFile(imageVal);
					
					
//							var url = file.getURL();
							var url = "https://system.na1.netsuite.com"+imageVal
						  var altImgObj = {
				             "image_slot_id": i,
				             "image_url": url
				             }
				nlapiLogExecution('DEBUG','Before',imageVal);
						  if(rcd.getFieldValue(imageNsid) !='')
						  {
							  altImg.push(altImgObj);
						  }
						}
//						nlapiLogExecution('DEBUG','img json',JSON.stringify(altImg));
				}
			
			
			
			
//			alert('234');
			var attrArr=[];
			for(var i=1 ;i<11;i++)
			{
				var attrId = 'custrecord_attribute_id'+i;
				var attrValue = 'custrecord_enter_value'+i;
				if(rcd.getFieldValue(attrId)){
				var attributeSet={
						"attribute_id":Number(rcd.getFieldValue(attrId)),
						"attribute_value":rcd.getFieldValue(attrValue)
				};
				var attValue = defVal(rcd.getFieldValue(attrValue));
				if(attValue !='')
				attrArr.push(attributeSet);
				}
				
			}
			
			
			for(var i=1;i<6;i++)
			{
				var st = 'custrecord_bullet'+i;
				if(defVal(rcd.getFieldValue(st)) !='')
				{
					bullets.push(rcd.getFieldValue(st));
				}
			}
		

			
			var skuData = {
					
					"product_title": title,
					"jet_browse_node_id":browserNodeId,
					"multipack_quantity": multiPackQuantity,
					"brand": brand,
					"manufacturer": manufacture,
					"mfr_part_number": partNumber,
					"product_description": description,
					"bullets": 
					            bullets
					,
		
					"shipping_weight_pounds": shippingWeight[0],
					"map_price": mapPrice,
					"map_implementation": mapImpl,
					//"product_tax_code": productTaxCode,
					"attributes_node_specific": (attrArr),
					"main_image_url": imgUrl,
					"alternate_images": altImg
			}
			
			var productCodeSt={};
			var productCodeArr=[];
						
				if(productcode != '')
				{
					productCodeSt.standard_product_code = productcode;
					productCodeSt.standard_product_code_type = productCodeType;
					productCodeArr.push(productCodeSt);
					skuData.standard_product_codes = productCodeArr;
				}
				if(asin !='')
				{
					skuData.ASIN = asin;
					
				}
			
			skuData = JSON.stringify(skuData);
			
			nlapiSendEmail('1659','govind@webbee.biz','Jet Listing 1'+sku,skuData,null,null,null,null);
//			alert(skuData);
			var skuResponse = nlapiRequestURL(merchantSkuLink,skuData, header2,null,'PUT');
			
			var SkuStatus =defVal(skuResponse.getBody());
		//	nlapiSetFieldValue('custrecord_attribute_values8',skuResponse.getBody());
			
			if(SkuStatus =='')
			{SkuStatus = 'Success'}
			
//			fulfillmentPrice
			var priceData ={
					"price": price,
					"fulfillment_nodes": [
					{
						"fulfillment_node_id": fulfillmentId,
						"fulfillment_node_price": price
					}
					]
			}
			
			var priceUpdateLink =merchantSkuLink+'/price'
			priceData = JSON.stringify(priceData);
			var priceResponse = nlapiRequestURL(priceUpdateLink, priceData, header2, null, 'PUT');
			
			var priceStatus =priceResponse.getBody();
			if(priceStatus =='')
			{priceStatus = 'Success'}
			
			var inventoryUpdateLink = merchantSkuLink+'/Inventory';
			

			
			if(itemId =='')
			{
				alert('Select an Item');
				return false;
				
			}
			var item = nlapiLoadRecord('inventoryitem', itemId);

//			var count = item.getLineItemCount('locations');
			var loc = item.findLineItemValue('locations','location_display',warehouseId);
//			alert(loc);

			var qty = item.getLineItemValue('locations','quantityavailable',loc)
			qty = Number(qty);
			
			
			if(overQtyCheck=='T')
				qty=overQty;
			
			var inventory = {
					"fulfillment_nodes": [
					                      {
					                    	  "fulfillment_node_id": fulfillmentId,
					                    	  "quantity": qty
					                      }
					                      ]
			}

			inventory = JSON.stringify(inventory);
			var inventoryResponse = nlapiRequestURL(inventoryUpdateLink,inventory, header2, null,'PUT');
			
			var inventoryStatus =inventoryResponse.getBody();
			if(inventoryStatus =='')
			{inventoryStatus = 'Success'}
			var variationStatus = '- NO child Sku';
			if(childsku !='' && childsku !=null){
			var variationRefinementsArr=[];
			variationRefinements= variationRefinements.split(',');
		
			for(var i=0;i<Number(variationRefinements.length);i++)
			{
				var val =Number(variationRefinements[i]);
		
				variationRefinementsArr.push(val);
			}
			

			childsku = childsku.split(',');
			childsku = JSON.stringify(childsku);
			childsku = JSON.parse(childsku);
			
			var variationUpdateLink = merchantSkuLink+'/variation';
			var variation ={
					  "relationship": variationRelation,
					  "variation_refinements": variationRefinementsArr,
					  "children_skus": 
					    childsku
					  
					}
			
			
			variation = JSON.stringify(variation);
			var variationResponse = nlapiRequestURL(variationUpdateLink,variation, header2, null,'PUT');
			
			var variationStatus =variationResponse.getBody();
			if(variationStatus =='')
			{variationStatus = 'Success'}
			}
		
			
			
			var archivedLink = merchantSkuLink+'/status/archive';
			if(archivedCheck =='T'){
			archivedCheck = true;
		
			}
			else{
				archivedCheck =false;
			
			}
			
			
			var archived = {
					  "is_archived": archivedCheck
			}
			
			archived = JSON.stringify(archived);
			try{
			var archivedStatus = nlapiRequestURL(archivedLink,archived, header2, null,'PUT');
			}catch(e1){}
			
			var st = 'sku Sent -'+SkuStatus
			var st1 =' \nPrice sent-'+priceStatus+' \nInventory sent-'+inventoryStatus+' \nVariation Update'+variationStatus;
			
			if(SkuStatus =='Success')
			{
			st=st+st1;	
			}
			
			alert(st); 
		
			nlapiSendEmail('1659','govind@webbee.biz','Jet Listing 1'+sku,st,null,null,null,null);
		
			}
			}
			catch(e)
			{
				alert('exception '+e.name+'-'+e);
			}
		
			}
		catch(e)
		{
			alert('exception '+e.name+'-'+e);
		}
	
		}
	
	
	
	//before Load
	function JetButton(type,form,request)
	{		
		if(type =='view'){
		var sentJet = "ListOnJEt();";
	
			form.addButton('custpage_sent','List On JET',sentJet);
	//		form.addField('custpage_sent_checkbox', 'checkbox', 'Sent on Jet');
			form.setScript('customscriptcustomscript_jet_listing_but');
	
		}
		if(type == 'edit'){
			
			var sendLink = "viewPageLink();"

			form.addButton('custpage_viewPage','View (To list on JET)',sendLink);
			form.setScript('customscriptcustomscript_jet_listing_but');
		}
	}
	function viewPageLink()
	{
		var id = nlapiGetRecordId();
		var type = nlapiGetRecordType()
	
		try{
			var link = nlapiResolveURL('RECORD','customrecord_jet_listing',id,'VIEW');
			link = 'https://system.na1.netsuite.com'+link

			window.location=link
		}
		catch(e)
		{
			alert(e);
		}
	}
	
	
	function imageLink()
	{
		var type = nlapiGetRecordType();
		var id = nlapiGetRecordId();
		
var urls=[]
				for(var i=1 ;i<=8;i++)
				{
					var imageName = 'custrecord_image'+i;
					var imageId = nlapiGetFieldValue(imageName)
					
					if(defVal(imageId) !=''){
					var file = nlapiLoadFile(imageId);
					var url=file.getURL();
					urls.push(url);
					}
				}
			nlapiLogExecution('DEBUG','URLS',JSON.stringify(urls));
				for(var i=1 ;i<=8;i++)
				{
					var hiddenImg = "custrecord_imageurl"+i;
					nlapiSubmitField(type, id, hiddenImg, urls[(i-1)])
					
				}
				
	}
	
	
	
	
	
	function defVal(value)
	{	
		try
		{ 
		    if(value == null || value == undefined || value == 'undefined')
		    value = '';	    
		    return value;
		}
		catch(ex)
		{
			var body =  'Exception : '+ex.name;
			body += '\n Function : defVal';
			body += '\n Message : '+ex.message;
	
			nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet DefVal err',body);	
		    nlapiLogExecution('DEBUG',body);
		}
	}
	
	
	
	
	
	
	

	