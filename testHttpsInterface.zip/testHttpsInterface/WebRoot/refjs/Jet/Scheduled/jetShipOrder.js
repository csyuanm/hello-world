/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Jul 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */

var method = {
		35171: {service: "UPS 2nd Day Air", carrier: "UPS"},
		35174: {service: "UPS 3 Day Select", carrier: "UPS"},
		35173: {service: "UPS Next Day Air Saver", carrier: "UPS"},
		4: {service: "UPS Ground", carrier: "UPS"},
		8: {service: "USPS First Class Mail", carrier: "USPS"},
		35179: {service: "USPS Priority Mail", carrier: "USPS"},
		35178: {service: "USPS Priority Mail", carrier: "USPS"},
		35170: {service: "USPS Priority Mail", carrier: "USPS"},
	  	
	}

function shipOrder()
{
	nlapiLogExecution('DEBUG','start', 'start');
	var soId;
	try{
		var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
		var header2={
				
				"Content-Type" : "application/json",
				"Authorization" : "bearer "+tokenId};
		
//		var soRcd = nlapiLoadRecord('salesorder','4278729')
		
		var search = nlapiLoadSearch('transaction','2713');
		
		
		
		var columns = search.getColumns();
		var resultSet = search.runSearch();
		
		var from = 0;
		var to = 1000;
		var itemFulfilRcd = resultSet.getResults(from, to);
		var i=0;
		while (itemFulfilRcd != null &&  i<itemFulfilRcd.length) {
			try{
				
				
				var IfId = defVal(itemFulfilRcd[i].getId());
				var createdFrom = defVal(itemFulfilRcd[i].getValue(columns[0]));
				var trackingNumber = defVal(itemFulfilRcd[i].getValue(columns[1]));
				
				var shipMethod = Number(defVal(itemFulfilRcd[i].getValue(columns[2])));
				var shipCarrier = defVal(itemFulfilRcd[i].getValue(columns[3]))
		
				
				var itemFullfilRcdLoad = nlapiLoadRecord('itemfulfillment',IfId);
				var timeGet = itemFullfilRcdLoad.getDateTimeValue('custbody_last_modified_form','Europe/London');
				
				nlapiLogExecution('DEBUG', 'timeGet',timeGet);
				
				nlapiLogExecution('DEBUG','IFID= CreatedFrom =Tracking numbers=shipMethod',IfId+'='+createdFrom+'='+trackingNumber+'='+shipMethod);
				

				nlapiLogExecution('DEBUG','length',itemFulfilRcd.length);
				nlapiLogExecution('DEBUG','IFID',itemFulfilRcd[i].getId());
				
//				var ifId = itemFulfilRcd[i].getId();
				soId = createdFrom;
				
//				var soRcd = nlapiLoadRecord('salesorder', soId);
				var totalItems = itemFullfilRcdLoad.getLineItemCount('item');
				nlapiLogExecution('DEBUG','soId && tottalItems',soId+'='+totalItems)
				
				var shipTimeSend;
				
				var shipmentItems=[];
				for(var j=1;j<=totalItems;j++)
				{
//					var orderId = itemFullfilRcdLoad.getLineItemValue('item','custcol_order_item_id',j);
					var merchantSku = itemFullfilRcdLoad.getLineItemValue('item','custcol_merchant_sku',j);

					
					var qty = itemFullfilRcdLoad.getLineItemValue('item','quantity',j)
					var shipitem ={
				          "merchant_sku": merchantSku,
				          "response_shipment_sku_quantity": Number(qty)
				        };
				nlapiLogExecution('DEBUG', 'push', 'Push');
				shipmentItems.push(shipitem);
					
				}
				
				nlapiLogExecution('DEBUG','shipitem json',JSON.stringify(shipitem))
//				var soFields =  nlapiLookupField('salesorder', soId,['custbody_merchant_order_id','actualshipdate','shipdate']);

				var merchantId =  nlapiLookupField('salesorder', soId,'custbody_merchant_order_id');
				var shipdate = timeGet.split(' ');
				shipdate = shipdate[0];
				
				
				
				 
				nlapiLogExecution('DEBUG', 'trackingNumber&merchantId&shipdate', trackingNumber+'-'+merchantId+'-'+shipdate);
				 shipdate = shipdate.split('/');
			var mmShipdate= Number(shipdate[0]);
			if(mmShipdate<10)
				mmShipdate = '0'+mmShipdate;
			var ddShipdate = Number(shipdate[1]);
			if(ddShipdate <10)
				ddShipdate = '0'+ddShipdate
			var yyShipdate = shipdate[2];
			var date = yyShipdate+'-'+mmShipdate+'-'+ddShipdate;
			nlapiLogExecution('DEBUG','date',date);
					
			if(shipCarrier != 'UPS')
			{
				shipCarrier = 'USPS'
			}

			
			var shipcarrierObj;
			
//			if(method[shipMethod])
//			{
//				shipcarrierObj = method[shipMethod];
//				shipCarrier = shipcarrierObj.service;
//			}
			
				
			
			nlapiLogExecution('DEBUG',' shipcarrier',shipCarrier);
			
			
			
		
			
			
			var shipTime = timeGet.split(' ');
			var amPm = shipTime[2];
			amPm = amPm.toUpperCase();
			if(amPm == 'PM')
			{
				shipTime = shipTime[1];
				var time= shipTime.split(':');
nlapiLogExecution('DEBUG','shipTime',JSON.stringify(shipTime));
				var hrTime = Number(time[0]);
				hrTime = hrTime+12;
				var minTime = Number(time[1]);
				if(minTime<10)
					minTime = "0"+minTime;
				
				var secTime = Number(time[2]);
				if(secTime <10)
					secTime = "0"+secTime;
				
				shipTimeSend = hrTime+":"+minTime+":"+secTime;
nlapiLogExecution('DEBUG','shipTimeSend',JSON.stringify(shipTimeSend));

			 }else{
				 
			 
			
			 shipTime = shipTime[1];
			 shipTime = shipTime.split(':');
			
nlapiLogExecution('DEBUG','shipTime',JSON.stringify(shipTime));

			var hhtime= Number(shipTime[0]);
			var mmtime= Number(shipTime[1]);
			var sstime= Number(shipTime[2]);
			if(hhtime<10)
				hhtime = "0"+hhtime;
			if(mmtime<10)
				mmtime = "0"+mmtime;
			if(sstime <10)
				sstime = "0"+sstime;
			
			shipTimeSend=hhtime+":"+mmtime+":"+sstime;
			 }
			
			var dateSend = date+"T"+shipTimeSend+".0000000-04:00";


				nlapiLogExecution('DEBUG','dateSend',dateSend);
				
			
			
			var shipOrder ={
					  "shipments": [
					    {
					      "shipment_tracking_number": trackingNumber,
					      "response_shipment_date": dateSend,
//					      "response_shipment_method": "ups_ground",
//					      "expected_delivery_date": "2014-06-11T18:00:00.0000000-04:00",
//					      "ship_from_zip_code": "12061",
//					      "carrier_pick_up_date": "2014-06-11T18:00:00.0000000-04:00",
					      "carrier": shipCarrier,
					      "shipment_items": shipmentItems
					    }
					  ]
					}
			
			shipOrder = JSON.stringify(shipOrder);
			var shipLink ="https://merchant-api.jet.com/api/orders/"+merchantId+"/shipped";
			
			nlapiLogExecution('DEBUG','Link && shipOrder',shipLink+'='+shipOrder);
			var shipOrderRes = nlapiRequestURL(shipLink,shipOrder,header2,'PUT');
			
			if(defVal(shipOrderRes.getBody()) == '')
			{
				nlapiSubmitField('itemfulfillment',IfId, 'custbody_tracked','T');
			}
			nlapiLogExecution('DEBUG','shipOrderRes',shipOrderRes.getBody());
			
			var requestFile = nlapiCreateFile('request.txt','PLAINTEXT',shipOrder);
			var responseFile = nlapiCreateFile('response.txt','PLAINTEXT',shipOrderRes.getBody())
			
			nlapiSendEmail(1659, 'kulveer@webbee.biz', 'Zake-Jet Order Send on jet', 'Request send & response- for soId'+soId, null, null, null, [requestFile,responseFile]);
//			nlapiSendEmail(1659, 'kulveer@webbee.biz', 'Zake-Jet Order Shipped shipOrder()', 'Response Get- for soId'+soId, null, null, null, responseFile);
			
//			nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet Order Send on jet','Request send-'+shipOrder);
//			nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet Order Shipped shipOrder()','Response get-'+shipOrderRes.getBody());	
			shipmentItems=[];
		
				
				
				
				i++;
				 if (i >= itemFulfilRcd.length) 
			     {
			      nlapiLogExecution('DEBUG', 'i', i);

			      from+=1000;
			      to+=1000;
			      itemFulfilRcd = resultSet.getResults(from, to);
			      i = 0;
			  
			      nlapiLogExecution('DEBUG', 'results.length', itemFulfilRcd.length);

			     }
			
				}
				catch (e) {
					i++;
					nlapiLogExecution('DEBUG','while catch',e);
				}
					
			}
		
		
		
		

		
}
catch(ex)
{
	var soId = 'SoId = '+soId;
	var body =  soId+' Exception : '+ex.name;
	body += '\n Function : shipOrder()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err shipOrder',body);	
    nlapiLogExecution('DEBUG',body);
}	
}

function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;
	
		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet defVal() err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}


