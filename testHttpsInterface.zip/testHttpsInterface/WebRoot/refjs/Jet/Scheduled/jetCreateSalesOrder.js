/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Jul 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 
 *
 *
 *{
  "alt_order_id": "",
  "buyer": {
    "name": "Thomas J White",
    "phone_number": "3342031815"
  },
  "customer_reference_order_id": "334483396533",
  "fulfillment_node": "06220582219c400dab6c1dc5bc2baaa5",
  "has_shipments": false,
  "hash_email": "625934184164@customer.jet.com",
  "jet_request_directed_cancel": false,
  "mart_id": 21,
  "merchant_order_id": "bccd48210a334741985d3c2c5a60fcbd",
  "order_detail": {
    "request_shipping_carrier": null,
    "request_shipping_method": "UPS Ground",
    "request_service_level": "Standard",
    "request_ship_by": "2017-07-23T14:30:30.8668817Z",
    "request_delivery_by": "2017-07-31T00:00:00Z"
  },
  "order_items": [
    {
      "order_item_id": "da33e95602cd45649c77902ddf6e7043",
      "alt_order_item_id": null,
      "order_item_acknowledgement_status": null,
      "merchant_sku": "J-2011K9_58",
      "request_order_quantity": 1,
      "request_order_cancel_qty": 0,
      "adjustment_reason": null,
      "item_tax_code": null,
      "item_price": {
        "base_price": 269,
        "item_tax": null,
        "item_shipping_cost": 0,
        "item_shipping_tax": null,
        "item_fulfillment_cost": null
      },
      "price_adjustment": null,
      "item_fees": 0,
      "fee_adjustments": [
        {
          "commission_id": "default",
          "adjustment_name": "",
          "adjustment_type": "base",
          "value": 40.35
        }
      ],
      "regulatory_fees": null,
      "tax_info": null,
      "product_title": "KitchenAid KSM150PSWH Artisan 325-Watt 5-Quart Stand Mixer (White)",
      "url": "https://images.jet.com/md5/e2b9000841532d39a3074aa81a9643d9.500"
    }
  ],
  "order_placed_date": "2017-07-22T14:30:28.5700501Z",
  "order_ready_date": "2017-07-22T15:00:30Z",
  "order_totals": {
    "item_fees": 0,
    "regulatory_fees": null,
    "fee_adjustments": [
      {
        "commission_id": "default",
        "adjustment_name": "",
        "adjustment_type": "base",
        "value": 40.35
      }
    ],
    "item_price": {
      "base_price": 269,
      "item_tax": null,
      "item_shipping_cost": 0,
      "item_shipping_tax": null,
      "item_fulfillment_cost": null
    },
    "tax_info": null
  },
  "order_transmission_date": "2017-07-22T14:30:30.8668817Z",
  "reference_order_id": "342865657730",
  "shipping_to": {
    "recipient": {
      "name": "Tom White",
      "phone_number": "3342031815"
    },
    "address": {
      "address1": "3100 Quail Run",
      "address2": "",
      "city": "OPELIKA",
      "state": "AL",
      "zip_code": "36801",
      "is_business": false,
      "is_weekend_deliveries": true,
      "business_name": ""
    }
  },
  "status": "ready"
}
 *
 *
 *
 *
 *
 *
 *
 */
var arr=[];

function jetOrderDetails() {
	
	jetToken();
	
	
	var obj = nlapiGetContext();
	var jet_actid = obj.getSetting('SCRIPT', 'custscript_jet_account_id');
//	var tokenId = nlapiLookupField('customrecord_jet_accounts', 'jet_actid', 'custrecord_jet_access_token');
	
	
	var filter =[];
	filter.push(new nlobjSearchFilter('internalid',null,'is',jet_actid));
	
	
	var columns = [];
	columns.push(new nlobjSearchColumn('custrecord_jet_access_token'));
	
	var jetAccRcd = nlapiSearchRecord('customrecord_jet_accounts', null, filter, columns);
	nlapiLogExecution('DEBUG', 'jetAccRcd', jetAccRcd.length);
	for(var i=0;i<jetAccRcd.length;i++){
		
	var tokenId = jetAccRcd[i].getValue(columns[0]);
	var accnt_id=jetAccRcd[i].getId();
	nlapiLogExecution('DEBUG', 'tokenId', tokenId);
	nlapiLogExecution('DEBUG', 'accnt_id', accnt_id);

	var header1={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	var orderLinks ='https://merchant-api.jet.com/api/orders/ready';
	var orderResponse = nlapiRequestURL(orderLinks, null, header1);
	orderResponse = orderResponse.getBody();
	nlapiLogExecution('DEBUG', 'orderResponse', orderResponse);
	orderResponse = JSON.parse(orderResponse);
	
	
//	var obj={
//			  "order_urls": [
//			                 "/orders/withoutShipmentDetail/a525148358a44e59a2541e9da564ad43"
//			               ]
//			             }
	var orderUrls = orderResponse.order_urls;
	for(var i=0;i<orderUrls.length;i++)
	{
		getDetails(orderUrls[i],header1,accnt_id);
	}
	
	}
	
}	

function getDetails(url,header,accnt_id,fromUI,orderID)
{

	try{
		if(fromUI!='T'){
	var orderDetailsLink = 'https://merchant-api.jet.com/api'+url;
	
	var id;
	var orderDetailsResponse = nlapiRequestURL(orderDetailsLink, null, header);
	orderDetailsResponse = orderDetailsResponse.getBody();
	var dataIn = JSON.parse(orderDetailsResponse);
	nlapiLogExecution('DEBUG', 'orderDetail', JSON.stringify(orderDetailsResponse));
	var po = dataIn.reference_order_id.toString();
	 var isPremier = false;
	}else{
		po= orderID;
	}
	    nlapiLogExecution('DEBUG', 'orderid', po);
	    var marketPl = 24;//Jet
	    var storfront = 76;//JET-76//75-sandbox
        var warehouse=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'custrecord_jet_warehouse_location');
        var actname=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'name');

	    var exists = checkExists(po,marketPl,storfront);
		if (exists != null) {
			var obj = {
				id : exists,
				type : 'salesOrder',
				status : 'exists',
				storefront: storfront,
				market: marketPl
			};
			
			return exists;
		}else{
			var orderDetailsLink = 'https://merchant-api.jet.com/api'+url;
			
			var id;
			var orderDetailsResponse = nlapiRequestURL(orderDetailsLink, null, header);
			orderDetailsResponse = orderDetailsResponse.getBody();
			var dataIn = JSON.parse(orderDetailsResponse);
			nlapiLogExecution('DEBUG', 'orderDetail', JSON.stringify(orderDetailsResponse));
			
			var custID = getCustID(dataIn);
		      nlapiLogExecution('Debug','customerId:',custID);
		      
		      var serviceLvl = dataIn.order_detail.request_service_level;
		      var serviceLvlCode = ship(serviceLvl);
		      
		      var placedDate = dataIn.order_placed_date;
		      placedDate = placedDate.split('T');
		      placedDate = placedDate[0];
		      placedDate = placedDate.split('-');
		      
		      var dateGet = placedDate[2];
		      var monthGet = placedDate[1];
		      var yearGet = placedDate[0];
		      
		      var tranDate = monthGet+'/'+dateGet+'/'+yearGet;
		      
		      var custForm = nlapiLookupField('customrecord_jet_accounts',accnt_id,'custrecord_jet_custom_form');
		      
		      //-------------------------------------
		      var items = dataIn.items;//------------------
		        var rec = nlapiCreateRecord('salesorder',{recordmode:"dynamic"});
		        rec.setFieldValue('customform',custForm);
		        rec.setFieldValue('entity', custID);  // set customer
		        rec.setFieldValue('custbody_storefront_list', '76'); // set storefront-76
		        rec.setFieldValue('custbody_marketplace', '24'); // set marketplace
		        rec.setFieldValue('subsidiary', 1); // 1 = zake international
		        rec.setFieldValue('memo', 'Import from Jet'); // mark as order that came from JET
//		         rec.setFieldValue('custbody_order_report_id', dataIn.reportid);
		        rec.setFieldValue('otherrefnum', po); // set po #
		        rec.setFieldValue('custbody_storefront_order', po); // set storefront OrderId #
		        rec.setFieldValue('custbody_customer_email', dataIn.hash_email); // set email
		        rec.setFieldValue('custbody_merchant_order_id', dataIn.merchant_order_id); //merchant Order Id
		        
		        rec.setFieldValue('trandate',tranDate); // set email

		        	 rec.setFieldValue('shipaddressee', dataIn.shipping_to.recipient.name.slice(0,30));

		        	 nlapiLogExecution('DEBUG','line 170','170');
		        rec.setFieldValue('shipaddr1', dataIn.shipping_to.address.address1);
		        rec.setFieldValue('shipaddr2', dataIn.shipping_to.address.address2);
		        rec.setFieldValue('shipcity', dataIn.shipping_to.address.city);
		        rec.setFieldValue('shipstate', dataIn.shipping_to.address.state);
		        rec.setFieldValue('shipzip', dataIn.shipping_to.address.zip_code);
			
		        
		        rec.setFieldValue('custbody_market_ship_serv_lvl', serviceLvlCode);
		        rec.setFieldValue('custbody_jet_account',accnt_id);
		        

		        rec.setFieldValue('shipmethod', '35170');
		        
//		        

		        rec.setFieldValue('location', '2')
		       nlapiLogExecution('DEBUG','line 186','186')
		        var items = dataIn.order_items;
		        var shippingCost=0;
		        var itemTax = 0;
		        
		        for(var i=0;i<items.length;i++)
		        {
		        	shippingCost +=items[i].item_price.item_shipping_cost;
		        	itemTax += Number(defVal(items[i].item_price.item_tax));
		        }
		       
		        nlapiLogExecution('DEBUG','itemTax',itemTax);
		        var merchantSku = dataIn.order_items.merchant_sku;
		        
		        
		        

		        var tax = isTaxable(items);
		        if(tax){
		            rec.setFieldValue('istaxable', 'T');
		            
		          //updated on 26.07.2017
//		            rec.setFieldValue('taxrate', 7); // indiana tax
//		            rec.setFieldValue('taxitem', 10);
//		            rec.setFieldValue('taxtotal', itemTax);
		            
		            
		        }
		        
		        nlapiLogExecution('DEBUG', 'After is Taxable',tax);
		        var keep = 0;


                    var flag=0;
            		var itemArr = items;
            		nlapiLogExecution('DEBUG', 'arr',JSON.stringify(itemArr));
            		for(var k=0;k<itemArr.length;k++){
            			nlapiLogExecution('DEBUG','in for loop',k);
            			var merchantSku = itemArr[k].merchant_sku;
            			nlapiLogExecution('DEBUG', 'merchantSku',merchantSku);
            			var findItem=searchItem(merchantSku,accnt_id);
            			 if(findItem!=0){
                            nlapiLogExecution('DEBUG','record found',findItem);
            				 var itemId=findItem[0];
            				 var is_kit=findItem[1];
            				 if(is_kit=='F'){
            			var qty = itemArr[k].request_order_quantity;
            			var prc = itemArr[k].item_price.base_price;
            			var orderId = itemArr[k].order_item_id;
            			
        		        nlapiLogExecution('DEBUG', 'itemId',itemId);
            			
            			rec.selectNewLineItem('item');
            			rec.setCurrentLineItemValue('item', 'item', itemId);
            			rec.setCurrentLineItemValue('item', 'quantity', qty);
            			rec.setCurrentLineItemValue('item', 'rate', prc);
            			rec.setCurrentLineItemValue('item', 'custcol_order_item_id', orderId);
            			rec.setCurrentLineItemValue('item', 'custcol_merchant_sku', merchantSku);
					    rec.setCurrentLineItemValue('item', 'location', warehouse);
            			rec.commitLineItem('item');
            			flag++;
	    			 }else{
					rec.setFieldValue('custbody_kitorder', 'T')
					var kititems=itemId;
					nlapiLogExecution('DEBUG', 'kititems', kititems);
					var split_item=[];
					split_item=kititems.split(';')
					var kitflag=0;
					for(var m=0;m<split_item.length;m++){
						var split_item1=[];
						split_item1=split_item[m].split('=');
						var kit_item=split_item1[0];
						var quantity=(parseInt(split_item1[1]))*qty;
						if(quantity>1){
							prc=prc/quantity
						}
						nlapiLogExecution('DEBUG', ' kit_item', kit_item);
						nlapiLogExecution('DEBUG', 'quantity', quantity);
						var filter = new Array();
						filter[0] = new nlobjSearchFilter('name', null, 'is', kit_item);
						var item = nlapiSearchRecord('inventoryitem', null, filter);
						if(item==null){
							nlapiLogExecution('DEBUG', 'Item not found with name '+kit_item);

						}else{
						var item_qty=quantity;

						kit_itemid=item[0].id;
						nlapiLogExecution('DEBUG', ' kit_itemid', kit_itemid);
						nlapiLogExecution('DEBUG', ' itemPrice', prc);

							rec.selectNewLineItem('item');
							rec.setCurrentLineItemValue('item', 'item', kit_itemid);
						    rec.setCurrentLineItemValue('item', 'location', warehouse);
						    rec.setCurrentLineItemValue('item', 'quantity',item_qty);
						    rec.setCurrentLineItemValue('item', 'price','-1');
						    if(m==0)
						    rec.setCurrentLineItemValue('item', 'rate',prc);
						    else
						    rec.setCurrentLineItemValue('item', 'rate','0');
						    rec.setCurrentLineItemValue('item', 'custcol_order_item_id', orderId);
                			rec.setCurrentLineItemValue('item', 'custcol_merchant_sku', merchantSku);
						    rec.commitLineItem('item');
							kitflag++;
						
	                    }
			          }
						if(kitflag==split_item.length){
							flag++;
						}
	    			  }
            	   }else{
            		    	   nlapiLogExecution('DEBUG','record not found',po);
            		   		if(fromUI!='T'){
		            		   	var search_miss=nlapiSearchRecord('customrecord_jet_missing_order', null, ["custrecord_jet_order_id","is",dataIn.reference_order_id.toString()]);
		            		   	if(search_miss==null)
		            		   	{
		            		   		var missed_record = nlapiCreateRecord("customrecord_jet_missing_order");
		            		   	missed_record.setFieldValue('custrecord_jet_order_id',po);
		            		   	missed_record.setFieldValue('name',po);
		            		   	missed_record.setFieldValue('custrecord_jet_accnt',accnt_id);
		            		   	missed_record.setFieldValue('custrecord_order_missing_reason_jet', 'item Sku : '+merchantSku+ ' not Found');
		            		   	missed_record.setFieldValue('custrecord_order_url',url);
		            		   	nlapiSubmitRecord(missed_record);
		            		       }
		            			nlapiSendEmail(1659, 'govind@webbee.biz','Jet sku notification','item sku '+merchantSku+' does not exist for Order Id: '+po+' | '+actname,'aj@webbeglobal.com');

		            		       }else{
		            		    	   return "error";
		            		       } }}
            		if(flag>0){
            		   	
            			rec.setFieldValue('shippingcost', shippingCost);
            			id = nlapiSubmitRecord(rec,null,true);
            			nlapiLogExecution('DEBUG','salesOrderId',id);
            			acknowledgeOrder(id,dataIn);
            			nlapiSendEmail(1659, 'govind@webbee.biz', 'Sales order created with nsid '+id,JSON.stringify(dataIn));
            		   	
            			if(fromUI=='T')
            			return id;
            		}       		
		  }
	
	}
	catch(e)
	{
	if(fromUI!='T'){
		var search_miss=nlapiSearchRecord('customrecord_jet_missing_order', null, ["custrecord_jet_order_id","is",dataIn.reference_order_id.toString()]);
	if(search_miss==null)
	{var missed_record = nlapiCreateRecord("customrecord_jet_missing_order");
	missed_record.setFieldValue('custrecord_jet_order_id',dataIn.reference_order_id.toString());
	missed_record.setFieldValue('name',dataIn.reference_order_id.toString());
	
	missed_record.setFieldValue('custrecord_jet_accnt',accnt_id);
	missed_record.setFieldValue('custrecord_order_missing_reason_jet', e);
	nlapiSubmitRecord(missed_record);
    }
		nlapiLogExecution('DEBUG', 'getDetails err', e.name+'-'+e);
		nlapiSendEmail(1659, 'govind@webbee.biz', 'Err : Jet Order Import '+po,e,'aj@webbeeglobal.com');
	}else{
 	   return "error";
    
	}}
	

}
function searchItem(merchantSku,jet_account){
	var filter=[];
    filter.push(new nlobjSearchFilter('custrecord_sku_id',null, 'is',merchantSku));
    filter.push(new nlobjSearchFilter('custrecord_jet_account',null, 'anyof',jet_account))
    var column=[];
    column.push(new nlobjSearchColumn('custrecord_jet_item'));
    column.push(new nlobjSearchColumn('custrecord_is_jet_kit'));
    column.push(new nlobjSearchColumn('custrecord_related_kit_jet'));

    var rcd = nlapiSearchRecord('customrecord_jet_listing',null, filter, column);
   if(rcd!=null){
	   var itemid=rcd[0].getValue('custrecord_jet_item');
	   var is_kit=rcd[0].getValue('custrecord_is_jet_kit');
	   var related_kit=rcd[0].getValue('custrecord_jet_item');
	   if(is_kit=='T'){
		   itemid=nlapiLookupField('customrecord_kit', related_kit, 'custrecord_kit_mapping');
	   }
		   return [itemid,is_kit];
	  
   }else{
	   return 0;
   }
}

function isTaxable(items){  // checks sales tax
	var done = false;
	items.forEach(function(item, i){
		if (item.item_price.item_tax != null) {
			done = true;
		}
	});
	return done;
}

function getCustID(dataIn) {  // checks if customer exists.  If it doesn't creates the customer
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.hash_email);
	var x = nlapiSearchRecord('customer', null, filter);
	if (x == null) {
		var id = createCustomer(dataIn);
		nlapiLogExecution('DEBUG','Old customer',id);
		return id;
	} 
	else {
		var id = x[0].id;
		nlapiLogExecution('DEBUG','New Customer',id);
		
		nlapiLogExecution('DEBUG', 'Existing Customer',id);
		var obj=nlapiLoadRecord('customer',id,{recordmode : 'dynamic'});
		var flag=0;
		
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG','lines',lines);		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addr1=obj.getLineItemValue('addressbook','addr1', z);

			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addr1',cust_addr1);

			if(cust_zipcode==dataIn.shipping_to.address.zip_code&&cust_addr1==dataIn.shipping_to.address.address1){
				flag++;
			}
         

		}
		nlapiLogExecution('DEBUG','flag',flag);
		
		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addr1 );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping_to.address.address1);
		var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');

			subrecord.setFieldValue('country', 'US');
		
        subrecord.setFieldValue('attention', dataIn.shipping_to.recipient.name);
          
   	if (dataIn.shipping_to.recipient.phone_number.match(/[^0]/) && (dataIn.shipping_to.recipient.phone_number.length >= 8)) {
			subrecord.setFieldValue('addrphone', dataIn.shipping_to.recipient.phone_number);
		}
		if(dataIn.shipping_to.address1)
		{
	    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address1);
		subrecord.setFieldValue('addr2', dataIn.shipping_to.address.address2);
		}
		else{
		    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address2);
		}
		subrecord.setFieldValue('city', dataIn.shipping_to.address.city);
		subrecord.setFieldValue('state', dataIn.shipping_to.address.state);
		subrecord.setFieldValue('zip', dataIn.shipping_to.address.zip_code);
		subrecord.commit();
		obj.commitLineItem('addressbook');
			
		}
	    var submited =  nlapiSubmitRecord(obj, null,true);
	
		return submited;
	}
}

function createCustomer(dataIn) {
	
	try{
	var phone= dataIn.shipping_to.recipient.phone_number;
	nlapiLogExecution('DEBUG', 'creating Customer',phone);
	var cust = nlapiCreateRecord('customer');
	cust.setFieldValue('isperson', 'T');
	cust.setFieldValue('subsidiary', 1); // 1 = zake international//---------------
    if(dataIn.buyer.name.length > 32){
    	dataIn.buyer.name = dataIn.buyer.name.slice(0,30);
    }
  
	var name = (dataIn.buyer.name).split(' ');
	if(name.length>1){
		cust.setFieldValue('firstname',name[0]);
		lastName = name[(name.length)-1];
		cust.setFieldValue('lastname',lastName);
	}
	else
		cust.setFieldValue('firstname', dataIn.buyer.name);
	
	
	nlapiLogExecution('DEBUG','after last name');
	cust.setFieldValue('email', dataIn.hash_email);
	cust.setFieldValue('phone', dataIn.buyer.phone_number.slice(0,22));
	cust.setFieldValue('receivablesaccount',2330);
	
	//updated on 26.07.2017
	cust.setFieldValue('custentity_storefront',76);

	cust.selectNewLineItem('addressbook');
	cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
	nlapiLogExecution('DEBUG', 'Before address1', 'Before');
	nlapiLogExecution('DEBUG', 'address is',dataIn.shipping_to.recipient.name);
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping_to.address.address1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.shipping_to.address.country)
		subrecord.setFieldValue('country', 'US');
	else
	subrecord.setFieldValue('country', arr[dataIn.shipping_to.address.country]);
	
   
  subrecord.setFieldValue('attention', dataIn.shipping_to.recipient.name.slice(0,30));
//  if(dataIn.shipping.company){
//    subrecord.setFieldValue('addressee', dataIn.shipping.company);
//  }else{
//    subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
//  }
  
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping_to.address.address1)
	{
    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address1);
	subrecord.setFieldValue('addr2', dataIn.shipping_to.address.address2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.shipping_to.address.address2);
	}
	subrecord.setFieldValue('city', dataIn.shipping_to.address.city);
	subrecord.setFieldValue('state', dataIn.shipping_to.address.state);
	subrecord.setFieldValue('zip', dataIn.shipping_to.address.zip_code);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	
	
	var id = nlapiSubmitRecord(cust,null,true);
	nlapiLogExecution('DEBUG', 'new customer', id)
	return id;
}
catch(ex)
{
	
	var body =  'Exception : '+ex.name;
	body += '\n Function : createCustomer()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'govind@webbee.biz','Zake-Jet err createCustomer',body);	
    nlapiLogExecution('DEBUG',body);
}
	
	
}

function checkExists(po,market,storefront){  // checks to see if a sales order with that po# exists in NS.
	nlapiLogExecution('DEBUG', 'In check Exist', po);
	var filter = new Array();
//	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', po);
	
	filter[0] = new nlobjSearchFilter('custbody_storefront_order', null, 'is', po);
	filter[1] = new nlobjSearchFilter('custbody_marketplace', null, 'is', market);
	filter[2] = new nlobjSearchFilter('custbody_storefront_list', null, 'is', storefront);
	var x = nlapiSearchRecord('salesorder', null, filter);
	nlapiLogExecution('DEBUG', 'x',x);
	if (x != null) {
		return x[0].id;
		
	} else {
		return null; // if it does exists returns internal id of existing order for logging
	}
   
}


function acknowledgeOrder(soId,dataIn)
{
		
	try{
	nlapiLogExecution('DEBUG', 'acknowledgeOrder Start','Start');
	var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
	var shipmentItems = [];
	var header2={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	

			dataIn = JSON.stringify(dataIn);
			nlapiLogExecution('DEBUG', 'dataIn',dataIn);
			dataIn = JSON.parse(dataIn);
			var totalItems = dataIn.order_items;
			nlapiLogExecution('DEBUG','SoId',soId);
			
			var orderItems=[];
			nlapiLogExecution('DEBUG','total Items',totalItems);
			for(var j=0;j<totalItems.length;j++)
			{
				try{
				var merchantSku = totalItems[j].merchant_sku;
    			var qty = totalItems[j].request_order_quantity;
    			var orderId = totalItems[j].order_item_id;
				nlapiLogExecution('AUDIT','j',j);

				nlapiLogExecution('DEBUG','orderId',orderId)
				nlapiLogExecution('DEBUG','qty',qty);
				var accItems={
						"order_item_acknowledgement_status": "fulfillable",
						"order_item_id": orderId
				};
				orderItems.push(accItems);
				
				var shipitem ={
				          "merchant_sku": merchantSku,
				          "response_shipment_sku_quantity": Number(qty)
				        };
				nlapiLogExecution('DEBUG', 'push', 'Push');
				shipmentItems.push(shipitem);
				
			}
			catch(ex)
			{
				var body =  'Exception : '+ex.name;
				body += '\n Function : acknowledgeOrder() for loop';
				body += '\n Message : '+ex.message;
			
				nlapiSendEmail(1659,'govind@webbee.biz','Zake-Jet err acknowledgeOrder',body,'aj@webbeeglobal.com');	
			    nlapiLogExecution('DEBUG',body);
			}
			
			}
				
			var acknowledgementStatus = {
					  "acknowledgement_status": "accepted", //this order will moved to the 'acknowledged' status
					  "order_items": orderItems
					}
			
			var ackLink = nlapiLookupField('salesorder',soId,'custbody_merchant_order_id');
			var acknowledgeLink = "https://merchant-api.jet.com/api/orders/"+ackLink+"/acknowledge"
			
			nlapiLogExecution('DEBUG','Link',acknowledgeLink);
			
			acknowledgementStatus = JSON.stringify(acknowledgementStatus);
			nlapiLogExecution('DEBUG','ackStatus',acknowledgementStatus);
			var ackStatus =nlapiRequestURL(acknowledgeLink,acknowledgementStatus,header2,'PUT');

			nlapiSubmitField('salesorder',soId,'custbody_acknowledgement_sent_on_jet','T');
		
			nlapiLogExecution('DEBUG', 'ackStatus',ackStatus.getBody());
			
			shipmentItems=[];
			orderItems=[];
			
			
}
catch(ex)
{
	var body = 'SoId ='+soId+' Exception : '+ex.name;
	body += '\n Function : acknowledgeOrder()';
	body += '\n Message : '+ex.message;

	nlapiSendEmail(1659,'govind@webbee.biz','Zake-Jet err acknowledgeOrder',body,'aj@webbeeglobal.com');	
    nlapiLogExecution('DEBUG',body);
}
}


function CreateMissedOrder(type){
	try{
		var obj=nlapiGetContext();
	var context=obj.getExecutionContext();
	if(context=='userinterface'){
	var check=nlapiGetFieldValue('custrecord_create_order_jet');
	var id=nlapiGetRecordId();
	var recordType=nlapiGetRecordType();
	var fromUI='T';
	if(check=='T'){
	var accnt_id = nlapiGetFieldValue('custrecord_jet_accnt');
	var jetOrderId = nlapiGetFieldValue('custrecord_jet_order_id');
	nlapiLogExecution('DEBUG', 'accnt_id', accnt_id);
	nlapiLogExecution('DEBUG', 'jetOrderId',  jetOrderId);
	var url=nlapiGetFieldValue('custrecord_order_url');
	var tokenId=nlapiLookupField('customrecord_jet_accounts', accnt_id, 'custrecord_jet_access_token');
var header={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	//custrecord_rltd_transaction_jet
	var flag=getDetails(url,header,accnt_id,fromUI,jetOrderId);
	if(flag=="error"){
		obj=nlapiLoadRecord(recordType, id);
		obj.setFieldValue('custrecord_create_order_jet', 'F');
		nlapiSubmitRecord(obj, false, true);
	}
	else{
		obj=nlapiLoadRecord(recordType, id)
		obj.setFieldValue('custrecord_rltd_transaction_jet', flag);
		nlapiSubmitRecord(obj, false, true);
	}
    }
}}
	catch(e){
		nlapiLogExecution('DEBUG', 'error',  e);
	}
}

function defVal(value)
{		
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;

}


function ship(ship_via){
    // shipping codes
    var TBD = 6;
    var Standard = 1;
    var TwoDay = 3;
    var NextDay = 4;

    if (ship_via == "Standard") {
        return Standard;
	} else if (ship_via == "Second Day") {
        return TwoDay;
	} else if (ship_via == "Next Day") {
        return NextDay;
	}else if(ship_via == "Expedited"){
		return Standard;
	} else {
		return TBD;
	}
}
