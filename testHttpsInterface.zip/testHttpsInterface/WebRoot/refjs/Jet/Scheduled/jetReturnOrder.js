/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       01 Aug 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function returnOrder()
{
	var soId;
	
	try{
	var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');

	var header2={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	
	var returnOrderLink = "https://merchant-api.jet.com/api/returns/created"
	var returnOrderRes = nlapiRequestURL(returnOrderLink,null,header2);
	returnOrderRes = returnOrderRes.getBody();
	nlapiLogExecution('DEBUG','returnOrderRes',returnOrderRes);
	returnOrderRes = JSON.parse(returnOrderRes);
	
	var orderArr= returnOrderRes.return_urls;
	for(var i=0;i<orderArr.length;i++){
		var orderDetailsLink = orderArr[i];
		orderDetailsLink = "https://merchant-api.jet.com/api"+orderDetailsLink;
		
		var orderDetail=nlapiRequestURL(orderDetailsLink,null,header2);
		orderDetail = orderDetail.getBody();
		nlapiLogExecution('DEBUG','orderDetails',orderDetail);
		orderDetail = JSON.parse(orderDetail);
		
		var merchantId = orderDetail.merchant_order_id;
//		var raRefId = orderDetail.merchant_return_authorization_id;
//		var trackingNumber = orderDetail.tracking_number;
		var returnMerchantSKUs  = orderDetail.return_merchant_SKUs;
		
		var itemQuantityGet=[];
		var skuGet=[];
		
		for(var k=0;k<returnMerchantSKUs.length;k++)
		{
			skuGet.push(returnMerchantSKUs[k].merchant_sku);
			itemQuantityGet.push(returnMerchantSKUs[k].return_quantity);
		}
		
		var filter =[];
		filter.push(new nlobjSearchFilter('custbody_merchant_order_id',null,'is',merchantId))
//		filter.push(new nlobjSearchFilter('status',null,'is','SalesOrd:G'));
//		filter.push(new nlobjSearchFilter('mainline',null,'is','F'));
//		filter.push(new nlobjSearchFilter('type','','is','F'));
		
		
		var column=[];
		
		
		var soRcd = nlapiSearchRecord('salesorder',null,filter,column);
		
		if(soRcd != null && soRcd.length>0){
		
		soId = soRcd[0].getId();
		nlapiLogExecution('DEBUG','soId find',soId);
		
//		var raRecord = nlapiTransformRecord('salesorder',soId,'returnauthorization');
		
//		var loadSoRcd = nlapiLoadRecord('returnauthorization',rtRecord);
//		var itemCount = raRecord.getLineItemCount('item');
//		for(var i=1;i<=itemCount;i++)
//		{
//			var itemSku = raRecord.getLineItemValue('item','custcol_merchant_sku',i)
//			var flag=0;
//			
//			for(var j=0;j<skuGet.length;j++)
//			{
//				if(itemSku == skuGet[j])
//				{
//					raRecord.setLineItemValue('item','quantity',i,itemQuantityGet[j]);
//					flag=1;
//					break;
//				}
//				
//			}
//			if(flag == 0)
//			{
//				raRecord.setLineItemValue('item','quantity',i,'0');
//			}
//			
//		}
		
//		var raId = nlapiSubmitRecord(raRecord,null,true);
//		nlapiLogExecution('DEBUG','raId',raId);
		
		
		
		
		}
		
		
	}
	
	}
	catch(ex)
	{
		var soId = 'SoId = '+soId;
		var body =  soId+' Exception : '+ex.name;
		body += '\n Function : returnOrder()';
		body += '\n Message : '+ex.message;

		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err returnOrder',body);	
	    nlapiLogExecution('DEBUG',body);
	}
	
	 
}


function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}


function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;
	
		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet defVal() err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}