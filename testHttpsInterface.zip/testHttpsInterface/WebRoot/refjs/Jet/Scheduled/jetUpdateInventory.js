/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Jul 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function updateInventory()
{

	var tokenId = nlapiLookupField('customrecord_jet_accounts', '1', 'custrecord_jet_access_token');
	var shipmentItems = [];
	var header2={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	
	var accountId = 1;
	var fulfillmentId = '06220582219c400dab6c1dc5bc2baaa5';

	var search = nlapiCreateSearch('customrecord_jet_listing');
	search.addFilter(new nlobjSearchFilter('custrecord_jet_account',null, 'is',accountId));
	
	
	search.addColumn(new nlobjSearchColumn('custrecord_sku_id'));
	search.addColumn(new nlobjSearchColumn('custrecord_jet_item'));
	search.addColumn(new nlobjSearchColumn('custrecord_is_overwrite'));
	search.addColumn(new nlobjSearchColumn('custrecord_overwrite_quantity'));
	search.addColumn(new nlobjSearchColumn('custrecord_price'));
	search.addColumn(new nlobjSearchColumn('custrecord_jet_primary_warehou'));
	
	
	
	var startIndx = 0;
	var endIndx = 500;
	var i = 0;
    
	var resultSet = search.runSearch();
	var result = resultSet.getResults(startIndx,endIndx);
	if(result !=null){
	nlapiLogExecution('Debug','result length',result.length);
    while(result.length != null && i < result.length){	
    	try{
		checkGovernance();
	
		var recId= result[i].getId();
		var sku=result[i].getValue('custrecord_sku_id');
		var itemId = result[i].getValue('custrecord_jet_item');
		var isOverwrite=result[i].getValue('custrecord_is_overwrite');
		var overwriteQuantity = result[i].getValue('custrecord_overwrite_quantity');
		var price = Number(result[i].getValue('custrecord_price'));
		var warehouseId = result[i].getValue('custrecord_jet_primary_warehou');
		nlapiLogExecution('DEBUG','ID && recId && ItemId',warehouseId+'-'+recId+'='+itemId);
		nlapiLogExecution('DEBUG','overwriteQuantity',overwriteQuantity);
		
		var priceObj;
		var inventoryObj;
		if(isOverwrite == 'T')
		{
			var qty = nlapiLookupField('customrecord_jet_listing',recId,'custrecord_overwrite_quantity');
			priceObj ={
					"price": Number(price),
					"fulfillment_nodes": [
					{
						"fulfillment_node_id": fulfillmentId,
						"fulfillment_node_price": Number(price)
					}
					]
			}
			inventoryObj =	{
				"fulfillment_nodes": [
				                      {
				                    	  "fulfillment_node_id": fulfillmentId,
				                    	  "quantity": Number(overwriteQuantity)
				                      }
				                      ]
		}
		}
		else
		{
		
			
	        
			if(itemId){
			var item = nlapiLoadRecord('inventoryitem', itemId);

			
			var warehouseQty = Number(warehouseId)+1;

			

			item = JSON.stringify(item);
			item = JSON.parse(item);
			var qty = item.locations;

			qty = qty[warehouseQty].quantityavailable;

			nlapiLogExecution('DEBUG', 'qty', qty);
			 nlapiLogExecution('DEBUG', 'itemID', itemId);
//			
				priceObj ={
						"price": price,
						"fulfillment_nodes": [
						{
							"fulfillment_node_id": fulfillmentId,
							"fulfillment_node_price": price
						}
						]
				}
				inventoryObj =	{
					"fulfillment_nodes": [
					                      {
					                    	  "fulfillment_node_id": fulfillmentId,
					                    	  "quantity": Number(qty)
					                      }
					                      ]
			}
		}
		
		
    	}
		i++;
		
		var priceUpdateLink = 'https://merchant-api.jet.com/api/merchant-skus/'+sku+'/price';
		priceObj = JSON.stringify(priceObj);
		var priceResponse = nlapiRequestURL(priceUpdateLink, priceObj, header2,'PUT');
		var priceStatus =priceResponse.getBody();
		if(priceStatus =='')
		{priceStatus = 'Success'}
		
		
		var inventoryUpdateLink ='https://merchant-api.jet.com/api/merchant-skus/'+sku+'/Inventory';
		inventoryObj = JSON.stringify(inventoryObj);
		var inventoryResponse = nlapiRequestURL(inventoryUpdateLink,inventoryObj, header2,'PUT');
		
		var inventoryStatus =inventoryResponse.getBody();
		if(inventoryStatus =='')
		{inventoryStatus = 'Success'}
    	
		nlapiLogExecution('DEBUG', 'price && inventory Update', priceStatus+'-'+inventoryStatus);
    	}
    	catch(ex)
    	{
    		i++;
    		var body =  'Exception : '+ex.name;
    		body += '\n Function : updateInventory()';
    		body += '\n Message : '+ex.message;
    	
    		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err updateInventory',body);	
    	    nlapiLogExecution('DEBUG',body);
    	}
    	
    	
    	
    	
    }
}
	
	
}


function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}

function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;
	
		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet defVal() err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}

