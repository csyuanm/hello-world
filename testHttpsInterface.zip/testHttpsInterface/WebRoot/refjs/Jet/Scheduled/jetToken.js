/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Jul 2017     kulveer
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function jetToken(type) {

	var filters=[];
	var columns =[];
	columns.push(new nlobjSearchColumn('custrecord_user_id'));
	columns.push(new nlobjSearchColumn('custrecord_jet_secret_key'))
	var accountRecord = defVal(nlapiSearchRecord('customrecord_jet_accounts', null, filters, columns)); 

	if(accountRecord !=''){
	for(var i=0;i<accountRecord.length;i++){
		
		try{
	var user = accountRecord[i].getValue(columns[0]);
	var pass = accountRecord[i].getValue(columns[1]);
	
	nlapiLogExecution('DEBUG', 'user-pass', user+'-'+pass);
	
	if(accountRecord !='')
	nlapiLogExecution('DEBUG', 'token generate length', accountRecord.length);
	
	var tokenUrl = 'https://merchant-api.jet.com/api/token';
	var cred = '{"user": "'+user+'","pass": "'+pass+'"}';
	var header1 = {
			"Content-Type" : "application/json"
	};
	
	var tokenResponse = nlapiRequestURL(tokenUrl,cred, header1);
	
	var tokenBody = tokenResponse.getBody();
	nlapiLogExecution('DEBUG', 'token Body', tokenBody);

	tokenBody = JSON.parse(tokenBody);
	
	var tokenId = tokenBody.id_token;
	nlapiLogExecution('DEBUG', 'token Id', tokenId);
	var id = accountRecord[i].getId();
	nlapiSubmitField('customrecord_jet_accounts', id, 'custrecord_jet_access_token',tokenId);
	
		}
    	catch(ex)
    	{
    	
    		var body =  'Exception : '+ex.name;
    		body += '\n Function : jetToken()';
    		body += '\n Message : '+ex.message;
    	
    		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet err jetToken',body);	
    	    nlapiLogExecution('DEBUG',body);
    	}
    	
		}
}	
}


function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined' || value == ' ')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;
	
		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet defVal() err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}

