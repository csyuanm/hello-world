/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       26 Jul 2017     kulveer
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function cancelOrderBeforeLoad(type, form, request){
 
	if(type =='view' || type=='edit')
	{
		var jetOrder = nlapiGetFieldValue('custbody_storefront_list');
		var cancelOrderCheckBox = nlapiGetFieldValue('custbody_order_cancelled');
		if(jetOrder == '76' && cancelOrderCheckBox == 'F'){
		var cancelOrder = "cancelOrder();";
		
		form.addButton('custpage_sent','Cancel On Jet',cancelOrder);
		form.setScript('customscript_jet_cancel_order');
		}

	}
	
}

function cancelOrder()
{
	
	nlapiLogExecution('DEBUG','FUNCTION CALL','function call');
	var soId =  nlapiGetRecordId();
	var soRcd = nlapiLoadRecord('salesorder',soId);
	
	
	var jetAccount = soRcd.getFieldValue('custbody_jet_account')
	var merchantOrderId = soRcd.getFieldValue('custbody_merchant_order_id');
	var storefront = soRcd.getFieldValue('custbody_storefront_order');
	
	
	var altId = storefront+'-'+soId;
	var tokenId = nlapiLookupField('customrecord_jet_accounts', jetAccount, 'custrecord_jet_access_token');
	
	var itemCount = soRcd.getLineItemCount('item');
	
	
	
	var shipmentArr=[];
	for(var i=1 ;i<=itemCount;i++)
	{
		var itemSku= defVal(soRcd.getLineItemValue('item','custcol_merchant_sku',i))
		var itemQuantity = Number(defVal(soRcd.getLineItemValue('item','quantity',i)));
			
		var shipmentItem={
				"merchant_sku":itemSku,
				"response_shipment_cancel_qty":itemQuantity
		};
		shipmentArr.push(shipmentItem);
		
	}
	
	
	
	var header={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
	var cancelOrderLink = 'https://merchant-api.jet.com/api/orders/'+merchantOrderId+'/shipped';
	
	var cancelOrderObj = {
			 
			  "shipments": [
			    {
			      "alt_shipment_id": altId,
			      "shipment_items": shipmentArr
			    }
			  ]
			}
	
	
	
	cancelOrderObj = JSON.stringify(cancelOrderObj);
	
	var cancelOrderResponse = nlapiRequestURL(cancelOrderLink,cancelOrderObj, header,null,'PUT');
	
	var cancelOrderStatus = defVal(cancelOrderResponse.getBody());
	if(cancelOrderStatus == '')
	{
		alert("order Cancelled");
		soRcd.setFieldValue('custbody_order_cancelled','T');
	}
	else{
		alert(cancelOrderStatus);
	}
	
	nlapiSubmitRecord(soRcd,null,true);

}




function defVal(value)
{	
	try
	{ 
	    if(value == null || value == undefined || value == 'undefined')
	    value = '';	    
	    return value;
	}
	catch(ex)
	{
		var body =  'Exception : '+ex.name;
		body += '\n Function : defVal';
		body += '\n Message : '+ex.message;

		nlapiSendEmail(1659,'kulveer@webbee.biz','Zake-Jet DefVal err',body);	
	    nlapiLogExecution('DEBUG',body);
	}
}


