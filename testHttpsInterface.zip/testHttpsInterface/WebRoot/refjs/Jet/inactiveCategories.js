/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       30 Jun 2017     kulveer
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function inactiveCategory(type) {
	
	var tokenId = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IldscUZYb2E1WkxSQ0hldmxwa1BHOVdHS0JrMCJ9.eyJpc19zYW5kYm94X3VpZCI6ImZhbHNlIiwibWVyY2hhbnRfaWQiOiI2NzY0M2Q4ZjkxODA0N2VjYWQ2N2ZhNzdmNWU3MmJmNiIsInBhcnRuZXJfdHlwZSI6Ik1lcmNoYW50Iiwic2NvcGUiOiJpcm9ubWFuLWFwaSIsImlzcyI6ImpldC5jb20iLCJleHAiOjE0OTg4NjYyNDQsIm5iZiI6MTQ5ODgzMDI0NH0.yxkR3hq99wU3eMYpi5TNfEkjo6QKrgAcdHOT3FDOBinV0WZrPEjW3vhV-_S9TZ6_QRhCFSUECjTPjkwwidY85R0PfI6xYTP7Oo8negUTZeMBwkQCKNd9ut4fkkpOaMX4c-BjegbEGTZod4NgKdqXNgcsloE13JNkc0xGL_CVcOBNXWS0cdmDP-G70Q2AMcsz3Br09FI9Fgzr2nTKecMmqWk8n1FF5AtPymAQ5mC2Fc9icc3DdAVOugGiDkEhWbx12mDNxHI3skN2TBEZPqB1sZWJK61KMI--mFa636m3khQqV77rtBwGBDT8aeYEK_fUgRglj7a3D09iw7r3P8Ek986eoeeYsOeTwGyAUTXSbeAjo7Qpd5GNBtunXoQPK6cdWJfg7TEimLYohUBPosrrYkw1JMr4ydXe3dgdjmtaoupVdVywj0Qt9gF7rC7wrH8HKgEvvO2Sjue_YMXJvfO2UO_sxc3eUysf1guQR9xzVTUEMckoPYwZ7BHf0xl9jTr8QaEP-BNXHVPDjZVhrgYUM8QpAVq566Pih5UyqpC5vejGr6-IysO8_eycWL6lm0rbFHhQuKAPuI6YojzIV55npanew0lQXvT2CqEHYVMyyTSQE8lOJdTseGn9m3b0hWiYYD2e9m8t94XCPQ2aogKzJlqDq-AnU2WoniKo_kh6gS0";
	
	
var header={
			
			"Content-Type" : "application/json",
			"Authorization" : "bearer "+tokenId};
	
var filter=[];
var column=[];

column.push(new nlobjSearchColumn('custrecord_jet_node_id'))



var search = nlapiCreateSearch('customrecord_jet_categories', filter, column)
	
	var tableHtml='';
	var resultSet = search.runSearch();
	
	var from = 0;
	var to = 1000;
	var result = resultSet.getResults(from, to);
	var i=0;
	
	var count=0;

	while (result != null &&  i<result.length) {
		try{
			CheckGovernance();
			var rcdIdGet = result[i].getValue(column[0]);
			var categoryId = rcdIdGet;
			
			
			var taxonomyLink ='https://merchant-api.jet.com/api/taxonomy/nodes/'+categoryId;
			var taxonomyLinkResponse = nlapiRequestURL(taxonomyLink, null, header);
			taxonomyLinkResponse = taxonomyLinkResponse.getBody();
			nlapiLogExecution('DEBUG', 'orderResponse', taxonomyLinkResponse);
			taxonomyLinkResponse = JSON.parse(taxonomyLinkResponse);
			
			var taxonomyActive = taxonomyLinkResponse.active;
			
			if(taxonomyActive == false)
			{
				nlapiLogExecution('DEBUG','Enter false active',taxonomyActive);
				nlapiSubmitField('customrecord_jet_categories',result[i].getId(),'isinactive','T');
				count +=1;
				
			}
			nlapiLogExecution('DEBUG','active',taxonomyActive);
			nlapiLogExecution('DEBUG','Record',result[i].getId());
			nlapiLogExecution('DEBUG','count',count);
			
			
			i++;
			
			 if (i >= result.length) 
		     {
		      nlapiLogExecution('DEBUG', 'i', i);

		      from+=1000;
		      to+=1000;
		      result = resultSet.getResults(from, to);
		      i = 0;
		  
		      nlapiLogExecution('DEBUG', 'results.length', result.length);

		     }
		
			}
			catch (e) {
				i++;
				nlapiLogExecution('DEBUG','while catch',e);
			}
	}

	nlapiLogExecution('DEBUG','Total count',count);


//	var obj={
//			  "order_urls": [
//			                 "/orders/withoutShipmentDetail/a525148358a44e59a2541e9da564ad43"
//			               ]
//			             }
	
//	var obj = {
//	    "jet_node_id": 17000098,
//	    "jet_node_name": "Standard Skateboards & Longboards",
//	    "jet_node_path": "Standard Skateboards & Longboards/Bikes/Sporting Goods",
//	    "parent_id": 17000066,
//	    "jet_level": 2,
//	    "active": false
//	}
	
	
	

}

function CheckGovernance() {

    try {
        var currentContext = nlapiGetContext();

        if (currentContext.getRemainingUsage() < 100) {
            nlapiLogExecution('DEBUG', 'Remaining Usage :', currentContext.getRemainingUsage());
            var state = nlapiYieldScript();

            if (state.status == 'FAILURE') {
                nlapiLogExecution('DEBUG', 'Failed to yield script, exiting:', 'Reason = ' + state.reason + ' / Size = ' + state.size);
            }
            else if (state.status == 'RESUME') {
                nlapiLogExecution('DEBUG', 'Resuming script because of :', state.reason + '/ Size = ' + state.size);
            }
        }
    }
    catch (ex) {
     
        nlapiLogExecution('DEBUG', 'ERROR in CheckGovernance() : ', ex);

    }
}
