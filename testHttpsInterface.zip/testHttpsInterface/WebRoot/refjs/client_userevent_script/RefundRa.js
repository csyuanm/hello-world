/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       14 Feb 2017     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function SetConditionType(type){
   try{
	 var createdfrom = nlapiGetFieldValue('createdfrom');
	 var rec_type=nlapiLookupField('transaction', createdfrom, 'recordtype');
	 if(rec_type=='returnauthorization'){
		 var action=nlapiLookupField('returnauthorization', createdfrom,'custbody_zake_action');
		 var items=nlapiGetLineItemCount('item');
		
		 if(action=='2')
			 {
				for(var i=1;i<=items;i++){
					 nlapiSelectLineItem('item', i);
					  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',1, false);
				}

			 }
//		 else if(action=='Refund-Intercepted/Refused')
//		 {
//		  nlapiSelectLineItem('item', 1);
//		  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',5, false);
//		 }
		 else if(action=='8'||action=='5')
		 {
				for(var i=1;i<=items;i++){
					 nlapiSelectLineItem('item', i);
					  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',3, false);
				}
		
		 }
		 else if(action=='3')
		 {
				for(var i=1;i<=items;i++){
					 nlapiSelectLineItem('item', i);
					  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',2, false);
				}
		 }
		 
		 else if(action=='14')
		 {
				for(var i=1;i<=items;i++){
					 nlapiSelectLineItem('item', i);
					  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',4, false);
				}
		 }
		 else if(action=='6'||action=='11'||action=='15'||action=='16')
		 {
				for(var i=1;i<=items;i++){
					 nlapiSelectLineItem('item', i);
					  nlapiSetCurrentLineItemValue('item', 'custcol_zake_prodt_condtion',1, false);
				}
		 }
	 }
   }
   catch(e){
	   alert('error : '+e)
   }
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @returns {Void}
 */
function SetLocation(type,name,linenum) {
	if(type=='item'&&name=='custcol_zake_item_condition'){

		var condition=nlapiGetLineItemValue(type, 'custcol_zake_item_condition',linenum);
//		alert('condition : '+condition);
		
		nlapiSelectNewLineItem(type)
		if(condition=='')
			nlapiSetCurrentLineItemValue(type, 'location','',false)
		else if(condition=='7'||condition=='8')
			nlapiSetCurrentLineItemValue(type, 'location',49,true)
		else if(condition=='9'||condition=='10'||condition=='11')
			nlapiSetCurrentLineItemValue(type, 'location',48,true)
		else
			nlapiSetCurrentLineItemValue(type, 'location',19,true)
			nlapiCommitLineItem(type) 
	}
     
}
