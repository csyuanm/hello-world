/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       15 Dec 2015     Govind
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function taxcomparision(type){
	try{
	var mymail='govind@webbee.biz';
	var marketplace=(nlapiGetFieldValue('custbody_marketplace'));
	var amazonorder_tax=parseFloat(nlapiGetFieldValue('custbody__amazonordertax'));
	var amazonOrderId=nlapiGetFieldValue('custbody_storefront_order');
	var ns_tax=parseFloat(nlapiGetFieldValue('taxtotal'));
	if(ns_tax!=amazonorder_tax&&marketplace==2);
	{
	nlapiSendEmail(1659,mymail, 'Tax for: '+amazonOrderId,'total tax : '+amazonorder_tax,'aj@webbeeglobal.com');
	}}
	catch (e) {
		nlapiSendEmail(1659,mymail, 'Err:Tax comparision|OrderId '+amazonOrderId,e,'aj@webbeeglobal.com');
	}
  
}
