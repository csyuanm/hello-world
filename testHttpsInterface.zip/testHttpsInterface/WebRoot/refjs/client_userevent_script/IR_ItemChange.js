/*******************************************************************
*
*
* Name: Manage Item Receipt
* Script Type: User Event
* Version: 0.0.1
*
*
* Author: Govind Sharma
* Purpose: To manage Item Receipt for Items different from item being received ( from Nick Tepe )
* Date: 31/05/2017
* ******************************************************************* */
function IR_adjustment(type){
	nlapiLogExecution('DEBUG', 'type',type );
	var ir_recid= nlapiGetRecordId();
	nlapiLogExecution('DEBUG', 'ir_rec',ir_recid );
	var ir_rec = nlapiLoadRecord('itemreceipt', ir_recid);
	var tranid=ir_rec.getFieldValue('tranid');
	try{
//	if(type!='Create')
//		return;
		
	var line=nlapiGetLineItemCount('item');
	nlapiLogExecution('DEBUG', 'lines',line );
	var items={};
	for(i=1;i<=line;i++){
		var o_item=nlapiGetLineItemValue('item', 'custcol_originalitem',i);
		if(o_item>0){
			if(!items[o_item]){
				items[o_item]={
						"w_item":nlapiGetLineItemValue('item', 'item', i),
						"location":nlapiGetLineItemValue('item', 'location', i),
						"qty":nlapiGetLineItemValue('item','quantity', i)
				}
			}
			else{
				items[o_item].qty=parseInt(items[o_item].qty)+parseInt(nlapiGetLineItemValue('item','quantity', i));
			}
		}}
		nlapiLogExecution('DEBUG', 'original items', JSON.stringify(items));
	   	  var subsidiary='1';
	   	  var adjustment_act='356';
		var rec=nlapiCreateRecord('inventoryadjustment',{recordmode:"dynamic"});
	   	rec.setFieldValue('subsidiary', subsidiary);
	   	rec.setFieldValue('account', adjustment_act);
	   	rec.setFieldValue('memo', "Inventory adjustment for  #"+tranid);
	   	var t=0;
		for(var x in items){
			var itemId1=x;
			var itemId2=items[x].w_item;
			var quantity=items[x].qty;
			var loc=items[x].location;
			var price;
			nlapiLogExecution('DEBUG', 'itemId1 : '+itemId1+' itemId2 : '+itemId2+' quantity : '+quantity+' loc : '+loc+' price : '+price);
			for(var j=0;j<2;j++){
				if(j==0){	

					rec.selectNewLineItem('inventory');
			    	rec.setCurrentLineItemValue('inventory', 'item', itemId2);
			    	rec.setCurrentLineItemValue('inventory', 'adjustqtyby', (quantity*-1));
			    	rec.setCurrentLineItemValue('inventory', 'location', loc);
			    	rec.commitLineItem('inventory');
				
				
		    	}
				else{
					nlapiLogExecution('DEBUG', 'item inserted',rec.getLineItemCount('inventory'));
					price=rec.getLineItemValue('inventory', 'unitcost',rec.getLineItemCount('inventory'));
					nlapiLogExecution('DEBUG', 'j1',price);
				rec.selectNewLineItem('inventory');
		    	rec.setCurrentLineItemValue('inventory', 'item', itemId1);
		    	rec.setCurrentLineItemValue('inventory', 'adjustqtyby', quantity);
		    	rec.setCurrentLineItemValue('inventory', 'location', loc);
		    	rec.setCurrentLineItemValue('inventory', 'unitcost',price);
		    	rec.commitLineItem('inventory');}
			}
			t++;
		}
		if(t>0)
		{
			var rec_id=nlapiSubmitRecord(rec, null, true);
			nlapiLogExecution('DEBUG', 'rec_id',rec_id);
			var new_rec=nlapiLoadRecord("inventoryadjustment",rec_id);
			var total_value=new_rec.getFieldValue("estimatedtotalvalue");
			nlapiLogExecution('DEBUG', 'total_val',total_value);
			if(total_value>0){
				nlapiSendEmail('1659', 'govind@webbee.biz', 'Inventory Adjustment exceed zero ',tranid)
//			var current_val=new_rec.getLineItemValue("inventory","unitcost",2);
//			nlapiLogExecution('DEBUG', 'current_val',current_val);
//			new_rec.setLineItemValue("inventory","unitcost",2,( current_val-(total_value)));
//			nlapiSubmitRecord(new_rec);
			}
		nlapiSubmitField('itemreceipt', nlapiGetRecordId(), 'custbody_rltd_adjustment',rec_id);
		var url=nlapiResolveURL('RECORD', 'inventoryadjustment', rec_id)
		url='https://system.na1.netsuite.com'+url;
		nlapiSendEmail('1659', 'nick@zake.com', 'Inventory Adjustment for '+tranid, 'Please click the url:\n'+url, 'govind@webbee.biz')
		
	}
	}
	catch(e){
		nlapiSendEmail('1659', 'govind@webbee.biz', 'Inventory Adjustment for '+tranid,e)
	}
}
