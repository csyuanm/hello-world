/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       07 Oct 2015     Rohit
 *
 */

/**
 * The recordType (internal id) corres ponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email	
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function filterBeforeLoad(type, form, request)
{
	var id = nlapiGetRecordId(), recType = nlapiGetRecordType();role=nlapiGetRole();
    nlapiLogExecution('DEBUG', 'id', id);
   var item_id=nlapiGetFieldValue('custrecord_custitem');
   nlapiLogExecution('DEBUG', 'item_id', item_id);

    var Column=[];
    Column.push(new nlobjSearchColumn('formulacurrency',null,'max').setFormula("DECODE({pricing.pricelevel},'Online Price',{pricing.unitprice})"));        	  
    Column.push(new nlobjSearchColumn('custitem_legacy_3b_sku',null,'group'));        	  

    var Filters=[];
    if(item_id)
    	{
    	Filters.push(new nlobjSearchFilter('internalid',null,'is',item_id));
    var search_result_item=nlapiSearchRecord('item',null,Filters,Column);
if(search_result_item!=null){  
	var item_sku=search_result_item[0].getValue(Column[1]);
    var cost=search_result_item[0].getValue(Column[0]);
    if(cost==0){cost=0;}}
nlapiLogExecution('DEBUG', 'cost', cost);
nlapiLogExecution('DEBUG', 'item_sku', item_sku);

nlapiSetFieldValue('custrecord_onlineprice', cost);
nlapiSetFieldValue('custrecord_itemsku',item_sku);
}
	var button =  form.addField("custpage_post_to_amazon",'checkbox',"POST to Amazon");
	  var obj={};
	    obj[1164]=8; //BCO US
	    obj[1173]=35;//CBCO US
	    obj[1171]=36;//BCO CA
	    obj[1172]=40;//BCO UK
	    obj[1183]=43;//BCO FR
	    obj[1184]=41;//BCO DE
	    obj[1185]=44;//BCO IT
	    obj[1186]=42;//BCO ES
	    obj[1191]=9;//Shop A Bit
	    obj[1192]=1;//SG
	    obj[1195]=26;//Gallany
	if(role=='1164'||role=='1172'||role=='1183'||role=='1186'||role=='1184'||role=='1185'||
	   role=='1173'||role=='1171'||role=='1191'||role=='1192'||role=='1195'){
		nlapiSetFieldValue('custrecord_isactive', "T", false);
		nlapiSetFieldValue('custrecord_active_repricer', "T", false);
		nlapiSetFieldValue('custrecord_account_name', obj[role], false);
		var site_id=nlapiLookupField('customrecord_amazon_accounts',  obj[role],'custrecord_amazon_enabled_sites')
		nlapiSetFieldValue('custrecord_sites', site_id, false);
		 var amz_act=nlapiGetField('custrecord_account_name');
		 amz_act.setDisplayType('disabled');
		 var amz_site=nlapiGetField('custrecord_sites');
		 amz_site.setDisplayType('disabled');
		 var primary_warehouse=nlapiGetField('custrecord_warehouse');
		 primary_warehouse.setDisplayType('disabled');
		 var sec_warehouse=nlapiGetField('custrecord_secondarywarehouse');
		 sec_warehouse.setDisplayType('disabled');
//		var locations=form.addField('custpage_location_pri', 'select', 'Primary Warehouse');
//		locations.addSelectOption('','');
//		locations.addSelectOption('2','USA : Southbend Primary');
//		locations.addSelectOption('11','USA : Southbend Primary : FBA BCO USA');
//		var locations_sec=form.addField('custpage_location_sec', 'select', 'Secondary Warehouse');
//		locations_sec.addSelectOption('','');
//		locations_sec.addSelectOption('2','USA : Southbend Primary');
//		locations_sec.addSelectOption('11','USA : Southbend Primary : FBA BCO USA');
	}

	    return true;

	  }

  
function submitbuttonclicked(type,name){
	
	
	var role=nlapiGetRole();

	if(name=='custrecord_price_overwrite'){
		nlapiLogExecution('DEBUG', 'name', name);
		var online_price=nlapiGetFieldValue('custrecord_onlineprice');
		var over_writeprice=nlapiGetFieldValue('custrecord_price_overwrite');
		if(parseFloat(over_writeprice)>(parseFloat(online_price)*1.1)||parseFloat(over_writeprice)<(parseFloat(online_price)*0.9))
		{
			alert('price overwrite is plus or minus 10% of online price.\nare you sure to insert it?');
		return true;
		}
		else{return true;}
	}
	else if(name=='custrecord_custitem'){
		 var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
		    nlapiLogExecution('DEBUG', 'id', id);
		   var item_id=nlapiGetFieldValue('custrecord_custitem');
		   nlapiLogExecution('DEBUG', 'item_id', item_id);
		   try
		   { var item_sku=nlapiLookupField('inventoryitem', item_id,'custitem_legacy_3b_sku');}
		   catch(e){
			   var item_sku=nlapiLookupField('noninventoryitem', item_id,'custitem_legacy_3b_sku');
		   }
		    var Column=[];
		    Column.push(new nlobjSearchColumn('formulacurrency',null,'max').setFormula("DECODE({pricing.pricelevel},'Online Price',{pricing.unitprice})"));
		    var Filters=[];
		    Filters.push(new nlobjSearchFilter('internalidnumber',null,'equalto',item_id));
		    var search_result_item=nlapiSearchRecord('item',null,Filters,Column);
		if(search_result_item!=null){  
		    var cost=search_result_item[0].getValue(Column[0]);
		    if(cost>0)
		    	nlapiSetFieldValue('custrecord_onlineprice', cost);
		    else
		    	nlapiSetFieldValue('custrecord_onlineprice', '0');
			nlapiLogExecution('DEBUG', 'cost', cost);

		    }
	    nlapiLogExecution('DEBUG', 'item_sku', item_sku);

		nlapiSetFieldValue('custrecord_itemsku',item_sku);
		return true;

	}
	else if(name=='custrecord_amazon_kit'){
        
		if(nlapiGetFieldValue('custrecord_amazon_kit')=='F'){
			nlapiSetFieldValue('custrecord_kitlink', '');
			return true;
		}
	else{
		var kit_sku=nlapiGetFieldValue('custrecord_sku');
		var asin=nlapiGetFieldValue('custrecord_asin');
		nlapiLogExecution('DEBUG', 'kit_sku', kit_sku);
		var ary=[];
		ary=kit_sku.replace("@","|").split("|");
//		kit_sku=ary[0];
		if(kit_sku){
			var search=nlapiSearchRecord('customrecord_kit',null, [["custrecord_kit_sku",'is',kit_sku],"OR",["custrecord_kit_sku",'is',ary[0]]]);
			if(search!=null){
				nlapiSetFieldValue('custrecord_kitlink', search[0].id);
				return true;
			}
			else
			{
				alert('No Kit Record found for SKU & ASIN inserted');
			   nlapiSetFieldValue('custrecord_amazon_kit', 'F',false);
				return true;
				}
		}
		else{
			alert('Please Enter values of SKU and ASIN before check me');
			nlapiSetFieldValue('custrecord_amazon_kit', 'F',false);
			return true;
		}
		
	}}
	else if(name=='custrecord_skutype'&&(role=='1164'||role=='1171'||role=='1172'||role=='1173'||role=='1183'||
			role=='1184'||role=='1185'||role=='1186'||role=='1191'||role=='1192'||role=='1195')){
		    var loc_val={};
		    loc_val[1164]=11; //BCO US
		    loc_val[1171]=102;//BCO CA
		    loc_val[1172]=54;//BCO UK
		    loc_val[1173]=81;//CBCO US
		    loc_val[1183]=54;//BCO FR
		    loc_val[1184]=54;//BCO DE
		    loc_val[1185]=54;//BCO IT
		    loc_val[1186]=54;//BCO ES
		    loc_val[1191]=53;//Shop A Bit
		    loc_val[1192]=12;//SG
		    loc_val[1195]=82;//Gallany
		if(nlapiGetFieldText(name)=='FBA'){
			nlapiSetFieldValue('custrecord_warehouse', loc_val[role], false);
		}
		else if(nlapiGetFieldText(name)=='MFN'){
	        	nlapiSetFieldValue('custrecord_warehouse', 2, false);
	    }
	    else{
	        	nlapiSetFieldValue('custrecord_warehouse', '', false);
	        }
	}
	else if(name=='custpage_post_to_amazon'){
		if(nlapiGetFieldValue('custpage_post_to_amazon')=='T')
		{
		var user=nlapiGetUser();
		var account=nlapiGetFieldValue('custrecord_account_name');
		nlapiLogExecution('DEBUG', 'account', account);

		var count=0;
		var filter=[];
		var column=[];
		var col1=nlapiLookupField('customrecord_amazon_accounts', account, 'custrecord_allowed_users');
		var users=[];
		users=col1.split(',');
		nlapiLogExecution('DEBUG','users',users.length);
		for(var i=0;i<users.length;i++){
		if(users[i]==user){count++;}
		}
		//column.push(new nlobjSearchColumn('custrecord_allowed_users'));
		//filter.push(new nlobjSearchFilter('internalid',null,'is',account));
		//var search=nlapiSearchRecord('customrecord_amazon_accounts',null, filter, column);
		//if(search!=null){
//			var col1=search[0].getValue('custrecord_allowed_users');
//			nlapiLogExecution('DEBUG','allowedUser',col1);
		//var users=[];
		//col1=col1.split(',');
		//users=col1;
		//nlapiLogExecution('DEBUG','users',users.length);
		//for(var i=0;i<users.length;i++){
		//if(users[i]==user){count++;}
		//}
		//}
		if(count!=0){

			    var sku=nlapiGetFieldValue('custrecord_sku');
			    var asin=nlapiGetFieldValue('custrecord_asin');
			    var amzn_accnt=nlapiGetFieldValue('custrecord_account_name');
			    var amzn_site=nlapiGetFieldValue('custrecord_sites');
              
			    if(sku&&asin&&amzn_accnt&&amzn_site){
			     var item_condition=nlapiGetFieldText('custrecord_itemcondition');
		         var marketId=nlapiLookupField('customrecord_amazon_global_sites', amzn_site, 'custrecord_amazon_marketplace_id');
		         var endpoint=nlapiLookupField('customrecord_amazon_global_sites', amzn_site, 'custrecord_amazon_mws_endpoint');
		         var sellerId=nlapiLookupField('customrecord_amazon_accounts',amzn_accnt,'custrecord_amazon_seller_id');
		         var awsKey=nlapiLookupField('customrecord_amazon_accounts',amzn_accnt,'custrecord_aws_access_key_id');
		         var securityKey=nlapiLookupField('customrecord_amazon_accounts',amzn_accnt,'custrecord_secret_key');


		   var timestamp =new Date();
		   timestamp=timestamp.toISOString();
		   timestamp=encodeURIComponent(timestamp);
		   
		   		var feed='<?xml version="1.0" encoding="utf-8"?> <AmazonEnvelope>'
		   		        +'<Header><DocumentVersion>1.01</DocumentVersion>'
		   		        +'<MerchantIdentifier>Webbee</MerchantIdentifier></Header>'
		   		        +'<MessageType>Product</MessageType><Message>'
		   		        +'<MessageID>1</MessageID>'
		   		        +'<OperationType>Update</OperationType>'
		   		        +'<Product><SKU>'+sku+'</SKU>'
		   		        +'<StandardProductID>'
		   		        +'<Type>ASIN</Type>'
		   		        +'<Value>'+asin+'</Value>'
		   		        +'</StandardProductID>'
		   		        +'<Condition><ConditionType>'+item_condition+'</ConditionType></Condition>'
		   		        +'</Product></Message></AmazonEnvelope>';
		   		nlapiLogExecution('DEBUG','feed',feed);
		   		var item_md5=CryptoJS1.MD5(feed);
		   		var item_md5b64 = CryptoJS.enc.Base64.stringify(item_md5);
		   		
		   		var queryString="AWSAccessKeyId="+awsKey
		   		+"&Action=SubmitFeed"
		   		+"&FeedType=_POST_PRODUCT_DATA_"
		   		+"&MarketplaceId.Id.1="+marketId//764574542755"
		   		+"&Merchant="+sellerId
		   		+"&PurgeAndReplace=false"
		   		+"&SignatureMethod=HmacSHA256"
		   		+"&SignatureVersion=2"
		   		+"&Timestamp="+timestamp
		   		+"&Version=2009-01-01";
			var porduct_string = "POST\n"+endpoint+"\n/\n"+queryString;
			var hash = CryptoJS.HmacSHA256(porduct_string, securityKey);
			var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
			hashInBase64 = encodeURIComponent(hashInBase64);
			var headers = new Array();
			headers['User-Agent-x'] = 'AmazonJavascriptScratchpad/1.0 (Language=Javascript)';
			headers['Content-MD5'] = item_md5b64;
			headers['Content-Type'] = 'text/xml';	
			var response = nlapiRequestURL('https://'+endpoint+'?'+ queryString+"&Signature="+hashInBase64,feed,headers);
			nlapiLogExecution('DEBUG','response' , response.getBody());
			var product_xml=nlapiStringToXML(response.getBody());
			 var feed_requestid=product_xml.getElementsByTagName('FeedSubmissionId').item(0).textContent; 
				nlapiLogExecution('DEBUG','feed_requestid' ,feed_requestid);

			alert('Product Xml submitted to Amazon.Submission Id:'+feed_requestid+'\nStatus will be emailed if error seperately');
			
			      return true;
			      
		}
		else{
			alert('\t\t\t\t\t\t\tNotice!!!\n SELLER SKU , ASIN ,Amazon Account & Amazon Site must be filled to perform this Action.');
			nlapiSetFieldValue('custpage_post_to_amazon', 'F', false);
		}}
			      else{alert('\t\t\t\tWarning !!!\nYou do not have access to create listing on this account');}
	}
	}
	else{
		return true;
		}


	      }


function ValidateSku(type, name){
	var base_price_field={};
	base_price_field[1164]='custitem_amazon_bco_fba_bp';
	base_price_field[1171]='custitem_amazon_bcoca_fba_bp';
	base_price_field[1172]='custitem_amazon_bco_uk_bp';
	base_price_field[1173]='custitemamazon_cbco_us_bp';	
	base_price_field[1183]='custitem_amazon_bco_fr_bp';
	base_price_field[1184]='custitem_amazon_bco_de_bp';
	base_price_field[1185]='custitem_amazon_bco_it_bp';
	base_price_field[1186]='custitem_amazon_bco_es_bp';
	base_price_field[1191]='custitem_amazon_sab_fba_bp';
	base_price_field[1192]='custitem_amazon_sg_fba_bp';
	base_price_field[1195]='custitem_amazon_gallany_fba_bp';
	 var obj={};
	    obj[1164]=8; //BCO US
	    obj[1171]=36;//BCO CA
	    obj[1172]=40;//BCO UK
	    obj[1173]=35;//CBCO US  
	    obj[1183]=43;//BCO FR
	    obj[1184]=41;//BCO DE
	    obj[1185]=44;//BCO IT
	    obj[1186]=42;//BCO ES
	    obj[1191]=9;//Shop A Bit
	    obj[1192]=1;//SG
	    obj[1195]=26;//Gallany
	var obj1=nlapiGetContext();
	var context=obj1.getExecutionContext();
	var amz_account=nlapiGetFieldValue('custrecord_account_name');
	var role=nlapiGetRole();
	var item=nlapiGetFieldValue('custrecord_custitem')
	
	if(role=='1164'||role=='1171'||role=='1172'||role=='1173'||role=='1183'||
	   role=='1184'||role=='1185'||role=='1186'||role=='1191'||role=='1192'||role=='1195'){
		var fbaprice=check_null(nlapiLookupField('item', item,base_price_field[role]));
		if(obj[role]!=amz_account){
			alert("You are not autorized to Edit/Save this record!!");
			return false;
	}

		if(fbaprice==0&&role!='1164'){
			alert("LISTING CAN NOT BE CREATED!!!\nITEM DOES NOT HAVE PRICING GROUP FIELD PRICE ENTERED.");
			return false;
		}
	}
	if(context=='userinterface'){
		var user=nlapiGetUser();
		
	    var count=0;
		var filter=[];
		var column=[];
		column.push(new nlobjSearchColumn('custrecord_allowed_users'));
		filter.push(new nlobjSearchFilter('internalid',null,'is',amz_account));
		var search=nlapiSearchRecord('customrecord_amazon_accounts',null, filter, column);
		if(search!=null){
			var col1=search[0].getValue('custrecord_allowed_users');
			nlapiLogExecution('DEBUG','allowedUser',col1);
	var users=[];
	col1=col1.split(',');
	users=col1;
	nlapiLogExecution('DEBUG','users',users.length);
	for(var i=0;i<users.length;i++){
		if(users[i]==user){count++;}
	}
		}
		if(count!=0){
	var filters=[];
var id=nlapiGetRecordId();
	var asin=nlapiGetFieldValue('custrecord_asin');
    var sku=nlapiGetFieldValue('custrecord_sku');
	var sku_type=nlapiGetFieldValue('custrecord_skutype');
	var is_kit=nlapiGetFieldValue('custrecord_amazon_kit');
	var account= nlapiGetFieldValue('custrecord_account_name');
	if(!item&&is_kit=='F'){
		alert('Item need to be inserted if you are not lisitng a "Kit"');
		return false;
	}
	else
	{
			
	    if(item)
	    {filters.push(new nlobjSearchFilter('custrecord_custitem', null, 'anyof',item));}
	    filters.push(new nlobjSearchFilter('custrecord_skutype', null, 'is',sku_type));
	    filters.push(new nlobjSearchFilter('custrecord_account_name', null, 'is',account));
	    if(asin){
		filters.push(new nlobjSearchFilter('custrecord_asin', null, 'is',asin));}
	    filters.push(new nlobjSearchFilter('custrecord_sku', null, 'is',sku));
//	    if(is_kit=='T'){
//	    	filters.push(new nlobjSearchFilter('custrecord_sku', null, 'is',sku));
//	    }
        if(id)
        {filters.push(new nlobjSearchFilter('internalId', null, 'noneof',id));}
	var search_listing=nlapiSearchRecord('customrecord_amazon_listings',null, filters, null);
	if(search_listing!=null){
		var len = search_listing.length;
		var display = len+' Amazon Listing Already Exist With this ASIN & SKU Type';
		for(var i=0; i<len ;i++)
		{
				var listig_id = search_listing[i].getId();
				display +='\n Amazon Listing ID : '+listig_id;		    					 
		}
		 display += '\n\n Only 1 listing is allowed for one ASIN & SKU Type';
			alert(display);		
   		 return false;
	
	}
return true;
}
	}
	else{alert('\t\t\t\tWarning !!!\nYou do not have access to create listing on this account');
    return false;}
}
}

function check_null(value){
	if(value>0)
		value=parseFloat(value);
	else
		value=0;
	return value;
	
}