/*******************************************************************
*
* Name: Manage Item Receipt
* Script Type: Client Script
* Version: 0.0.1
*
*
* Author: Govind Sharma
* Purpose: Restrict all 3B Tech Roles from using certain Forms ( from Caleb Worm )
* Date: 13/06/2017
* ******************************************************************* */
function SelectField(type, name, linenum){
	var itemforms=['255','248','247','232','220','231'];
	var subsidiary=nlapiGetSubsidiary();
	var recordtype=nlapiGetRecordType();
	var form=nlapiGetFieldValue('customform');
	if(subsidiary=='1'&&(recordtype=='inventoryitem'||recordtype=='noninventoryitem')){
//		if(name=='customform')
		{
//			alert('form '+form);
			var custommform=nlapiGetFieldValue(name);
//			alert('custommform '+custommform);
			if(itemforms.indexOf(custommform)!=-1){
				alert('\tNot authorised !!\nContact Administrator to use this Customform');
//				nlapiSetFieldValue(name, '', false);
			}
			
		}
	}
	
 
}
function onSave(type, name){
	var itemforms=['255','248','247','232','220','231'];
	var subsidiary=nlapiGetSubsidiary();
	var recordtype=nlapiGetRecordType();
	var custommform=nlapiGetFieldValue('customform');
	if(subsidiary=='1'&&(recordtype=='inventoryitem'||recordtype=='noninventoryitem')){
			if(itemforms.indexOf(custommform)!=-1){
				alert('\tNot authorised !!\nContact Administrator to use this Custom Form');
                 return false;
                  }
			else{
				return true;
			}
		
	}
	else{
		return true;
	}
}
