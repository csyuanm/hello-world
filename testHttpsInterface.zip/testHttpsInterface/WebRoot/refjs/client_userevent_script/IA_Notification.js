/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       13 Jun 2017     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function AfterSubmit_IA(type){
	try{
		var totalcost=nlapiGetFieldValue('estimatedtotalvalue');
		var user=nlapiGetUser();
		var id=nlapiGetRecordId();
		var supervisor=nlapiLookupField('employee', user,'supervisor');
		var user_name=nlapiLookupField('employee', user,'entityid');
		if(!supervisor){
			supervisor='318';
		}
		var supervisor_mail=nlapiLookupField('employee', supervisor, 'email')
		var ia_rec = nlapiLoadRecord('inventoryadjustment',id);
		var tranid=ia_rec.getFieldValue('tranid');
		var memo=ia_rec.getFieldValue('memo');
		var to_mail=[];
		var records={};
		nlapiLogExecution('DEBUG','type '+type+ ' tranid '+tranid+' id : '+id+' user_name '+user_name+' totalcost '+totalcost);
		var url=nlapiResolveURL('RECORD', 'inventoryadjustment',  id);
		url='https://system.na1.netsuite.com'+url;
		if(type=='create'){
			nlapiSendEmail(user,supervisor_mail , 'New Inventory Adjustment : '+tranid+' | '+'User : '+user_name, 'Adjustment Memo : '+memo+'\nPlease click the url to view adjustment:\n'+url, 'govind@webbee.biz', null, {"entity":supervisor}, null);
			var flag=nlapiFindLineItemValue('inventory', 'unitcost', '0.00');
			if(totalcost>2000||flag!=(-1)||totalcost<(-2000)){
			to_mail.push('kate@zake.com');
			records.entity=['997861'];
			nlapiSendEmail(user,to_mail , 'New Inventory Adjustment : '+tranid+' | '+'User : '+user_name, 'Adjustment Memo : '+memo+'\nPlease click the url to view adjustment:\n'+url, 'govind@webbee.biz', null, records, null);
			}

			
		}
		else if(type=='edit'){
			var oldrec=nlapiGetOldRecord();
			var oldcost=oldrec.getFieldValue('estimatedtotalvalue');
			var flag=nlapiFindLineItemValue('inventory', 'unitcost', '0.00');
			nlapiLogExecution('DEBUG', 'oldcost '+oldcost+' flag '+flag);
			to_mail.push('kate@zake.com');
//			to_mail.push('aj@webbeeglobal.com');
//			to_mail.push('govind@webbee.biz');
			records.entity=['997861'];
//			records.entity=['3888120'];
//			nlapiSendEmail(user,to_mail, 'Inventory Adjustment Edited : '+tranid+' | '+user_name, 'Please click the url:\n'+url, null, null,records, null)

			if(oldcost!=totalcost){				
				if(totalcost>2000||flag!=(-1)||totalcost<(-2000)){
					nlapiSendEmail(user,to_mail, 'Inventory Adjustment Edited : '+tranid+' | '+'User : '+user_name, 'Adjustment Memo : '+memo+'\nPlease click the url to view Adjustment:\n'+url,'govind@webbee.biz', null,records, null)
					nlapiLogExecution('DEBUG', 'mail sent ');
				}
			}
		}
	}
catch(e){
	nlapiSendEmail('1659', 'govind@webbee.biz', 'Error Interanl Inventory Adjustment for '+tranid,e)

}
  
}
