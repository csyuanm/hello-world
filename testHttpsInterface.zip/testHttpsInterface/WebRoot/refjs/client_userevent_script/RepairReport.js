/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       18 Sep 2017     Admin
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function getReportData(request, response){
 var obj=nlapiGetContext();
 var start=0;
 var end=1000;
 var search=nlapiLoadSearch('salesorder', 2853);
 var columns=search.getColumns();
 search=search.runSearch();
 results=search.getResults(start, end);
 nlapiLogExecution('DEBUG', 'results', results.length);
 var i=0;
 var k=0;
 var data={};
 var part_description={};
 var total_repair=0;
 while(results.length>0&&results.length>i){
	 
	 var so_id=results[i].getValue(columns[0]);
	 var ra_item=results[i].getValue(columns[5]);
	 var so_item=results[i].getValue(columns[3]);
	 var ra_item_name=results[i].getText(columns[5]);
	 var so_item_name=results[i].getText(columns[3]);
	 var so_qty=parseInt(results[i].getValue(columns[4]));
	 var so_item_description=results[i].getValue(columns[6]);
	 var so_item_rate=results[i].getValue(columns[7]);
	
		
	 if(!(ra_item=='-8'||so_item=='42935'||ra_item=='10')){
//		 nlapiLogExecution('DEBUG', i);
//             if((i+1)>=results.length){
//            		start+=1000;
//        			end+=1000;
//        			nlapiLogExecution('DEBUG', 'start', start);
//        			nlapiLogExecution('DEBUG', 'end', end);
//        			results=search.getResults(start, end);
//        			i=0; 
//             }
//			 continue;
//	 }
		 try{
		 if(!part_description[so_item_name]){
			 part_description[so_item_name]=format_csv(so_item_description);
		 }
	 }catch(e){
		 nlapiLogExecution('AUDIT',ra_item_name, e);
	 }
	 if(!data[ra_item_name]){
		 var ra_cost=0;
		 data[ra_item_name]={
				 "item_description":format_csv(so_item_description),
				 "cost":ra_cost,
				 "repair_so":{},
				 "repaired_items":{}
		 }
		 if(ra_item!=so_item){
			 data[ra_item_name].repaired_items[so_item_name]=so_qty;
			 
		 }else{
			 data[ra_item_name].repair_so[so_id]=so_qty;
			 data[ra_item_name].cost=parseFloat(data[ra_item_name].cost)+parseFloat(so_item_rate);
			 total_repair+=so_qty;
		 }
	 }else{
		 if(!data[ra_item_name].repair_so[so_id]){
			 if(ra_item!=so_item){
				 if(!data[ra_item_name].repaired_items[so_item_name]){
					 data[ra_item_name].repaired_items[so_item_name]=so_qty;
				 }else{
					 data[ra_item_name].repaired_items[so_item_name]=parseInt(data[ra_item_name].repaired_items[so_item_name])+so_qty;
				 }
				 
			 }else{
				 if(!data[ra_item_name].repair_so[so_id])
				 data[ra_item_name].repair_so[so_id]=so_qty;
				 data[ra_item_name].cost=parseFloat(data[ra_item_name].cost)+parseFloat(so_item_rate);
				 total_repair+=so_qty;
			 } 
		 }
		 if(ra_item!=so_item){
			 if(!data[ra_item_name].repaired_items[so_item_name]){
				 data[ra_item_name].repaired_items[so_item_name]=so_qty;
			 }else{
				 data[ra_item_name].repaired_items[so_item_name]=parseInt(data[ra_item_name].repaired_items[so_item_name])+so_qty;
			 }
			 }
		
		 
	 }
	
//	 nlapiLogExecution('DEBUG', so_id, ra_item+' : '+so_item);
	 k++;
 }
	 i++;
	 
	 if(i>=results.length){
		 nlapiLogExecution('DEBUG', 'i', i);
			start+=1000;
			end+=1000;
			nlapiLogExecution('DEBUG', 'start', start);
			nlapiLogExecution('DEBUG', 'end', end);
			results=search.getResults(start, end);
			i=0;
			 nlapiLogExecution('DEBUG', 'usage', obj.getRemainingUsage());
		}
 }
 nlapiLogExecution('DEBUG', 'usage', obj.getRemainingUsage());
 nlapiLogExecution('DEBUG', 'k', k);
 nlapiLogExecution('DEBUG', 'data', JSON.stringify(data));
 var file=nlapiCreateFile('SKUrepair.txt', 'PLAINTEXT', JSON.stringify(data));
 var file2=nlapiCreateFile('PartsDescription.txt', 'PLAINTEXT', JSON.stringify(part_description));
 
// response.write(JSON.stringify(data));
var report='Item Repaired,Description,Cost,Total Repair,Total Repair(%),Parts Used,Description,Quantity,Parts Used(%)\n';
for(var item in data){
	var total_repairs=0
	var repaired_item=item;
	
	 var repairs=Object.keys(data[item].repair_so);
	 if(repairs.length>0){
		 
		 var get_repairs=data[item].repair_so;
		 var item_description=data[item].item_description;
		 var repair_cost=data[item].cost;
		 report+='\n'+repaired_item+','+item_description+','+repair_cost+',';
		 for(so in get_repairs){
			 total_repairs+= get_repairs[so]
		 }
		 
		 var toata_repairs_per=(total_repairs/total_repair)*100;
		 report+=total_repairs+','+toata_repairs_per+',';
		 var parts=data[item].repaired_items;
		 var total_parts=0;
		 for(var part in parts){
			 total_parts+=parts[part];
		 }
		 var index=0;
		 for(var part in parts){
			 var part_name=part;
			 var part_qty=parts[part];
			 var part_qty_per=(part_qty/total_parts)*100;
			 var part_des=part_description[part_name];
			 if(index==0){
				 report+=part_name+','+part_des+','+part_qty+','+part_qty_per+'\n'
				 index++;
			 }
			 else{
				 report+=',,,,,'+part_name+','+part_des+','+part_qty+','+part_qty_per+'\n'
			 }
			 
		 }
		 if(index==0){
			 report+=',,,\n'
		 }
	 }
}
var csv_report=nlapiCreateFile('Repair_Tracking_Report.csv', 'CSV', report);
nlapiSendEmail(1659, 'govind@webbee.biz', 'Sku Repair', 'Toatal Repairs '+total_repair, null, null, null, [file,file2,csv_report]);

}
function format_csv(innerValue){
	var result='';

if(innerValue){
	        result = innerValue.replace(/,/g, '');
	        result = result.replace(/&gt;/g, '>');
	        result = result.replace(/"/g, '');
	        result = result.replace(/\n/g,'');
	        result = result.replace(/\r/g,'');
	        result = result.replace(/\t/g,'');

}
	  return result;

}