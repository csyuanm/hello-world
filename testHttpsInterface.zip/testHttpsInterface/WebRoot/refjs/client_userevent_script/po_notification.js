/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       21 Mar 2017     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function SendNotification(type){
	try{var nxt_app=nlapiGetFieldValue('nextapprover');
	var po_id=nlapiGetRecordId();
	var user=nlapiGetUser();
	var po_no=nlapiGetFieldValue('tranid');
	var email=nlapiLookupField('employee', nxt_app, 'email');
	nlapiLogExecution('DEBUG', 'na _email', email);
	nlapiLogExecution('DEBUG', 'user id', user);
	var url=nlapiResolveURL('RECORD', 'purchaseorder',po_id,'EDIT');
	url='https://system.na1.netsuite.com'+url;
	nlapiLogExecution('DEBUG', 'url', url);
	nlapiSendEmail(1659,email, po_no+' is Pending Approval', 'You have a Purchase Order to approve. You can log in at\n'+url+' to approve.\n\n Thanks');
	}
	catch(e){
		nlapiLogExecution('DEBUG', 'err', e);
	}
}
