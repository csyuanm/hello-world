/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       19 Apr 2017     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function SetLocation_WRD(type){
	var role=nlapiGetRole();
	var items=nlapiGetLineItemCount('item');
	for(var i=1;i<=items;i++){
		 nlapiSelectLineItem('item', items);
		  nlapiSetCurrentLineItemValue('item', 'location',50, false);
	}
   
}
