/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       23 Mar 2017     Govind
 *
 */

/**
 */
function userEventBeforeLoad(type, form, request){
 var role=nlapiGetRole();
 var customform=nlapiGetFieldValue('customform');
 nlapiLogExecution('DEBUG', 'form', customform);
 if(customform==115){
	 form.addField('custpage_fulfill','checkbox','AUTOFULFILL ON SAVE');
 }
 if(role=='1163'||role=='1170'||role=='1174'||role=='1175'||
	role=='1179'||role=='1180'||role=='1181'||role=='1182'||
	role=='1190'||role=='1193'||role=='1194'){
	 var to_loc=nlapiGetField('transferlocation');
	 to_loc.setDisplayType('disabled');
	 var from_loc=nlapiGetField('location');
	 from_loc.setDisplayType('disabled');
	 var transferlocation = form.addField('custpage_transferlocation','select','To Location');	
//	 transferlocation.setMandatory(true);
	 transferlocation.addSelectOption('','');
	 transferlocation.addSelectOption('2','3B USA : Southbend Primary');
	 transferlocation.addSelectOption('19','3B USA : South Bend Primary : William R CS Return Buffer Zone');
	 if(role=='1163'){
		 transferlocation.addSelectOption('11','3B USA : Southbend Primary : FBA BCO USA');
	 }else if(role=='1170'){
		 transferlocation.addSelectOption('102','3B USA : Southbend Primary : FBA BCO CA');
	 }else if(role=='1175'){
		 transferlocation.addSelectOption('81','3B USA : Southbend Primary : FBA CBCO USA');
	 }else if(role=='1180'||role=='1182'||role=='1179'||role=='1181'||role=='1174'){
		 transferlocation.addSelectOption('54','3B USA : Southbend Primary : FBA BCO EU');
	 }else if(role=='1190'){
		 transferlocation.addSelectOption('53','3B USA : Southbend Primary : FBA DN Amazon');
		 transferlocation.addSelectOption('108','3B USA : Southbend Primary : 3B-LA');
	 }else if(role=='1193'){
		 transferlocation.addSelectOption('12','3B USA : Southbend Primary : FBA SG');
		 transferlocation.addSelectOption('108','3B USA : Southbend Primary : 3B-LA');
	 }
	 else if(role=='1194'){
		 transferlocation.addSelectOption('82','3B USA : Southbend Primary : FBA Gallany');
	 }
	 var location = form.addField('custpage_location','select','From Location');
	 location.addSelectOption('','');
	 location.addSelectOption('2','3B USA : Southbend Primary');
	 location.addSelectOption('19','3B USA : South Bend Primary : William R CS Return Buffer Zone');
	 if(role=='1163'){
		 location.addSelectOption('11','3B USA : Southbend Primary : FBA BCO USA');
	 }else if(role=='1170'){
		 location.addSelectOption('102','3B USA : Southbend Primary : FBA BCO CA');
	 }else if(role=='1190'){
		 location.addSelectOption('53','3B USA : Southbend Primary : FBA DN Amazon');
		 location.addSelectOption('108','3B USA : Southbend Primary : 3B-LA');
	 }else if(role=='1193'){
		 location.addSelectOption('12','3B USA : Southbend Primary : FBA SG');
		 location.addSelectOption('108','3B USA : Southbend Primary : 3B-LA');
	 }else if(role=='1175'){
		 location.addSelectOption('81','3B USA : Southbend Primary : FBA CBCO USA');
	 }else if(role=='1194'){
		 location.addSelectOption('82','3B USA : Southbend Primary : FBA Gallany');
	 }else if(role=='1180'||role=='1182'||role=='1179'||role=='1181'||role=='1174'){
		 location.addSelectOption('54','3B USA : Southbend Primary : FBA BCO EU');
	 }
//	 else if(role=='1174'){
//		 location.addSelectOption('101','USA : Southbend Primary : FBA-BCO UK');	 
//	 } else if(role=='1181'){
//		 location.addSelectOption('99','USA : Southbend Primary : FBA BCO IT');
//	 } else if(role=='1179'){
//		 location.addSelectOption('98','USA : Southbend Primary : FBA BCO FR');
//	 } else if(role=='1182'){
//		 location.addSelectOption('100','USA : Southbend Primary : FBA BCO ES');
//	 } else if(role=='1180'){
//		 location.addSelectOption('97','USA : Southbend Primary : FBA BCO DE');
//	 }

 }
}
function fulfillInternal_IA(){
	try{
	var ia_form=nlapiGetFieldValue('customform');
	var fulfill=nlapiGetFieldValue('custpage_fulfill');
	nlapiLogExecution('DEBUG', 'fulfill',fulfill);
	var ia_id=nlapiGetRecordId();
	if(ia_form==115&&fulfill=='T'){
		var if_rec=nlapiTransformRecord('transferorder', ia_id, 'itemfulfillment', {"customform":"103"});
		if_rec.setFieldValue('shipstatus', 'C')
		if_rec.setFieldValue('custbody_marketplace', '16')
		if_rec.setFieldValue('custbody_storefront_list', '7')
		nlapiSubmitRecord(if_rec, false, true);
	}
	
	}catch(e){
		nlapiLogExecution('DEBUG', 'errr in internal ia fulfill', e);
	}
}