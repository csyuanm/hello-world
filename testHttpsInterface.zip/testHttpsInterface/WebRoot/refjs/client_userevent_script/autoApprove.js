function UPSxml(shipToName, shipToPhoneNumber, shipToAddressLine, shipToCity,
		shipToPostalCode, shipToCountryCode, serviceCode, packageTypeCode,
		unitOfMeasurement, weight, residential) {
	
	var url = 'https://onlinetools.ups.com/ups.app/xml/Rate';
	var XML = "";
	XML += '<?xml version="1.0"?><AccessRequest xml:lang="en-US"><AccessLicenseNumber>1CF3D7AB6CD541A8</AccessLicenseNumber><UserId>zakeusa</UserId><Password>Keepout1</Password></AccessRequest><?xml version="1.0"?><RatingServiceSelectionRequest xml:lang="en-US"><Request><TransactionReference><CustomerContext>Rating and Service</CustomerContext><XpciVersion>1.0</XpciVersion></TransactionReference><RequestAction>Rate</RequestAction><RequestOption>Rate</RequestOption></Request><Shipment><Description>Rate Description</Description><Shipper><Name>abc</Name><PhoneNumber>1234567890</PhoneNumber><ShipperNumber>X865V0</ShipperNumber><Address><AddressLine1>3431 William Richardson dr</AddressLine1><City>south bend</City><StateProvinceCode>IN</StateProvinceCode><PostalCode>46628</PostalCode><CountryCode>US</CountryCode></Address></Shipper><ShipTo><CompanyName>';
	XML += shipToName;
	XML += '</CompanyName>';
	if (residential == true) {
		XML += '<ResidentialAddress/>';
	}
	XML += '<PhoneNumber>';
	XML += shipToPhoneNumber;
	XML += '</PhoneNumber><Address><AddressLine1>';
	XML += shipToAddressLine;
	XML += '</AddressLine1><City>';
	XML += shipToCity;
	XML += '</City><PostalCode>';
	XML += shipToPostalCode;
	XML += '</PostalCode><CountryCode>';
	XML += shipToCountryCode;
	XML += '</CountryCode></Address></ShipTo><ShipFrom><CompanyName>abc</CompanyName><AttentionName>abc</AttentionName><PhoneNumber>1234567890</PhoneNumber><FaxNumber>1234567890</FaxNumber><Address><AddressLine1>3431 William Richardson dr</AddressLine1><City>south bend</City><StateProvinceCode>IN</StateProvinceCode><PostalCode>46628</PostalCode><CountryCode>US</CountryCode></Address></ShipFrom><Service><Code>';
	XML += serviceCode;
	XML += '</Code></Service><PaymentInformation><Prepaid><BillShipper><AccountNumber>Ship Number</AccountNumber></BillShipper></Prepaid></PaymentInformation><Package><PackagingType><Code>';
	XML += packageTypeCode;
	XML += '</Code><Description>Customer Supplied</Description></PackagingType><Description>Rate</Description><PackageWeight><UnitOfMeasurement><Code>';
	XML += unitOfMeasurement;
	XML += '</Code></UnitOfMeasurement><Weight>';
	XML += weight;
	XML += '</Weight></PackageWeight></Package><RateInformation><NegotiatedRatesIndicator/></RateInformation></Shipment></RatingServiceSelectionRequest>';
	nlapiLogExecution("debug", "UPS XML", XML);

	var response = nlapiRequestURL(url, XML);
	nlapiLogExecution("debug", "feild values", response.getBody());

	var xml = nlapiStringToXML(response.getBody());
	var shippingPrice = nlapiSelectValue(
			xml,
			'/RatingServiceSelectionResponse/RatedShipment/NegotiatedRates/NetSummaryCharges/GrandTotal/MonetaryValue');
	if(shippingPrice==''){
		 shippingPrice = nlapiSelectValue(
					xml,
					'/RatingServiceSelectionResponse/RatedShipment/GrandTotal/MonetaryValue');
	}
	nlapiLogExecution("debug", "shippingPrice", shippingPrice);

	return parseFloat(shippingPrice);
}

function USPSxml(service, zipOrigination, zipDestination, weightinOunces, size,
		width, length, height) {

	var zipDestinationList = zipDestination.split("-");
	zipDestination = zipDestinationList[0];
 if(zipDestination.length>5){
	 zipDestination=zipDestination.slice(0,5)
 }
	

	var XML = '';
	XML += '<RateV4Request USERID="4503BTEC1282" ><Revision/><Package ID="1ST"><Service>';
	XML += service;
	XML += '</Service><ZipOrigination>';
	XML += zipOrigination;
	XML += '</ZipOrigination><ZipDestination>';
	XML += zipDestination;
	XML += '</ZipDestination><Pounds>0</Pounds><Ounces>';
	XML += weightinOunces;
	XML += '</Ounces><Container>NONRECTANGULAR</Container><Size>';
	XML += size;
	XML += '</Size><Width>'
	XML += width;
	XML += '</Width><Length>';
	XML += length;
	XML += '</Length><Height>';
	XML += height;
	XML += '</Height><Girth>55</Girth></Package></RateV4Request>'; //

	var url = 'http://production.shippingapis.com/ShippingAPI.dll?API=RateV4&XML='
			+ escape(XML);

	nlapiLogExecution('DEBUG', 'USPS xml created : ', XML);
	var response = nlapiRequestURL(url);
	nlapiLogExecution('DEBUG', 'USPSResponse : ', response.getBody());

	var xml = nlapiStringToXML(response.getBody());
	var shippingPrice = nlapiSelectValue(xml,
			'/RateV4Response/Package/Postage/Rate');
	var shippingPriceCommercial = nlapiSelectValue(xml,
			'/RateV4Response/Package/Postage/CommercialRate');
	shippingPrice = shippingPriceCommercial ? shippingPriceCommercial
			: shippingPrice;
	nlapiLogExecution('DEBUG', 'shippingPrice', shippingPrice)
	if(shippingPrice>0){
		shippingPrice=parseFloat(shippingPrice)
	}
	else{
		shippingPrice=0;
	}
	return shippingPrice;
}

function userEventPendingApprovalAfterSubmit(type, request) {
//	if (type != 'create') {
//		return; // TODO: debug by Allan
//	}

	try {

		// Here Status : Pending Fulfillment : B and Status : Pending Approval :
		// A
		var mail_cc=['josh@3btech.net','matt@3btech.net','nate@3btech.net','govind@webbee.biz'];
		var notMatched = false;
		var clac_shipping=nlapiGetFieldValue('custbody_donot_change_shipping');
		if(clac_shipping=='F')
		{
		var calculateweight = calculateTotalWeight();
		var weight_in_oz = parseFloat(calculateweight[0]);
		nlapiLogExecution('debug', 'weight up', weight_in_oz);
		var unit_of_measurement = calculateweight[1];
		nlapiLogExecution('debug', 'unit_of_measurement', unit_of_measurement);
		var recordType = nlapiGetRecordType();
		var recordId = nlapiGetRecordId();
		var record = nlapiLoadRecord(recordType, recordId);
		var status = nlapiGetFieldValue('orderstatus');
		var shipname = nlapiGetFieldValue('shipattention');
		var shipcity = nlapiGetFieldValue('shipcity');
		var shipaddress = nlapiGetFieldValue('shipaddr1');
		var shipaddress2 = nlapiGetFieldValue('shipaddr2');
		if (!shipaddress2) {
			shipaddress2 = '';
		}
		var shipaddress3 = nlapiGetFieldValue('shipaddr3');
		if (!shipaddress3) {
			shipaddress3 = '';
		}
		var amazon_ordId = nlapiGetFieldValue('otherrefnum');
		var shipzip = nlapiGetFieldValue('shipzip');
		var shipphone = nlapiGetFieldValue('shipphone');
		var shipstate = nlapiGetFieldValue('shipstate');
		var shipcountry = nlapiGetFieldValue('shipcountry');
		var shipcarrier = nlapiGetFieldValue('carrier');
		var shipcost = nlapiGetFieldValue('shippingcost');
		var shippingService = nlapiGetFieldValue('custbody_market_ship_serv_lvl');
		var shipping_expense;
		nlapiLogExecution('DEBUG', 'recordtype :', recordType);
		nlapiLogExecution('DEBUG', 'status : ', status);
		nlapiLogExecution('DEBUG', 'shipaddress :', shipaddress);
		nlapiLogExecution('DEBUG', 'shipaddress2 :', shipaddress2);
		nlapiLogExecution('DEBUG', 'shipaddress3 : ', shipaddress3);
		nlapiLogExecution('DEBUG', 'shippingService :', shippingService);
		nlapiLogExecution('DEBUG', 'shipcountry: ', shipcountry);
		nlapiLogExecution('DEBUG', 'shipcity: ', shipcity);
		nlapiLogExecution('DEBUG', 'shipzip: ', shipzip);
		nlapiLogExecution('DEBUG', 'shipcarrier:', shipcarrier);
		nlapiLogExecution('DEBUG', 'shipcost: ', shipcost);
		try{
            var isResidential = getAddressType();
		if (isResidential == true) {
			var residential_flag = 'T';
		} else {
			var residential_flag = 'F';
		}}
		catch(e){
			var isResidential = false;
			var residential_flag = 'F';
		}
		nlapiLogExecution('DEBUG', 'isResidential : ' + isResidential);

		// code to set residential flag in netsuite according to the value of
		// isResidential
		var customer_id = nlapiGetFieldValue('entity');
		nlapiLogExecution('DEBUG', 'customer_id : ' + customer_id);
		var customer_record = nlapiLoadRecord('customer', customer_id);
		var customer_name = customer_record.getFieldValue('entityid');
		nlapiLogExecution('DEBUG', 'customer_name : ' + customer_name);
		var addressCount = customer_record.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG', 'addressCount : ' + addressCount);
		for (var k = 1; k <= addressCount; k++) {
			var address1 = customer_record.getLineItemValue('addressbook',
					'addr1', k);
			nlapiLogExecution('DEBUG', 'address1 : ' + address1);
			var address2 = customer_record.getLineItemValue('addressbook',
					'addr2', k);
			if (!address2) {
				address2 = '';
			}
			nlapiLogExecution('DEBUG', 'address2 : ' + address2);
			var address3 = customer_record.getLineItemValue('addressbook',
					'addr3', k);
			if (!address3) {
				address3 = '';
			}
			nlapiLogExecution('DEBUG', 'address3 : ' + address3);
			var city = customer_record.getLineItemValue('addressbook', 'city',
					k);
			nlapiLogExecution('DEBUG', 'city : ' + city);
			var country = customer_record.getLineItemValue('addressbook',
					'country', k);
			nlapiLogExecution('DEBUG', 'country : ' + country);
			var zip = customer_record.getLineItemValue('addressbook', 'zip', k);
			nlapiLogExecution('DEBUG', 'zip : ' + zip);
			var residential = customer_record.getLineItemValue('addressbook',
					'isresidential', k);
			nlapiLogExecution('DEBUG', 'residential : ' + residential);
			// var check1 = '1';
			// var check2 = '2';
			if ((shipaddress == address1) && (shipaddress2 == address2)
					&& (shipaddress3 == address3)) {
				nlapiLogExecution("debug", 'im checking');
				customer_record.selectLineItem('addressbook', k);
				customer_record.setCurrentLineItemValue('addressbook',
						'isresidential', residential_flag);
				customer_record.commitLineItem('addressbook');
				nlapiLogExecution('debug', 'checking the if', residential_flag);

			}
		}
		nlapiSubmitRecord(customer_record);
		if ((shippingService == '1') && weight_in_oz <= 14) {
			var column = [];
	    column.push(new nlobjSearchColumn('internalid').setSort(true)); 
	    column.push(new nlobjSearchColumn('custrecord_firstclassparcelcost'));
	    column.push(new nlobjSearchColumn('custrecord_firtsclassmailcost').setSort(false));
	    	var filter = [];
	     filter.push(new nlobjSearchFilter('custrecord_weightupto',null,'lessthanorequalto',(weight_in_oz+1)));
	    	var search = nlapiSearchRecord('customrecord_weightfirstclass',null, filter, column);
	    	if(search!=null){
	    			var firstclassparcel_cost = search[0]
	    					.getValue('custrecord_firstclassparcelcost');
	    			var firstclassmail_cost = search[0]
	    					.getValue('custrecord_firtsclassmailcost');
	    			
	    		}
	    	else{
	    		var firstclassparcel_cost =0;
	    		var firstclassmail_cost =0;
	    		nlapiSendEmail(1659, 'govind@webbee.biz',
	    				'Alert | Auto Approve | Std Order: '
	    						+ amazon_ordId, 'No Cost is calculated for criteria : Standard ShipService & weight='+weight_in_oz, 'aj@webbeeglobal.com');
	    	}
		}
		var uspspriority = '35170';
		var uspspriorityinternational = '35178';
		var uspsprioritycommercial = '35170';
		var uspsfirstclass = '8';
		var uspsfirstclassCommercial = '8';
		var customer_pickup=44246;

		var uspsfirstclassCommercialMailLessThan14 = '35175';

		var upsNextDayAirSaver = '35173';
		var upsNextDaySaver = 35173;
		var upsSecondDayAir = 35171;
		var upsThirdDay = 35174;
		var upsground = 4;

		var uspspriorityforxml = 'Priority CPP';
		var uspsprioritycommercialforxml = 'Priority CPP';
		var uspsfirstclassforxml = 'First Class Commercial';
		var uspsfirstclassCommercialforxml = 'First Class Commercial';
		var upsNextDayAirSaverforxml = '13';
		var upsNextDaySaverforxml = '13';
		var upsSecondDayAirforxml = '02';
		var upsThirdDayforxml = '12';
		var upsgroundforxml = '03';

		var upsshipcarrier = 'ups';
		var uspsshipcarrier = 'noups';
		var isEnvelope = nlapiGetFieldValue('custitem_fc_envelope_capable');
		if (!shippingService || shippingService == "") {
			nlapiLogExecution('ERROR',
					'Error: returning due to no shipservice level variable ',
					"Error: returning due to no shipservice level variable");
			return true;

		}
		nlapiLogExecution('debug', 'record type for condition', recordType);
		nlapiLogExecution('debug', 'status for condition', status);
		nlapiLogExecution('debug', 'shipaddress type for condition',
				shipaddress);
		nlapiLogExecution('debug', 'shipcountry type for condition',
				shipcountry);
		nlapiLogExecution('debug', 'ship service type for condition',
				shippingService);

		// status = 'A';

		if (recordType == 'salesorder') {
			nlapiLogExecution('debug', 'i am in first if');

			if (shipaddress && shipaddress != null) {
				nlapiLogExecution('debug', 'i am in second if');

				if (shipcountry == 'US') {
					var is_apo=check_apo(shipaddress);
		            if(is_apo=='T'){
		            	  
		                       var service = uspspriorityforxml;
		                       record.setFieldValue('shipmethod', uspspriority);
		                   
		                   
		                   var zipOrigination = '46628';
		                   var zipDestination = shipzip;
		                   var weightinOunces = weight_in_oz;
		                   var size = 'LARGE';
		                   var width = 6;
		                   var length = 3;
		                   var height = 8;
		                   var uspsrate = USPSxml(service, zipOrigination,
		                       zipDestination, weightinOunces, size, width,
		                       length, height);
		                   var shipcostchange=uspsrate;
		            }
				else
				{
					if((weight_in_oz * 0.062500)>70){
						
						var shipToName = shipname;
						var shipToPhoneNumber = shipphone;
						var shipToAddressLine = shipaddress;
						var shipToCity = shipcity;
						var shipToPostalCode = shipzip;
						var shipToCountryCode = shipcountry;
						var serviceCode = upsgroundforxml;
						var packageTypeCode = '02';
						var unitOfMeasurement = 'LBS';
						var weight = weight_in_oz * 0.062500; // for ounce
						var residential = isResidential;
						var upsrate = UPSxml(shipToName, shipToPhoneNumber,
								shipToAddressLine, shipToCity,
								shipToPostalCode, shipToCountryCode,
								serviceCode, packageTypeCode,
								unitOfMeasurement, weight, residential);
						if (shippingService == 3)
						{record.setFieldValue('shipmethod', upsSecondDayAir);}
						else if(shippingService==2){
							{record.setFieldValue('shipmethod', upsThirdDay);}

						}
						else if(shippingService==1)
						{record.setFieldValue('shipmethod', upsground);}
						else if(shippingService==4)
						{record.setFieldValue('shipmethod', upsNextDaySaver);}
						nlapiLogExecution('debug', 'ups rate',upsrate);

						if(upsrate>0)
						record.setFieldValue('custbody_shipping_expense',
								upsrate);
						nlapiSubmitRecord(record);
						return true;
					}
					else{
					nlapiLogExecution('debug', 'i am in third if');

					if (shippingService == 2 && shippingService == 0) {
						if (residential_flag == 'T') {
							var service = uspspriorityforxml;
						} else {
							var service = uspsprioritycommercialforxml;
						}
						var zipOrigination = '46628';
						var zipDestination = shipzip;
						var weightinOunces = weight_in_oz;
						var size = 'LARGE';
						var width = 6;
						var length = 3;
						var height = 8;
						var shipcostchange = USPSxml(service, zipOrigination,
								zipDestination, weightinOunces, size, width,
								length, height);
						record.setFieldValue('shipmethod', uspspriority);

					}
					 
					else if (shippingService == '1') {
						if (weight_in_oz <= 14) {
							if (weight_in_oz <= 3.5 && (isEnvelope == 'T')) {
								var service = uspsfirstclassCommercialforxml;
								record.setFieldValue('shipmethod',
										uspsfirstclassCommercial);
							
								var zipDestination = shipzip;
								var weightinOunces = weight_in_oz;
								var size = 'LARGE';
								var width = 6;
								var length = 3;
								var height = 8;
								var shipcostchange = firstclassmail_cost;
								nlapiLogExecution("debug", "Setting USPS ",
										uspsfirstclassletter);
							} else {
								var service = uspsfirstclassCommercialforxml;
								record.setFieldValue('shipmethod',
										uspsfirstclassCommercial);
								
								var zipOrigination = '46628';
								var zipDestination = shipzip;
								var weightinOunces = weight_in_oz;
								var size = 'LARGE';
								var width = 6;
								var length = 3;
								var height = 8;
								var shipcostchange = firstclassparcel_cost;
							
							}
							
						} else if (weight_in_oz > 14) {
							if (residential_flag == 'T') {
								var service = uspspriorityforxml;
								record
										.setFieldValue('shipmethod',
												uspspriority);
							} else {
								var service = uspsprioritycommercialforxml;
								record.setFieldValue('shipmethod',
										uspsprioritycommercial);
							}
							var zipOrigination = '46628';
							var zipDestination = shipzip;
							var weightinOunces = weight_in_oz;
							var size = 'LARGE';
							var width = 6;
							var length = 3;
							var height = 8;
							var uspsrate = USPSxml(service, zipOrigination,
									zipDestination, weightinOunces, size,
									width, length, height);
							
							var shipToName = shipname;
							var shipToPhoneNumber = shipphone;
							var shipToAddressLine = shipaddress;
							var shipToCity = shipcity;
							var shipToPostalCode = shipzip;
							var shipToCountryCode = shipcountry;
							var serviceCode = upsgroundforxml;
							var packageTypeCode = '02';
							var unitOfMeasurement = 'LBS';
							var weight = weight_in_oz * 0.062500; // for ounce
							var residential = isResidential;
							var upsrate = UPSxml(shipToName, shipToPhoneNumber,
									shipToAddressLine, shipToCity,
									shipToPostalCode, shipToCountryCode,
									serviceCode, packageTypeCode,
									unitOfMeasurement, weight, residential);
							if (uspsrate != null && upsrate != null) {
								upsrate = parseFloat(upsrate);
								uspsrate = parseFloat(uspsrate);
							}
							if (uspsrate==0||upsrate==0) {
								nlapiLogExecution("debug", 'upsrate', upsrate);
								record.setFieldValue('shipmethod', upsground);
								shipcostchange = upsrate;
							} 
							else if (upsrate < uspsrate) {
								nlapiLogExecution("debug", 'upsrate', upsrate);
								record.setFieldValue('shipmethod', upsground);
								shipcostchange = upsrate;
							} else {
								nlapiLogExecution("debug", 'uspsrate', uspsrate);

								shipcostchange = uspsrate;
								
							}
						}
					} else if (shippingService == '4') {
						var shipToName = shipname;
						var shipToPhoneNumber = shipphone;
						var shipToAddressLine = shipaddress;
						var shipToCity = shipcity;
						var shipToPostalCode = shipzip;
						var shipToCountryCode = shipcountry;
						var serviceCode = upsNextDaySaverforxml;
						var packageTypeCode = '02';
						var unitOfMeasurement = 'LBS';
						var weight = weight_in_oz * 0.062500; // for ounce
						var residential = isResidential;
						var shipcostchange = UPSxml(shipToName,
								shipToPhoneNumber, shipToAddressLine,
								shipToCity, shipToPostalCode,
								shipToCountryCode, serviceCode,
								packageTypeCode, unitOfMeasurement, weight,
								residential);
						record.setFieldValue('shipmethod', upsNextDaySaver);
					} else if (shippingService == '5') {
						nlapiLogExecution('debug', 'shippingService',shippingService);

						var weightinOunces = weight_in_oz;
						if (weightinOunces > 15) {
							var service = uspspriorityforxml;
							record.setFieldValue('shipmethod',
									uspspriorityinternational);
						} else {
							var service = uspspriorityforxml;
							record.setFieldValue('shipmethod',
									uspspriorityinternational);
						}
						var zipOrigination = '46628';
						var zipDestination = shipzip;
						var size = 'LARGE';
						var width = 6;
						var length = 3;
						var height = 8;
						var shipcostchange = USPSxml(service, zipOrigination,
								zipDestination, weightinOunces, size, width,
								length, height);
					} else if (shippingService == '3') {
						var shipToName = shipname;
						var shipToPhoneNumber = shipphone;
						var shipToAddressLine = shipaddress;
						var shipToCity = shipcity;
						var shipToPostalCode = shipzip;
						var shipToCountryCode = shipcountry;
						var serviceCode = upsSecondDayAirforxml;
						var packageTypeCode = '02';
						var unitOfMeasurement = 'LBS';
						var weight = weight_in_oz * 0.062500; // for ounce
						var residential = isResidential;
						var shipcostchange = UPSxml(shipToName,
								shipToPhoneNumber, shipToAddressLine,
								shipToCity, shipToPostalCode,
								shipToCountryCode, serviceCode,
								packageTypeCode, unitOfMeasurement, weight,
								residential);
						record.setFieldValue('shipmethod', upsSecondDayAir);
					} else if (shippingService == '2') {
						if (residential_flag == 'T') {
							var service = uspspriorityforxml;
						} else {
							var service = uspsprioritycommercialforxml;
						}
						var shipToName = shipname;
						var shipToPhoneNumber = shipphone;
						var shipToAddressLine = shipaddress;
						var shipToCity = shipcity;
						var shipToPostalCode = shipzip;
						var shipToCountryCode = shipcountry;
						var serviceCode = upsThirdDayforxml;
						var packageTypeCode = '02';
						var unitOfMeasurement = 'LBS';
						var weight = weight_in_oz / 16; // for ounce
						var residential = isResidential;
						var upsrate = UPSxml(shipToName, shipToPhoneNumber,
								shipToAddressLine, shipToCity,
								shipToPostalCode, shipToCountryCode,
								serviceCode, packageTypeCode,
								unitOfMeasurement, weight, residential);
						var zipOrigination = '46628';
						var zipDestination = shipzip;
						var weightinOunces = weight_in_oz;
						var size = 'LARGE';
						var width = 6;
						var length = 3;
						var height = 8;
						var uspsrate = USPSxml(service, zipOrigination,
								zipDestination, weightinOunces, size, width,
								length, height);
						if (uspsrate==0||upsrate==0) {
							record.setFieldValue('shipmethod', upsThirdDay);
							shipcostchange = upsrate;
							
						} 
						else if(upsrate < uspsrate) {
							record.setFieldValue('shipmethod', upsThirdDay);
							shipcostchange = upsrate;
							
						}
						else{

							record.setFieldValue('shipmethod', uspspriority);
							shipcostchange = uspsrate;
						
						}
					}
					else if (shippingService == '7'){
						var url=nlapiResolveURL('RECORD', 'salesorder',recordId);
						url='https://system.na1.netsuite.com'+url;
						nlapiLogExecution('DEBUG','url',url);
					    nlapiSendEmail(1659, 'aj@webbeeglobal.com', 'Local Pickup Notification | Zake', 'Shipping method is Customer Pickup for this Salesorder\n '+url, mail_cc);
						
						record.setFieldValue('shipmethod', customer_pickup);

					}

					else {
						nlapiLogExecution("debug", "Not changing SO Status",
								"Setting condition false");
						notMatched = true;
					}
			
				}
				}
		    		if (notMatched == false) {
						nlapiLogExecution('debug', 'shpiexpense',
								shipcostchange);
						nlapiLogExecution("debug", "changing SO Status",
								"as the condition is true");
						// record.setFieldValue('orderstatus', 'B'); // By Allan
						record.setFieldValue('shippingcost', shipcost);
						if (shipcostchange == undefined) {
							shipcostchange = 0;
							nlapiSendEmail(1659, 'govind@webbee.biz',
									'auto approve ',
									'Shipping Expense is undefined for Amazon Order Id: '
											+ amazon_ordId,
									'aj@webbeeglobal.com');
						}
						record.setFieldValue('custbody_shipping_expense',
								shipcostchange);
						nlapiSubmitRecord(record);
					}
				}
			}
		}
	}} catch (err) {
		nlapiSendEmail(1659, 'govind@webbee.biz',
				'Err: in Zake Auto Approve for Amazon Order Id: '
						+ amazon_ordId, err, 'aj@webbeeglobal.com');
	}
}

function calculateTotalWeight() {

	var lines = nlapiGetLineItemCount('item');
	var totalWeight = 0;

	for (var i = 1; i <= lines; i++) {
		var itemid = nlapiGetLineItemValue('item', 'item', i);

		var lineitem = nlapiLookupField("item", itemid, [ "weight" ]);
		var weight = lineitem.weight ? lineitem.weight : 0;

		var unit_of_measurement = nlapiLookupField("item", itemid, 'weightunit');
		var shipindividually = nlapiLookupField("item", itemid, 'shipindividually');

		if (unit_of_measurement == 1) // lbs
		{
			weight = weight * 16;
		} else if (unit_of_measurement == 3) // kg
		{
			weight = weight * 35.274;
		} else if (unit_of_measurement == 4) // gms
		{
			weight = weight * 0.035274;
		}

		var quantity = nlapiGetLineItemValue('item', 'quantity', i);
		if(shipindividually=='F')
		{
			var weightTimesQuantity = weight * quantity;
			}
		else{
			var weightTimesQuantity = weight;
		}
		totalWeight = totalWeight + weightTimesQuantity;

		nlapiLogExecution('DEBUG', 'Id' + itemid + 'Weight : ' + weight
				+ 'Total Weight ' + totalWeight + ' Quantity : ' + quantity);
	}
	var calculateweight = [ totalWeight, unit_of_measurement ];
	return calculateweight;

}

function getAddressType() {
	// return false;

	var customer = new Array();
	var city = nlapiGetFieldValue('shipcity');
	var street = nlapiGetFieldValue('shipaddr1');
	var zipcode = nlapiGetFieldValue('shipzip');
	var state = nlapiGetFieldValue('shipstate');

	// nlapiLogExecution('DEBUG', 'City : '+city+' Street : '+street+' Zipcode :
	// '+zipcode+' State : '+state) ; // StudentRecord.setFieldValue(
	// 'custrecord_sname', sname);

	var url = 'https://api.smartystreets.com/street-address?auth-id=81662d0d-4945-4c3a-84fc-62fb8f2d0ff7&auth-token=sTZeYEyqBQZWbR8lims4&street='
			+ escape(street) + '&city=' + escape(city) + '&state=' + state;
	var response = nlapiRequestURL(url);
	if (response.getBody().indexOf('"rdi":"Residential"') > 1) {
		// nlapiLogExecution('DEBUG', 'Response : ',url+response.getBody());
		// nlapiSendEmail(-5, -5, 'Response Data', response.getBody());
		return true;
	} else {
		return false;
	}
}
function check_apo(shipaddress)
{
	var is_apo='F';
	if(shipaddress.match(/^PO\W/)||shipaddress.match(/^P.O\W/)||shipaddress.match(/^P O\W/))
	{is_apo='T';}
	return is_apo;
}