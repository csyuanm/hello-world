/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       17 Nov 2015     govind
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function submitbuttonclicked(type,name){
	alert(name);
//	return true;
//if(name!=""){
//	
//}
	var jsonData = nlapiGetFieldValue('custpage_textarea');
	var filtertext;
	try {
		filtertext = JSON.parse(jsonData);
	} catch (e) {
		alert('Please contact admin, some error occured');
		return true;
	}
	if (!filtertext) {
		alert('Submission cannot be performed now. Please contact addminsitrator');
		return true;
	}
   var sku=filtertext.sku;
   var asin=filtertext.asin;
   var amzn_accnt=filtertext.acount;
   var amzn_site=filtertext.site;
   var column =[];
   column.push(new nlobjSearchColumn('custrecord_amazon_marketplace_id'));
   var filter =[];
   filter.push(new nlobjSearchFilter('internalid',null,'is',amzn_site));
   var search_result2=nlapiSearchRecord('customrecord_amazon_global_sites',null, filter, column);
   if(search_result2!=null){
   var marketId=search_result2[0].getValue('custrecord_amazon_marketplace_id');
   nlapiLogExecution('DEBUG','mktid',marketId);
   
   
	var columns = [];
	columns.push(new nlobjSearchColumn('custrecord_amazon_seller_id'));
	columns.push(new nlobjSearchColumn('custrecord_aws_access_key_id'));
   columns.push(new nlobjSearchColumn('custrecord_secret_key'));
   var filters =[];
   filters.push(new nlobjSearchFilter('custrecord_amazon_seller_id',null,'isnotempty'));
   filters.push(new nlobjSearchFilter('isinactive',null,'is','F'));
   filters.push(new nlobjSearchFilter('internalid',null,'is',amzn_accnt));

	var search_result=nlapiSearchRecord('customrecord_amazon_accounts',null, filters, columns);
	if(search_result!=null){
        var sellerId=search_result[0].getValue('custrecord_amazon_seller_id');
		var awsKey=search_result[0].getValue('custrecord_aws_access_key_id');
		var securityKey=search_result[0].getValue('custrecord_secret_key');
		   nlapiLogExecution('DEBUG','sellerId',sellerId);
		   nlapiLogExecution('DEBUG','awsKey',awsKey);
		   nlapiLogExecution('DEBUG','securityKey',securityKey);

	}
   
		   }
   var timestamp =new Date();
   timestamp=timestamp.toISOString();
   timestamp=encodeURIComponent(timestamp);
   
   		var feed='<?xml version="1.0" encoding="utf-8"?> <AmazonEnvelope>   <Header>     <DocumentVersion>1.01</DocumentVersion>     <MerchantIdentifier>Webbee</MerchantIdentifier>   </Header>   <MessageType>Product</MessageType>     <Message>     <MessageID>1</MessageID>     <OperationType>Update</OperationType>     <Product>       <SKU>'+sku+'</SKU>       <StandardProductID>         <Type>ASIN</Type>         <Value>'+asin+'</Value></StandardProductID> </Product>   </Message> </AmazonEnvelope>           ';
   		var item_md5=CryptoJS1.MD5(feed);
   		var item_md5b64 = CryptoJS.enc.Base64.stringify(item_md5);
   		
   		var queryString="AWSAccessKeyId="+awsKey
   		+"&Action=SubmitFeed"
   		+"&FeedType=_POST_PRODUCT_DATA_"
   		+"&MarketplaceId.Id.1=764574542755"
   		+"&Merchant="+sellerId
   		+"&PurgeAndReplace=false"
   		+"&SignatureMethod=HmacSHA256"
   		+"&SignatureVersion=2"
   		+"&Timestamp="+timestamp
   		+"&Version=2009-01-01";
	var porduct_string = "POST\nmws.amazonservices.com\n/\n"+queryString;
	var hash = CryptoJS.HmacSHA256(porduct_string, securityKey);
	var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);
	hashInBase64 = encodeURIComponent(hashInBase64);
	var headers = new Array();
	headers['User-Agent-x'] = 'AmazonJavascriptScratchpad/1.0 (Language=Javascript)';
	headers['Content-MD5'] = item_md5b64;
	headers['Content-Type'] = 'text/xml';		
	var response = nlapiRequestURL('https://mws.amazonservices.com?'+ queryString+"&Signature="+hashInBase64,feed,headers);
	nlapiLogExecution('DEBUG','response' , response.getBody());
	alert('Product Xml submitted');
}
