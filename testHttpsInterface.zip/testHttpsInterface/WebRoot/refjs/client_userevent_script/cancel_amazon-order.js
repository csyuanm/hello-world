/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       11 Apr 2016     Admin
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function cancel_order(){

	if(confirm("Important!!\nThis Will Canclel Order from Amazon."))
	{
		
		var nsid=nlapiGetRecordId();
		var obj=nlapiLoadRecord('salesorder', nsid);
		var marketplace = obj.getFieldValue('custbody_marketplace');
		var amazon_oredrid=obj.getFieldValue('custbody_storefront_order');
		var cancel_reason=nlapiGetFieldText('custbody_ordercancelreason');
		var cancel_checkbox = obj.getFieldValue('custbody_cancelorder');
		var amazon_ac = obj.getFieldValue('custbody_orderfrom');
		var tranid = obj.getFieldValue('tranid');
		var marketplace = obj.getFieldValue('custbody_marketplace');
	


		if(marketplace==2)
	{
		var xml_feed = '<?xml version="1.0" ?><AmazonEnvelope>'
			+ '<Header><DocumentVersion>1.01</DocumentVersion><MerchantIdentifier>Webbee</MerchantIdentifier>'
			+ '</Header><MessageType>OrderAcknowledgement</MessageType>'
			+ '<Message>'
			+ '<MessageID>1</MessageID>'
			+ '<OrderAcknowledgement>'
			+ '<AmazonOrderID>'+amazon_oredrid+'</AmazonOrderID>'
			+ '<MerchantOrderID>'+tranid+'</MerchantOrderID>'
			+ '<StatusCode>Failure</StatusCode>'

		var line_item_count=obj.getLineItemCount('item');
		nlapiLogExecution('DEBUG', 'line_item_count',line_item_count );
		var flag=0;
		for(var i=1;i<=line_item_count;i++)
		{
			var amazon_itemid=obj.getLineItemValue('item', 'custcol_amazon_itemid', i);
			var quantity=obj.getLineItemValue('item', 'quantity', i);

	
			xml_feed+='<Item>'
		+ '<AmazonOrderItemCode>'+amazon_itemid+'</AmazonOrderItemCode>'
		+ '</Item>';
		}
				       
		xml_feed += '</OrderAcknowledgement></Message></AmazonEnvelope>';
		       //cancel_order_request(amazon_account,feed);

//		   	var newAttachment = nlapiCreateFile('feedresult.txt',
//		   			'PLAINTEXT', xml_feed);



	
		   	var item_md5 = CryptoJS1.MD5(xml_feed);
		   	var item_md5b64 = CryptoJS.enc.Base64
		   			.stringify(item_md5);

		   	var timestamp = new Date();
		   	timestamp = timestamp.toISOString();
		   	timestamp = encodeURIComponent(timestamp);

		   	var 
		   	columns = [];
		   	columns.push(new nlobjSearchColumn('name'));
		   	columns.push(new nlobjSearchColumn('custrecord_amazon_seller_id'));
		   	columns.push(new nlobjSearchColumn('custrecord_aws_access_key_id'));
		   	columns.push(new nlobjSearchColumn('custrecord_secret_key'));
		   	columns.push(new nlobjSearchColumn('custrecord_fbm_warehouse'));
		   	columns.push(new nlobjSearchColumn('custrecord_amz_fba_warehouse'));
		   	columns.push(new nlobjSearchColumn('custrecord_fba_invoice_form'));
		   	columns.push(new nlobjSearchColumn('custrecord_mfn_salesorder_form'));
		   	columns.push(new nlobjSearchColumn('custrecord_amazon_enabled_sites'));
		   	columns.push(new nlobjSearchColumn('custrecord_accounts_receivable_account'));
		   	var filters = [];
		   	filters.push(new nlobjSearchFilter('custrecord_amazon_seller_id', null,
		   			'isnotempty'));
		   	filters.push(new nlobjSearchFilter('internalid', null, 'is', amazon_ac));
		   	var search_result = nlapiSearchRecord('customrecord_amazon_accounts', null,
		   			filters, columns);
		   	var sellerId = search_result[0].getValue('custrecord_amazon_seller_id');
		   	var awsKey = search_result[0].getValue('custrecord_aws_access_key_id');
		   	var securityKey = search_result[0].getValue('custrecord_secret_key');
		   	var actname = search_result[0].getValue('name');
		   	var site = search_result[0].getText('custrecord_amazon_enabled_sites');
		   	var column = [];
		   	column.push(new nlobjSearchColumn(
		   			'custrecord_amazon_marketplace_id'));
		   	var filter = [];
		   	filter.push(new nlobjSearchFilter('name', null, 'is',
		   			site));
		   	var search_result2 = nlapiSearchRecord(
		   			'customrecord_amazon_global_sites', null,
		   			filter, column);
		   	if (search_result2 != null) {
		   		var marketId = search_result2[0]
		   				.getValue('custrecord_amazon_marketplace_id');}



		   	
		   	var queryString = "AWSAccessKeyId="
		   		+ awsKey
		   		+ "&Action=SubmitFeed"
		   		+ "&FeedType=_POST_ORDER_ACKNOWLEDGEMENT_DATA_"
		   		+ "&MarketplaceId.Id.1=" + marketId
		   		+ "&Merchant=" + sellerId
		   		+ "&PurgeAndReplace=false"
		   		+ "&SignatureMethod=HmacSHA256"
		   		+ "&SignatureVersion=2" + "&Timestamp="
		   		+ timestamp + "&Version=2009-01-01";
		   		nlapiLogExecution('DEBUG', 'queryString',queryString );
		   		
		   		var feed_string = "POST\nmws.amazonservices.com\n/\n"
		   			+ queryString;
		   	var hash = CryptoJS.HmacSHA256(feed_string,
		   			securityKey);

		   	var hashInBase64 = CryptoJS.enc.Base64
		   			.stringify(hash);
		   	hashInBase = encodeURIComponent(hashInBase64);
		   	nlapiLogExecution('DEBUG', 'hashInBase',hashInBase );
		   	nlapiLogExecution('DEBUG', 'item_md5b64',item_md5b64 );

		   	var headers = new Array();
		   	headers['User-Agent-x'] = 'AmazonJavascriptScratchpad/1.0 (Language=Javascript)';
		   	headers['Content-MD5'] = item_md5b64;
		   	headers['Content-Type'] = 'text/xml';
		   try{
		   	var itemresponse = nlapiRequestURL('https://mws.amazonservices.com?'
		   					+ queryString + "&Signature="
		   					+ hashInBase,xml_feed, headers);
		   	nlapiLogExecution('DEBUG', 'queryString',queryString );


		   	var itemxml = nlapiStringToXML(itemresponse
		   			.getBody());
		   	var itemfeed_requestid = itemxml
		   			.getElementsByTagName('FeedSubmissionId')
		   			.item(0).textContent;
		   	alert('ordercancel_requestid:'+itemfeed_requestid);
		   		
		   	 nlapiSendEmail(1659, 'govind@webbee.biz',
		   			 'Cancel order request'
		   			 + ' | '+ itemfeed_requestid +'|'+ actname,
		   			 'XML FEED Attached\n\n'+xml_feed, 'aj@webbeeglobal.com', null, null);	
		   }

		   catch (e) {
		   	alert('err:'+e)
		   }


		       

		
	}
		
    }
	else{
    	return false;
    }
	
}


function display_button(type, form, request)
{
	try
	{var so_id=nlapiGetRecordId();
	var marketplace=nlapiLookupField('salesorder', so_id, 'custbody_marketplace', true)
	var form_id=nlapiLookupField('salesorder', so_id,'customform')
	var parent_so=nlapiLookupField('salesorder', so_id, 'custbody_parent_sales_order');
	var status=nlapiLookupField('salesorder', so_id,'statusref');
	
	nlapiLogExecution('DEBUG', 'salesorder',so_id)
		nlapiLogExecution('DEBUG', 'status',status);

              if(type == 'view'&&marketplace=='Amazon'&&((form_id==199)||(form_id==263)||(form_id==313))&&parent_so==''&&status!='fullyBilled')
             {
                  var script = "alert('Hello World')";
               form.addButton('custpage_button_complete', 'Cancel On Amazon','cancel_order();');
		     form.setScript("customscript_cancel_amazon_order_buttton");
		
             }
		
	}
	catch(ex)
	{
		nlapiLogExecution('DEBUG', 'Exception : '+ex.name, ex.message);
	}
 
}
