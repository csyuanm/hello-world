/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Aug 2017     Admin
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function createCloseButton(type, form, request){
	
	if(type !='create'){
		var recId=nlapiGetRecordId();
		var recTyp=nlapiGetRecordType();
		var rec=nlapiLoadRecord(recTyp, recId)
		 var status=rec.getFieldValue('status');
		 nlapiLogExecution('DEBUG', status, status);
		 alert('status '+status);
		if(status!=5) {
	var closeCase = "closeCase();";

		form.addButton('custpage_sent','Close Case',closeCase);
		form.setScript('customscript_gotohome_page');

	}}

	
}
function closeCase(){
	var recId=nlapiGetRecordId();
	var recTyp=nlapiGetRecordType();
	var rec=nlapiLoadRecord(recTyp, recId)
	rec.setFieldValue('status', '5', false);
	nlapiSubmitRecord(rec, false, true);
	var url='/app/center/card.nl?sc=-29&whence=';
    var initURL = window.location.origin +url;
    
    window.location = initURL;

	
	

}
