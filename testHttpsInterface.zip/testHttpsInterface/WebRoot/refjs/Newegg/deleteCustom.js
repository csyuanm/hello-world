/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       17 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
	var filter = [];
    var search = nlapiSearchRecord('customrecord_newegg_itemlisting',null,filter);
    
    if(search){
    	for(var i = 0;i<search.length;i++){
    		var id = search[i].getId();
    		
    		nlapiDeleteRecord('customrecord_newegg_itemlisting',id);
    		nlapiLogExecution('Debug','id and nums',id+ ": "+i)
    		
    	}
    }
}
