/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       16 Jan 2017     ratul
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Operation types: create, edit, delete, xedit,
 *                      approve, cancel, reject (SO, ER, Time Bill, PO & RMA only)
 *                      pack, ship (IF only)
 *                      dropship, specialorder, orderitems (PO only) 
 *                      paybills (vendor payments)
 * @returns {Void}
 */
function userEventAfterSubmit(type){
      
	try{
		if(type == "edit"){
			var checked = nlapiGetFieldValue('custrecord_recreate_order');
			
			if(checked == "T"){
				var orderData = nlapiGetFieldValue('custrecord_order_object');
				var accId = nlapiGetFieldValue('custrecord_newegg_acc');
				nlapiLogExecution('Debug','obj',orderData)
				var fromUI = "T"
				var  data = JSON.parse(orderData)
				var obj = start(data,accId,fromUI)
				nlapiLogExecution('Debug','obj',JSON.stringify(obj))
				if(obj.status === "created" || obj.status === "exists"){
					 
		    		nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(),'custrecord_created_order',obj.id);
		    		nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(),'custrecord_recreate_order','F') 
					
				}else if(obj.status === "Failed"){
					nlapiSubmitField(nlapiGetRecordType(), nlapiGetRecordId(),'custrecord_recreate_order','F')
					 
				}
			}
		}
	}catch(e){
		nlapiLogExecution('Debug','error in script',e)
	}
	
}
