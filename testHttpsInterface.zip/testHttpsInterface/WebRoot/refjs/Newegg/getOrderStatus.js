/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       09 Feb 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
var ids = ['225360449','225367029','225370509','225383249','225388129','225409469','225430369','225431669','225432549','225435709','225449289','225464369','225478429','225481129','225494409','225496569','233662899','233676239','233680599','233681079','233686059','233686779','233696819','233708819','233722419','233734859','233734999','233755759','233760899','264972024','264972864','264978624','264982324','264995784','265003124','265014844','265032644','265052204','265058464','265072504','265091164','265092324','282062263','282098963','282100223','282101563','282102803','282138543','282160443','282220483','282230883','282236803','282239623','282265743','282272243','282275683','282285963','282325323','289129556','289186056','289186356','289194396','289197836','289206156','289209976','289219096','289224976','289239256','289240236','296782377','296788517','296799297','296818917','296823697','301612575','301740075','301740215','301751875','301753515','301762535','301763715','301765195','301765835','301768735','301796975','301798895','301810755','301814255','301850015','301856875','327181558','327185238','327220818'];



function scheduled(type) {
   
//	var search = nlapiLoadSearch('transaction','1999');
//	var columns = search.getColumns();
//	
//	var resultSet = search.runSearch();
//	var result = resultSet.getResults(0,1000);
//	nlapiLogExecution('Debug','results length',result.length);
//	
//	var headers = {
//		    "Authorization": "30c21d2c04780175954eb9d6138ad552",
//		    "SecretKey": "954960cb-09b1-4342-a110-6f8077c2a8b8",
//		    "Content-Type": "application/json"
//		  }
	
for(var i = 0 ;i<ids.length;i++){
		
	var search = nlapiLoadSearch('transaction','1999');
	search.addFilter(new nlobjSearchFilter('poastext','createdfrom','is',ids[i]))
	var columns = search.getColumns();
	
	var resultSet = search.runSearch();
	var result = resultSet.getResults(0,1000);
	nlapiLogExecution('Debug','results length',result.length);
	
	for(var j=0;j<result.length;j++){
		
		var recId = result[j].getId();
		nlapiLogExecution('Debug','recID',recId);
		nlapiSubmitField('itemfulfillment',recId,'custbody_tracking_number_sync','F')
		
	}	
	
	}
	
}





function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}

