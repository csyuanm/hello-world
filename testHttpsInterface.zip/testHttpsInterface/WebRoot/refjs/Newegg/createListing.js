/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       17 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
	
	var file = nlapiLoadFile("1548616");
    var data = file.getValue();
	var csv =new CSV(data).parse();
	
	for(var i = 0;i<csv.length;i++){
		
			
			var itemSku = csv[i][0];
			var newEggId = csv[i][1];
			var acc = csv[i][3]; 
			var internalId = csv[i][4];
			

			var rec = nlapiCreateRecord("customrecord_newegg_itemlisting",{"recordmode":"dynamic"});

			rec.setFieldValue("custrecord_newegg_item",internalId);
			rec.setFieldValue("custrecord_newegg_item_sku",itemSku);
			rec.setFieldValue("custrecord_newegg_item_acc",acc);
			rec.setFieldValue("custrecord_newegg_item_id",newEggId);

			var id = nlapiSubmitRecord(rec,false,true);
			nlapiLogExecution('Debug','id',id);
	}
	
	
}
