/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       15 Dec 2016     Admin
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
var b2b="/b2b";
function requestReport(type) {

	 //try{
		
	  var obj = nlapiGetContext();
	  var newegg_actid = obj.getSetting('SCRIPT', 'custscript4');
	  nlapiLogExecution('DEBUG', 'newegg_actid', newegg_actid);
	   if(newegg_actid==1){
	     b2b='';
	   }
	  var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_sellerid',
	    'custrecord_newegg_marketplace', 'custrecord_newegg_soform', 'custrecord_newegg_subsidiary',
	    'custrecord_accounts_receivable', 'custrecord_newegg_location', 'custrecord_newegg_storefront',
	    'custrecord_orderreportid', 'custrecord_last_orderreport_time'
	  ];
	  var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	  var sellerId = columns.custrecord_newegg_sellerid;
	  var SecretKey = columns.custrecord_secretkey;
	  var authKey = columns.custrecord_authorization_key;
	  
	  var subsidiary = columns.custrecord_newegg_subsidiary; 
	  var location = columns.custrecord_newegg_location;
	  var storefront = columns.custrecord_newegg_storefront;
	  var reportId = columns.custrecord_orderreportid;
	  var lastReporttime = columns.custrecord_last_orderreport_time;
	  
	  var headers = {
	    "Authorization": authKey,
	    "SecretKey": SecretKey,
	    "Content-Type": "application/json"
	  }
	 {
	  
	        nlapiLogExecution('Debug', 'GetReport Data');
	        var reportData =  GetReportData(sellerId, headers,columns);
	        nlapiLogExecution('Debug', 'report Data length',reportData.length);
	        var soData = [];
	        var fromUI = "F"
	        for(var i = 0 ;i<reportData.length;i++){
	        	
	        	var data = start(reportData[i],newegg_actid,fromUI);
	        
	        		soData.push(data);
	        	
	        }
	        nlapiLogExecution('Debug', 'SO Data',JSON.stringify(soData));        
	                nlapiLogExecution('Debug', 'script ends here','<<<--->>>');
	  
	      

	    }
	  

}




function GetReportData( sellerId, headers,columns) {
 
//	try {
	  var marketplace = columns.custrecord_newegg_marketplace;
	  var so_form = columns.custrecord_newegg_soform;
	  var location = columns.custrecord_newegg_location;
	  var storefront = columns.custrecord_newegg_storefront;
	  var accontReceivable = columns.custrecord_accounts_receivable;
	  if(storefront!="18"){
        b2b='';        
      }
	  var page = 1;
	  var flag = 0;
	  var name = 0;
	  var orders = [];
	  
	  while (flag == 0) {
		  
	    var postData = {
	    		  "OperationType": "GetOrderInfoRequest",
	    		  "RequestBody": {
	    		    "PageIndex": page,
	    		    "PageSize": "100",
	    		    "RequestCriteria": {
	    		      "Status": "0"
	    		    }
	    		  }
	    		}
	    nlapiLogExecution('Debug', 'postData', JSON.stringify(postData));
	    var url = 'https://api.newegg.com/marketplace'+b2b+'/ordermgmt/order/orderinfo?sellerid=' + sellerId;
	    var rawResponse = nlapiRequestURL(url, JSON.stringify(postData), headers, 'PUT');
	    nlapiLogExecution('Debug', 'response', rawResponse.getBody());
	    var response = nlapiStringToXML(rawResponse.getBody());
	    var isSuccess = nlapiSelectValue(response, '/NeweggAPIResponse/IsSuccess');
	    nlapiLogExecution('Debug', 'isSuccess', isSuccess);
	    if (isSuccess == 'true') {
	    	
	      var file = nlapiCreateFile('newEggReport'+name+".txt",'PLAINTEXT',rawResponse.getBody());
	      file.setFolder('1121488');
	      nlapiSubmitFile(file);

	      nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Order report file data', 'Latest report file :',null,null,null,file);

	      var totalpage = nlapiSelectValue(response, '/NeweggAPIResponse/ResponseBody/PageInfo/TotalPageCount');
	      nlapiLogExecution('Debug', 'totalpage', totalpage);
          
          var name = 0;
	      
	      
	      var orderInfoList = response.getElementsByTagName('OrderInfo');
	      nlapiLogExecution('Debug', 'orderInfoList', orderInfoList.length);
	      
	      
          
         // nlapiLogExecution('Audit','file json report data',JSON.stringify(refund_json));
          
          
	      
	      for(var i = 0;i<orderInfoList.length;i++){
	    	  
	    	  var orderObj = {};
	    	  orderObj.firstName = orderInfoList.item(i).getElementsByTagName('ShipToFirstName').item(0).textContent;
	    	  orderObj.lastName = orderInfoList.item(i).getElementsByTagName('ShipToLastName').item(0).textContent;
	    	  orderObj.email = orderInfoList.item(i).getElementsByTagName('CustomerEmailAddress').item(0).textContent;
	    	  orderObj.phone = orderInfoList.item(i).getElementsByTagName('CustomerPhoneNumber').item(0).textContent;
	    	  orderObj.orderNumber = orderInfoList.item(i).getElementsByTagName('OrderNumber').item(0).textContent;
              
              var ShipService = orderInfoList.item(i).getElementsByTagName('ShipService').item(0).textContent;
              nlapiLogExecution('Audit','ShipService '+i,ShipService)
              if(ShipService === "Standard Shipping (5-7 business days)"){
                  orderObj.ship_via = 'Ground';
              }
              if(ShipService === "One-Day Shipping(Next day)"){
                  orderObj.ship_via = "Next Day";
              }
              if(ShipService === "Two-Day Shipping(2 business days)"){
                  orderObj.ship_via = '2 Days';
              }
              if(ShipService === "Expedited Shipping (3-5 business days)"){
                  orderObj.ship_via = 'Expedited';
              }  
            
            
	    	   
	    	  orderObj.status = "B";   //"B"  response.getElementsByTagName('OrderStatus').item(i).textContent;
	    	  orderObj.market = marketplace;
	    	  orderObj.storefront = storefront;
	    	  orderObj.shippingAmount = orderInfoList.item(i).getElementsByTagName('ShippingAmount').item(0).textContent;
	    	  orderObj.account = accontReceivable;
	    	  orderObj.location = location;
	    	  orderObj.form = so_form;
//	    	  orderObj.reportid = reportId;
	    	  orderObj.shipping = {};
	    	  orderObj.shipping.addr1 = orderInfoList.item(i).getElementsByTagName('ShipToAddress1').item(0).textContent;
	    	  orderObj.shipping.addr2 = orderInfoList.item(i).getElementsByTagName('ShipToAddress2').item(0).textContent;
	    	  orderObj.shipping.city = orderInfoList.item(i).getElementsByTagName('ShipToCityName').item(0).textContent;
	    	  orderObj.shipping.state = orderInfoList.item(i).getElementsByTagName('ShipToStateCode').item(0).textContent;
	    	  orderObj.shipping.zip = orderInfoList.item(i).getElementsByTagName('ShipToZipCode').item(0).textContent;
	    	  orderObj.shipping.country = orderInfoList.item(i).getElementsByTagName('ShipToCountryCode').item(0).textContent;
	    	  
              //updated on 11.04.2017
              var company = orderInfoList.item(i).getElementsByTagName('ShipToCompany').item(0).textContent;
              if(company)
              orderObj.shipping.company = company;
              nlapiLogExecution('Debug','company is ',company);
            
	          orderObj.billing = orderObj.shipping;  
	
	    	  
	    	   
	    	  
	          var itemLength =  orderInfoList.item(i).getElementsByTagName('ItemInfoList').item(0).getElementsByTagName('ItemInfo');
	    	  nlapiLogExecution('Debug', 'itemlength', itemLength.length);
	    	  
	    	  orderObj.items = [];
	    	  
	    	  for(var j = 0;j<itemLength.length;j++){
	    		  
	    		  var itemObj = {}
	    		  
	    		  itemObj.item_id = itemLength.item(j).getElementsByTagName('SellerPartNumber').item(0).textContent;
	    		  nlapiLogExecution('Debug','item_id', itemObj.item_id);
	        	try{
                itemObj.description = itemLength.item(j).getElementsByTagName('Description').item(0).textContent;
                }catch(e){
                  nlapiLogExecution('Debug', 'desc', e);
                }
                try{ 
	        	  itemObj.price = itemLength.item(j).getElementsByTagName('UnitPrice').item(0).textContent;
                  }catch(e){
                  nlapiLogExecution('Debug', 'price', e);
                }
                try{ 
	        	  itemObj.qty = itemLength.item(j).getElementsByTagName('OrderedQty').item(0).textContent;
	        	   }catch(e){
                  nlapiLogExecution('Debug', 'qty', e);
                }
                 nlapiLogExecution('Debug', 'End', "END");
	        	  orderObj.items.push(itemObj);
	    		  
	    	  }
	    	
	    	  orders.push(orderObj);
	      }
	     
	      var file1 = nlapiCreateFile('newEggOrderList'+name+'.txt','PLAINTEXT',JSON.stringify(orders));
	      file1.setFolder('1121488');
	      nlapiSubmitFile(file1);
	      nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Order report file (JSON) data', 'Latest report JSON file :',null,null,null,file1);
	      
	      name++;
	      
	      if (totalpage > page) {
	        page++; 
	      } else {
	        flag++
	      }
	      
	
	    }
	  }
	  
	  return orders;
// }
	
// catch(e){
// nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg Error: Getting result report',e);
// }
}