/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       18 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
//{
//"Type": "1",
//"Value": "A006BSP3",
//"Inventory": "20",
//"MSRP": "250",
//"MAP": "230",
//"CheckoutMAP": "0",
//"SellingPrice": "200",
//"EnableFreeShipping": "1",
//"Active": "0",
//“FulfillmentOption”:”1”
//}
var b2b = "/b2b";

function scheduled(type) {
   
 try{
	 
	var context = nlapiGetContext();
	
    var newegg_actid = context.getSetting('SCRIPT','custscript_newegg_accou');
    if(newegg_actid == 1){
        b2b = '';
      }
    
	var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_storefront',
		'custrecord_newegg_sellerid','name'];
	var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	
	var search = nlapiCreateSearch('customrecord_newegg_listings');//1889
	 
	//filters
	search.addFilter(new nlobjSearchFilter('custrecord_newegg_item_acc',null,'is',newegg_actid));
	search.addFilter(new nlobjSearchFilter('custrecord_is', null, 'is', 'T'));
	search.addFilter(new nlobjSearchFilter('internalid', null, 'is','303'));// '1774' //'1737'//1690;
	//columns
	search.addColumn(new nlobjSearchColumn('custrecord_is_kit'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item_sku'));
	search.addColumn(new nlobjSearchColumn('custrecord_is_qty_ovrwrite'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_itemprice'));
    var startIndx = 0;
	var endIndx = 500;
	var i = 0;
    
	var resultSet = search.runSearch();
	var result = resultSet.getResults(startIndx,endIndx);
	var arr = [];
	nlapiLogExecution('Debug','result str',JSON.stringify(result));
    while(result.length != null && i < result.length){
    	
    	try{
		
		checkGovernance();
		
		var recId = result[i].getId();
		nlapiLogExecution('Audit','i value is ',i);
		var sellerSku = result[i].getValue('custrecord_newegg_item_sku');// newegg seller sku
		nlapiLogExecution('Debug','sellerSku',sellerSku);
		//var price = getPrice(id,columns);// item price from newegg system
		var price = result[i].getValue('custrecord_newegg_itemprice');
		var overwrite = result[i].getValue('custrecord_is_qty_ovrwrite');
		nlapiLogExecution('Debug','overwrite',overwrite);
		if(overwrite == "T"){
			var qty = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_ovrwrite_qty');
			nlapiLogExecution('Debug','inside overwrite qty',qty);
			var obj = {};
	        obj.sellerId = sellerSku;
	        obj.qty = qty;
	        obj.price = price;
	        var rslt = update(columns,obj);
			
	        arr.push(rslt);
		}
		else{
			var isKit = result[i].getValue('custrecord_is_kit');
			nlapiLogExecution('Debug','iskit',isKit);
			if(isKit == "F"){
			   
				var itemID = result[i].getValue('custrecord_newegg_item');
		        nlapiLogExecution('DEBUG', 'itemID', itemID);
				var item = nlapiLoadRecord('inventoryitem', itemID);
				nlapiLogExecution('DEBUG', 'itemID', itemID);
				var loc = item.findLineItemValue('locations','location_display','3B USA : South Bend : South Bend Primary');
				nlapiLogExecution('DEBUG', 'loc', loc);
				var qty = item.getLineItemValue('locations','quantityavailable', loc);
				nlapiLogExecution('DEBUG', 'qty', qty);
				 nlapiLogExecution('DEBUG', 'itemID', itemID);
//		        if(qty > 200){
//					qty = 200;
//				}
		        var obj = {};
		        obj.sellerId = sellerSku;
		        obj.qty = qty;
		        obj.price = price;
		        nlapiLogExecution('Debug','obj',JSON.stringify(obj));
		        var rslt = update(columns,obj);
				
		        arr.push(rslt);
		
		       }
			   else{
				
				var kitRec = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_kit_item');
				nlapiLogExecution('Debug','kitRec',kitRec);
				//var newEggSku = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_sku');
				var mapping = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_mapping');
				nlapiLogExecution('Debug','mapping',mapping);
				var mappItems = mapping.split(';');
				var kitArr = []
				for(var i = 0;i<mappItems.length;i++){
					
					var mappItemArr = mappItems[i].split('=');
					var mapItemName = mappItemArr[0];
					nlapiLogExecution('Debug',' mapItemName',mapItemName)
					var mapItemQty = mappItemArr[1];
					var filter = [];
					filter.push(new nlobjSearchFilter('itemid',null,'is',mapItemName))
					var itemFound = nlapiSearchRecord('item',null,filter);
					nlapiLogExecution('Debug',' itemFound',JSON.stringify(itemFound));
					
					var loc = '3B USA : South Bend : South Bend Primary';
					var column = [];
					column.push(new nlobjSearchColumn('formulanumeric',null,'max').setFormula("DECODE({inventorylocation.name},'"+loc+"',{locationquantityavailable})"));
					
					var fil = [];
					fil.push(new nlobjSearchFilter('internalid',null,'is',itemFound[0].id))
				   // var recType = nlapiLookupField('item',itemFound[0].id,'recordtype');		
					var itemRec =  nlapiSearchRecord('item',null,fil,column);
					//var loc = itemRec.findLineItemValue('locations','location_display','USA : South Bend : South Bend Primary');
					var invQty = itemRec[0].getValue(column[0]);
					nlapiLogExecution('Debug',' invQty',invQty);
					
					var kitQty = Math.floor(invQty/mapItemQty);
					nlapiLogExecution('Debug',' kitQty',kitQty);
					kitArr.push(kitQty);
					
				}
				nlapiLogExecution('Debug','kit Arr',JSON.stringify(kitArr))
				var kit_qty = kitArr[0];
				for(var t=1;t<kitArr.length;t++)
				{
					if(kitArr[t]<kit_qty)
						kit_qty=kitArr[t];
					
				}
				
				nlapiLogExecution('Debug',' kit_qty 123',kit_qty)
				var obj = {};
		        obj.sellerId = sellerSku;
		        obj.qty = kit_qty;
		        obj.price = price;
		        nlapiLogExecution('Debug','obj',JSON.stringify(obj));
		        
		        var rslt = update(columns,obj);
				
		        arr.push(rslt);
				
			}
		}
		
		
     
        i++;
		
        
		if(i == result.length){
			startIndx = endIndx;
			endIndx += 500;
			result = resultSet.getResults(startIndx,endIndx);
			i = 0;
		}
        
	}catch(e){
      nlapiLogExecution('Error','error in NewEggItem update :'+i+' ,record :',recId)
		i++;
		
		if(i == result.length){
			startIndx = endIndx;
			endIndx += 500;
			result = resultSet.getResults(startIndx,endIndx);
			i = 0;
		}
	}
    }	
	nlapiLogExecution('Debug','updated',JSON.stringify(arr));
    var newAttachment = nlapiCreateFile('feedresult.txt',
				'PLAINTEXT', JSON.stringify(arr));
        nlapiLogExecution('Debug','updated',JSON.stringify(arr));
		nlapiSendEmail(1659, 'ratul@webbee.biz',
		'Quantity Reprort Newegg | '+columns.name,
		'File Attached', null,
		null, null, newAttachment);
 }
 catch(e){
	 nlapiLogExecution('Debug','error in script',e);
	
 }
	
}

function update(columns,obj){
	
	var sellerId = columns.custrecord_newegg_sellerid;
	var SecretKey = columns.custrecord_secretkey;
	var authKey =  columns.custrecord_authorization_key;
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	 
	nlapiLogExecution('Audit','b2b is ',b2b);
	var body = {};
    body.Type = 1;//seller Part type
    body.Value = obj.sellerId;
    body.Inventory = obj.qty;
    if(obj.price != '' && obj.price > 0)
	body.SellingPrice = obj.price;
    
    var url = "https://api.newegg.com/marketplace"+b2b+"/contentmgmt/item/inventoryandprice?sellerid="+ sellerId;
    
    nlapiLogExecution('Debug','on Update / headers',JSON.stringify(headers));
    nlapiLogExecution('Debug','on Update / body',JSON.stringify(body));
	nlapiLogExecution('Debug','on Update / URL',url);
	var response = nlapiRequestURL(url, JSON.stringify(body), headers,"PUT");
	nlapiLogExecution('Debug','response',response.getBody());
	response = nlapiStringToXML(response.getBody());
	
	 var status = nlapiSelectValue(response, '/UpdateInventoryAndPriceResult/Result') 
	 var available =  nlapiSelectValue(response, '/UpdateInventoryAndPriceResult/AvailableQuantity') 
	 var neweggItem =  nlapiSelectValue(response, '/UpdateInventoryAndPriceResult/ItemNumber');
	 var neweggPrice = nlapiSelectValue(response, '/UpdateInventoryAndPriceResult/SellingPrice');
	 if(status == "1" && available == obj.qty){
	 	nlapiLogExecution('Debug','inventory updated for item ',obj.sellerId);
	 }
	
	 nlapiLogExecution('Debug','status',status);
	 nlapiLogExecution('Debug','quantity',available);
	 nlapiLogExecution('Debug','neweggPrice',neweggPrice);
	 var newobj = {};
	 newobj.item = neweggItem;
	 newobj.available = available;
	 newobj.price = neweggPrice
	 return newobj;
	 
    
    
}


//function getPrice(id,columns){
//	
//	var sellerId = columns.custrecord_newegg_sellerid;
//	var SecretKey = columns.custrecord_secretkey;
//	var authKey =  columns.custrecord_authorization_key;
//	var headers = {
//		    "Authorization": authKey,
//		    "SecretKey": SecretKey,
//		    "Content-Type": "application/json"
//		  }
//	
//	var body = {};
//    body.Type = 0;
//    body.Value = id;
//	
//    var url = "https://api.newegg.com/marketplace/contentmgmt/item/price?sellerid="+ sellerId;
//    var response = nlapiRequestURL(url, JSON.stringify(body), headers,"POST");
//	nlapiLogExecution('Debug','response',response.getBody());
//	response = nlapiStringToXML(response.getBody());
//	
//	var msrp = nlapiSelectValue(response, '/PriceResult/MSRP');
//	var sellingPrice = nlapiSelectValue(response, '/PriceResult/SellingPrice');
//	nlapiLogExecution('Debug','MSRP',msrp);
//	nlapiLogExecution('Debug','sellingPrice',sellingPrice);
//	return sellingPrice;
//    
//}



function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}