//--------------------------------------------------------------------------------------------------------------------------------------------
// createSalesOrder.js
//
// Author: Jacob Van Vleet
// Email: jake@zake.com, jacob.vanvleet@gmail.com
// Skype: jake3bt
// Created: 8/4/2016
// Netsuite Attachment: Restlet - url: https://rest.na1.netsuite.com/app/site/hosting/restlet.nl?script=703&deploy=1
// Purpose: Rest api to create a sales order
//--------------------------------------------------------------------------------------------------------------------------------------------
// Example dataIn object
//  {
//      firstName: string,
//      lastName: string,
//      email: string,
//      phone: string,
//      orderNumber: string,
//      ship_via: string,
//      status: string,
//      market: number,
//      storefront: number,
//      shippingAmount: number,
//      account: number,
//      location: number,
//      form: number,
//      shipping: {
//          addr1: string,
//          addr2: string,
//          city: string,
//          state: string,
//          zip: string,
//          country:string
//      },
//      billing: {
//          addr1: string,
//          addr2: string,
//          city: string,
//          state: string,
//          zip: string,
//          country:string
//      },
//      items: [
//          {
//              item_id: string,
//              description: string,
//              price: number,
//              qty: number
//          }
//      ]
//  }



// misc item ids
var shipping = 37625; // internal id of shipping item
var assembly = 40258; // internal id of assembly item
var arr={};
arr['Afghanistan']='AF' 
	arr['Aland Islands']='AX' 
	arr['Albania']='AL' 
	arr['Algeria']='DZ' 
	arr['American Samoa']='AS' 
	arr['Andorra']='AD' 
	arr['Angola']='AO' 
	arr['Anguilla']='AI' 
	arr['Antarctica']='AQ' 
	arr['Antigua And Barbuda']='AG' 
	arr['Argentina']='AR' 
	arr['Armenia']='AM' 
	arr['Aruba']='AW' 
	arr['Australia']='AU' 
	arr['Austria']='AT' 
	arr['Azerbaijan']='AZ' 
	arr['Bahamas']='BS' 
	arr['Bahrain']='BH' 
	arr['Bangladesh']='BD' 
	arr['Barbados']='BB' 
	arr['Belarus']='BY' 
	arr['Belgium']='BE' 
	arr['Belize']='BZ' 
	arr['Benin']='BJ' 
	arr['Bermuda']='BM' 
	arr['Bhutan']='BT' 
	arr['Bolivia']='BO' 
	arr['Bosnia And Herzegovina']='BA' 
	arr['Botswana']='BW' 
	arr['Bouvet Island']='BV' 
	arr['Brazil']='BR' 
	arr['British Indian Ocean Territory']='IO' 
	arr['Brunei Darussalam']='BN' 
	arr['Bulgaria']='BG' 
	arr['Burkina Faso']='BF' 
	arr['Burundi']='BI' 
	arr['Cambodia']='KH' 
	arr['Cameroon']='CM' 
	arr['Canada']='CA' 
	arr['Cape Verde']='CV' 
	arr['Cayman Islands']='KY' 
	arr['Central African Republic']='CF' 
	arr['Chad']='TD' 
	arr['Chile']='CL' 
	arr['China']='CN' 
	arr['Christmas Island']='CX' 
	arr['Cocos (Keeling) Islands']='CC' 
	arr['Colombia']='CO' 
	arr['Comoros']='KM' 
	arr['Congo']='CG' 
	arr['Congo Democratic Republic']='CD' 
	arr['Cook Islands']='CK' 
	arr['Costa Rica']='CR' 
	arr['Cote D\'Ivoire']='CI' 
	arr['Croatia']='HR' 
	arr['Cuba']='CU' 
	arr['Cyprus']='CY' 
	arr['Czech Republic']='CZ' 
	arr['Denmark']='DK' 
	arr['Djibouti']='DJ' 
	arr['Dominica']='DM' 
	arr['Dominican Republic']='DO' 
	arr['Ecuador']='EC' 
	arr['Egypt']='EG' 
	arr['El Salvador']='SV' 
	arr['Equatorial Guinea']='GQ' 
	arr['Eritrea']='ER' 
	arr['Estonia']='EE' 
	arr['Ethiopia']='ET' 
	arr['Falkland Islands (Malvinas)']='FK' 
	arr['Faroe Islands']='FO' 
	arr['Fiji']='FJ' 
	arr['Finland']='FI' 
	arr['France']='FR' 
	arr['French Guiana']='GF' 
	arr['French Polynesia']='PF' 
	arr['French Southern Territories']='TF' 
	arr['Gabon']='GA' 
	arr['Gambia']='GM' 
	arr['Georgia']='GE' 
	arr['Germany']='DE' 
	arr['Ghana']='GH' 
	arr['Gibraltar']='GI' 
	arr['Greece']='GR' 
	arr['Greenland']='GL' 
	arr['Grenada']='GD' 
	arr['Guadeloupe']='GP' 
	arr['Guam']='GU' 
	arr['Guatemala']='GT' 
	arr['Guernsey']='GG' 
	arr['Guinea']='GN' 
	arr['Guinea-Bissau']='GW' 
	arr['Guyana']='GY' 
	arr['Haiti']='HT' 
	arr['Heard Island & Mcdonald Islands']='HM' 
	arr['Holy See (Vatican City State)']='VA' 
	arr['Honduras']='HN' 
	arr['Hong Kong']='HK' 
	arr['Hungary']='HU' 
	arr['Iceland']='IS' 
	arr['India']='IN' 
	arr['Indonesia']='ID' 
	arr['Iran Islamic Republic Of']='IR' 
	arr['Iraq']='IQ' 
	arr['Ireland']='IE' 
	arr['Isle Of Man']='IM' 
	arr['Israel']='IL' 
	arr['Italy']='IT' 
	arr['Jamaica']='JM' 
	arr['Japan']='JP' 
	arr['Jersey']='JE' 
	arr['Jordan']='JO' 
	arr['Kazakhstan']='KZ' 
	arr['Kenya']='KE' 
	arr['Kiribati']='KI' 
	arr['Korea']='KR' 
	arr['Kuwait']='KW' 
	arr['Kyrgyzstan']='KG' 
	arr['Lao People\'s Democratic Republic']='LA' 
	arr['Latvia']='LV' 
	arr['Lebanon']='LB' 
	arr['Lesotho']='LS' 
	arr['Liberia']='LR' 
	arr['Libyan Arab Jamahiriya']='LY' 
	arr['Liechtenstein']='LI' 
	arr['Lithuania']='LT' 
	arr['Luxembourg']='LU' 
	arr['Macao']='MO' 
	arr['Macedonia']='MK' 
	arr['Madagascar']='MG' 
	arr['Malawi']='MW' 
	arr['Malaysia']='MY' 
	arr['Maldives']='MV' 
	arr['Mali']='ML' 
	arr['Malta']='MT' 
	arr['Marshall Islands']='MH' 
	arr['Martinique']='MQ' 
	arr['Mauritania']='MR' 
	arr['Mauritius']='MU' 
	arr['Mayotte']='YT' 
	arr['Mexico']='MX' 
	arr['Micronesia Federated States Of']='FM' 
	arr['Moldova']='MD' 
	arr['Monaco']='MC' 
	arr['Mongolia']='MN' 
	arr['Montenegro']='ME' 
	arr['Montserrat']='MS' 
	arr['Morocco']='MA' 
	arr['Mozambique']='MZ' 
	arr['Myanmar']='MM' 
	arr['Namibia']='NA' 
	arr['Nauru']='NR' 
	arr['Nepal']='NP' 
	arr['Netherlands']='NL' 
	arr['Netherlands Antilles']='AN' 
	arr['New Caledonia']='NC' 
	arr['New Zealand']='NZ' 
	arr['Nicaragua']='NI' 
	arr['Niger']='NE' 
	arr['Nigeria']='NG' 
	arr['Niue']='NU' 
	arr['Norfolk Island']='NF' 
	arr['Northern Mariana Islands']='MP' 
	arr['Norway']='NO' 
	arr['Oman']='OM' 
	arr['Pakistan']='PK' 
	arr['Palau']='PW' 
	arr['Palestinian Territory Occupied']='PS' 
	arr['Panama']='PA' 
	arr['Papua New Guinea']='PG' 
	arr['Paraguay']='PY' 
	arr['Peru']='PE' 
	arr['Philippines']='PH' 
	arr['Pitcairn']='PN' 
	arr['Poland']='PL' 
	arr['Portugal']='PT' 
	arr['Puerto Rico']='PR' 
	arr['Qatar']='QA' 
	arr['Reunion']='RE' 
	arr['Romania']='RO' 
	arr['Russian Federation']='RU' 
	arr['Rwanda']='RW' 
	arr['Saint Barthelemy']='BL' 
	arr['Saint Helena']='SH' 
	arr['Saint Kitts And Nevis']='KN' 
	arr['Saint Lucia']='LC' 
	arr['Saint Martin']='MF' 
	arr['Saint Pierre And Miquelon']='PM' 
	arr['Saint Vincent And Grenadines']='VC' 
	arr['Samoa']='WS' 
	arr['San Marino']='SM' 
	arr['Sao Tome And Principe']='ST' 
	arr['Saudi Arabia']='SA' 
	arr['Senegal']='SN' 
	arr['Serbia']='RS' 
	arr['Seychelles']='SC' 
	arr['Sierra Leone']='SL' 
	arr['Singapore']='SG' 
	arr['Slovakia']='SK' 
	arr['Slovenia']='SI' 
	arr['Solomon Islands']='SB' 
	arr['Somalia']='SO' 
	arr['South Africa']='ZA' 
	arr['South Georgia And Sandwich Isl.']='GS' 
	arr['Spain']='ES' 
	arr['Sri Lanka']='LK' 
	arr['Sudan']='SD' 
	arr['Suriname']='SR' 
	arr['Svalbard And Jan Mayen']='SJ' 
	arr['Swaziland']='SZ' 
	arr['Sweden']='SE' 
	arr['Switzerland']='CH' 
	arr['Syrian Arab Republic']='SY' 
	arr['Taiwan']='TW' 
	arr['Tajikistan']='TJ' 
	arr['Tanzania']='TZ' 
	arr['Thailand']='TH' 
	arr['Timor-Leste']='TL' 
	arr['Togo']='TG' 
	arr['Tokelau']='TK' 
	arr['Tonga']='TO' 
	arr['Trinidad And Tobago']='TT' 
	arr['Tunisia']='TN' 
	arr['Turkey']='TR' 
	arr['Turkmenistan']='TM' 
	arr['Turks And Caicos Islands']='TC' 
	arr['Tuvalu']='TV' 
	arr['Uganda']='UG' 
	arr['Ukraine']='UA' 
	arr['United Arab Emirates']='AE' 
	arr['United Kingdom']='GB' 
	arr['United States']='US' 
    	arr['UNITED STATES']='US'
        arr['US']='US'
	arr['United States Outlying Islands']='UM' 
	arr['Uruguay']='UY' 
	arr['Uzbekistan']='UZ' 
	arr['Vanuatu']='VU' 
	arr['Venezuela']='VE' 
	arr['Viet Nam']='VN' 
	arr['Virgin Islands British']='VG' 
	arr['Virgin Islands U.S.']='VI' 
	arr['Wallis And Futuna']='WF' 
	arr['Western Sahara']='EH' 
	arr['Yemen']='YE' 
	arr['Zambia']='ZM' 
	arr['Zimbabwe']='ZW'

function start(dataIn,newegg_actid,fromUI){
	try{
  
  nlapiLogExecution('DEBUG', 'dataIn',JSON.stringify(dataIn));
  
    var isPremier = false;
    var po = dataIn.orderNumber.toString();
    var exists = checkExists(po,dataIn.market,dataIn.storefront);
	if (exists != null) {
		var obj = {
			id : exists,
			type : 'salesOrder',
			status : 'exists',
			storefront: dataIn.storfront,
			market: dataIn.market
		};
		return obj;
	}else{
        var custID = getCustID(dataIn);
      nlapiLogExecution('Debug','customerId:',custID);
        //var address = getAddress(custID, dataIn);
        var items = dataIn.items;
        var rec = nlapiCreateRecord('salesorder');
        rec.setFieldValue('entity', custID);  // set customer
        rec.setFieldValue('custbody_storefront_list', dataIn.storefront); // set storefront
        rec.setFieldValue('custbody_marketplace', dataIn.market); // set marketplace
        rec.setFieldValue('subsidiary', 1); // 1 = zake international
        rec.setFieldValue('memo', 'Import from Pitchfork'); // mark as order that came from pitchfork
//         rec.setFieldValue('custbody_order_report_id', dataIn.reportid);
        rec.setFieldValue('otherrefnum', dataIn.orderNumber.toString()); // set po #
        rec.setFieldValue('custbody_customer_email', dataIn.email); // set email
        if(dataIn.shipping.company){
            rec.setFieldValue('shipaddressee', dataIn.shipping.company)
            rec.setFieldValue('shipattention', dataIn.firstName+' '+dataIn.lastName);
          }
        else{
        	 rec.setFieldValue('shipaddressee', dataIn.firstName+' '+dataIn.lastName);
        }
        rec.setFieldValue('shipaddr1', dataIn.shipping.addr1);
        rec.setFieldValue('shipaddr2', dataIn.shipping.addr2);
        rec.setFieldValue('shipcity', dataIn.shipping.city);
        rec.setFieldValue('shipstate', dataIn.shipping.state);
        rec.setFieldValue('shipzip', dataIn.shipping.zip);
        if (dataIn.billing.addr1 != dataIn.shipping.addr1 && dataIn.billing.addr1 != null && dataIn.billing.addr1 != undefined) {  
            // if billing and shipping address diffrent, add second address
            rec.setFieldValue('billaddressee', dataIn.firstName+' '+dataIn.lastName);
            rec.setFieldValue('billaddr1', dataIn.billing.addr1);
            rec.setFieldValue('billaddr2', dataIn.billing.addr2);
            rec.setFieldValue('billcity', dataIn.billing.city);
            rec.setFieldValue('billstate',dataIn.billing.state);
            rec.setFieldValue('billzip', dataIn.billing.zip);
        }
//        if(dataIn.createdfrom != undefined){  // set if created from somthing, like an ra
//            if(dataIn.createdfrom != null){
//                rec.setFieldValue('custbody_return_auth_number', dataIn.createdfrom);
//            }
//        }

        if(dataIn.location == undefined){ // set location
            rec.setFieldValue('location', 2); // 2 = South Bend-Primary
        }else{
            rec.setFieldValue('location', dataIn.location);
        }
        if(dataIn.form == undefined){ // set custom from
            rec.setFieldValue('customform', 150); // default form id
        }else{
            rec.setFieldValue('customform', dataIn.form);
        }
        if(dataIn.status == undefined || ship(dataIn.ship_via)==6 || ship(dataIn.ship_via)==7){  // set order status // added  || ship(dataIn.ship_via)==6 and 7 modified by AJ for Premier orders
             nlapiLogExecution('Debug','123')
            rec.setFieldValue("orderstatus", "A"); // pending approval
        }else{
            nlapiLogExecution('Debug','dataIn.status',dataIn.status)
            rec.setFieldValue("orderstatus", dataIn.status);
        }
        if(dataIn.account != undefined){  // set account
            rec.setFieldValue('account', dataIn.account);
        } // default is auto assigned
        if (dataIn.shippingAmount != undefined) {  // set shipping charge
            if(dataIn.ship_via == 'Ground'){
                rec.setFieldValue('shippingcost', 0);
            }else{
                rec.setFieldValue('shippingcost', dataIn.shippingAmount);
            }
        } else {
            rec.setFieldValue('shippingcost', 0);
        }
        rec.setFieldValue('custbody_market_ship_serv_lvl', ship(dataIn.ship_via));
        
        //modified for premier order only by Ratul // 22/03/2017
        if(ship(dataIn.ship_via) == 6){
        	
        	isPremier = true;
        	rec.setFieldValue('custbody_has_issues',"T");
        	rec.setFieldValue('custbody_delay_fulfill', "T");
        	rec.setFieldValue('custbody_internal_note', "PREMIER - ships via FedEx - WAITING for labels");
        	
        }
        
        var tax = isTaxable(items);
        if(tax){
            rec.setFieldValue('istaxable', 'T');
            rec.setFieldValue('taxrate', 7); // indiana tax
        }
        
        var keep = 0;

        for (var i = 0; i < items.length; i++) {
            var single = items[i];
            nlapiLogExecution('Debug','quantity : ',single.qty)
            nlapiLogExecution('Debug','price : ',single.price)
            if (single.description == "Sales Tax") {
                rec.setFieldValue('taxitem', 10);
                rec.setFieldValue('taxtotal', single.price);
                continue;
            } else if (single.description == "Freight Charges") {
                rec.setFieldValue('shippingcost', single.price);
                continue;
            } else if (single.description == "assembly") {
                rec.selectNewLineItem('item');
                rec.setCurrentLineItemValue('item', 'item', assembly);
                rec.setCurrentLineItemValue('item', 'quantity', 1);
                rec.setCurrentLineItemValue('item', 'price', '-1');
                rec.setCurrentLineItemValue('item', 'rate', single.price);
                if(tax){
                    rec.setCurrentLineItemValue('item', 'istaxable', 'T');
                }
                rec.commitLineItem('item');
                continue;
            } else if (single.description == "Storefront Discount"){
                nlapiLogExecution('DEBUG', 'Storefront Discount', JSON.stringify(single));
                rec.setFieldValue('custbody_has_issues', 'T');
                rec.setFieldValue('memo', 'Storefront Discount Error');
                continue;
            } else {
                var s = single.item_id.split('#');
                var sku = single.item_id;//s[0]; 
                var item = getItem(sku,newegg_actid);
                if(item == null){
                	item = findIteminKit(sku,dataIn.storefront);
                }
                nlapiLogExecution('Debug','item is:',JSON.stringify(item));
                if(item == null){
                	
                    if(fromUI == "F"){
                    	nlapiLogExecution('Debug','line 429',"got it");
                    	errorRec(sku,null,dataIn,newegg_actid);
                    	nlapiLogExecution('Debug','line 430',"got it");
                    	nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Seller part not Found', 'Seller part Not found '+sku,'ryan@zake.com');
                    }
                    
                    nlapiLogExecution('Debug','line 431',"got it");
                	keep++;
                	continue;
                }
                else{
                	var isK = item[0];
                	if(isK == "F"){
                		var itemId = item[1];
                		rec.selectNewLineItem('item');
                        rec.setCurrentLineItemValue('item', 'item', itemId);
                        nlapiLogExecution('Debug','quantity : ',single.qty)
                        rec.setCurrentLineItemValue('item', 'quantity', single.qty);
                        rec.setCurrentLineItemValue('item', 'price', '-1');
                        rec.setCurrentLineItemValue('item', 'rate', single.price);
                        rec.setCurrentLineItemValue('item', 'custcol_newegg_sku', single.item_id);
                        if(tax){
                            rec.setCurrentLineItemValue('item', 'istaxable', 'T');
                        }
                        rec.commitLineItem('item');
                        continue;
                	}
                	else{
                		var itemArr = item[1];
                		for(var k=0;k<itemArr.length;k++){
                			var itemId = itemArr[k].kitItemId;
                			var qty = itemArr[k].kitItemQty;
                			
                			rec.selectNewLineItem('item');
                			rec.setCurrentLineItemValue('item', 'item', itemId);
                			rec.setCurrentLineItemValue('item', 'quantity', qty);
                			rec.setCurrentLineItemValue('item', 'price', '-1');
                			rec.setCurrentLineItemValue('item', 'custcol_newegg_sku', single.item_id);
                			if(k == 0){
                				rec.setCurrentLineItemValue('item', 'amount', (single.price)*(single.qty));
                			}
                			else{
                				rec.setCurrentLineItemValue('item', 'amount', "0");
                				
                			}
                			rec.commitLineItem('item');
                			continue;
                		}
                      rec.setFieldValue('custbody_kitorder','T');
                	}
                }
                //
                
            }
        }
        var obj = {};
        nlapiLogExecution('Debug','keep ',keep);
        if(keep == 0){
        	var submited = nlapiSubmitRecord(rec,false,true);
            nlapiLogExecution('Debug','submited record',submited)           
            var d = new Date();
            
            obj.id = submited;
            obj.type = 'salesOrder';
            obj.status = 'created';
            obj.createdAt = d.toString();
            obj.storefront = dataIn.storfront;
    		obj.market = dataIn.market;
    		
    		var dataFile = nlapiCreateFile('jsonData.txt','PLAINTEXT',JSON.stringify(dataIn))
    		
    		var url = nlapiResolveURL('RECORD','salesorder',obj.id);
    		url = "https://system.na1.netsuite.com"+url;
    		
    		if(fromUI == "F"){
    			if(isPremier == false){
    	    		   nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Sales Order Success', 'order created with orderNumber :'+po+' :url '+url,null,null,null,dataFile);
	    		}else{
	    			nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Premier Sales Order Success', 'order created with orderNumber :'+po+' :url '+url,null,null,null,dataFile);
	    		}
    		}
    		
            return obj;
        }
        else{
        	obj.status = "Failed";
        	return obj;
        }
    
    }
}
	
catch(e){

	nlapiLogExecution('Debug','error', e);
	if(fromUI == "F"){
		errorRec(null,e,dataIn,newegg_actid);
	}
	
	 
}}

function errorRec(sku,e,dataIn,newegg_actid){
	
	nlapiLogExecution('Debug','inside errorRec func', "running...");
	var po = dataIn.orderNumber.toString();
	nlapiLogExecution('Debug','po', po);
	var filter = [];
	filter.push(new nlobjSearchFilter('custrecord_order_number',null,'is',po));
	var search = nlapiSearchRecord('customrecord_newegg_missing_order',null,filter);
	if(!search){

		var errRec = nlapiCreateRecord('customrecord_newegg_missing_order',{'recordmode':'dynamic'});
		errRec.setFieldValue('custrecord_order_number', po);
		errRec.setFieldValue('custrecord_newegg_acc',newegg_actid );
		errRec.setFieldValue('custrecord_order_object',JSON.stringify(dataIn));
		if(sku != null){
			errRec.setFieldValue('custrecord_error_sku',sku);
		}
		if(e != null){
			errRec.setFieldValue('custrecord_error_rsn',JSON.stringify(e));
		}
		var obj1 = {};
		obj1.status = "Error creating order";
		obj1.errRecId = nlapiSubmitRecord(errRec,false,true);
		
		
		var url = nlapiResolveURL('RECORD','customrecord_newegg_missing_order',obj1.errRecId);
		url = "https://system.na1.netsuite.com"+url;
		
		nlapiLogExecution('Debug','url', url);
		nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Sales Order Creation Fail', 'order creation fail:OrderNumber '+po+' Error record:'+url);

	}
	else{
		var errRecId = search[0].getId();
		var oldSku = nlapiLookupField('customrecord_newegg_missing_order',errRecId,'custrecord_error_sku');
		var newSku = oldSku;
		if(oldSku){
			oldSku = oldSku.split(',');
		    
			if(oldSku.indexOf(sku) == -1){
				newSku += sku;
			}
			  
			nlapiSubmitField('customrecord_newegg_missing_order',errRecId,'custrecord_error_sku',newSku);
	
		}else{
			nlapiSubmitField('customrecord_newegg_missing_order',errRecId,'custrecord_error_sku',sku);
		}
	}
	
}

//function handelError(e, obj){
//    var auth = 29799;
//    var sub = JSON.stringify(obj);
//    var msg = JSON.stringify(e);
//	var col = new Array();
//	col[0] = new nlobjSearchColumn('name');
//	var search = nlapiSearchRecord('customlist_script_error', null, null, col);
//	search.forEach(function(s){
//		var email = s.getValue('name');
//		nlapiSendEmail(auth, email, sub, msg);
//	});
//}

function ship(ship_via){
    // shipping codes
    var TBD = 6;
    var Standard = 1;
    var ThreeDay = 2;
    var TwoDay = 3;
    var NextDay = 4;
    var International = 5;
    var Pickup = 7;
    var obj = {};
    if (ship_via == "Ground") {
        return Standard;
	} else if (ship_via == "2 Days") {
        return TwoDay;
	} else if (ship_via == "3 Days") {
        return ThreeDay;
	} else if (ship_via == "International") {
        return International;
	} else if (ship_via == "Next Day") {
        return NextDay;
	}else if(ship_via == "Expedited"){
		return Standard;
	}else if(ship_via == "" || ship_via == "Pickup"){
		return Pickup;
	} else {
		return TBD;
	}
}

function checkExists(po,market,storefront){  // checks to see if a sales order with that po# exists in NS.
    var filter = new Array();
	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', po);
	filter[1] = new nlobjSearchFilter('custbody_marketplace', null, 'is', market);
	filter[2] = new nlobjSearchFilter('custbody_storefront_list', null, 'is', storefront);
	var x = nlapiSearchRecord('salesorder', null, filter);
	if (x == null) {
		return null;
	} else {
		return x[0].id;  // if it does exists returns internal id of existing order for logging
	}
}

function isTaxable(items){  // checks sales tax
	var done = false;
	items.forEach(function(item, i){
		if (item.description == "Sales Tax") {
			done = true;
		}
	});
	return done;
}

function getCustID(dataIn) {  // checks if customer exists.  If it doesn't creates the customer
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.email);
	var x = nlapiSearchRecord('customer', null, filter);
	if (x == null) {
		var id = createCustomer(dataIn);
		return id;
	} 
	else {
		var id = x[0].id;

		
		nlapiLogExecution('DEBUG', 'Existing Customer',id);
		var obj=nlapiLoadRecord('customer',id,{recordmode : 'dynamic'});
		var flag=0;
		var flag1=0;
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG','lines',lines);		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addr1=obj.getLineItemValue('addressbook','addr1', z);

			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addr1',cust_addr1);

			if(cust_zipcode==dataIn.shipping.zip&&cust_addr1==dataIn.shipping.addr1){
				flag++;
			}
           if(cust_zipcode==dataIn.billing.zip&&cust_addr1==dataIn.billing.addr1){
				flag1++;
			}

		}
		nlapiLogExecution('DEBUG','flag',flag);
		nlapiLogExecution('DEBUG','flag1',flag1);
		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addr1 );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping.addr1);
		var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
		if(!dataIn.shipping.country)
			subrecord.setFieldValue('country', 'US');
		else
		subrecord.setFieldValue('country', arr[dataIn.shipping.country]);
		//updated on 11.04.2017
        subrecord.setFieldValue('attention', dataIn.firstName+' '+dataIn.lastName);
        if(dataIn.shipping.company){
              subrecord.setFieldValue('addressee', dataIn.shipping.company);
            }else{
              subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
            }
          
          
		if (dataIn.phone.match(/[^0]/) && (dataIn.phone.length >= 8)) {
			subrecord.setFieldValue('addrphone', dataIn.phone);
		}
		if(dataIn.shipping.addr1)
		{
	    subrecord.setFieldValue('addr1', dataIn.shipping.addr1);
		subrecord.setFieldValue('addr2', dataIn.shipping.addr2);
		}
		else{
		    subrecord.setFieldValue('addr1', dataIn.shipping.addr2);
		}
		subrecord.setFieldValue('city', dataIn.shipping.city);
		subrecord.setFieldValue('state', dataIn.shipping.state);
		subrecord.setFieldValue('zip', dataIn.shipping.zip);
		subrecord.commit();
		obj.commitLineItem('addressbook');
			
		}
		if(flag1==0){
			obj.selectNewLineItem('addressbook');
			obj.setCurrentLineItemValue('addressbook', 'label', dataIn.billing.addr1);
			var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
			if(!dataIn.billing.country)
				subrecord.setFieldValue('country', 'US');
			else
			subrecord.setFieldValue('country', arr[dataIn.billing.country]);
			//updated on 11.04.2017
            subrecord.setFieldValue('attention', dataIn.firstName+' '+dataIn.lastName);
            if(dataIn.shipping.company){
                  subrecord.setFieldValue('addressee', dataIn.shipping.company);
                }else{
                  subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
                }
          
			if (dataIn.phone.match(/[^0]/) && (dataIn.phone.length >= 8)) {
				subrecord.setFieldValue('addrphone', dataIn.phone);
			}
			if(dataIn.shipping.addr1)
			{
		    subrecord.setFieldValue('addr1', dataIn.billing.addr1);
			subrecord.setFieldValue('addr2', dataIn.billing.addr2);
			}
			else{
			    subrecord.setFieldValue('addr1', dataIn.billing.addr2);
			}
			subrecord.setFieldValue('city', dataIn.billing.city);
			subrecord.setFieldValue('state', dataIn.billing.state);
			subrecord.setFieldValue('zip', dataIn.billing.zip);
			subrecord.commit();
			obj.commitLineItem('addressbook');
		}
	    var submited =  nlapiSubmitRecord(obj, null,true);
	
		return submited;
	}
}

function createCustomer(dataIn) {
	var phone=dataIn.phone;
	var cust = nlapiCreateRecord('customer');
	var billing = dataIn.billing;
	var shipping = dataIn.shipping;
	cust.setFieldValue('isperson', 'T');
	cust.setFieldValue('subsidiary', 1); // 1 = zake international
    if(dataIn.firstName.length > 32){
        dataIn.firstName = dataIn.firstName.slice(0,30);
    }
	cust.setFieldValue('firstname', dataIn.firstName);
	cust.setFieldValue('lastname', dataIn.lastName);
	cust.setFieldValue('email', dataIn.email);
	cust.setFieldValue('phone', phone.slice(0,22));

	cust.selectNewLineItem('addressbook');
	//cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping.addr1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.shipping.country)
		subrecord.setFieldValue('country', 'US');
	else
	subrecord.setFieldValue('country', arr[dataIn.shipping.country]);
	
    //updated on 11.04.2017
  subrecord.setFieldValue('attention', dataIn.firstName+' '+dataIn.lastName);
  if(dataIn.shipping.company){
    subrecord.setFieldValue('addressee', dataIn.shipping.company);
  }else{
    subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
  }
  
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping.addr1)
	{
    subrecord.setFieldValue('addr1', dataIn.shipping.addr1);
	subrecord.setFieldValue('addr2', dataIn.shipping.addr2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.shipping.addr2);
	}
	subrecord.setFieldValue('city', dataIn.shipping.city);
	subrecord.setFieldValue('state', dataIn.shipping.state);
	subrecord.setFieldValue('zip', dataIn.shipping.zip);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	
	cust.selectNewLineItem('addressbook');
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.billing.addr1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.billing.country)
		subrecord.setFieldValue('country', 'US');	
	else
	subrecord.setFieldValue('country', arr[dataIn.billing.country]);
	subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping.addr1)
	{
    subrecord.setFieldValue('addr1', dataIn.billing.addr1);
	subrecord.setFieldValue('addr2', dataIn.billing.addr2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.billing.addr2);
	}
	subrecord.setFieldValue('city', dataIn.billing.city);
	subrecord.setFieldValue('state', dataIn.billing.state);
	subrecord.setFieldValue('zip', dataIn.billing.zip);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	var id = nlapiSubmitRecord(cust);
	nlapiLogExecution('DEBUG', 'new customer', id)
	return id;
}



function getItem(sku,newegg_actid){
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('custrecord_newegg_item_sku', null, 'is', sku);
	filter[1] = new nlobjSearchFilter('custrecord_newegg_item_acc', null, 'is', newegg_actid);
	var item = nlapiSearchRecord('customrecord_newegg_listings', null, filter);
	if(item == null){
		//nlapiLogExecution('Debug','errror','item sku not found')
	    //nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg:Item sku not Found', 'sku Not found '+sku);
	    //nlapiSendEmail(1659,'ratul@webbee.biz','sales order error', 'item sku not found',null,null,null);
	    return null;
	}else{
		
		var recId = item[0].getId()
		var isKit = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_is_kit');
		nlapiLogExecution('Debug','isKit',isKit)
		if(isKit == "F"){
			var itemId = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_newegg_item');
			
			return ["F",itemId];
		}else{
			var kitRecId =  nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_kit_item');
			var kitSKU = nlapiLookupField('customrecord_kit',kitRecId,'custrecord_kit_mapping');
			
			var itemArr = getKitItems(kitSKU);
			
			
			
			return ["T",itemArr];
			
			
		}
		
	}
	

}

function findIteminKit(seller_sku, storefront) {
  try{
	  var sku = seller_sku;
	  var ary = [];
	  ary = seller_sku.replace("@", "|").split("|");
	  nlapiLogExecution('DEBUG', 'ary', ary);
	  seller_sku = ary[0];
	  var columns = new nlobjSearchColumn('custrecord_kit_mapping')
	  var search = nlapiSearchRecord('customrecord_kit', null, ['custrecord_kit_sku', 'is', seller_sku], columns);
	  if (search != null) {
	    var kitid = search[0].getId();
	    var items = search[0].getValue('custrecord_kit_mapping');
	    var record = nlapiCreateRecord("customrecord_newegg_listings");
	    //record.setFieldValue('custrecord_newegg_item_id', itemInternalId);
	    record.setFieldValue('custrecord_is', 'T');
	    record.setFieldValue('custrecord_newegg_item_sku', sku);
	    record.setFieldValue('custrecord_kit_item', kitid);
	    record.setFieldValue('custrecord_is_kit', "T");
	    record.setFieldValue('custrecord_newegg_item_acc', storefront);
	     
	    var success = nlapiSubmitRecord(record, null, true);
	    nlapiLogExecution('DEBUG', 'new listing', success);
	    
	    items = getKitItems(items);
	    
	    return ['T',items];
	  } else {
	    return null;
	  }
  }catch(e){
    nlapiLogExecution('DEBUG', 'Error in getting Kit Item', e);
  }
	}


function getKitItems(kitSKU){
	try{
	var kitItems = kitSKU.split(';');
	
	var arr = []
	
	for(var i = 0;i<kitItems.length;i++){
		var object = {} 
		var kitItem = kitItems[i];
		var kitItemId1 = kitItem.split('=')[0];
		var iFilter = [];
		iFilter.push(new nlobjSearchFilter('itemid',null,'is',kitItemId1));
	    var searchItem = nlapiSearchRecord('item',null,iFilter);
	    if(searchItem){
	    	object.kitItemId = searchItem[0].getId();
	    }//else
		object.kitItemQty = kitItem.split('=')[1];
		arr.push(object);
	}
	return arr;
    }catch(e){
      nlapiLogExecution('DEBUG', 'Error in getting Items of Kit', e);
    }   
}










