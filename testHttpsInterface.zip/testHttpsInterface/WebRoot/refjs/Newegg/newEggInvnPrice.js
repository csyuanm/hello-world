/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       18 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
//{
//"Type": "1",
//"Value": "A006BSP3",
//"Inventory": "20",
//"MSRP": "250",
//"MAP": "230",
//"CheckoutMAP": "0",
//"SellingPrice": "200",
//"EnableFreeShipping": "1",
//"Active": "0",
//“FulfillmentOption”:”1”
//}
var b2b = "/b2b";

function scheduled(type) {
   
 try{
	 
	var context = nlapiGetContext();
	var itemDes = '';
    var newegg_actid = context.getSetting('SCRIPT','custscript5');
    var kitUpdate = context.getSetting('SCRIPT','custscript_kit_update');
    nlapiLogExecution('Audit','kitUpdate is ',kitUpdate);
    if(newegg_actid == 1){
        b2b = '';
      }
    
	var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_storefront',
		'custrecord_newegg_sellerid','name'];
	var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	
	var search = nlapiCreateSearch('customrecord_newegg_listings');//1889
	 
	//filters
	
	if(kitUpdate == 'F'){
		itemDes = 'Inventory'
		search.addFilter(new nlobjSearchFilter('custrecord_newegg_item', null, 'noneof', '@NONE@'));
	}
	else{
		itemDes = 'Kit';
		search.addFilter(new nlobjSearchFilter('custrecord_is_kit', null, 'is', 'T'));
	}
	
	search.addFilter(new nlobjSearchFilter('custrecord_newegg_item_acc',null,'is',newegg_actid));
	search.addFilter(new nlobjSearchFilter('custrecord_is', null, 'is', 'T'));
	//search.addFilter(new nlobjSearchFilter('internalid', null, 'is','258'));// '1774' //'1737'//1690;
	//columns
	search.addColumn(new nlobjSearchColumn('custrecord_is_kit'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item_sku'));
	search.addColumn(new nlobjSearchColumn('custrecord_is_qty_ovrwrite'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_itemprice'));
    var startIndx = 0;
	var endIndx = 500;
	var i = 0;
    
	var resultSet = search.runSearch();
	var result = resultSet.getResults(startIndx,endIndx);
	var arr = [];
	var feedData = [];
	nlapiLogExecution('Debug','result length',result.length);
    while(result.length != null && i < result.length){
    	
    	
		
		checkGovernance();
		
		var recId = result[i].getId();
		nlapiLogExecution('Audit','i value is ',i);
		var sellerSku = result[i].getValue('custrecord_newegg_item_sku');// newegg seller sku
		nlapiLogExecution('Debug','sellerSku',sellerSku);
		//var price = getPrice(id,columns);// item price from newegg system
		var price = result[i].getValue('custrecord_newegg_itemprice');
		var overwrite = result[i].getValue('custrecord_is_qty_ovrwrite');
		nlapiLogExecution('Debug','overwrite',overwrite);
		if(overwrite == "T"){
			var qty = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_ovrwrite_qty');
			nlapiLogExecution('Debug','inside overwrite qty',qty);
			var obj = {};
	        obj.SellerPartNumber = sellerSku;
	        obj.Inventory = qty;
	        if(price != '' && price > 0)
	        obj.SellingPrice = price;
	      		
	        feedData.push(obj);
		}
		else{
			var isKit = result[i].getValue('custrecord_is_kit');
			nlapiLogExecution('Debug','iskit',isKit);
			if(isKit == "F"){
			   
				var itemID = result[i].getValue('custrecord_newegg_item');
		       
		        if(itemID){
				var item = nlapiLoadRecord('inventoryitem', itemID);
				nlapiLogExecution('DEBUG', 'itemID', itemID);
				var loc = item.findLineItemValue('locations','location_display','3B USA : South Bend : South Bend Primary');
				nlapiLogExecution('DEBUG', 'loc', loc);
				var qty = item.getLineItemValue('locations','quantityavailable', loc);
				nlapiLogExecution('DEBUG', 'qty', qty);
				 nlapiLogExecution('DEBUG', 'itemID', itemID);
//		        if(qty > 200){
//					qty = 200;
//				}
				var obj = {};
		        obj.SellerPartNumber = sellerSku;
		        obj.Inventory = qty;
		        if(price != '' && price > 0)
		        obj.SellingPrice = price;
		      		
		        feedData.push(obj);
		        
		        }else{
		        	i++;
		        
		        	nlapiLogExecution('Error','error :Item not avail '+i+' ,record :',recId);
		        	continue;
		        }
		
		       }
			   else{
				
				var kitRec = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_kit_item');
				nlapiLogExecution('Debug','kitRec',kitRec);
				//var newEggSku = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_sku');
				var mapping = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_mapping');
				nlapiLogExecution('Debug','mapping',mapping);
				var mappItems = mapping.split(';');
				var kitArr = []
				for(var k = 0;k<mappItems.length;k++){
					
					var mappItemArr = mappItems[k].split('=');
					var mapItemName = mappItemArr[0];
					nlapiLogExecution('Debug',' mapItemName',mapItemName)
					var mapItemQty = mappItemArr[1];
					var filter = [];
					filter.push(new nlobjSearchFilter('itemid',null,'is',mapItemName))
					var itemFound = nlapiSearchRecord('item',null,filter);
					nlapiLogExecution('Debug',' itemFound',JSON.stringify(itemFound));
					
					var loc = '3B USA : South Bend : South Bend Primary';
					var column = [];
					column.push(new nlobjSearchColumn('formulanumeric',null,'max').setFormula("DECODE({inventorylocation.name},'"+loc+"',{locationquantityavailable})"));
					
					var fil = [];
					fil.push(new nlobjSearchFilter('internalid',null,'is',itemFound[0].id))
				   // var recType = nlapiLookupField('item',itemFound[0].id,'recordtype');		
					var itemRec =  nlapiSearchRecord('item',null,fil,column);
					//var loc = itemRec.findLineItemValue('locations','location_display','USA : South Bend : South Bend Primary');
					var invQty = itemRec[0].getValue(column[0]);
					nlapiLogExecution('Debug',' invQty',invQty);
					
					var kitQty = Math.floor(invQty/mapItemQty);
					nlapiLogExecution('Debug',' kitQty',kitQty);
					kitArr.push(kitQty);
					
				}
				nlapiLogExecution('Debug','kit Arr',JSON.stringify(kitArr))
				var kit_qty = kitArr[0];
				for(var t=1;t<kitArr.length;t++)
				{
					if(kitArr[t]<kit_qty)
						kit_qty=kitArr[t];
					
				}
				
				nlapiLogExecution('Debug',' kit_qty 123',kit_qty)
				var obj = {};
		        obj.SellerPartNumber = sellerSku;
		        obj.Inventory = kit_qty;
		        if(price != '' && price > 0)
		        obj.SellingPrice = price;
		      		
		        feedData.push(obj);
				
			}
		}
		
		
     
        i++;
//		if(i == 100){
//			break;
//		}
        
        
		if(i >= result.length){
			startIndx = endIndx;
			endIndx += 500;
			result = resultSet.getResults(startIndx,endIndx);
			i = 0;
		}
        
	
    }
    
    nlapiLogExecution('Audit','feedData length',feedData.length);
    var feedResult = update(columns,feedData);
    
    var newAttachment1 = nlapiCreateFile('feedData.txt',
			'PLAINTEXT', JSON.stringify(feedData));
	
    var newAttachment2 = nlapiCreateFile('feedresult.txt',
				'PLAINTEXT', feedResult);
       
		nlapiSendEmail(1659, 'ratul@webbee.biz',
		'Quantity Report Newegg | '+columns.name+' | '+itemDes,
		'File Attached', null,
		null, null, [newAttachment1,newAttachment2]);
 }
 catch(e){
	 nlapiLogExecution('Debug','error in script',e);
	
 }
	
}

function update(columns,feedData){
	
	var sellerId = columns.custrecord_newegg_sellerid;
	var SecretKey = columns.custrecord_secretkey;
	var authKey =  columns.custrecord_authorization_key;
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	 
	nlapiLogExecution('Audit','b2b is ',b2b);
	var body = {
			"NeweggEnvelope": {
				"Header": { "DocumentVersion": "1.0" },
				"MessageType": "Inventory",
				"Message": {
				"Inventory": {
				"Item": feedData
				}
				}
				}
				}
    
    
    var url = "https://api.newegg.com/marketplace"+b2b+"/datafeedmgmt/feeds/submitfeed?sellerid="+ sellerId+"&requesttype=INVENTORY_AND_PRICE_DATA"
    nlapiLogExecution('Debug','on Update / headers',JSON.stringify(headers));
    nlapiLogExecution('Debug','on Update / body',JSON.stringify(body));
	nlapiLogExecution('Debug','on Update / URL',url);
	var response = nlapiRequestURL(url, JSON.stringify(body), headers,"POST");
	nlapiLogExecution('Debug','response',response.getBody());
	//response = nlapiStringToXML(response.getBody());
	
	return response.getBody();
	 
    
    
}


//function getPrice(id,columns){
//	
//	var sellerId = columns.custrecord_newegg_sellerid;
//	var SecretKey = columns.custrecord_secretkey;
//	var authKey =  columns.custrecord_authorization_key;
//	var headers = {
//		    "Authorization": authKey,
//		    "SecretKey": SecretKey,
//		    "Content-Type": "application/json"
//		  }
//	
//	var body = {};
//    body.Type = 0;
//    body.Value = id;
//	
//    var url = "https://api.newegg.com/marketplace/contentmgmt/item/price?sellerid="+ sellerId;
//    var response = nlapiRequestURL(url, JSON.stringify(body), headers,"POST");
//	nlapiLogExecution('Debug','response',response.getBody());
//	response = nlapiStringToXML(response.getBody());
//	
//	var msrp = nlapiSelectValue(response, '/PriceResult/MSRP');
//	var sellingPrice = nlapiSelectValue(response, '/PriceResult/SellingPrice');
//	nlapiLogExecution('Debug','MSRP',msrp);
//	nlapiLogExecution('Debug','sellingPrice',sellingPrice);
//	return sellingPrice;
//    
//}



function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}