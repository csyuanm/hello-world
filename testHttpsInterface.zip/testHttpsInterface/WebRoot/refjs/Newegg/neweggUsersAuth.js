/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Dec 2016     ratul
 *
 */

/**
 * @param {Object} dataIn Parameter object
 * @returns {Object} Output object
 */
function isAuth(dataIn) {
	
	var username = dataIn.user;
	var password = dataIn.pass;
	
	var filter = [];
	filter.push(new nlobjSearchFilter('custrecord_user',null,'is',username));
	filter.push(new nlobjSearchFilter('custrecord_pass',null,'is',password));
	
	var column = [];
	column.push(new nlobjSearchColumn('custrecord_user'));
	column.push(new nlobjSearchColumn('custrecord_pass'));
	
	var searchRec = nlapiSearchRecord('customrecord_newegg_usersauth',null,filter,column); 
	
	nlapiLogExecution('Debug','searchResult',JSON.stringify(searchRec))
	var rslt ;
	if(searchRec){
		rslt = true;
	}
	else{
		rslt = false;
	}
	
	return {'valid': rslt};
}
