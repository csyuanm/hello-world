/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       20 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
   try{
	var context = nlapiGetContext();
	
    var newegg_actid = context.getSetting('SCRIPT','custscript6');
	
	var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_storefront',
		'custrecord_newegg_sellerid'];
	var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	
	var search = nlapiLoadSearch('customrecord_newegg_listings','customsearch_newegg_listing');
	 
	
	search.addFilter(new nlobjSearchFilter('custrecord_newegg_item_acc',null,'is',newegg_actid));
	search.addFilter(new nlobjSearchFilter('custrecord_is', null, 'is', 'T'))
	
	var resultSet = search.runSearch();
	var result = resultSet.getResults(0,1000);
	var arr = [];
	for(var i = 0;i<2;i++){
		 
	   var id = result[i].getValue('custrecord_newegg_item_id');
       
       var rslt = getInventory(columns,id);
	  
       arr.push(rslt);
        
	}
	nlapiLogExecution('Debug','arr',JSON.stringify(arr))
   }
   catch(e){
	   nlapiLogExecution('Debug','error',e)
   }
	
	
}

function getInventory(columns,id){
	
	var sellerId = columns.custrecord_newegg_sellerid;
	var SecretKey = columns.custrecord_secretkey;
	var authKey = columns.custrecord_authorization_key;
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	
	 
	
	var body = {};
    body.Type = 0;
    body.Value = id;
     
	
    var url = "https://api.newegg.com/marketplace/contentmgmt/item/inventory?sellerid="+ sellerId;
    
    nlapiLogExecution('Debug','on Update / headers',JSON.stringify(headers));
    nlapiLogExecution('Debug','on Update / body',JSON.stringify(body));
	nlapiLogExecution('Debug','on Update / URL',url);
	var response = nlapiRequestURL(url, JSON.stringify(body), headers,"POST");
	
	response = nlapiStringToXML(response.getBody());
	
	var obj = {};
    obj.newEggItem = nlapiSelectValue(response, '/InventoryResult/ItemNumber') 
    obj.quantity = nlapiSelectValue(response, '/InventoryResult/AvailableQuantity') 
	
	return obj;
    
    
}

