/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       15 Dec 2016     Admin
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
var b2b="/b2b";
function requestReport(type) {

 //try{
	
  var obj = nlapiGetContext();
  var newegg_actid = obj.getSetting('SCRIPT', 'custscript8');
  nlapiLogExecution('DEBUG', 'newegg_actid', newegg_actid);
   if(newegg_actid==1){
     b2b='';
   }
  var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_sellerid',
    'custrecord_newegg_marketplace', 'custrecord_newegg_soform', 'custrecord_newegg_subsidiary',
    'custrecord_accounts_receivable', 'custrecord_newegg_location', 'custrecord_newegg_storefront',
    'custrecord_orderreportid', 'custrecord_last_orderreport_time'
  ];
  var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
  var sellerId = columns.custrecord_newegg_sellerid;
  var SecretKey = columns.custrecord_secretkey;
  var authKey = columns.custrecord_authorization_key;
  
  var subsidiary = columns.custrecord_newegg_subsidiary; 
  var location = columns.custrecord_newegg_location;
  var storefront = columns.custrecord_newegg_storefront;
  var reportId = columns.custrecord_orderreportid;
  var lastReporttime = columns.custrecord_last_orderreport_time;
  
  var headers = {
    "Authorization": authKey,
    "SecretKey": SecretKey,
    "Content-Type": "application/json"
  }
  
  
 
    
        var reportId = '22BEEKO2HDEAP';
        var reportData =  GetReportData(reportId, sellerId, headers,columns);
        nlapiLogExecution('Debug', 'reportData',JSON.stringify(reportData));
        nlapiLogExecution('Debug', 'report Data length',reportData.length);
        
        for(var j = 3;j<reportData.length;j++){
        	
        	if(j == 4){
        		break;
        	}
        	start(reportData[j],newegg_actid,"T");
        	
        }
        
        var file = nlapiCreateFile('testData.txt','PLAINTEXT',JSON.stringify(reportData));
	      file.setFolder('1121488');
	      var fId = nlapiSubmitFile(file);
	      nlapiLogExecution('Debug', 'fId',fId);            
        //nlapiSubmitField('customrecord_newegg_accounts', newegg_actid, 'custrecord_orderreportid', '');
        
       // var lastTime = new Date();
       // lastTime.setMilliseconds((lastTime.getMilliseconds() - 1800000));
       // lastTime = lastTime.toISOString();
       // lastTime = lastTime.split('.')
       // nlapiSubmitField('customrecord_newegg_accounts', newegg_actid, 'custrecord_last_orderreport_time', lastTime[0])
        nlapiLogExecution('Debug', 'script ends here','<<<--->>>');
}
    
function GetReportData(reportId, sellerId, headers,columns) {
 
//	try {
	  var marketplace = columns.custrecord_newegg_marketplace;
	  var so_form = columns.custrecord_newegg_soform;
	  var location = columns.custrecord_newegg_location;
	  var storefront = columns.custrecord_newegg_storefront;
	  var accontReceivable = columns.custrecord_accounts_receivable;
	  if(storefront!="18"){
        b2b='';        
      }
	  var page = 1;
	  var flag = 0;
	  var name = 0;
	  var orders = [];
	  
	  while (flag == 0) {
		  
	    var postData = {
	      "OperationType": "OrderListReportRequest",
	      "RequestBody": {
	        "RequestID": reportId,
	        "PageInfo": {
	          "PageSize": "100",
	          "PageIndex": page
	        }
	      }
	    }
	    nlapiLogExecution('Debug', 'postData', JSON.stringify(postData));
	    var url = 'https://api.newegg.com/marketplace'+b2b+'/reportmgmt/report/result?sellerid=' + sellerId;
	    var rawResponse = nlapiRequestURL(url, JSON.stringify(postData), headers, 'PUT');
	    nlapiLogExecution('Debug', 'response', rawResponse.getBody());
	    var response = nlapiStringToXML(rawResponse.getBody());
	    
	    var loadfile = nlapiLoadFile('1955328');
	    
	    
	    response = nlapiStringToXML(loadfile.getValue())
	    
	    var isSuccess = nlapiSelectValue(response, '/NeweggAPIResponse/IsSuccess');
	    nlapiLogExecution('Debug', 'isSuccess', isSuccess);
	    if (isSuccess == 'true') {
	    	
	      
	      
	     
	      var totalpage = nlapiSelectValue(response, '/NeweggAPIResponse/ResponseBody/PageInfo/TotalPageCount');
	      nlapiLogExecution('Debug', 'totalpage', totalpage);
	      
	      var orderInfoList = response.getElementsByTagName('OrderInfo');
	      nlapiLogExecution('Debug', 'orderInfoList', orderInfoList.length);
	      
	      var name = 0;
	      
	      
	      for(var i = 0;i<orderInfoList.length;i++){
	    	  
	    	  var orderObj = {};
	    	  orderObj.firstName = response.getElementsByTagName('ShipToFirstName').item(i).textContent;
	    	  orderObj.lastName = response.getElementsByTagName('ShipToLastName').item(i).textContent;
	    	  orderObj.email = response.getElementsByTagName('CustomerEmailAddress').item(i).textContent;
	    	  orderObj.phone = response.getElementsByTagName('CustomerPhoneNumber').item(i).textContent;
	    	  orderObj.orderNumber = response.getElementsByTagName('OrderNumber').item(i).textContent;
	    	  nlapiLogExecution('Audit','orderObj.orderNumber',orderObj.orderNumber)
              var ShipService = response.getElementsByTagName('ShipService').item(i).textContent;
              
              nlapiLogExecution('Audit','ShipService',ShipService)
              if(ShipService === "Standard Shipping (5-7 business days)"){
                  orderObj.ship_via = 'Ground';
              }
              if(ShipService === "One-Day Shipping(Next day)"){
                  orderObj.ship_via = "Next Day";
              }
              if(ShipService === "Two-Day Shipping(2 business days)"){
                  orderObj.ship_via = '2 Days';
              }
              if(ShipService === "Expedited Shipping (3-5 business days)"){
                  orderObj.ship_via = 'Expedited';
              }  
            
            
	    	   
	    	  orderObj.status = "B";   //"B"  response.getElementsByTagName('OrderStatus').item(i).textContent;
	    	  orderObj.market = marketplace;
	    	  orderObj.storefront = storefront;
	    	  orderObj.shippingAmount = response.getElementsByTagName('ShippingAmount').item(i).textContent;
	    	  orderObj.account = accontReceivable;
	    	  orderObj.location = location;
	    	  orderObj.form = so_form;
	    	  orderObj.reportid = reportId;
	    	  orderObj.shipping = {};
	    	  orderObj.shipping.addr1 = response.getElementsByTagName('ShipToAddress1').item(i).textContent;
	    	  orderObj.shipping.addr2 = response.getElementsByTagName('ShipToAddress2').item(i).textContent;
	    	  orderObj.shipping.city = response.getElementsByTagName('ShipToCityName').item(i).textContent;
	    	  orderObj.shipping.state = response.getElementsByTagName('ShipToStateCode').item(i).textContent;
	    	  orderObj.shipping.zip = response.getElementsByTagName('ShipToZipCode').item(i).textContent;
	    	  orderObj.shipping.country = response.getElementsByTagName('ShipToCountryCode').item(i).textContent;
	    	  
	          orderObj.billing = orderObj.shipping;  
	
	    	  
	    	   
	    	  
	          var itemLength =  response.getElementsByTagName('OrderInfo').item(i).getElementsByTagName('ItemInfoList').item(0).getElementsByTagName('ItemInfo');
	    	  nlapiLogExecution('Debug', 'itemlength', itemLength.length);
	    	  
	    	  orderObj.items = [];
	    	  
	    	  for(var j = 0;j<itemLength.length;j++){
	    		  
	    		  var itemObj = {}
	    		  
	    		  itemObj.item_id = itemLength.item(j).getElementsByTagName('SellerPartNumber').item(0).textContent;
	    		  nlapiLogExecution('Debug','item_id', itemObj.item_id);
	        	try{
                itemObj.description = itemLength.item(j).getElementsByTagName('Description').item(0).textContent;
                }catch(e){
                  nlapiLogExecution('Debug', 'desc', e);
                }
                try{ 
	        	  itemObj.price = itemLength.item(j).getElementsByTagName('UnitPrice').item(0).textContent;
                  }catch(e){
                  nlapiLogExecution('Debug', 'price', e);
                }
                try{ 
	        	  itemObj.qty = itemLength.item(j).getElementsByTagName('OrderedQty').item(0).textContent;
	        	   }catch(e){
                  nlapiLogExecution('Debug', 'qty', e);
                }
                 nlapiLogExecution('Debug', 'End', "END");
	        	  orderObj.items.push(itemObj);
	    		  
	    	  }
	    	
	    	  orders.push(orderObj);
	      }
	     
	     
	      
	      name++;
	      
	      if (totalpage > page) {
	        page++; 
	      } else {
	        flag++
	      }
	      
	
	    }
	  }
	  
	  return orders;
// }
	
// catch(e){
// nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'NewEgg Error: Getting result report',e);
// }
}