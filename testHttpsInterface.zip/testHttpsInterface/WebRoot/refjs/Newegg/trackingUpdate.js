/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       13 Jan 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
var method = {
	178: {service: "APACShipping ePakcet", carrier: "APACShipping"}, 
	175: {service: "China Post", carrier: "China Post"},
	177: {service: "Dutch Post", carrier: "Dutch Post"},
	42548: {service: "First Class Envelop", carrier: "USPS"},
	35311: {service: "To Be Determined", carrier: "To Be Determined"},
	35171: {service: "UPS 2nd Day Air", carrier: "UPS"},
	35174: {service: "UPS 3 Day Select", carrier: "UPS"},
	35173: {service: "UPS Next Day Air Saver", carrier: "UPS"},
	35182: {service: "UPS Worldwide Expedited", carrier: "UPS"},
	35181: {service: "UPS Worldwide Express", carrier: "UPS"},
	4: {service: "UPS Ground", carrier: "UPS"},
	35175: {service: "USPS First Class Envelope (up to 4oz total shipment weight)", carrier: "USPS"},
	8: {service: "USPS First-Class Mail  (up to 14oz total weight)", carrier: "USPS"},
	35179: {service: "USPS Priority Mail Express International", carrier: "USPS"},
	35178: {service: "USPS Priority Mail International", carrier: "USPS"},
	35170: {service: "USPS Priority Mail", carrier: "USPS"},
  	44178: {service: "UPS Next Day Air", carrier: "UPS"}

}

var b2b="/b2b";
var sellerId = '';
var SecretKey = '';
var authKey = '';

function scheduled(type) {
	
  try{	
	nlapiLogExecution('Debug','script starts here',"<<<-->>>")
	
	var context = nlapiGetContext();	
	var newegg_actid = context.getSetting('SCRIPT','custscript7');
	if(newegg_actid == 1){
     b2b='';
   }
	var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_storefront',
		'custrecord_newegg_sellerid'];
	var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	
	sellerId = columns.custrecord_newegg_sellerid;
	SecretKey = columns.custrecord_secretkey;
	authKey = columns.custrecord_authorization_key;
	
	
	var storefront = columns.custrecord_newegg_storefront;
	
	var search = nlapiLoadSearch('transaction',"1506");//1611//1913
    var column = search.getColumns();
	
	search.addFilter(new nlobjSearchFilter('custbody_storefront_list',null,'is',storefront));
	
	var putStructure = {};
	
	var resultSet = search.runSearch();
	var result = resultSet.getResults(0,1000);
	nlapiLogExecution('Debug','results length',result.length);
	var arr = [];
	for(var i = 0 ;i<result.length;i++){
		
		checkGovernance();
		
		var po = result[i].getValue(column[5]);
		
		if(po && !putStructure[po]){
			putStructure[po] = {"recIds":[],
					           "data":{
							        "Action": "2",
							        "Value": {
							            "Shipment": {
							                "Header": {
							                    "SellerID": sellerId,
							                    "SONumber": po
							                },
							                "PackageList": {
							                    "Package": []
							                }
							            }
							        }
							    }
			}
			
			
		}
		if(putStructure[po]) {
          var recId = result[i].getId();
          var methodType = result[i].getValue(column[3]);
          var if_rec=nlapiLoadRecord('itemfulfillment', recId)

          var total_pckg=if_rec.getLineItemCount('package');
          nlapiLogExecution('DEBUG', 'total_pckg', total_pckg);
          var total_items=if_rec.getLineItemCount('item');
          var tracking_no='';
          for(var p=1;p<=total_pckg;p++){
               tracking_no+=if_rec.getLineItemValue('package', 'packagetrackingnumber', p);
               if(p!=total_pckg)
                   tracking_no+='';
          }
          if(tracking_no == '')
              tracking_no = result[i].getValue(column[0]);
          tracking_no = tracking_no.replace(/<BR>/g, ',');
          var pack = {
                  "TrackingNumber": tracking_no,
                  "ShipCarrier": method[methodType].carrier,
                  "ShipService": method[methodType].service,
                  "ItemList": {
                      "Item": []
                  }
          };
          var sellerPart = result[i].getValue(column[1]);
          for(var t=1;t<=total_items;t++){

              var item = {
                      "SellerPartNumber":if_rec.getLineItemValue('item', 'custcol_newegg_sku', t) || sellerPart,
                      "ShippedQty": if_rec.getLineItemValue('item', 'quantity', t)
                  };
              pack.ItemList.Item.push(item);
          }

          putStructure[po].data.Value.Shipment.PackageList.Package.push(pack);
          putStructure[po].recIds.push(recId);

        }
	    
	}
	
	nlapiLogExecution('Audit','putStructure',JSON.stringify(putStructure));
	
	for(var key in putStructure){
		var trackResult = update(key,putStructure[key]);
		var newObj = {};
        newObj.done = trackResult;
        newObj.po = key;
        arr.push(newObj);
	}
	
	
	nlapiLogExecution('Debug','array',JSON.stringify(arr));
  }
  catch(e){
	  nlapiLogExecution('Debug','error in script',e);
  }
}

function update(po,structure){
	
	
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	
	
	var body = structure.data;
	 
	
	var url = "https://api.newegg.com/marketplace"+b2b+"/ordermgmt/orderstatus/orders/"+po+"?sellerid="+ sellerId;
	
	nlapiLogExecution('Debug','on Update / body',JSON.stringify(body));
	nlapiLogExecution('Debug','on Update / URL',url);
	var response = nlapiRequestURL(url, JSON.stringify(body), headers,"PUT");
	nlapiLogExecution('Debug','response',response.getBody());
	response = nlapiStringToXML(response.getBody());
	
	var isSuccess = nlapiSelectValue(response, '/UpdateOrderStatusInfo/IsSuccess');
	var errorCode = nlapiSelectValue(response, '/Errors/Error/Code');
	
    if(isSuccess === "true"){
    var status = nlapiSelectValue(response, '/UpdateOrderStatusInfo/Result/Shipment/PackageList/Package/ProcessResult');
    if(status == "Success"){
    	submitTrue(structure.recIds);
		nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'Order Shipped | Newegg', 'Order ID : '+po+'\n'+JSON.stringify(structure)) ;
        
      
	  nlapiLogExecution('Debug','tracking done',"true");
	  return "True";
    }
      else{
  		nlapiSendEmail(1659, 'zake@webbeeglobal.com', 'Order Not Shipped | Newegg', 'Order ID : '+po+'\n'+JSON.stringify(structure)) ;

        return "False";
      }
    }
    else if(errorCode === "SO011"){
    	submitTrue(structure.recIds);
    	nlapiLogExecution('Debug','tracking done',"true");
    	return "True";
    }
    else{
    	nlapiLogExecution('Debug','tracking done',"false");
    	return "False";
    }
	
	
	
}


function submitTrue(recordIds){
	
	for(var j = 0;j<recordIds.length;j++){
		nlapiLogExecution('Audit','recordIds',recordIds[j]);
		nlapiSubmitField('itemfulfillment',recordIds[j],'custbody_tracking_number_sync','T');
	}
	
}


function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}


























