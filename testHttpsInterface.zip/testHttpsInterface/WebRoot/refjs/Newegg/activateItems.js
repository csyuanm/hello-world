/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       04 May 2017     ratul
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */



var b2b = "/b2b";

function scheduled(type) {
	
	
	
    var context = nlapiGetContext();
	
    var newegg_actid = context.getSetting('SCRIPT','custscript_account');
    var kitUpdate = context.getSetting('SCRIPT','custscript_is_kit_item');
    if(newegg_actid == 1){
        b2b = '';
      }
    
	var fields = ['custrecord_authorization_key', 'custrecord_secretkey', 'custrecord_newegg_storefront',
		'custrecord_newegg_sellerid','name'];
	var columns = nlapiLookupField('customrecord_newegg_accounts', newegg_actid, fields);
	
	
	
	//
//	var activeData = [];
//	var feedId = "28A7VZ8TBQGSI";
	//var data = getFeedResult(feedId,columns);
	
	
	
	
	var search = nlapiCreateSearch('customrecord_newegg_listings');//1889
	 
	//filters
	
	if(kitUpdate == 'F'){
		
		search.addFilter(new nlobjSearchFilter('custrecord_newegg_item', null, 'noneof', '@NONE@'));
	}
	else{
		
		search.addFilter(new nlobjSearchFilter('custrecord_is_kit', null, 'is', 'T'));
	}
	
	search.addFilter(new nlobjSearchFilter('custrecord_newegg_item_acc',null,'is',newegg_actid));
	search.addFilter(new nlobjSearchFilter('custrecord_is', null, 'is', 'T'));
	//search.addFilter(new nlobjSearchFilter('internalid', null, 'is','258'));// '1774' //'1737'//1690;
	//columns
	search.addColumn(new nlobjSearchColumn('custrecord_is_kit'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item_sku'));
	search.addColumn(new nlobjSearchColumn('custrecord_is_qty_ovrwrite'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_item'));
	search.addColumn(new nlobjSearchColumn('custrecord_newegg_itemprice'));
    var startIndx = 0;
	var endIndx = 500;
	var i = 0;
    
	var resultSet = search.runSearch();
	var result = resultSet.getResults(startIndx,endIndx);
	var arr = [];
	var feedData = [];
	nlapiLogExecution('Debug','result length',result.length);
    while(result.length != null && i < result.length){
    	
    	
		
		checkGovernance();
		
		var recId = result[i].getId();
		nlapiLogExecution('Audit','i value is ',i);
		var sellerSku = result[i].getValue('custrecord_newegg_item_sku');// newegg seller sku
		nlapiLogExecution('Debug','sellerSku',sellerSku);
		//var price = getPrice(id,columns);// item price from newegg system
		var price = result[i].getValue('custrecord_newegg_itemprice');
		var overwrite = result[i].getValue('custrecord_is_qty_ovrwrite');
		nlapiLogExecution('Debug','overwrite',overwrite);
		if(overwrite == "T"){
			var qty = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_ovrwrite_qty');
			nlapiLogExecution('Debug','inside overwrite qty',qty);
			var obj = {};
	        obj.SellerPartNumber = sellerSku;
	        obj.Inventory = qty;
	        if(price != '' && price > 0)
	        obj.SellingPrice = price;
	      		
	        feedData.push(obj);
		}
		else{
			var isKit = result[i].getValue('custrecord_is_kit');
			nlapiLogExecution('Debug','iskit',isKit);
			if(isKit == "F"){
			   
				var itemID = result[i].getValue('custrecord_newegg_item');
		       
		        if(itemID){
				var item = nlapiLoadRecord('inventoryitem', itemID);
				nlapiLogExecution('DEBUG', 'itemID', itemID);
				var loc = item.findLineItemValue('locations','location_display','3B USA : South Bend : South Bend Primary');
				nlapiLogExecution('DEBUG', 'loc', loc);
				var qty = item.getLineItemValue('locations','quantityavailable', loc);
				nlapiLogExecution('DEBUG', 'qty', qty);
				 nlapiLogExecution('DEBUG', 'itemID', itemID);
//		        if(qty > 200){
//					qty = 200;
//				}
				var obj = {};
		        obj.SellerPartNumber = sellerSku;
		        obj.Inventory = qty;
		        if(price != '' && price > 0)
		        obj.SellingPrice = price;
		      		
		        feedData.push(obj);
		        
		        }else{
		        	i++;
		        
		        	nlapiLogExecution('Error','error :Item not avail '+i+' ,record :',recId);
		        	continue;
		        }
		
		       }
			   else{
				
				var kitRec = nlapiLookupField('customrecord_newegg_listings',recId,'custrecord_kit_item');
				nlapiLogExecution('Debug','kitRec',kitRec);
				//var newEggSku = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_sku');
				var mapping = nlapiLookupField('customrecord_kit',kitRec,'custrecord_kit_mapping');
				nlapiLogExecution('Debug','mapping',mapping);
				var mappItems = mapping.split(';');
				var kitArr = []
				for(var k = 0;k<mappItems.length;k++){
					
					var mappItemArr = mappItems[k].split('=');
					var mapItemName = mappItemArr[0];
					nlapiLogExecution('Debug',' mapItemName',mapItemName)
					var mapItemQty = mappItemArr[1];
					var filter = [];
					filter.push(new nlobjSearchFilter('itemid',null,'is',mapItemName))
					var itemFound = nlapiSearchRecord('item',null,filter);
					nlapiLogExecution('Debug',' itemFound',JSON.stringify(itemFound));
					
					var loc = '3B USA : South Bend : South Bend Primary';
					var column = [];
					column.push(new nlobjSearchColumn('formulanumeric',null,'max').setFormula("DECODE({inventorylocation.name},'"+loc+"',{locationquantityavailable})"));
					
					var fil = [];
					fil.push(new nlobjSearchFilter('internalid',null,'is',itemFound[0].id))
				   // var recType = nlapiLookupField('item',itemFound[0].id,'recordtype');		
					var itemRec =  nlapiSearchRecord('item',null,fil,column);
					//var loc = itemRec.findLineItemValue('locations','location_display','USA : South Bend : South Bend Primary');
					var invQty = itemRec[0].getValue(column[0]);
					nlapiLogExecution('Debug',' invQty',invQty);
					
					var kitQty = Math.floor(invQty/mapItemQty);
					nlapiLogExecution('Debug',' kitQty',kitQty);
					kitArr.push(kitQty);
					
				}
				nlapiLogExecution('Debug','kit Arr',JSON.stringify(kitArr))
				var kit_qty = kitArr[0];
				for(var t=1;t<kitArr.length;t++)
				{
					if(kitArr[t]<kit_qty)
						kit_qty=kitArr[t];
					
				}
				
				nlapiLogExecution('Debug',' kit_qty 123',kit_qty)
				var obj = {};
		        obj.SellerPartNumber = sellerSku;
		        obj.Inventory = kit_qty;
		        if(price != '' && price > 0)
		        obj.SellingPrice = price;
		      		
		        feedData.push(obj);
				
			}
		}
		
		
     
        i++;
        
        
		if(i >= result.length){
			startIndx = endIndx;
			endIndx += 500;
			result = resultSet.getResults(startIndx,endIndx);
			i = 0;
		}
        
	
    }
	
	
	
	
	
    //
//    for(var k = 0;k<feedData.length;k++){
//		
//		var sellerPart = feedData[k].SellerPartNumber;
//		var invntory = feedData[k].Inventory;
//		
//		if(data.indexOf(sellerPart) != -1 && invntory > 0){
//			var newFeedData = feedData[k];
//			
//			activeData.push(newFeedData);
//		}
//		
//	}
	
//    var newAttachment = nlapiCreateFile('activateItemData.txt',
//			'PLAINTEXT', JSON.stringify(activeData));
//   
//	nlapiSendEmail(1659, 'ratul@webbee.biz',
//	'Activate Item data| NewEgg |  '+columns.name,
//	'File Attached', null,
//	null, null, [newAttachment]);
	
	var feedResultArr = [];
	
	for(var j = 0;j<feedData.length;j++){
		
	    checkGovernance()
	
		var newData = feedData[j];
		
		var rslt = update(columns,newData); 
		nlapiLogExecution('Audit','j is '+j+',update done for',rslt);
		var obj = {};
		obj.sellerPart = newData.SellerPartNumber;
		obj.result = rslt.toString()
		feedResultArr.push(obj);
		
		
		
	}
	
	var newAttachment = nlapiCreateFile('feedResultArr.txt',
			'PLAINTEXT', JSON.stringify(feedResultArr));
   
	nlapiSendEmail(1659, 'ratul@webbee.biz',
	'Activate Item data | NewEgg |  '+columns.name,
	'File Attached', null,
	null, null, [newAttachment]);
	
}





function getFeedResult(feedId,columns){
	
	var sellerId = columns.custrecord_newegg_sellerid;
	var SecretKey = columns.custrecord_secretkey;
	var authKey =  columns.custrecord_authorization_key;
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	
	var feedresultUrl = "https://api.newegg.com/marketplace"+b2b+"/datafeedmgmt/feeds/result/"+feedId+"?sellerid="+sellerId;
	
	var response = nlapiRequestURL(feedresultUrl,null, headers,"GET");
	//nlapiLogExecution('Audit','feedresult ', response.getBody())
	
	
	var x2js = new X2JS();

    var data = x2js.xml_str2json(response.getBody());
    
    var newAttachment = nlapiCreateFile('activateItemData.txt',
			'PLAINTEXT', JSON.stringify(data));
   
	nlapiSendEmail(1659, 'ratul@webbee.biz',
	'Activate Item data| NewEgg |  '+columns.name,
	'File Attached', null,
	null, null, [newAttachment]);
	
    //nlapiLogExecution('Audit','feedresult data JSON ', JSON.stringify(data));
    
	var arr = [];
	var result = data.NeweggEnvelope.Message.ProcessingReport.Result; //data.Message.ProcessingReport.Result;

	for(var i = 0;i<result.length;i++){

	   var error = result[i].ErrorList.ErrorDescription.__cdata;
	   if(error != "CEI0001:Can't find this item in the system, please create it first" && error != "CEI0022:Item On Promotion,Locked by Newegg." && error != "CEI0011:The following field(s) has failed to update due to item price locked by promotion: Selling Price. All other fields updated successfully."){
	      var sellerpart = result[i].AdditionalInfo.SellerPartNumber.__cdata;
	      arr.push(sellerpart);
	   }

	}
	nlapiLogExecution('Audit','arr res ', JSON.stringify(arr));
	return arr;
}


function update(columns,obj){
	
	var sellerId = columns.custrecord_newegg_sellerid;
	var SecretKey = columns.custrecord_secretkey;
	var authKey =  columns.custrecord_authorization_key;
	var headers = {
		    "Authorization": authKey,
		    "SecretKey": SecretKey,
		    "Content-Type": "application/json"
		  }
	
	var body = {};
    body.Type = 1;//seller Part type
    body.Value = obj.SellerPartNumber;
    body.Inventory = obj.Inventory;
    if(obj['SellingPrice'])
    body.SellingPrice = obj.SellingPrice;
    body.Active = "1";
	
	var url = "https://api.newegg.com/marketplace"+b2b+"/contentmgmt/item/inventoryandprice?sellerid="+ sellerId;
	
	var response = nlapiRequestURL(url, JSON.stringify(body), headers,"PUT");
	
	return response.getBody();
	
}


function checkGovernance(){
	
	try{
		var context = nlapiGetContext();
		
		if(context.getRemainingUsage() < 100){
			
			nlapiLogExecution('Debug','Remaining usage : ', context.getRemainingUsage())
			
			var script = nlapiYieldScript();
			if(script.status == "FAILURE"){
				nlapiLogExecution('Debug','script STOPPED because of : ', script.reason + '/SIZE : '+script.size);
			}
			
			if(script.status == "RESUME"){
				nlapiLogExecution('Debug','script resuming because of : ', script.reason + '/SIZE : '+script.size);
			}
		}
	}
	catch(err){
		nlapiLogExecution('Debug','checkGovernance failure', err);
	}
	
}







var ac = [
	  {
		    "SellerPartNumber": "PD-GB-BXI5-5200-F",
		    "Inventory": "11",
		    "SellingPrice": "219.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-VR-VTK-VRCS-1-WHT",
		    "Inventory": "44",
		    "SellingPrice": "1.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-VR-VTK-VRCP-1-BLK",
		    "Inventory": "221",
		    "SellingPrice": "14.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-DE-XPS870-7312K-F",
		    "Inventory": "2",
		    "SellingPrice": "799.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-DE-I3656-3355BLK-F",
		    "Inventory": "1",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PL-DE-AW17R3-4175SLV-F",
		    "Inventory": "5",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-ES-NG-1-REM",
		    "Inventory": "1",
		    "SellingPrice": "29.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PL-DE-AW13R2-8900SLV-F",
		    "Inventory": "3",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-DE-X8900-7944BLK-F",
		    "Inventory": "2",
		    "SellingPrice": "1099.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PL-DE-I7559-3762GRY-F",
		    "Inventory": "1",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PS-VTK-700W-24PIN-V2",
		    "Inventory": "43",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PS-VTK-600W-24PIN-V2",
		    "Inventory": "381",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PS-VTK-450W-24PIN-V2",
		    "Inventory": "554",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PS-VTK-850W-24PIN",
		    "Inventory": "82",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "KB-USB-VTK-TWILIGHT",
		    "Inventory": "598",
		    "SellingPrice": "29.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "MB-AM3-AS-M4A87TD-U3",
		    "Inventory": "1",
		    "SellingPrice": "49.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PSM-CM-450W-24PIN",
		    "Inventory": "204",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HG-WAR-WPM1000WS#2",
		    "Inventory": "69",
		    "SellingPrice": "109.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "MS-USB-ZOW-EC2-A",
		    "Inventory": "80",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-GB-BSI7H-6500LAIWUS-F",
		    "Inventory": "1",
		    "SellingPrice": "339.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-SBW-STRON-T6-PNKCMO",
		    "Inventory": "100",
		    "SellingPrice": "499.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-SBW-SR-56729-5",
		    "Inventory": "898",
		    "SellingPrice": "399.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "HE-PAS-SWGR-PRO-2",
		    "Inventory": "714",
		    "SellingPrice": "399.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-GB-BXI7-4770R-F",
		    "Inventory": "10",
		    "SellingPrice": "399.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "PD-GB-BXI5-4200-F",
		    "Inventory": "4",
		    "SellingPrice": "259.99",
		    "Active": "1"
		  },
		  {
		    "SellerPartNumber": "MB-1150-AS-H81I-PCSM",
		    "Inventory": "3",
		    "SellingPrice": "87.99",
		    "Active": "1"
		  }
		]


