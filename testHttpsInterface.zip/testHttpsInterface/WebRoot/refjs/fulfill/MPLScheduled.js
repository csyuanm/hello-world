function run() {
    try {
        var d = new Date();
        _log("new Date()", d);
    } catch (e) {
        processException(e);
    }
}