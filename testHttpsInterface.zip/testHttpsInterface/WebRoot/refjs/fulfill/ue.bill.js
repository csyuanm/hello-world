/**
 * 这个是Invoice 专属的UE
 * @param type
 * @param form
 * @param request
 */
function beforeLoad(type, form, request) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    try {
        var ctx = nlapiGetContext().getExecutionContext();

        var subsidiary = nlapiGetFieldValue('subsidiary');
        if (subsidiary == Subsidiaries.TaiwuInternational && ctx == 'userinterface') {
            if (type == 'view') {
                form.setScript('customscript_client_so');
                form.setScript('customscript_cs_button_action');
                if (nlapiGetFieldValue('status') == 'Open') {
                    var market = nlapiGetFieldValue('custbody_marketplace');
                    if (market == MarketplaceShipName.eBay) {
                        //if (nlapiGetFieldValue('custbody_order_type') != 3) {
                        form.addButton("custpage_ap", "收款", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=904&deploy=1&" + serializeURL({
                            ivsId: id,
                            custbody_order_type: nlapiGetFieldValue('custbody_order_type'),
                            custbody_paypal_transaction_id: nlapiGetFieldValue('custbody_paypal_transaction_id')
                        }) + "'");
                        //}
                    } else {
                        form.addButton("custpage_ap", "收款", "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=958&deploy=1&" + serializeURL({
                            ivsId: id
                        }) + "'");
                    }

                }
            }

        }
        if (ctx == "userinterface") {
            setARAccount(type);
        }

    } catch (e) {
        processException(e, ['beforeLoad', id, recType, type].join(', '));
    }

}

function beforeSubmit(type) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    try {
        setARAccount(type);
    } catch (e) {
        var ex = processException(e, ['beforeSubmit', id, recType, type].join(', '));
        if (ex.code == 'UI_USER_ERROR') {
            throw e;
        }
    }

}

// For check and fix
// 主要是针对 Amazon
function afterSubmit(type) {
    try {
        var subsidiary = nlapiGetFieldValue('subsidiary');
        if (subsidiary == Subsidiaries.ZakeInternational) {
            var id = nlapiGetRecordId(), recType = nlapiGetRecordType();

            if (type == 'create' && recType == 'invoice') {


                var marketplace = nlapiGetFieldValue('custbody_marketplace');

                if (marketplace) {

                    var account = null;
                    var accountid = MARKETPLACE_LIST.filter(function (m) {
                        return m.marketplaceId == marketplace;
                    });

                    if (accountid.length) {
                        if (accountid.length == 1) {
                            account = accountid[0].ARAccount;
                        } else {
                            accountid = accountid.filter(function (item) {
                                return item.store == nlapiGetFieldValue('custbody_orderfrom');
                            });

                            if (accountid.length && accountid.length == 1) {
                                account = accountid[0].ARAccount;
                            } else {
                                throw nlapiCreateError('BILL_ACCOUNT_ISSUES',
                                    'afterSubmit d has issue --- ' + JSON.stringify(accountid))
                            }

                        }

                    }

                    if (account != nlapiGetFieldValue('account')) {
                        nlapiSetFieldValue('account', account);
                        _log_email('The invoice record not reset the account', account + ' --- ' + id);
                    }


                } else {
                    _log_email('The invoice record not marketplace', id);
                }
            }


        } else if (subsidiary == Subsidiaries.TaiwuInternational) {
            if (type == 'delete') {
                var createdfrom = nlapiGetFieldValue('createdfrom');
                _audit('createdfrom', createdfrom);
                nlapiSubmitField('salesorder', createdfrom, 'custbody_taiwu_bill_status_code', 8);
            }
        }
    } catch (e) {
        processException(e, ['afterSubmit', id, recType, type].join(', '));
    }
}

/**
 * Invoice 的User Event
 * @param type
 */
function setARAccount(type) {

    var subsidiary = nlapiGetFieldValue('subsidiary');

    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    _log("setARAccount id: " + id + " recType: " + recType + " type: " + type);

    //if (type == 'create' && recType == 'invoice') { //
    //    // 160	Swagway Product Invoice
    //    //if (nlapiGetFieldValue('customform') == '160') {
    //    if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.Swagway) {
    //        // 177	Swagway Credit Card	Accounts Receivable
    //        nlapiSetFieldValue('account', 177);
    //    }
    //}

    if (recType == 'invoice') {
        if (type == 'create' || type == 'copy' || type == 'edit') {
            var marketplace = nlapiGetFieldValue('custbody_marketplace');

            if (subsidiary == Subsidiaries.ZakeInternational) {

                if (marketplace == MarketplaceShipName.Amazon) {

                    // Amazon 去账号去寻 AR Account
                    var orderfrom = nlapiGetFieldValue('custbody_orderfrom');
                    if (orderfrom) {
                        var amzARAccount = nlapiLookupField('customrecord_amazon_accounts', orderfrom, 'custrecord_accounts_receivable_account');
                        if (amzARAccount) {
                            nlapiSetFieldValue('account', amzARAccount);
                        } else {
                            throw nlapiCreateError('NOT_AMZ_AR_Account',
                                'afterSubmit d has issue --- ' + type + id)
                        }
                    }
                }
                else if (marketplace == MarketplaceShipName.eBay) {
                    var ebayAccountId = nlapiGetFieldValue('custbody_linked_ebay_account');
                    if (ebayAccountId) {
                        var ebayARAccount = nlapiLookupField('customrecord_ebay_account', ebayAccountId, 'custrecord_ebay_account_ar');
                        if (ebayARAccount) {
                            nlapiSetFieldValue('account', ebayARAccount);
                        } else {
                            throw nlapiCreateError('ebayARAccountERROR',
                                'afterSubmit d has issue --- ' + type + id)
                        }
                    } else {
                        if (nlapiGetContext().getExecutionContext() == 'userinterface') {
                            throw nlapiCreateError('UI_USER_ERROR',
                                'Ebay order must be fill the eBay account record!');
                        }
                    }

                }
                else if (marketplace == MarketplaceShipName.Jet) {
                    var acc = nlapiGetFieldValue('account');
                    if (acc != 2330) {
                        nlapiSetFieldValue('account', 2330);
                    }
                }
                else {

                    var accountid = MARKETPLACE_LIST.filter(function (m) {
                        return m.marketplaceId == marketplace;
                    });

                    _log(type, 'accountid: ' + JSON.stringify(accountid));
                    if (accountid.length) {
                        if (accountid.length == 1) {
                            accountid = accountid[0].ARAccount;
                            nlapiSetFieldValue('account', accountid);
                        } else {

                            accountid = accountid.filter(function (item) {
                                return item.store == nlapiGetFieldValue('custbody_storefront_list');
                            });

                            _log(type, 'accountid:222 ' + JSON.stringify(accountid));

                            if (accountid.length && accountid.length == 1) {
                                accountid = accountid[0].ARAccount;
                                nlapiSetFieldValue('account', accountid);
                            } else {
                                // createdfrom
                                // 一般 从 SO 过来的 都是有的， 但是单独新建 Invoice是没有的， 也不用考虑
                                //var createdfrom = nlapiGetFieldValue('createdfrom');
                                //if (createdfrom) {
                                //    throw nlapiCreateError('BILL_ACCOUNT_ISSUES', 'BILL_ACCOUNT_ISSUES ue.bill.js accountid has issue --- ' +
                                //    JSON.stringify(accountid) + "id: " + id +
                                //    " recType: " + recType +
                                //    " createdfrom: " + createdfrom +
                                //    " type: " + type)
                                //}

                            }

                        }

                    }
                }
            } else if (subsidiary == Subsidiaries.TaiwuInternational) {
                if (marketplace) {
                    if (marketplace == MarketplaceShipName.eBay) {

                        //var custbody_bank_account = nlapiGetFieldValue('custbody_bank_account');
                        //if (!custbody_bank_account) {
                        //    throw new UIException('没有PP Bank Account！');
                        //}
                        nlapiSetFieldValue('account', '1384'); // Ebay China Store - AR
                    }
                }
            }

            //else {
            //
            //    // marketplace: null id: null type: create envContext: scheduled recType: invoice[]
            //    var envContext = nlapiGetContext().getExecutionContext();
            //    _log('envContext', envContext);
            //
            //    throw nlapiCreateError('accountid_not_found', 'accountid_not_found ue.bill.js accountid has issue --- ' +
            //    'marketplace: ' + marketplace +
            //    ' id: ' + id +
            //    ' type: ' + type +
            //    ' envContext: ' + envContext +
            //    ' recType: ' + recType +
            //    JSON.stringify(accountid))
            //}

        }

    }

}

//function getARAccount(marketplace){
//
//    var accountid = MARKETPLACE_LIST.filter(function (m) {
//        return m.marketplaceId == marketplace;
//    });
//
//    if (accountid.length) {
//        if (accountid.length == 1) {
//            accountid = accountid[0].ARAccount;
//            nlapiSetFieldValue('account', accountid);
//        } else {
//            accountid = accountid.filter(function (item) {
//                return item.store == nlapiGetFieldValue('custbody_orderfrom');
//            });
//
//            if (accountid.length && accountid.length == 1) {
//                accountid = accountid[0].ARAccount;
//                nlapiSetFieldValue('account', accountid);
//            } else {
//                throw nlapiCreateError('BILL_ACCOUNT_ISSUES', 'BILL_ACCOUNT_ISSUES ue.bill.js accountid has issue --- ' + JSON.stringify(accountid))
//            }
//
//        }
//
//    }
//
//}