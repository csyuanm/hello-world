/*****************************************************
*File Name   : Zake_SL_ReverseAdjustment.js
*Description : Suitelet for reversing inventory adjustment
*Created By  : Daniel Cai
*Created On  : 13-Nov-2016
*****************************************************/

function reverse_adjustment(request, response) {
    var myForm = nlapiCreateForm('Reverse Adjustment/虚拟库存到货');
    myForm.setScript('customscript_zake_reverseadjusment');
    var reverseBtn = myForm.addButton('reverse', 'Reverse', 'reverseAdjsutment()');
    myForm.addSubmitButton('Refresh');
    var msgFld = myForm.addField('message', 'text', 'Message').setDisplayType('inline');

    if (request.getMethod() == 'POST') {
        var listStr = request.getParameter('liststr');
        if (!isNull(listStr)) {
            var selected = listStr.split(',');
            // Total 40 usage for 1 reverse, 1000 / 40 = 25
            for (var i = 0; i < selected.length; i++) {
                var adjustRecOld = nlapiLoadRecord('inventoryadjustment', selected[i]); //10
                adjustRecOld.selectLineItem('inventory', 1);
                var subRecOld = adjustRecOld.viewCurrentLineItemSubrecord('inventory', 'inventorydetail');
                var binId = subRecOld.getLineItemValue('inventoryassignment', 'binnumber', 1);

                var adjustRec = nlapiCreateRecord('inventoryadjustment'); //10 usage
                adjustRec.setFieldValue('subsidiary', adjustRecOld.getFieldValue('subsidiary'));
                adjustRec.setFieldValue('account', adjustRecOld.getFieldValue('account'));
                adjustRec.setFieldValue('custbody_zake_reverseadjustment', selected[i]);
                adjustRec.setFieldValue('memo', 'Reverse ' + adjustRecOld.getFieldValue('tranid'));
                for (var j = 1; j <= adjustRecOld.getLineItemCount('inventory') ; j++) {
                    adjustRec.selectNewLineItem('inventory');
                    adjustRecOld.selectLineItem('inventory', j);
                    var itemId = adjustRecOld.getCurrentLineItemValue('inventory', 'item');
                    adjustRec.setCurrentLineItemValue('inventory', 'item', itemId);
                    var locationId = adjustRecOld.getCurrentLineItemValue('inventory', 'location');
                    adjustRec.setCurrentLineItemValue('inventory', 'location', locationId);
                    var qty = adjustRecOld.getCurrentLineItemValue('inventory', 'adjustqtyby');
                    adjustRec.setCurrentLineItemValue('inventory', 'adjustqtyby', qty);

                    var subRecOld = adjustRecOld.editCurrentLineItemSubrecord('inventory', 'inventorydetail');
                    var binId = subRecOld.getLineItemValue('inventoryassignment', 'binnumber', 1);

                    var subRec = adjustRec.createCurrentLineItemSubrecord('inventory', 'inventorydetail');
                    subRec.selectNewLineItem('inventoryassignment');
                    subRec.setCurrentLineItemValue('inventoryassignment', 'binnumber', binId);
                    subRec.setCurrentLineItemValue('inventoryassignment', 'quantity', qty);
                    subRec.commitLineItem('inventoryassignment');
                    subRec.commit();
                    adjustRec.commitLineItem('inventory');
                }
                var adjustId = nlapiSubmitRecord(adjustRec); //20 usage
                nlapiLogExecution('debug', i, 'New Reverse #: ' + adjustId);
                nlapiSubmitField('inventoryadjustment', selected[i], 'custbody_zake_reverseadjustment', adjustId); //10 usage
                nlapiLogExecution('debug', i, 'Old adjustment updated.');
            }
        }
    }

    try {
        var sublist = myForm.addSubList('adjlist', 'list', 'Adjustment List');
        sublist.addMarkAllButtons();
        sublist.addField('select', 'checkbox', 'Slect');
        sublist.addField('custitem_sourcing_image', 'image', 'Image', 'image');
        sublist.addField('tranid', 'text', 'Adj. #');
        sublist.addField('trandate', 'text', 'Adj. Date');
        sublist.addField('custbody_zake_backorderso', 'select', 'SO #', 'transaction').setDisplayType('inline');
        sublist.addField('item', 'select', 'Item', 'item').setDisplayType('inline');
        sublist.addField('quantity', 'text', 'Quantity');
        sublist.addField('amount', 'text', 'Amount');
        sublist.addField('rate', 'text', 'Unit Pirce');
        //sublist.addField('displayname', 'text', 'Displayname');
        sublist.addField('departmenttext', 'text', 'Department');
        sublist.addField('locationtext', 'text', 'Location');
        sublist.addField('department', 'select', 'Department', 'department').setDisplayType('hidden');
        sublist.addField('location', 'select', 'Location', 'location').setDisplayType('hidden');
        sublist.addField('internalid', 'text', 'Internal ID').setDisplayType('hidden');

        var list = nlapiSearchRecord('inventoryadjustment', 'customsearch_zake_reverseinventoryadj');
        //sublist.setLineItemValues(list);
        for (var i = 0; !isNull(list) && i < list.length; i++) {
            var allCols = list[i].getAllColumns();
            sublist.setLineItemValue('custitem_sourcing_image', i + 1, list[i].getValue(allCols[0]));
            sublist.setLineItemValue('tranid', i + 1, list[i].getValue(allCols[1]));
            sublist.setLineItemValue('trandate', i + 1, list[i].getValue(allCols[2]));
            sublist.setLineItemValue('custbody_zake_backorderso', i + 1, list[i].getValue(allCols[3]));
            sublist.setLineItemValue('item', i + 1, list[i].getValue(allCols[4]));
            sublist.setLineItemValue('quantity', i + 1, list[i].getValue(allCols[5]));
            sublist.setLineItemValue('amount', i + 1, list[i].getValue(allCols[6]));
            sublist.setLineItemValue('rate', i + 1, list[i].getValue(allCols[7]));
            sublist.setLineItemValue('departmenttext', i + 1, list[i].getValue(allCols[9]));
            sublist.setLineItemValue('locationtext', i + 1, list[i].getValue(allCols[10]));
            sublist.setLineItemValue('department', i + 1, list[i].getValue(allCols[11]));
            sublist.setLineItemValue('location', i + 1, list[i].getValue(allCols[12]));
            sublist.setLineItemValue('internalid', i + 1, list[i].getValue(allCols[13]));
        }
        response.writePage(myForm);
    }
    catch (ex) {
        nlapiLogExecution('debug', 'reverse_adjustment', ex);
        msgFld.setDefaultValue(ex);
        response.writePage(myForm);
    }
}

function getSelected() {
    var adjList = new Array();
    var hasSelect = false;
    for (var i = 1; i <= nlapiGetLineItemCount('adjlist') ; i++) {
        var selected = nlapiGetLineItemValue('adjlist', 'select', i);
        if (selected == 'T') {
            adjList.push(nlapiGetLineItemValue('adjlist', 'internalid', i));
            hasSelect = true;
        }
    }
    if (!hasSelect) { alert('Please select at least one line.请选择至少一行!'); return 'error'; }
    if (adjList.length > 20) { alert('20 lines allowed.最多只能选择20行!'); return 'error'; }
    var result = [], tmp = {};
    for (var i = 0; i < adjList.length; i++) {
        var ai = adjList[i];
        if (!tmp[ai]) {
            result = result.concat(ai);
            tmp[ai] = ai;
        }
    }

    var listStr = '';
    for (var i = 0; i < result.length; i++) {
        listStr = listStr + result[i];
        if (i != result.length - 1) listStr += ',';
    }
    return result;
}

function isNull(str) {
    if (str == null || str == '' || str == 'undefined') return true;
    else return false;
}

function reverseAdjsutment() {
    try {
        var selected = getSelected();
        if (selected == 'error') return;
        var scriptId = 'customscript_zake_reverseadjusment';
        var deployId = 'customdeploy_zake_reverseadjusment';
        var params = { 'liststr': selected };
        var url = nlapiResolveURL('SUITELET', scriptId, deployId);
        alert('Job is in progress.任务进行中, 请勿关闭页面');
        nlapiRequestURL(url, params, null, myCallBack);
    }
    catch (ex) {
        alert('Error');
        alert(ex);
        alert(ex.getDetails());
    }
}

function myCallBack() {
    alert('Job done. 虚拟库存已调整完毕');
    history.go(0);
}