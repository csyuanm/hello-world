var SL_MPL_URL = "/app/site/hosting/scriptlet.nl?script=186&deploy=1";

NProgressInit();

function search(type) {
    var initURL = window.location.origin + "/app/site/hosting/scriptlet.nl?script=186&deploy=1&compid=277620&whence=";
    var _url;
    if (type == 1)
        _url = initURL + "&custpage_mpl_category=" + nlapiGetFieldValue("custpage_mpl_category") + "&custpage_mpl_allow_reprinting=" + nlapiGetFieldValue("custpage_mpl_allow_reprinting") + "&f_index=" + nlapiGetFieldValue('custpage_sort') + "&is_asc=" + nlapiGetFieldValue('custpage_is_asc') + "&p_index=" + nlapiGetFieldValue("custpage_rows");
    else
        _url = initURL + "&custpage_mpl_category=" + nlapiGetFieldValue("custpage_mpl_category") + "&custpage_mpl_allow_reprinting=" + nlapiGetFieldValue("custpage_mpl_allow_reprinting") + "&f_index=" + nlapiGetFieldValue('custpage_sort') + "&is_asc=" + nlapiGetFieldValue('custpage_is_asc');
    var custpage_mpl_ff_select = nlapiGetFieldValue("custpage_mpl_ff_select");
    console.log(custpage_mpl_ff_select);
    if (custpage_mpl_ff_select) {
        if (isNaN(parseInt(custpage_mpl_ff_select))) {
            _url += "&custpage_mpl_ff_select=" + escape(custpage_mpl_ff_select);
        } else {
            custpage_mpl_ff_select = parseInt(custpage_mpl_ff_select);
            if (custpage_mpl_ff_select) {
                _url += "&custpage_mpl_ff_select=" + custpage_mpl_ff_select;
            }
        }
    }
    window.location = _url;
}

var $inpt_custpage_mpl_ff_select2 = jQuery("#inpt_custpage_mpl_ff_select2");

var title_init = $inpt_custpage_mpl_ff_select2.attr("title");

function onFieldChangeFn(type, name, linenum) {
    var now_title = $inpt_custpage_mpl_ff_select2.attr("title");
    if (title_init != now_title || name == 'custpage_sort' || name == 'custpage_is_asc') {
        search();   // run search function when user click on "search" button or chnage the filter ( cheng li hou)
    }
    if (name == 'custpage_rows') {
        search(1);
    }
    if (name == 'mpl_checkbox' && type == 'custpage_mpl_list') {
        var checked = nlapiGetLineItemValue("custpage_mpl_list", "mpl_checkbox", linenum);
        var selected_count = parseInt(nlapiGetFieldValue('custpage_selected'));
        if (checked == 'T') {
            nlapiSetFieldValue('custpage_selected', selected_count + 1);
        } else {
            nlapiSetFieldValue('custpage_selected', selected_count - 1);
        }
    }
}


function onPageInit() {
}

function print() {
    var ffCount = nlapiGetLineItemCount("custpage_mpl_list");
    var ffSelectedList = [];
    for (var line = 1; line <= ffCount; line++) {
        var checked = nlapiGetLineItemValue("custpage_mpl_list", "mpl_checkbox", line);
        var ffid = nlapiGetLineItemValue("custpage_mpl_list", "mpl_ffid_hidden", line);
        if (checked == "T") {
            ffSelectedList.push(ffid);
        }
    }
    if (ffSelectedList.length) {
        console.log(JSON.stringify(ffSelectedList));
        jQuery.ajax({
            url: SL_MPL_URL,
            data: {
                action: "print",
                ffSelectedList: JSON.stringify(ffSelectedList),
                custpage_mpl_category: nlapiGetFieldValue("custpage_mpl_category"),
                inpt_custpage_mpl_category: nlapiGetFieldValue("inpt_custpage_mpl_category").toUpperCase()
            },
            success: function (data) {
                console.log(data);
                PageOverlay.removeOverlay();
                NProgress.done(true);
                data = JSON.parse(data);
                if (data.mpl_id) {
                    post_to_url(SL_MPL_URL, {
                        action: "showMPLPDF2",
                        mpl_id: data.mpl_id
                    });
                    window.setTimeout(function () {
                        window.location.reload();
                    }, 1e3);
                } else {
                    alert("Not to created the PDF file YET!");
                }
            },
            beforeSend: function () {
                PageOverlay.showOverlay();
                NProgress.start();
            }
        });
    } else {
        alert("Please select records for print.");
    }
}

jQuery(function () {

    var sort_by_title = nlapiGetFieldText('custpage_sort');
    console.log(nlapiGetFieldValue('custpage_is_asc'));

    jQuery("#custpage_mpl_listheader > td").each(function () {
        if (jQuery(this).data('label').toUpperCase() == sort_by_title) {
            jQuery(this).click();
            if (nlapiGetFieldValue('custpage_is_asc') == 'true')
                jQuery(this).click();
        }
    });

    jQuery("#custpage_mpl_listmarkall").click(function () {
        nlapiSetFieldValue('custpage_selected', nlapiGetLineItemCount("custpage_mpl_list"));
    });

    jQuery("#custpage_mpl_listunmarkall").click(function () {
        nlapiSetFieldValue('custpage_selected', 0);
    });

});

window.page_unload = null;