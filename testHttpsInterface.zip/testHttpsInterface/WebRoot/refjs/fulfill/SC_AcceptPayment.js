function run() {

    // For Zake
    zakeAcceptPayment();

    // For Taiwu 这是另外一个 配置 with 不同的Function Name
    // taiwuAcceptPayment();
}

function zakeAcceptPayment() {
    var context = nlapiGetContext();


    var search = nlapiSearchRecord('invoice', null, [
        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.ZakeInternational),
        new nlobjSearchFilter('mainline', null, 'is', 'T'),
        new nlobjSearchFilter('status', null, 'is', 'CustInvc:A'), // Open status 以这个判断
        new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
            MarketplaceShipName.eBay,
            MarketplaceShipName.Hautebrush,

            //Three storefronts still need to have payment applied to their individual cash account:
            //1) Newegg: “Newegg Cash Account”
            //2) 3Btech.net: paypal@3btech.net
            //3) Buy.com/Rakuten: “Buy.com Cash Account”

            MarketplaceShipName._3BNewegg,
            MarketplaceShipName._3Btech,

            MarketplaceShipName.Jet,

            // Buy.com/Rakuten
            MarketplaceShipName.Rakuten
        ])
    ]);

    if (search != null) {
        //var stopFlag = false;

        _audit('total size', search.length);

        var issues = [];
        for (var i = 0, len = search.length; i < len; i++) {

            try {
                _log('Invoice ID', search[i].getId());
                var customerpayment = nlapiTransformRecord('invoice', search[i].getId(), 'customerpayment');

                // Check
                var arAccount = customerpayment.getFieldValue('aracct');
                if (customerpayment.getFieldValue('account') == nlapiLookupField('account', arAccount, 'custrecord_ar_linked_payment_account')) {
                    nlapiSubmitRecord(customerpayment, true);
                } else {

                    issues.push('arAccount不相等 ' + search[i].getRecordType() + search[i].getId() + '---' + arAccount);
                }
            } catch (e) {
                e = processException(e);
                issues.push(e.code, e.message);
            }


            //if (i == 1) {
            //    break; // Testing.....
            //}

            checkGovernance();
        }

        if (issues.length) {
            _log_email('SC Accept Payment has errors', JSON.stringify(issues));
        }

        if (search.length == 1000) {

            var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
            _audit('nlapiScheduleScript', status);

            //if (!stopFlag) {
            //    var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
            //    _audit('nlapiScheduleScript', status);
            //}
        }

    } else {
        _audit('Nothing...');
    }
}
