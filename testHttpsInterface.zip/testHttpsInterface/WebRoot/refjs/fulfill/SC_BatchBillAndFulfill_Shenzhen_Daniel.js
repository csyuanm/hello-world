/*******************************************************************
*File Name   : SC_BatchBillAndFulfill_Shenzhen_Daniel.js
*Description : Suitlet for fake fulfill sales orders
*Company     : Zake International
*Created By  : Daniel Cai
*Created On  : 12-Nov-2016
********************************************************************/

function fakeFulfill(request, response) {
    var beginTime = new Date();
    var myForm = nlapiCreateForm('Fake Fulfill');
    myForm.setScript('customscript_zake_fake_fulfillso')
    myForm.addSubmitButton('Refresh');
    myForm.addButton('deletefulfillment', 'Delete', 'deleteFulfillment()');
    var msgFld = myForm.addField('message', 'text', 'Fulfill ID').setDisplayType('inline');
    var timeFld = myForm.addField('time', 'text', 'Time Consumed').setDisplayType('inline');
    var schFld = myForm.addField('sch', 'checkbox', 'Schedule Script').setDisplayType('inline');
    var isSchedule = request.getParameter('sch');
    if (isSchedule == 'T') {
        var scriptId = 'customscript_sc_shenzhen_fulfill_dan';
        var deployId = 'customdeploy_sc_shenzhen_fulfill_dan';
        nlapiSchedulScript(scriptId, deployId);
    }
    if (false) {
        try {
            var soId = '7169391';
            var soRec = nlapiLoadRecord('salesorder', soId); // 10 usage

            // Get item list information from sales order
            var soLineInfo = getSOLineInfo(soRec); // 15 usage
            var fulfillListStr = '';

            // Check back order & overweight
            if (soLineInfo.overWeight) {
                soRec.setFieldValue('custbody_taiwu_fulfill_status_code', 17);
                nlapiSubmitRecord(soRec);
                throw 'Single item over 2KG!';
                return;
            }
            var adjustId = soLineInfo.backOrder ? createInventoryAdjsutment(soLineInfo.itemList, soRec) : ''; //30 usage
            // IA753
            nlapiLogExecution('debug', 'fakeFulfilSO', 'Adjustment ID: ' + adjustId);

            // If total weight is greater than 2KG, SO needs to be splitted into several fulifllments.
            // Every fulfillment should be <= 2KG
            var orderTotalWeight = soRec.getFieldValue('custbody_total_weight');
            nlapiLogExecution('debug', 'fakeFulfilSO', 'Order Total Weight: ' + orderTotalWeight);
            // Break SO line into minimum levels by total quantity
            var breakDownItemList = breakSOLine(soLineInfo.itemList);
            var fulfillSummary = getFulfillSummary(breakDownItemList);
            for (var i = 0; i < fulfillSummary.length; i++) {
                var fulfillRec = nlapiTransformRecord('salesorder', soId, 'itemfulfillment');
                // If back ordered, mark 'picked', else mark 'packed'
                var fulfillStatus = isNull(adjustId) ? 'A' : 'B';
                fulfillRec.setFieldValue('shipstatus', fulfillStatus);

                // Unmark all checkboxes
                for (var j = 1; j <= fulfillRec.getLineItemCount('item') ; j++) {
                    fulfillRec.setLineItemValue('item', 'itemreceive', j, 'F');
                }

                for (var j = 1; j <= fulfillRec.getLineItemCount('item') ; j++) {

                    for (var k = 0; k < fulfillSummary[i].length; k++) {
                        if (fulfillSummary[i][k].itemId == fulfillRec.getLineItemValue('item', 'item', j)) {
                            fulfillRec.selectLineItem('item', j);
                            fulfillRec.setCurrentLineItemValue('item', 'itemreceive', 'T');
                            fulfillRec.setCurrentLineItemValue('item', 'quantity', fulfillSummary[i][k].fulfillQty);
                            var subRec = fulfillRec.createCurrentLineItemSubrecord('item', 'inventorydetail');
                            subRec.selectLineItem('inventoryassignment', 1);
                            subRec.setCurrentLineItemValue('inventoryassignment', 'binnumber', fulfillSummary[i][k].binId);
                            subRec.setCurrentLineItemValue('inventoryassignment', 'quantity', fulfillSummary[i][k].fulfillQty);
                            subRec.commitLineItem('inventoryassignment');
                            subRec.commit();
                            fulfillRec.commitLineItem('item');
                        }
                    }
                }
                var fulfillId = nlapiSubmitRecord(fulfillRec);
                nlapiLogExecution('debug', 'fakeFulfilSO', i + ', Fulfill ID: ' + fulfillId);
                fulfillListStr += fulfillId + ',';
            }

            fulfillListStr = fulfillListStr.substring(0, fulfillListStr.length - 1);
            msgFld.setDefaultValue(fulfillListStr);
            var soStatusCode = isNull(adjustId) ? 12 : 3;
            soRec.setFieldValue('custbody_taiwu_fulfill_status_code', soStatusCode);
            soRec.setFieldValue('custbody_zake_inventoryadjnumber', adjustId);
            soRec.setFieldValue('custbody_zake_fulfilidlist', fulfillListStr);
            nlapiSubmitRecord(soRec);

            var endTime = new Date();
            var executionTime = (endTime - beginTime) / 1000;
            nlapiLogExecution('debug', 'fakeFulfilSO', 'Execution Time: ' + executionTime);
            timeFld.setDefaultValue(executionTime + ' seconds passed.');
        }
        catch (ex) {
            nlapiLogExecution('debug', 'fakeFulfilSO', ex);
            msgFld.setDefaultValue(ex);
            response.writePage(myForm);
        }
    }
    response.writePage(myForm);
}

function splitSalesOrder(request, response) {
    var beginTime = new Date();
    var myForm = nlapiCreateForm('Split Sales Order - SO154826');
    myForm.setScript('customscript_zake_fake_fulfillso')
    myForm.addSubmitButton('Refresh');
    myForm.addButton('deletefulfillment', 'Delete', 'deleteFulfillment()');
    var msgFld = myForm.addField('message', 'text', 'Fulfill ID').setDisplayType('inline');
    var timeFld = myForm.addField('time', 'text', 'Time Consumed').setDisplayType('inline');
    var schFld = myForm.addField('sch', 'checkbox', 'Schedule Script');
    var isSchedule = request.getParameter('sch');
    if (isSchedule == 'T') {
        var scriptId = 'customscript_sc_shenzhen_fulfill_dan';
        var deployId = 'customdeploy_sc_shenzhen_fulfill_dan';
        nlapiScheduleScript(scriptId, deployId);
    }
    if (false) {
        try {
            var oldSOId = '7169391';
            var oldSORec = nlapiLoadRecord('salesorder', oldSOId); // 10 usage

            // Get item list information from sales order
            var soLineInfo = getSOLineInfo(oldSORec); // 15 usage
            //var fulfillListStr = '';
            var soListStr = '';

            // Check back order & overweight
            if (soLineInfo.overWeight) {
                oldSORec.setFieldValue('custbody_taiwu_fulfill_status_code', 17);
                nlapiSubmitRecord(oldSORec);
                throw 'Single item over 2KG!';
                return;
            }
            // If total weight is greater than 2KG, SO needs to be splitted into several SO.
            // Every sales order should be <= 2KG
            var orderTotalWeight = oldSORec.getFieldValue('custbody_total_weight');
            nlapiLogExecution('debug', 'splitSalesOrder', 'Order Total Weight: ' + orderTotalWeight);
            // Break SO line into minimum levels by total quantity
            var breakDownItemList = breakSOLine(soLineInfo.itemList);
            var fulfillSummary = getFulfillSummary(breakDownItemList);
            for (var i = 0; i < fulfillSummary.length; i++) {
                //var fulfillRec = nlapiTransformRecord('salesorder', soId, 'itemfulfillment');
                var newSORec = nlapiCopyRecord('salesorder', oldSOId, 'itemfulfillment');
                newSORec.setFieldValue('orderstatus', 'B');
                newSORec.setFieldValue('custbody_parent_sales_order', oldSOId);

                // Remove all existing lines
                var lineCount = newSORec.getLineItemCount('item');
                for (var j = 1; j <= lineCount ; j++) newSORec.removeLineItem('item', 1);

                for (var k = 0; k < fulfillSummary[i].length; k++) {
                    newSORec.selectNewLineItem('item');
                    newSORec.setCurrentLineItemValue('item', 'item', fulfillSummary[i][k].itemId);
                    newSORec.setCurrentLineItemValue('item', 'quantity', fulfillSummary[i][k].fulfillQty);
                    newSORec.setCurrentLineItemValue('item', 'rate', fulfillSummary[i][k].salesPrice);
                    newSORec.setCurrentLineItemValue('item', 'location', fulfillSummary[i][k].locationId);
                    newSORec.setCurrentLineItemValue('item', 'isclosed', 'T');
                    newSORec.commitLineItem('item');
                }
                var newSOId = nlapiSubmitRecord(newSORec);
                nlapiLogExecution('debug', 'splitSalesOrder', i + ', newSOId ID: ' + newSOId);
                soListStr += newSOId + ',';
            }

            soListStr = soListStr.substring(0, soListStr.length - 1);
            msgFld.setDefaultValue(soListStr);

            var endTime = new Date();
            var executionTime = (endTime - beginTime) / 1000;
            nlapiLogExecution('debug', 'splitSalesOrder', 'Execution Time: ' + executionTime);
            timeFld.setDefaultValue(executionTime + ' seconds passed.');
        }
        catch (ex) {
            nlapiLogExecution('debug', 'splitSalesOrder', ex);
            msgFld.setDefaultValue(ex);
            response.writePage(myForm);
        }
    }
    response.writePage(myForm);
}

function isNull(str) {
    if (str == '' || str == null) return true;
    else return false;
}

function getSOLineInfo(soRec) {
    var soLineInfo = new Array();
    var itemSearchFilters = new Array();
    var itemList = new Array();
    var totalQty = 0;
    var backOrder = false;
    var lineCount = soRec.getLineItemCount('item');
    for (var i = 1; i <= soRec.getLineItemCount('item') ; i++) {
        var itemLine = new Object();
        itemLine.itemId = soRec.getLineItemValue('item', 'item', i);
        itemLine.salesQty = soRec.getLineItemValue('item', 'quantity', i);
        itemLine.salesPrice = soRec.getLineItemValue('item', 'rate', i);
        totalQty += parseFloat(itemLine.salesQty);
        itemLine.backOrderQty = soRec.getLineItemValue('item', 'quantitybackordered', i);
        if (itemLine.backOrderQty > 0) backOrder = true;
        itemLine.locationId = soRec.getLineItemValue('item', 'location', i);
        itemList.push(itemLine);

        // Generate new search filter for current sales order

        //nlapiLogExecution('debug', 'getSOLineInfo', i + ', itemLine.itemId: ' + itemLine.itemId);
        itemSearchFilters.push([['internalid', 'is', itemLine.itemId], 'AND', ['inventorylocation', 'anyof', itemLine.locationId]]);
        if (i != lineCount) itemSearchFilters.push('OR');
    }

    var itemSearchObj = nlapiLoadSearch('item', 'customsearch_taiwu_itembinweight'); //5 usage
    var filterExpression = new Array();
    filterExpression.push(itemSearchObj.getFilterExpression());
    filterExpression.push('AND');
    filterExpression.push(itemSearchFilters);
    itemSearchObj.setFilterExpression(filterExpression);
    var itemBinWeightList = itemSearchObj.runSearch();
    itemBinWeightList = itemBinWeightList.getResults(0, 1000); //10 usage

    // Get item weight & bin information from the new search
    var overWeight = false;
    for (var i = 0; i < itemBinWeightList.length; i++) {
        var itemIdInSearch = itemBinWeightList[i].getId();
        for (var j = 0; j < itemList.length; j++) {
            var itemIdinJSon = itemList[j].itemId;
            if (itemIdinJSon == itemIdInSearch) {
                itemList[j].binId = itemBinWeightList[i].getValue('internalid', 'binNumber');
                itemList[j].binNumber = itemBinWeightList[i].getValue('binNumber');
                itemList[j].weight = itemBinWeightList[i].getValue('weight');
                if (itemList[j].weight > 2000) overWeight = true;
                itemList[j].cost = itemBinWeightList[i].getValue('cost');
            }
        }
    }

    soLineInfo.itemList = itemList;
    soLineInfo.backOrder = backOrder;
    soLineInfo.overWeight = overWeight;
    soLineInfo.totalQty = totalQty;
    return soLineInfo;
}

function createInventoryAdjsutment(itemList, soRec) {
    //nlapiLogExecution('debug', 'createInventoryAdjsutment', 'create inventory adjustment');
    var adjustRec = nlapiCreateRecord('inventoryadjustment'); //10 usage
    adjustRec.setFieldValue('subsidiary', 3);
    adjustRec.setFieldValue('account', 356);
    adjustRec.setFieldValue('custbody_zake_backorderso', soRec.getId());
    adjustRec.setFieldValue('memo', 'Increase inventory for back order sales order');
    for (var i = 0; i < itemList.length; i++) {
        var backOrderQty = itemList[i].backOrderQty;
        if (isNull(backOrderQty) || backOrderQty == 0) continue;
        adjustRec.selectNewLineItem('inventory');
        adjustRec.setCurrentLineItemValue('inventory', 'item', itemList[i].itemId);
        adjustRec.setCurrentLineItemValue('inventory', 'location', itemList[i].locationId);
        adjustRec.setCurrentLineItemValue('inventory', 'adjustqtyby', itemList[i].backOrderQty);
        adjustRec.setCurrentLineItemValue('inventory', 'unitcost', itemList[i].cost);
        var subRec = adjustRec.createCurrentLineItemSubrecord('inventory', 'inventorydetail');
        subRec.selectNewLineItem('inventoryassignment');
        subRec.setCurrentLineItemValue('inventoryassignment', 'binnumber', itemList[i].binId);
        subRec.setCurrentLineItemValue('inventoryassignment', 'quantity', itemList[i].backOrderQty);
        subRec.commitLineItem('inventoryassignment');
        subRec.commit();
        adjustRec.commitLineItem('inventory');
    }
    var adjustId = nlapiSubmitRecord(adjustRec); //20 usage
    return adjustId;
}

function breakSOLine(itemList) {
    var breakDownItemList = new Array();
    for (var i = 0; i < itemList.length; i++) {
        for (var j = 0; j < itemList[i].salesQty; j++) {
            var breakDownLine = new Object();
            breakDownLine.itemId = itemList[i].itemId;
            breakDownLine.weight = itemList[i].weight;
            breakDownLine.salesQty = itemList[i].salesQty;
            breakDownLine.salesPrice = itemList[i].salesPrice;
            breakDownLine.binId = itemList[i].binId;
            breakDownLine.locationId = itemList[i].locationId;
            breakDownLine.binNumber = itemList[i].binNumber;
            breakDownLine.fulfillQty = 0;
            breakDownItemList.push(breakDownLine);
        }
    }
    return breakDownItemList;
}

function getFulfillSummary(breakDownItemList) {
    //nlapiLogExecution('debug', 'getFulfillSummary', 'getFulfillSummary begin');
    var fulfillRecList = new Array();
    fulfillRecList.push(new Object());
    fulfillRecList[0].totalWeight = 0.00;
    fulfillRecList[0].itemLine = new Array();
    for (var i = 0; i < breakDownItemList.length; i++) {
        var lastFulfillRec = fulfillRecList[fulfillRecList.length - 1];
        var fTotalWeight = lastFulfillRec.totalWeight + parseFloat(breakDownItemList[i].weight);
        if (fTotalWeight > 2000) {
            // If fulfillment total weight is over 2KG, create a space for new fulfillment
            fulfillRecList.push(new Object());
            fulfillRecList[fulfillRecList.length - 1].totalWeight = 0.00;
            fulfillRecList[fulfillRecList.length - 1].itemLine = new Array();
            i--;
        }
        else {
            lastFulfillRec.totalWeight = parseFloat(fTotalWeight);
            lastFulfillRec.itemLine.push(breakDownItemList[i]);
        }
        //nlapiLogExecution('debug', 'getFulfillSummary', i + ', totalWeight' + lastFulfillRec.totalWeight);
    }

    nlapiLogExecution('debug', 'breakSOLine', 'fulfillRecList.length: ' + fulfillRecList.length);

    // Re-group the fulfillment record, to sum up the fulfill quantity
    var fulfillSummary = new Array();
    for (var i = 0; i < fulfillRecList.length; i++) {
    //for (var i = 0; i < 1; i++) {
        var itemLine = fulfillRecList[i].itemLine;
        nlapiLogExecution('debug', 'breakSOLine', 'itemLine.length: ' + itemLine.length);

        for (var j = 0; j < itemLine.length; j++) {
            if (isNull(fulfillSummary[i])) {
                fulfillSummary[i] = new Array();
                fulfillSummary[i].push(itemLine[j]);
            }

            var itemExist = false;
            var itemId = itemLine[j].itemId;
            for (var k = 0; k < fulfillSummary[i].length; k++) {
                if (itemId == fulfillSummary[i][k].itemId) {
                    fulfillSummary[i][k].fulfillQty++;
                    itemExist = true;
                }
            }

            if (!itemExist) {
                fulfillSummary[i].push(fulfillRecList[i].itemLine[j]);
                fulfillSummary[i][fulfillSummary[i].length - 1].fulfillQty = 1;
            }
        }
    }

    //nlapiLogExecution('debug', 'breakSOLine', 'fulfillSummary.length: ' + fulfillSummary.length);
    for (var j = 0; j < fulfillSummary.length; j++) {
        //nlapiLogExecution('debug', 'breakSOLine', 'fulfillSummary[j].length: ' + fulfillSummary[j].length);
        for (var i = 0; i < fulfillSummary[j].length; i++) {
            //nlapiLogExecution('debug', 'breakSOLine', i + ', ' + j + ', ' + fulfillSummary[j][i].fulfillQty + ', ' + fulfillSummary[j][i].itemId);
        }
    }
    return fulfillSummary;
}

function deleteFulfillment() {
    var soId = '7169391';
    var filters = new Array();
    filters.push(new nlobjSearchFilter('custbody_parent_sales_order', null, 'is', soId));
    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var list = nlapiSearchRecord('salesorder', null, filters);
    for (var i = 0; !isNull(list) && i < list.length; i++) {
        var fulfillId = list[i].getId();
        nlapiDeleteRecord('salesorder', fulfillId);
    }

    var filters = new Array();
    filters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var list = nlapiSearchRecord('itemfulfillment', null, filters);
    for (var i = 0; !isNull(list) && i < list.length; i++) {
        var fulfillId = list[i].getId();
        nlapiDeleteRecord('itemfulfillment', fulfillId);
    }

    alert('Done');
}