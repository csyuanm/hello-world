// Invoice 上面发起的

var INV_COL = [
    new nlobjSearchColumn('internalid').setSort(),
    new nlobjSearchColumn('trandate'), //.setSort(true),
    new nlobjSearchColumn('custbody_marketplace'),
    new nlobjSearchColumn('custbody_ebay_order_id'),
    new nlobjSearchColumn('custbody_storefront_order'),
    new nlobjSearchColumn('custbody_linked_ebay_account'),
    new nlobjSearchColumn('otherrefnum'),
    new nlobjSearchColumn('custbody_paypal_transaction_id'),

    new nlobjSearchColumn('custbody_order_type'),
    new nlobjSearchColumn('custbody_pp_checked'),

    new nlobjSearchColumn('total'),
    new nlobjSearchColumn('fxamount'),

    new nlobjSearchColumn('currency')


    // new nlobjSearchColumn('custbody_bank_account')
];

function taiwuAcceptPayment() {

    var deploymentId = nlapiGetContext().getDeploymentId();
    if (deploymentId == 'customdeploy_sc_ap_taiwu') {
        _taiwuPayment(); // Scheduled
    } else if (deploymentId == 'customdeploy_sc_ap_taiwu_fix') {
        _taiwuPayment(null, 'fix');// Not Scheduled but run in need
    } else if (deploymentId == 'customdeploy_sc_ap_taiwu_fencheck') {
        fencheck(); // Scheduled
    }

    //else if (deploymentId == 'customdeploy_sc_ap_taiwu_fixpp') {
    //    _fixpp();
    //}

}

//function _fix() {
//    _taiwuPayment(null, 'fix');
//}
//function _fixpp() {
//
//}

function fencheck(id) {


    var context = nlapiGetContext();
    var env = context.getExecutionContext();

    var search = nlapiLoadSearch(null, 2056);

    var col = search.getColumns();
    search = search.runSearch();
    search = search.getResults(0, 1000);

    if (env == 'scheduled') {
        var asBreakNumber = context.getSetting('script', 'custscript_sc_ap_inv_id');
        asBreakNumber = parseInt(asBreakNumber);
        if (asBreakNumber) {
            asBreakNumber = parseInt(asBreakNumber);
        }
        _audit('asBreakNumber', asBreakNumber);

        // Last id as the PP ID
        var testId = context.getSetting('script', 'custscript_ap_last_id');
        if (testId) {
            search = search.filter(function (sr) {
                return sr.getValue(col[0]) == testId;
            });
        }
    } else if (id) {
        search = search.filter(function (sr) {
            return sr.getValue(col[0]) == id;
        });
    }


    if (search.length) {

        _audit('Taiwu 准备Invoice Size -- B', search.length);

        var issues = [];
        var yes = [];

        var len = search.length;

        for (var i = 0; i < len; i++) {

            var searchResult = search[i];

            if (env == 'scheduled') {
                // : test
                //if (i == 100) break;
                if (asBreakNumber) {
                    if (i == asBreakNumber) {
                        break;
                    }
                }
            }
            var ppTransactionId = searchResult.getValue(col[0]);

            var count = parseInt(searchResult.getValue(col[3]));
            _log('count', count);
            if (count == 1) {
                issues.push(ppTransactionId + ' - ' + ' Count is 1!');
                continue;
            }

            var id = search[i].getId();
            _log('ppTransactionId', ppTransactionId);

            try {

                var ids = nlapiSearchRecord('invoice', null, [
                    new nlobjSearchFilter('custbody_paypal_transaction_id', null, 'is', ppTransactionId),
                    new nlobjSearchFilter('mainline', null, 'is', 'T'),
                    new nlobjSearchFilter('custbody_order_type', null, 'is', 3) // 分单
                ]);
                ids = ids.map(function (sr) {
                    return sr.getId();
                });

                var checkResult = compare(ids, ppTransactionId,
                    1, // 作为正常单
                    'F',
                    searchResult.getValue(col[1]),
                    searchResult.getText(col[2]));

                _log('checkResult', checkResult);
                if (checkResult.code == false) {
                    issues.push(ppTransactionId + ' - ' + 'Inv ID: ' + ids.join(', ') + ' ' + checkResult.msg);
                } else {
                    for (var j = 0; j < ids.length; j++) {

                        var invId = ids[j];
                        nlapiSubmitField('invoice', invId, 'custbody_pp_checked', 'T');

                        var filter = [
                            new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
                            new nlobjSearchFilter('mainline', null, 'is', 'T'),
                            new nlobjSearchFilter('status', null, 'is', 'CustInvc:A'), // Open status 以这个判断
                            new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
                                MarketplaceShipName.eBay
                            ]),
                            new nlobjSearchFilter('internalid', null, 'is', invId)
                        ];

                        var invSearch = nlapiSearchRecord('invoice', null, filter, INV_COL);
                        _transformPayment(invSearch[0], checkResult);
                        nlapiSubmitField('invoice', invId, 'custbody_taiwu_bill_status_code', 18);

                    }

                    yes.push(ppTransactionId + ' - ' + ids.join(', '));
                }


            } catch (e) {
                e = processException(e, 'Invoice 接受付款错误！！ ' + ppTransactionId + ' ' + invId + ' - ' + ids);
                issues.push(ppTransactionId + ' - ' + 'ppTransactionId ID: ' + ppTransactionId);
            }


            if (env == 'scheduled') {
                checkGovernance();
            }
        }

        if (env == 'scheduled') {
            _log_email('太武合并收款 Invoice access payment - Total: ' + len + ' Error: ' + issues.length, JSON.stringify({
                issues: issues,
                yes: yes
            }, null, 2));

            //if (len === 1000) {
            //    var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
            //    _audit('nlapiScheduleScript', status);
            //}
        }


    } else {
        _audit('Nothing...');
    }
}

function slRun(request, response) {
    var ivsId = request.getParameter('ivsId');
    var custbody_order_type = request.getParameter('custbody_order_type');
    if (custbody_order_type == 3) {
        fencheck(request.getParameter('custbody_paypal_transaction_id'));
    } else {
        _taiwuPayment(ivsId);
    }

    nlapiSetRedirectURL("RECORD", 'invoice', ivsId);
}
/**
 * 13 Bill OK
 * 18 Accept Payment OK
 * @param id
 * @param tag
 * @private
 */
function _taiwuPayment(id, tag) {

    var context = nlapiGetContext();

    var filter = [
        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
        new nlobjSearchFilter('mainline', null, 'is', 'T'),
        new nlobjSearchFilter('status', null, 'is', 'CustInvc:A'), // Open status 以这个判断
        new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
            MarketplaceShipName.eBay
        ])
    ];

    if (id) { // Suitelet
        filter.push(new nlobjSearchFilter('internalid', null, 'is', id));
    }

    else { // Scheduled
        if (tag == 'fix') {
            // : 调整开始日
            filter.push(new nlobjSearchFilter('trandate', null, 'before', '5/1/2017'));
            // filter.push(new nlobjSearchFilter('custbody_taiwu_bill_status_code', null, 'noneof', [13, 18]));
        } else { // 正常的
            // filter.push(new nlobjSearchFilter('trandate', null, 'onorafter', '4/1/2017'));
            filter.push(new nlobjSearchFilter('trandate', null, 'before', 'threeDaysAgo')); // 晚一天生成， 等PP 都下载好
            // filter.push(new nlobjSearchFilter('custbody_taiwu_bill_status_code', null, 'is', 13)); //13. ~~~Bill OK 准备入账
            filter.push(new nlobjSearchFilter('custbody_order_type', null, 'anyof', [ // 除了分单的
                '1', // 正常单
                '@NONE@', // 正常单
                '2', // 补发单
                '4' // 合单
            ]));
        }
    }

    var env = context.getExecutionContext();
    if (env == 'scheduled') {
        var breaklinenum = context.getSetting('script', 'custscript_sc_ap_inv_id');
        if (breaklinenum) {
            breaklinenum = parseInt(breaklinenum);
            _audit('breaklinenum', breaklinenum);
        } else {
            breaklinenum = null;
        }

        //var lastId = context.getSetting('SCRIPT', 'custscript_ap_last_id');
        //if (lastId) {
        //    lastId = parseInt(lastId);
        //    filter.push(new nlobjSearchFilter('internalidnumber', null, 'greaterthan', lastId));
        //}
    }

    //if (custscript_sc_ap_inv_id) {
    //    filter.push(new nlobjSearchFilter('internalid', null, 'is', custscript_sc_ap_inv_id))
    //}

    var search = nlapiSearchRecord('invoice', null, filter, INV_COL);

    if (search != null) {

        _audit('Taiwu 准备Invoice Size -- A', search.length);

        var issues = [];
        var yes = [];

        var len = search.length;

        for (var i = 0; i < len; i++) {

            if (env == 'scheduled') {
                // : test
                //if (i == 100) break;
                if (breaklinenum) {
                    if (i == breaklinenum) {
                        break;
                    }
                }
            }

            var id = search[i].getId();
            _log('Invoice ID', id);

            try {

                var searchResult = search[i];

                var ppTransactionId = searchResult.getValue('custbody_paypal_transaction_id');
                var checkResult = compare(id, ppTransactionId,
                    searchResult.getValue('custbody_order_type'),
                    searchResult.getValue('custbody_pp_checked'),
                    searchResult.getValue('fxamount'),
                    searchResult.getText('currency'),

                    searchResult,
                    tag);

                _log('checkResult', checkResult);
                if (checkResult.code == false) {
                    issues.push('Inv ID: ' + id + ' ' + checkResult.msg);
                } else {
                    _transformPayment(searchResult, checkResult);
                    nlapiSubmitField('invoice', id, 'custbody_taiwu_bill_status_code', 18);
                    yes.push(search[i].getId());
                }

            } catch (e) {
                e = processException(e, 'Invoice 接受付款错误！！ ' + id);
                issues.push('Inv ID: ' + id + e.getUserMessage());
            }

            if (env == 'scheduled') {
                checkGovernance();
            }
        }


        if (env == 'scheduled') {

            //_log_email('太武正常收款 Invoice access payment - Total: ' + len + ' Error: ' + issues.length, JSON.stringify({
            //    issues: issues,
            //    yes: yes
            //}, null, 2));

            if (len === 1000) {
                var params = {};
                params['custscript_ap_last_id'] = search[search.length - 1].getId();
                var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                _audit('nlapiScheduleScript', status);
            }
        }


    } else {
        _audit('Nothing...');
    }

    // P.end('', true);
}


function _transformPayment(invSearchResult, checkResult) {
    var customerpayment = nlapiTransformRecord('invoice', invSearchResult.getId(), 'customerpayment');

    customerpayment.setFieldValue('trandate', nlapiLookupField('invoice', invSearchResult.getId(), 'trandate'));

    customerpayment.setFieldValue('custbody_marketplace', invSearchResult.getValue('custbody_marketplace'));
    customerpayment.setFieldValue('custbody_ebay_order_id', invSearchResult.getValue('custbody_ebay_order_id'));
    customerpayment.setFieldValue('custbody_storefront_order', invSearchResult.getValue('custbody_storefront_order'));
    customerpayment.setFieldValue('custbody_linked_ebay_account', invSearchResult.getValue('custbody_linked_ebay_account'));
    customerpayment.setFieldValue('custbody_ref_number', invSearchResult.getValue('otherrefnum'));
    customerpayment.setFieldValue('custbody_paypal_transaction_id', invSearchResult.getValue('custbody_paypal_transaction_id'));

    if (checkResult.pp_linked) {
        customerpayment.setFieldValue('custbody_link_pt', checkResult.pp_linked);
    }

    customerpayment.setFieldValue('account', checkResult.bankAccountId); //入账！
    customerpayment.setFieldValue('memo', checkResult.memo); // custbody_bank_account 是在Bill 的时候设置的哦

    nlapiSubmitRecord(customerpayment, true);
}


function compare(invId, paypal_transaction_id,
                 custbody_order_type,
                 custbody_pp_checked,
                 total,
                 currency,
                 // 下面2个参数是 For fix situation
                 searchResult,
                 tag) {


    if (tag && tag == 'fix') {
        return _fixCheck(invId, null, searchResult.getValue('custbody_linked_ebay_account'));
    }

    _log('paypal_transaction_id', paypal_transaction_id);

    var multiPay = false;
    if (paypal_transaction_id) {
        if (paypal_transaction_id.indexOf(',') != -1) {
            paypal_transaction_id = paypal_transaction_id.split(',')[0];
            multiPay = true;
        }
        var ppSearch = nlapiSearchRecord('customrecord_paypal_transaction', null, [
            new nlobjSearchFilter('custrecord_pp_id', null, 'is', paypal_transaction_id)
        ], [
            new nlobjSearchColumn('custrecord_pp_total'),
            new nlobjSearchColumn('custrecord_pp_fee'),
            new nlobjSearchColumn('custrecord_pp_email'),
            new nlobjSearchColumn('custrecord_pp_status'),
            new nlobjSearchColumn('custrecord_pp_currency'),

            new nlobjSearchColumn('custrecord_ppaccount_id'),
            new nlobjSearchColumn('custrecord_paypal_account_id', 'custrecord_paypal_accounts')
        ]);
        if (ppSearch != null) {
            if (ppSearch.length == 1) {
                var pp = ppSearch[0];

                var pp_currency = pp.getValue('custrecord_pp_currency');
                var invCurrency = currency; //so.getFieldText('currency');
                _log('Currency 币种', pp_currency + '-' + invCurrency);
                if (pp_currency != invCurrency) {
                    return _updateInvoiceError(invId, '币种不对！');
                }

                var status = pp.getValue('custrecord_pp_status');
                _log('Status', status);

                // if (status == 'Completed' || status == 'Refunded' || status == 'Cleared') {
                if (status) { // 只要有状态就收了
                    var ppaccount_id = pp.getValue('custrecord_ppaccount_id');
                    if (!ppaccount_id) ppaccount_id = pp.getValue('custrecord_paypal_account_id', 'custrecord_paypal_accounts');
                    if (ppaccount_id) {

                        var accountSearch = nlapiSearchRecord('account', null, [
                            new nlobjSearchFilter('custrecord_pp_account_id', null, 'is', ppaccount_id)
                        ]);

                        if (accountSearch != null && accountSearch.length === 1) {
                            var account = accountSearch[0];
                            var bankAccountId = account.getId();

                            _log('bankAccountId', bankAccountId);

                            if (custbody_order_type == 2) { // 补发单逻辑

                                total = parseFloat(total);
                                if (total !== 0) return _updateInvoiceError(invId, 8, '补发单！但是价格不是0！ ' + paypal_transaction_id);

                                return {
                                    pp_linked: pp.getId(),
                                    bankAccountId: bankAccountId,
                                    memo: '补发单对账 0 OK！'
                                };

                            }

                            else if (custbody_order_type == 3) { // 分单

                                if (custbody_pp_checked == 'F') return _updateInvoiceError(invId, '是分单， 但是合并对账不通过！');

                                return {
                                    pp_linked: pp.getId(),
                                    bankAccountId: bankAccountId,
                                    memo: '分单对账OK！'
                                };
                            }

                            else {

                                if (multiPay == true || custbody_order_type == 4) {
                                    return {
                                        pp_linked: pp.getId(),
                                        bankAccountId: bankAccountId,
                                        memo: '对账OK！（MultiPay 或者是合单）'
                                    };

                                } else {
                                    var pp_money = _mathround(parseFloat(pp.getValue('custrecord_pp_total')) + parseFloat(pp.getValue('custrecord_pp_fee')));
                                    var soTotal = parseFloat(total);
                                    _log('pp_money --- soTotal', pp_money + '/' + soTotal);

                                    if (pp_money == soTotal) {

                                        return {
                                            pp_linked: pp.getId(),
                                            bankAccountId: bankAccountId,
                                            memo: '对账OK！'
                                        };

                                    } else {
                                        return _updateInvoiceError(invId, 9, '钱不对 ' + paypal_transaction_id + ' PP: ' + pp_money + ' But the SO is ' + soTotal);
                                    }
                                }

                            }
                        } else {
                            return _updateInvoiceError(invId, 'NS Account 找不到这个 PP Account 商户 的ID. 的 Record');
                        }
                    } else {
                        return _updateInvoiceError(invId, 'PP交易记录没有 PP Account 商户 的ID.');
                    }
                } else {
                    return _updateInvoiceError(invId, 9, 'PP Status is not correct. ' + status);
                }


            } else {
                return _updateInvoiceError(invId, 10, '发现了多个 Paypal Transaction ' + paypal_transaction_id);
            }
        } else {
            return _updateInvoiceError(invId, 1, '没找到这个订单 Paypal Transaction --- ID: ' + paypal_transaction_id);
        }
    } else {
        return _updateInvoiceError(invId, 11, '这个SO 是eBay订单 但是没有Paypal Transaction ID， 请检查。');
    }
}

function _fixCheck(invId, pp, ebayAccountId) {

    if (pp !== null) {
        var ppaccount_id = pp.getValue('custrecord_ppaccount_id');
        if (!ppaccount_id) ppaccount_id = pp.getValue('custrecord_paypal_account_id', 'custrecord_paypal_accounts');
        if (ppaccount_id) {

            var accountSearch = nlapiSearchRecord('account', null, [
                new nlobjSearchFilter('custrecord_pp_account_id', null, 'is', ppaccount_id)
            ]);

            if (accountSearch != null && accountSearch.length === 1) {
                var account = accountSearch[0];
                var bankAccountId = account.getId();

                return {
                    pp_linked: pp.getId(),
                    bankAccountId: bankAccountId,
                    memo: '---Fix---'
                };
            }
        }
    }


    // 直接整 for ebayAccountId
    var search = nlapiSearchRecord('customrecord_ep_mapping', null, [
        new nlobjSearchFilter('custrecord_ep_ebay', null, 'is', ebayAccountId),
        new nlobjSearchFilter('custrecord_paypal_enable', 'custrecord_ep_paypal', 'is', 'T'),
        new nlobjSearchFilter('custrecord_paypal_bank_account', 'custrecord_ep_paypal', 'noneof', '@NONE@')
    ], [
        new nlobjSearchColumn('custrecord_paypal_bank_account', 'custrecord_ep_paypal')
    ]);

    if (search != null) {
        return {
            pp_linked: null,
            bankAccountId: search[0].getValue('custrecord_paypal_bank_account', 'custrecord_ep_paypal'),
            memo: '---Fix---'
        };
    }

    return _updateInvoiceError(invId, 'Fix 过程中发生了问题');
}


function _updateInvoiceError(invId, code, msg) {

    if (!msg) {
        msg = code; //'BILL未知问题';
        code = 8;
    }

    if (Array.isArray(invId)) {

        invId.forEach(function (id) {

            var invRec = nlapiLoadRecord("invoice", id);

            // 设置各种Bill Error Code
            invRec.setFieldValue("custbody_taiwu_bill_status_code", code);

            // 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
            invRec.setFieldValue("custbody_script_memo", msg);
            nlapiSubmitRecord(invRec, true, true);
        });

    } else {
        var invRec = nlapiLoadRecord("invoice", invId);

        // 设置各种Bill Error Code
        invRec.setFieldValue("custbody_taiwu_bill_status_code", code);

        // 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
        invRec.setFieldValue("custbody_script_memo", msg);
        nlapiSubmitRecord(invRec, true, true);
    }


    return {
        code: false,
        statusId: code,
        msg: msg
    };

}