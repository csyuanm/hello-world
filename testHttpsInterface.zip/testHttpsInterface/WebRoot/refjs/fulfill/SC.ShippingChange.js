function run() {

    var search = nlapiSearchRecord('customrecord_shipping_change', null, [
        new nlobjSearchFilter('custrecord_sc_ok', null, 'is', 'F')
    ], [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_sc_carrier'),
        new nlobjSearchColumn('custrecord_sc_shipmethod'),
        new nlobjSearchColumn('custrecord_sc_is_sonumber'),
        new nlobjSearchColumn('custrecord_sc_ok')
    ]);

    if (search != null) {
        for (var i = 0; i < search.length; i++) {

            //   if (i == 1) break;

            var scResult = search[i];
            _log('scResult: ', scResult.getId());

            var filter = null;
            if (scResult.getValue('custrecord_sc_is_sonumber') == 'T') {
                filter = [
                    new nlobjSearchFilter('tranid', null, 'is', scResult.getValue('name')),
                    new nlobjSearchFilter('mainline', null, 'is', 'T')
                ]
            } else {
                filter = [
                    new nlobjSearchFilter('custbody_sz_carrier_trackingnumber', null, 'is', scResult.getValue('name')),
                    new nlobjSearchFilter('mainline', null, 'is', 'T')
                ]
            }

            var searchSO = nlapiSearchRecord('salesorder', null, filter, null);
            if (searchSO != null) {
                if (searchSO.length == 1) {
                    //var maxWeight = nlapiLookupField('customrecord_sz_shippingmethod',
                    //    scResult.getValue('custrecord_sc_carrier'), 'custrecord_sz_sm_max_weight');
                    //_fulfill(nlapiLoadRecord('salesorder', searchSO[0].getId()), {
                    //    custrecord_sz_sm_max_weight: maxWeight,
                    //    custrecord_sz_sm_carrier: scResult.getValue('custrecord_sc_carrier'),
                    //    custrecord_sz_rule_shippingmethod: scResult.getValue('custrecord_sc_shipmethod')
                    //});


                    var soRec = nlapiLoadRecord('salesorder', searchSO[0].getId());
                    soRec.setFieldValue('custbody_taiwu_fulfill_status_code', 8);
                    soRec.setFieldValue('custbody_sz_carrier', scResult.getValue('custrecord_sc_carrier'));
                    soRec.setFieldValue('custbody_ship_method_sz', scResult.getValue('custrecord_sc_shipmethod'));
                    soRec.setFieldValue('custbody_shiping_changed', 'T');

                    nlapiSubmitRecord(soRec, true);
                    //  nlapiSubmitField('customrecord_shipping_change', scResult.getId(), 'custrecord_sc_ok', 'T');

                    var rec = nlapiLoadRecord('customrecord_shipping_change', scResult.getId())
                    rec.setFieldValue('custrecord_sc_ok', 'T');
                    rec.setFieldValue('custrecord_sc_related_so', searchSO[0].getId());

                    nlapiSubmitRecord(rec, true);
                }
            }

        }
    }
}