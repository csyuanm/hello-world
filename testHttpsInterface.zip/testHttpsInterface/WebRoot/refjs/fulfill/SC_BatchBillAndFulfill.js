var SALES_ORDER_CHANGED = false;

var FulfillReport = [];

function processSalesOrder(id) {
    if (Array.isArray(id)) {
        id.forEach(function(_id) {
            _processSalesOrder(_id);
        });
    } else {
        _processSalesOrder(id);
    }
}

function processSalesOrderException(e, info) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "\r\n" + info;
    }
    _error(code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

function _processSalesOrderBill(id) {
    _log("-------- Sales Order ID -----------", id);
    var so = nlapiLoadRecord("salesorder", id);
    var _msg = "";
    try {
        var salesOrderStatus = so.getFieldValue("statusRef");
        switch (salesOrderStatus) {
          case "pendingBilling":
            _bill(so);
            break;

          default:
            throw createError("----------- Not process this status: " + salesOrderStatus);
        }
        _msg = "SO " + id + " Bill OK";
    } catch (e) {
        var ex = processSalesOrderException(e, "SO ID: " + id);
        var exmsg = ex.getUserMessage();
        exmsg = _cutTextLength(exmsg);
        if (so.getFieldValue("custbody_has_issues_bill") == "T" && so.getFieldValue("memo") == exmsg && so.getFieldValue("custbody_script_memo") == exmsg) {} else {
            so = nlapiLoadRecord("salesorder", id);
            so.setFieldValue("custbody_has_issues_bill", "T");
            so.setFieldValue("memo", exmsg);
            so.setFieldValue("custbody_script_memo", exmsg);
            nlapiSubmitRecord(so, true);
        }
        _msg = "SO " + id + " Bill Error. " + exmsg;
    } finally {
        if (so.getFieldValue("custbody_automated_processed") == "F") {
            nlapiSubmitField("salesorder", id, "custbody_automated_processed", "T", true);
        }
        SALES_ORDER_CHANGED = false;
    }
    return _msg;
}

function _processSalesOrder(id) {
    _log("-------- Sales Order ID -----------", id);
    var so = nlapiLoadRecord("salesorder", id);
    try {
        var salesOrderStatus = so.getFieldValue("statusRef");
        switch (salesOrderStatus) {
          case "pendingApproval":
            _approve(so);
            break;

          case "pendingFulfillment":
            _fulfill(so);
            break;

          default:
            throw createError("----------- Not process this status: " + salesOrderStatus);
        }
        FulfillReport.push("SO " + id + " has been fulfilled");
    } catch (e) {
        var ex = processSalesOrderException(e, "SO ID: " + id);
        var exmsg = ex.getUserMessage();
        exmsg = _cutTextLength(exmsg);
        _mustSubmitRecord(id, so, exmsg);
        FulfillReport.push("SO " + id + " on error. " + exmsg);
    } finally {
        if (so.getFieldValue("custbody_automated_processed") == "F") {
            _mustSubmitField(id, [ "custbody_automated_processed", "T" ]);
        }
        SALES_ORDER_CHANGED = false;
    }
}

function _mustSubmitRecord(id, so, exmsg) {
    var count = 0;
    var yes = false;
    do {
        count++;
        try {
            if (so.getFieldValue("custbody_has_issues") == "T" && so.getFieldValue("memo") == exmsg && so.getFieldValue("custbody_script_memo") == exmsg) {} else {
                so = nlapiLoadRecord("salesorder", id);
                so.setFieldValue("custbody_has_issues", "T");
                so.setFieldValue("memo", exmsg);
                so.setFieldValue("custbody_script_memo", exmsg);
                nlapiSubmitRecord(so, true);
            }
            yes = true;
        } catch (e) {
            processException(e, count);
        }
    } while (!yes && count < 3);
}

function _mustSubmitField(id, arr) {
    var count = 0;
    var yes = false;
    do {
        count++;
        try {
            nlapiSubmitField("salesorder", id, arr[0], arr[1]);
            yes = true;
        } catch (e) {
            processException(e, count);
        }
    } while (!yes && count < 3);
}

function checkSalesOrder(so) {
    var id = so.getId();
    _log("checkSalesOrder for", id);
    var linecount = so.getLineItemCount("item");
    var line = 1;
    var itemLines = [];
    for (;line <= linecount; line++) {
        var custcol_item_ships_individually = so.getLineItemValue("item", "custcol_item_ships_individually", line);
        _log("custcol_item_ships_individually --- line: " + line, custcol_item_ships_individually);
        itemLines.push({
            line: line,
            ships_individually: custcol_item_ships_individually,
            description: so.getLineItemValue("item", "description", line),
            quantity: parseInt(so.getLineItemValue("item", "quantity", line)),
            itemtype: so.getLineItemValue("item", "itemtype", line)
        });
    }
    itemLines = itemLines.filter(function(item) {
        return item.itemtype == "InvtPart" || item.itemtype == "Kit";
    });
    var ships_individually_line_size = itemLines.filter(function(item) {
        return item.ships_individually == "T";
    });
    if (ships_individually_line_size.length) {
        SALES_ORDER_CHANGED = true;
        if (itemLines.length > 1) {
            if (ships_individually_line_size.length == 1 && ships_individually_line_size[0].quantity == 1) {
                var shipTogetherLine = itemLines.filter(function(item) {
                    return item.ships_individually == "F";
                });
                var shipTogetherLineFulfillFlag = shipTogetherLine.some(function(item) {
                    return item.itemtype == "InvtPart" || item.itemtype == "Kit";
                });
                if (shipTogetherLineFulfillFlag) {
                    return _splitLineItems(so, id, linecount, itemLines, ships_individually_line_size);
                } else {
                    _log_email("不会走到这里的 shipTogetherLineFulfillFlag----1", id);
                    return _submitNoneShipsIndividuallyRecord(id, so, itemLines);
                }
            } else {
                return _splitLineItems(so, id, linecount, itemLines, ships_individually_line_size);
            }
        } else if (itemLines.length == 1 && ships_individually_line_size.length == 1) {
            var individually_line = ships_individually_line_size[0];
            if (individually_line.quantity > 1) {
                var list = [];
                for (var a = 0; a < individually_line.quantity; a++) {
                    list.push(createSubSalesOrder(id, linecount, individually_line.line, individually_line.description));
                }
                _closeParentSalesOrder(so);
                return list;
            } else {
                so.setFieldValue("custbody_ships_individually", "T");
                so.setFieldValue("custbody_shipment_label", individually_line.description);
                nlapiSubmitRecord(so, true);
                return nlapiLoadRecord("salesorder", id);
            }
        } else {
            _log_email("应该不会走到这一步的啦", id);
            return _submitNoneShipsIndividuallyRecord(id, so, itemLines);
        }
    } else {
        return _submitNoneShipsIndividuallyRecord(id, so, itemLines);
    }
}

function _submitNoneShipsIndividuallyRecord(id, so, itemLines) {
    so.setFieldValue("custbody_ships_individually", "F");
    so.setFieldValue("custbody_shipment_label", _sortShipmentLabel(itemLines));
    nlapiSubmitRecord(so, true);
    return nlapiLoadRecord("salesorder", id);
}

function _splitLineItems(so, id, linecount, itemLines, ships_individually_line_size) {
    var list = [];
    ships_individually_line_size.forEach(function(item) {
        var individually_line = item;
        for (var b = 0; b < individually_line.quantity; b++) {
            list.push(createSubSalesOrder(id, linecount, individually_line.line, individually_line.description));
        }
    });
    var shipTogetherLine = itemLines.filter(function(item) {
        return item.ships_individually == "F";
    });
    if (shipTogetherLine.length) {
        var copyId = createSubSalesOrder(id, linecount, shipTogetherLine.map(function(item) {
            return item.line;
        }), _sortShipmentLabel(shipTogetherLine));
        list.push(copyId);
        _log("A new shipTogether SO was created----------.", copyId);
    }
    _closeParentSalesOrder(so);
    return list;
}

function _sortShipmentLabel(line) {
    var label = "";
    if (Array.isArray(line)) {
        label = line.map(function(item) {
            return item.description;
        }).sort().join(" / ");
    } else {
        label = line.description;
    }
    if (label.length > 280) {
        label = label.substring(0, 280);
    }
    return label;
}

function _closeParentSalesOrder(so) {
    var linecount = so.getLineItemCount("item");
    var id = so.getId();
    var i = 1;
    for (;i <= linecount; i++) {
        so.setLineItemValue("item", "isclosed", i, "T");
    }
    nlapiSubmitRecord(so, true);
    _log("SO " + id + " was successfully closed.");
}

function createSubSalesOrder(id, linecount, retainLine, shipmentLabel) {
    SUB_SALES_ORDER_COUNT++;
    var salesOrderCopy = nlapiCopyRecord("salesorder", id);
    while (linecount--) {
        var line = linecount + 1;
        if (Array.isArray(retainLine)) {
            if (!retainLine.contains(line)) {
                salesOrderCopy.removeLineItem("item", line);
            }
        } else {
            if (line != retainLine) {
                salesOrderCopy.removeLineItem("item", line);
            } else {
                var rate = salesOrderCopy.getLineItemValue("item", "rate", line);
                salesOrderCopy.setLineItemValue("item", "quantity", line, 1);
                salesOrderCopy.setLineItemValue("item", "rate", line, rate);
            }
        }
    }
    if (Array.isArray(retainLine)) {
        salesOrderCopy.setFieldValue("custbody_ships_individually", "F");
    } else {
        salesOrderCopy.setFieldValue("custbody_ships_individually", "T");
    }
    if (shipmentLabel) salesOrderCopy.setFieldValue("custbody_shipment_label", shipmentLabel);
    salesOrderCopy.setFieldValue("orderstatus", "B");
    salesOrderCopy.setFieldValue("custbody_parent_sales_order", id);
    if (SUB_SALES_ORDER_COUNT > 1) {
        salesOrderCopy.setFieldValue("shippingcost", 0);
    }
    var copyId = nlapiSubmitRecord(salesOrderCopy, true);
    _log("3B: A new sub-SO is created.", copyId);
    return copyId;
}

function _approve(so) {
    _log("start---- Approve");
    var id = so.getId();
    so.setFieldValue("orderstatus", "B");
    nlapiSubmitRecord(so, true);
    so = nlapiLoadRecord("salesorder", id);
    _fulfill(so);
}

function _fulfill(so) {
    _log("start---- fulfill");
    var linecount = so.getLineItemCount("item");
    for (var line = 1; line <= linecount; line++) {
        var quantitybackordered = so.getLineItemValue("item", "quantitybackordered", line);
        quantitybackordered = parseInt(quantitybackordered);
        if (quantitybackordered > 0) {
            throw createError("SO has quantitybackordered items and can not to fulfill.");
        }
    }
    var arr_so = checkSalesOrder(so);
    _log("arr_so--- isArray", Array.isArray(arr_so));
    if (Array.isArray(arr_so)) {
        processSalesOrder(arr_so);
    } else {
        so = arr_so;
        var id = so.getId();
        if (so.getFieldValue("custbody_marketplace") == MarketplaceShipName.eBay) {
            if (so.getFieldValue("custbody_market_ship_serv_lvl") == "6") {
                so.setFieldValue("custbody_delay_fulfill", "T");
                so.setFieldValue("memo", "Ship service is TBD, please check.");
                nlapiSubmitRecord(so, true);
                return;
            }
        }
        if (!so.getFieldValue("custbody_shipping_expense")) {
            _log("custbody_shipping_expense", "calling AJ...");
            calculateShipping(id);
            so = nlapiLoadRecord("salesorder", id);
        }
        nlapiLogExecution("audit", "checkorder and call aj -- afterward", nlapiGetContext().getRemainingUsage());
        if (so.getFieldValue("custbody_marketplace") == MarketplaceShipName.eBay) {
            var shipstate = so.getFieldValue("shipstate");
            if (shipstate == "HI" || shipstate == "AK") {
                if (so.getFieldValue("custbody_approved_manually") == "F") {
                    so.setFieldValue("orderstatus", "A");
                    so.setFieldValue("memo", "Need Mike or Matt to approve this sales order manually.");
                    nlapiSubmitRecord(so, true);
                    nlapiSendEmail(530, "mikew@claimthis.com, matt@3btech.net", "SO #" + so.getFieldValue("tranid") + " need approve.", '<a href="' + nlapiResolveURL("record", so.getRecordType(), so.getId()) + '" target="_blank">Click here</a>', "allan@zakeusa.com, johnny@zake.com");
                    return;
                }
            }
        }
        fulfill(so);
        _updateSalesOrder(id, "Successfully fulfilled by script.", "F");
        _log("SO HAS BEEN successfully FULFILLED.", so.getId());
    }
}

function _bill(so) {
    var id = so.getId();
    var marketplace = so.getFieldValue("custbody_marketplace");
    _log("marketplace id", so.getFieldText("custbody_marketplace"));
    var storefrontName = so.getFieldValue("custbody_storefront");
    if (storefrontName == "Techroom Free Repair" || so.getFieldValue("custbody_storefront_list") == STOREFRONT.TechroomFreeRepair) {
        return;
    }
    var invoice = nlapiTransformRecord("salesorder", id, "invoice");
    var lineCount = invoice.getLineItemCount("item");
    for (var line = 1; line <= lineCount; line++) {
        if (!invoice.getLineItemValue("item", "taxcode", line)) {
            invoice.setLineItemValue("item", "taxcode", line, "-7");
        }
    }
    invoice.setFieldValue("memo", "The sales order has been billed successfully.");
    invoice.setFieldValue("custbody_script_memo", "The sales order has been billed successfully.");
    invoice.setFieldValue("custbody_has_issues_bill", "F");
    var invId = nlapiSubmitRecord(invoice, true);
    _log("SO " + id + " has been billed.");
    return invId;
}

function _checkPaypalTransaction(so) {
    var paypal_transaction_id = so.getFieldValue("custbody_paypal_transaction_id");
    _log("paypal_transaction_id", paypal_transaction_id);
    if (paypal_transaction_id) {
        var ppSearch = nlapiSearchRecord("customrecord_paypal_transaction", null, [ new nlobjSearchFilter("custrecord_pp_id", null, "is", paypal_transaction_id) ], [ new nlobjSearchColumn("custrecord_pp_total"), new nlobjSearchColumn("custrecord_pp_fee"), new nlobjSearchColumn("custrecord_pp_email"), new nlobjSearchColumn("custrecord_pp_status"), new nlobjSearchColumn("custrecord_pp_currency") ]);
        if (ppSearch != null) {
            if (ppSearch.length == 1) {
                var pp = ppSearch[0];
                var pp_currency = pp.getValue("custrecord_pp_currency");
                if (so.getFieldValue("custbody_link_pt") != pp.getId()) {
                    nlapiSubmitField("salesorder", so.getId(), "custbody_link_pt", pp.getId());
                }
                var nsEbayAccount = nlapiLoadRecord("customrecord_ebay_account", so.getFieldValue("custbody_linked_ebay_account"));
                var zakeBankEmailList = [ "custrecord_paypal_account_linked", "custrecord_micro_paypal_account_linked" ].map(function(field) {
                    return {
                        value: nsEbayAccount.getFieldValue(field),
                        text: nsEbayAccount.getFieldText(field)
                    };
                });
                _log("zakeBankEmailList", zakeBankEmailList);
                var pp_email = pp.getValue("custrecord_pp_email");
                var pp_money = _mathround(parseFloat(pp.getValue("custrecord_pp_total")) + parseFloat(pp.getValue("custrecord_pp_fee")));
                var soTotal = parseFloat(so.getFieldValue("total"));
                _log("pp_money", pp_money + "/" + soTotal);
                var match = zakeBankEmailList.find(function(item) {
                    return item.text == pp_email;
                });
                if (pp_money == soTotal && pp.getValue("custrecord_pp_status") == "Completed" && match && pp_currency == so.getFieldText("currency")) {
                    if (so.getFieldValue("custbody_bank_account") != match.value) {
                        nlapiSubmitField("salesorder", so.getId(), "custbody_bank_account", match.value);
                    }
                    return true;
                } else {
                    throw createError("Reconciliation result error" + paypal_transaction_id);
                }
            } else {
                throw createError("Found multi-PayPal transaction " + paypal_transaction_id);
            }
        } else {
            throw createError("No Found this Paypal Transaction --- ID: " + paypal_transaction_id);
        }
    } else {
        throw createError("The SO on eBay marketplace but no found PP transaction ID.");
    }
}

function createCashSale(createFromSaleOrderId, account) {
    _log("createCashSale on account", account);
    var cashsale = nlapiTransformRecord("salesorder", createFromSaleOrderId, "cashsale");
    cashsale.setFieldValue("undepfunds", "F");
    cashsale.setFieldValue("account", account);
    return nlapiSubmitRecord(cashsale, true);
}

function swagwayFulfill(salesOrderId, id) {
    var WEIGHT_SPLIT_CONDITION = 20;
    id = id || [];
    var fulfillmentRecord = null;
    try {
        fulfillmentRecord = nlapiTransformRecord("salesorder", salesOrderId, "itemfulfillment");
    } catch (e) {
        if (e instanceof nlobjError && e.getCode() === "VALID_LINE_ITEM_REQD") {
            _log("VALID_LINE_ITEM_REQD", "----000");
            return id;
        } else {
            throw e;
        }
    }
    if (fulfillmentRecord != null) {
        fulfillmentRecord.setFieldValue("shipstatus", "B");
        fulfillmentRecord.setFieldValue("generateintegratedshipperlabel", "T");
        var linecount = fulfillmentRecord.getLineItemCount("item");
        var line = 1;
        var itemtotalweight = 0;
        var shipmentLabel = [];
        for (;line <= linecount; line++) {
            var quantityremaining = fulfillmentRecord.getLineItemValue("item", "quantityremaining", line);
            fulfillmentRecord.setLineItemValue("item", "quantity", line, quantityremaining);
            var itemweight = fulfillmentRecord.getLineItemValue("item", "itemweight", line);
            itemtotalweight += parseFloat(itemweight);
            var itemdescription = fulfillmentRecord.getLineItemValue("item", "itemdescription", line);
            shipmentLabel.push(itemdescription);
            if (itemtotalweight >= WEIGHT_SPLIT_CONDITION) {
                fulfillmentRecord.setFieldValue("custbody_shipment_label", shipmentLabel.join(" | "));
                id.push(nlapiSubmitRecord(fulfillmentRecord, true));
                return swagwayFulfill(salesOrderId, id);
            }
        }
        id.push(nlapiSubmitRecord(fulfillmentRecord, true));
    } else {
        return id;
    }
}

function fulfill(so) {
    var id = so.getId();
    try {
        var fulfillment = nlapiTransformRecord("salesorder", so.getId(), "itemfulfillment");
        var shipmethod = fulfillment.getFieldText("shipmethod");
        if (shipmethod.indexOf("UPS") != -1) {
            fulfillment.setFieldValue("generatereturnlabel", "F");
        }
        fulfillment.setFieldValue("shipstatus", "B");
        fulfillment.setFieldValue("generateintegratedshipperlabel", "T");
        var ffId = nlapiSubmitRecord(fulfillment, true);
        _log("fulfillment has been created", ffId);
        return ffId;
    } catch (e) {
        if (e instanceof nlobjError && e.getCode() == "VALID_LINE_ITEM_REQD") {
            _log("VALID_LINE_ITEM_REQD - already fulfilled. -- from SO ID: ", so.getId());
            var existingFulfillment = nlapiSearchRecord("itemfulfillment", null, [ new nlobjSearchFilter("createdfrom", null, "is", so.getId()), new nlobjSearchFilter("mainline", null, "is", "T") ], [ new nlobjSearchColumn("status"), new nlobjSearchColumn("trackingnumbers") ]);
            if (existingFulfillment != null) {
                var ffIssues = [];
                existingFulfillment.forEach(function(ff) {
                    if (ff.getValue("status") != "packed") {
                        ffIssues.push("existingFulfillment " + ff.getId() + " status not in packed.");
                    }
                    if (ff.getValue("trackingnumbers").indexOf("<BR>") != -1) {
                        ffIssues.push("existingFulfillment " + ff.getId() + " with more than 1 tracking numbers, please check.");
                    }
                });
                if (ffIssues.length) {
                    throw nlapiCreateError("AUTO_FULFILL_ERROR", ffIssues.join(" "));
                }
            } else {
                throw nlapiCreateError("AUTO_FULFILL_ERROR", "not found existingFulfillment from so " + so.getId());
            }
        } else {
            throw e;
        }
    }
}

function _updateSalesOrder(id, memo, issuesFlag) {
    var so = nlapiLoadRecord("salesorder", id);
    memo = _cutTextLength(memo);
    so.setFieldValue("custbody_script_memo", memo);
    so.setFieldValue("memo", memo);
    so.setFieldValue("custbody_has_issues", issuesFlag);
    nlapiSubmitRecord(so, true);
}

var deploymentId = nlapiGetContext().getDeploymentId();

_audit("deploymentId---", deploymentId);

var SUB_SALES_ORDER_COUNT = 0;

function run() {
    try {
        var search = null;
        var columns = [ new nlobjSearchColumn("custbody_marketplace"), new nlobjSearchColumn("internalid").setSort() ];
        if (deploymentId == "customdeploy_batchbillandfulfill_ma") {
            var test_id = nlapiGetContext().getSetting("SCRIPT", "custscript_fulfill_order_id");
            if (test_id) {
                search = nlapiSearchRecord("salesorder", null, [ new nlobjSearchFilter("mainline", null, "is", "T"), new nlobjSearchFilter("internalid", null, "is", test_id) ], [ new nlobjSearchColumn("custbody_marketplace") ]);
                var process_action = nlapiGetContext().getSetting("script", "custscript_process_action");
                if (process_action == "fulfill") {
                    _fulfillSearch(search);
                } else if (process_action == "bill") {
                    _billSearch(search);
                } else {
                    _log_email("No the processing action");
                    return;
                }
            }
        } else if (deploymentId == "customdeploy_batchbill" || deploymentId == "customdeploy_batchbill_fix") {
            var billFilter = [ new nlobjSearchFilter("subsidiary", null, "is", "1"), new nlobjSearchFilter("mainline", null, "is", "T"), new nlobjSearchFilter("custbody_manually_payment_hold", null, "is", "F"), new nlobjSearchFilter("custbody_delay_bill", null, "is", "F"), new nlobjSearchFilter("custbody_marketplace", null, "anyof", [ MarketplaceShipName.Swagway, MarketplaceShipName.eBay, MarketplaceShipName.Amazon, MarketplaceShipName._3BBestbuy, MarketplaceShipName._3BNewegg, MarketplaceShipName._3Btech, MarketplaceShipName.PCDirect, MarketplaceShipName.Rakuten, MarketplaceShipName.Hautebrush, MarketplaceShipName.Walmart, MarketplaceShipName.Jet ]), new nlobjSearchFilter("status", null, "anyof", [ "SalesOrd:F" ]), new nlobjSearchFilter("type", "systemnotes", "is", "T"), new nlobjSearchFilter("context", "systemnotes", "anyof", [ "RST", "SLT", "SCH" ]) ];
            if (deploymentId == "customdeploy_batchbill") {
                billFilter.push(new nlobjSearchFilter("custbody_has_issues_bill", null, "is", "F"));
            } else {
                billFilter.push(new nlobjSearchFilter("custbody_has_issues_bill", null, "is", "T"));
            }
            search = nlapiSearchRecord("salesorder", null, billFilter, columns);
            _billSearch(search);
        } else if (deploymentId == "customdeploy_batchbillandfulfill" || deploymentId == "customdeploy_batchbillandfulfill_amz" || deploymentId == "customdeploy_batchbillandfulfill_swag" || deploymentId == "customdeploy_batchbillandfulfill_fix") {
            var custscript_fulfill_marketplace = nlapiGetContext().getSetting("script", "custscript_fulfill_marketplace");
            var filter = [ new nlobjSearchFilter("subsidiary", null, "is", "1"), new nlobjSearchFilter("custbody_automated_processed", null, "is", "F"), new nlobjSearchFilter("custbody_has_issues", null, "is", "F") ];
            if (deploymentId == "customdeploy_batchbillandfulfill_fix") {
                filter = [ new nlobjSearchFilter("subsidiary", null, "is", "1"), new nlobjSearchFilter("custbody_automated_processed", null, "is", "T"), new nlobjSearchFilter("custbody_has_issues", null, "is", "T") ];
            } else if (deploymentId == "customdeploy_batchbillandfulfill") {
                filter.push(new nlobjSearchFilter("custbody_marketplace", null, "anyof", [ MarketplaceShipName.eBay, MarketplaceShipName._3BNewegg, MarketplaceShipName._3Btech, MarketplaceShipName.Rakuten, MarketplaceShipName.Hautebrush, MarketplaceShipName.Viotek, MarketplaceShipName.Rollibot, MarketplaceShipName.Walmart, MarketplaceShipName.Jet, 26, 16, 25, 15 ]));
            } else if (deploymentId == "customdeploy_batchbillandfulfill_amz") {
                filter.push(new nlobjSearchFilter("custbody_marketplace", null, "anyof", [ MarketplaceShipName.Amazon ]));
            } else if (deploymentId == "customdeploy_batchbillandfulfill_swag") {
                filter.push(new nlobjSearchFilter("custbody_marketplace", null, "anyof", [ MarketplaceShipName.Swagway ]));
                filter.push(new nlobjSearchFilter("datecreated", null, "before", "minutesago30"));
            } else {
                _log_email("3B Fulfill without this deployment", deploymentId);
                return;
            }
            search = nlapiSearchRecord("salesorder", null, filter.concat([ new nlobjSearchFilter("category", "customermain", "noneof", [ "3" ]), new nlobjSearchFilter("status", null, "anyof", [ "SalesOrd:B" ]), new nlobjSearchFilter("mainline", null, "is", "T"), new nlobjSearchFilter("custbody_manually_payment_hold", null, "is", "F"), new nlobjSearchFilter("custbody_delay_fulfill", null, "is", "F"), new nlobjSearchFilter("custbody_is_dropship_so", null, "is", "F"), new nlobjSearchFilter("custbody_market_ship_serv_lvl", null, "noneof", [ 7 ]) ]), columns);
            _fulfillSearch(search);
        } else {
            _log_email("没有可以运行的Fulfill 脚本");
            return;
        }
    } catch (e) {
        processException(e, "Out side deploymentId: " + deploymentId);
    }
    _log("Batch fulfill and bill script end.", deploymentId);
}

function _fulfillSearch(search) {
    if (search != null) {
        var i = 0, len = search.length;
        _audit(deploymentId + " -- _fulfillSearch Pending process sales order size is", len);
        if (deploymentId == "customdeploy_batchbillandfulfill_fix") {
            if (len.length > 50) {
                _log_email("Fulfill Fix 的有点多啊，赶快看看", "https://system.na1.netsuite.com/app/common/search/searchresults.nl?searchtype=Transaction&Transaction_STATUS=SalesOrd%3AB&style=NORMAL&report=&grid=&searchid=1003&dle=T&sortcol=Transaction_TRANDATE_raw&sortdir=ASC&csv=HTML&OfficeXML=F&pdf=&size=50&twbx=F");
            }
        }
        for (;i < len; i++) {
            var id = search[i].getId();
            _audit("i: " + i, id);
            processSalesOrder(id);
            SUB_SALES_ORDER_COUNT = 0;
            if (deploymentId == "customdeploy_batchbillandfulfill_fix") {
                checkGovernance();
            } else {
                if (i >= 200) {
                    var reFlag = rescheduled();
                    if (reFlag == true) {
                        break;
                    }
                } else {
                    checkGovernance();
                }
            }
        }
    } else {
        _log("No search order to process.");
    }
}

function _billSearch(search) {
    if (search != null) {
        var report = [];
        var i = 0, len = search.length;
        _audit(deploymentId + " -- _billSearch Pending process sales order size is", len);
        if (deploymentId == "customdeploy_batchbill_fix") {
            if (len.length > 10) {
                _log_email("Bill Fix 的有点多啊，赶快看看", "https://system.na1.netsuite.com/app/common/search/searchresults.nl?searchtype=Transaction&Transaction_STATUS=SalesOrd%3AB&style=NORMAL&report=&grid=&searchid=1003&dle=T&sortcol=Transaction_TRANDATE_raw&sortdir=ASC&csv=HTML&OfficeXML=F&pdf=&size=50&twbx=F");
            }
        }
        for (;i < len; i++) {
            var id = search[i].getId();
            _log("i: " + i, id);
            report.push(_processSalesOrderBill(id));
            checkGovernance();
        }
        _log("_billSearch: " + report.length, JSON.stringify(report, null, 2));
    } else {
        _log("No search order to process.");
    }
}