// Every 15min for RUN...
var SALES_ORDER_CHANGED = false; //: 这个基本上也没啥用了， 等待修理

function _processException(e, info) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    var __id = info.__id;
    if (info) {
        if (typeof info == 'object') info = JSON.stringify(info);
        message += '\r\n' + info;
    }
    // https://system.na1.netsuite.com/app/common/custom/custlist.nl?id=2472&e=T&ord=T
    if (e.errorId) {
        if (e.code != 'TAIWU_BILL_EXCEPTION') {
            if (![3].contains(e.errorId)) {
                //nlapiSendEmail(530, 'allan@zakeusa.com', code + ' - ' + __id,
                //message + e.errorId +
                //'\r\n' + '<a target="_blank" href="https://system.na1.netsuite.com' + nlapiResolveURL('record', 'salesorder', __id) + '">View</a>');
            }
        }
    } else {
        //nlapiSendEmail(530, 'allan@zakeusa.com', code + ' - ' + __id,
        //message + '\r\n' + '<a target="_blank" href="https://system.na1.netsuite.com' + nlapiResolveURL('record', 'salesorder', __id) + '">View</a>');
    }
    _log(code, message);
    return {
        code: code,
        errorId: e.errorId,
        message: message,
        getMessage: function () {
            return code + ': ' + message;
        },
        getUserMessage: function () {
            return e.userMessage;
        }
    };
}

// 物流部门去发货
function _processSalesOrderFulfill(id) {
    var so = nlapiLoadRecord('salesorder', id);
    var salesOrderStatus = so.getFieldValue('statusRef');
    _log('Process SO Fulfill', so.getFieldValue('tranid'));

    try {
        switch (salesOrderStatus) {
            case 'pendingApproval':
                _approve(so);
                _fulfill(nlapiLoadRecord('salesorder', so.getId()));
                break;
            case 'pendingFulfillment':
            case 'partiallyFulfilled':
                _fulfill(so);
                break;
            default:
                throw createError('Do not process this status: ' + salesOrderStatus);
        }
    }
    catch (e) {
        var ex = _processException(e, { __id: id });
        so = nlapiLoadRecord("salesorder", id);
        if (ex.errorId) so.setFieldValue("custbody_taiwu_fulfill_status_code", ex.errorId);
        else so.setFieldValue("custbody_taiwu_fulfill_status_code", 8);

        // 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
        so.setFieldValue("custbody_script_memo", ex.getUserMessage());
        nlapiSubmitRecord(so, true);

    }
    finally {
        SALES_ORDER_CHANGED = false; // ***** 只有开头和结尾是False *********
    }
}

function _approve(so) {
    _log('start---- Approve');
    var id = so.getId();
    so.setFieldValue('orderstatus', 'B');
    nlapiSubmitRecord(so, true);
}

// 兼容 Error code 写法！！！ 有需要 Fix from Error ID 的时候，才从 ID 的条件开始 -- 但是也可以随便
function _createTaiwuFulfillException(errorId, details) {
    return new Exception(errorId, 'TAIWU_FULFILL_EXCEPTION', details);
}

function _fulfill(so) {
    var parentId = so.getId();
    _log('start---- fulfill');
    var shipItem = '';

    // 重量检查
    var childId = parentId;
    var maxWeight = 2000.00;
    var locationOrderId = '';
    var isDifferentLocation = hasDifferentLocation(so);
    var errors = [];
    var csldtShipLbInfo = new Array();
    var csldtFulfillInfo = new Array();
    var splitted = false;
    var trackingNumber = so.getFieldValue('custbody_sz_carrier_trackingnumber');
    var carrierAPIFlag = false;

    if (isNull(trackingNumber)) {
        // Split order according to different locations
        locationOrderId = splitLocation(so);
        nlapiLogExecution('debug', '_fulfill', 'locationOrderId: ' + locationOrderId)
        var locationIdList = locationOrderId.split(',');
        splitted = locationIdList.length == 1 ? splitted : true;
        var trackingNoStr = '';
        for (var i = 0; i < locationIdList.length; i++) {
            var locationOrderRec = locationOrderId == parentId ? so : nlapiLoadRecord('salesorder', locationIdList[i]);
            var shipItem = '';
            var carrierId = locationOrderRec.getFieldValue('custbody_sz_carrier');
            var shippingMethod = locationOrderRec.getFieldValue('custbody_ship_method_sz');

            // Find logistic vendor if carrier or shipping method is not found
            if (isNull(carrierId) || isNull(shippingMethod)) {
                // do not submit sales order record, find logistic vendor
                shipItem = getNSShipItem(locationOrderRec, true);
                //_log('shipItem', shipItem);
                if (shipItem == null) throw _createTaiwuFulfillException(4, '没有找到合适Shipping Item -- 未发现合适的物流方式');
                locationOrderRec.setFieldValue('custbody_sz_carrier', shipItem.custrecord_sz_sm_carrier);
                locationOrderRec.setFieldValue('custbody_ship_method_sz', shipItem.custrecord_sz_rule_shippingmethod);
                //nlapiLogExecution('debug', '_fulfill', i + ', carrierId: ' + shipItem.custrecord_sz_sm_carrier);
                //nlapiLogExecution('debug', '_fulfill', i + ', shipMethod: ' + shipItem.custrecord_sz_rule_shippingmethod);
            }
            var custbody_tw_fulfillment_status = locationOrderRec.getFieldValue('custbody_tw_fulfillment_status');
            //nlapiLogExecution('debug', 'custbody_tw_fulfillment_status', custbody_tw_fulfillment_status);
            carrierAPIFlag = false;
            nlapiSubmitRecord(locationOrderRec);

            // Split sales order by weight
            var totalWeight = parseFloat(locationOrderRec.getFieldValue('custbody_total_weight'));
            var maxWeight = shipItem.custrecord_sz_sm_max_weight;
            maxWeight = isNull(maxWeight) ? 2000.00 : parseFloat(maxWeight);
            if (totalWeight > maxWeight) childId = splitSalesOrderByWeight(locationOrderRec, maxWeight);
            else childId = locationIdList[i];

            nlapiLogExecution('debug', '_fulfill', 'childId: ' + childId);

            // 3 = 最后的成功
            var idList = childId.split(',');
            for (var j = 0; j < idList.length; j++) {
                isSplit = (idList[j] != locationIdList[i]);
                splitted = isSplit ? true : splitted;
                var childSO = isSplit ? locationOrderRec : nlapiLoadRecord('salesorder', idList[j]);
                try {
                    // Get shipping label information for child sales orders
                    carrierId = shipItem.custrecord_sz_sm_carrier;
                    shippingMethod = shipItem.custrecord_sz_rule_shippingmethod;
                    // Write shipping label in sales order. SALES ORDER WILL BE SUBMITTED!!!!!!!!!!!!!!!!!!!!.
                    carrierAPIFlag = _carrierAPI(idList[j], carrierId, shippingMethod);
                }
                catch (carrierEX) {
                    nlapiLogExecution('debug', '_fulfill_carrierEX', carrierEX);
                    var soId = parentId;
                    var filters = new Array();
                    filters.push(new nlobjSearchFilter('custbody_parent_sales_order', null, 'is', soId));
                    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
                    var list = nlapiSearchRecord('salesorder', null, filters);
                    if (isNull(list)) return;
                    for (var i = 0; i < list.length; i++) {
                        nlapiDeleteRecord('salesorder', list[i].getId());
                    }
                    carrierAPIFlag = false;
                    so.setFieldValue('custbody_script_memo', carrierEX.getDetails());
                    so.setFieldValue('custbody_taiwu_fulfill_status_code', 15);
                    so.setFieldValue('custbody_ship_method_sz', '');
                    so.setFieldValue('custbody_sz_carrier', '');
                    so.setFieldValue('custbody_tw_fulfillment_status', 2);
                    nlapiSubmitRecord(so);
                }

                _log('carrierAPIFlag', i + ', ' + carrierAPIFlag);
                if (!carrierAPIFlag) errors.push(_createTaiwuFulfillException(15, "物流商系统对接失败"));
                if (errors.length) throw errors[0];

                // Consolidate sub-sales order shipping label information
                var subShpgLb = nlapiLookupField('salesorder', idList[j], ['custbody_shippinglabel_info', 'custbody_zake_fulfillmentjson']);
                nlapiLogExecution('debug', i + ', ' + j + ', _fulfill_label', subShpgLb.custbody_shippinglabel_info);
                nlapiLogExecution('debug', i + ', ' + j + ', _fulfill_info', subShpgLb.custbody_zake_fulfillmentjson);
                csldtShipLbInfo.push(JSON.parse(subShpgLb.custbody_shippinglabel_info));
                trackingNoStr += JSON.parse(subShpgLb.custbody_shippinglabel_info).tracking_number + ',';
                nlapiLogExecution('debug', i + ', ' + j + ', _fulfill', 'isSplit: ' + isSplit);
                if (isSplit) {
                    var temp = subShpgLb.custbody_zake_fulfillmentjson.toString();
                    temp = JSON.parse(temp);
                    var fulfillInfo = new Object();
                    fulfillInfo.carrierId = carrierId;
                    fulfillInfo.shippingMethod = shippingMethod;
                    fulfillInfo.trackNumber = JSON.parse(subShpgLb.custbody_shippinglabel_info).tracking_number;
                    fulfillInfo.lines = temp;
                    csldtFulfillInfo.push(fulfillInfo);
                }
                else {
                    var fulfillLines = getSOLineInfo(locationOrderRec, maxWeight).itemList;
                    var fulfillInfo = new Object();
                    fulfillInfo.carrierId = carrierId;
                    fulfillInfo.shippingMethod = shippingMethod;
                    fulfillInfo.trackNumber = JSON.parse(subShpgLb.custbody_shippinglabel_info).tracking_number;
                    fulfillInfo.lines = new Array();
                    for (var k = 0; k < fulfillLines.length; k++) {
                        var temp = new Object();
                        temp.itemId = fulfillLines[k].itemId;
                        temp.fulfillQty = fulfillLines[k].salesQty;
                        temp.binId = fulfillLines[k].binId;
                        temp.binNumber = fulfillLines[k].binNumber;
                        temp.locationId = fulfillLines[k].locationId;
                        temp.salesPrice = fulfillLines[k].salesPrice;
                        fulfillInfo.lines.push(temp);
                        //nlapiLogExecution('debug', 'i+j+k', i + ',' + j + ',' + k + ', ' + temp.binId);
                    }
                    //fulfillInfo = JSON.stringify(fulfillInfo);
                    csldtFulfillInfo.push(fulfillInfo);
                }
            }
        }
        trackingNoStr = trackingNoStr.substring(0, trackingNoStr.length - 1);
        //nlapiLogExecution('debug', '_fulfill', 'csldtShipLbInfo: ' + csldtShipLbInfo);
        //nlapiLogExecution('debug', 'i+j+k', 'csldtFulfillInfo: ' + JSON.stringify(csldtFulfillInfo));
        //so = splitted ? so : nlapiLoadRecord('salesorder', parentId);
        so = nlapiLoadRecord('salesorder', parentId);
        so.setFieldValue('custbody_tw_fulfillment_status', 3);
        so.setFieldValue('custbody_shippinglabel_info', JSON.stringify(csldtShipLbInfo));
        so.setFieldValue('custbody_zake_fulfillmentjson', JSON.stringify(csldtFulfillInfo));
        var singleTrack = trackingNoStr.split(',')[0];
        so.setFieldValue('custbody_sz_carrier_trackingnumber', singleTrack);
        so.setFieldValue('custbody_zake_trackingnolist', trackingNoStr);
        so.setFieldValue('custbody_taiwu_fulfill_status_code', 12);
        if (splitted) so.setFieldValue('custbody_zake_haschildorder', 'T');
        nlapiSubmitRecord(so);
    }
    else carrierAPIFlag = true; 

    // 深圳Fulfill
    var backOrder = isBackOrder(so);
    if (backOrder) {
        //nlapiLogExecution('debug', '_fulfill', 'SO is back ordered');
        so.setFieldValue('custbody_out_of_stock', 'T');
        so.setFieldValue('custbody_script_memo', 'SO is back ordered');
        so.setFieldValue('custbody_taiwu_fulfill_status_code', 3);
        throw 'SO is back ordered';
        return;
    }

    if (!backOrder && carrierAPIFlag) szFulfill(parentId, maxWeight);
}

//shipstatus. Picked - ItemShip:A. Packed - ItemShip:B. Shipped	- ItemShip:C
function szFulfill(so_id, maxWeight) {
    var id = so_id;
    var existingFulfillmentSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', id),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);
    var fulfillment = null;
    var comment = '';
    if (existingFulfillmentSearch != null) {
        if (existingFulfillmentSearch.length == 1) {
            fulfillment = nlapiLoadRecord('itemfulfillment', existingFulfillmentSearch[0].getId());
            comment = '已经有了不更新了-- 有问题 手动删除包裹记录， 再操作';
            _log(comment);
            return existingFulfillmentSearch[0].getId();
        }
        else {
            throw _createTaiwuFulfillException('咋整的，发现了好几个已经存在的Fulfillment 发货记录');
        }
    }
    else {
        try {
            /* 太武国际包裹发货状态
             //分配物流商/物流方式 - 成功	1 ----------- 这个2个标记从SO 那边直接带过来的
             //分配物流商/物流方式 - 失败	2
             //获取物流商跟踪代码（包含交运）- 成功	3
             //获取物流商跟踪代码（包含交运）- 失败	4
             //已经打印主拣货单	5
             //主拣货单验证通过	6
             //已经打印面单	7
             //验证通过已经发货	8
             // Created in Packed	 	9 */

            var soId = so_id;
            var soRec = nlapiLoadRecord('salesorder', soId); // 10 usage

            // Get item list information from sales order
            var soLineInfo = getSOLineInfo(soRec, maxWeight); // 15 usage
            var fulfillListStr = '';
            var trackingStr = '';

            // Check back order & overweight
            if (soLineInfo.overWeight) {
                soRec.setFieldValue('custbody_taiwu_fulfill_status_code', 17);
                nlapiSubmitRecord(soRec);
                throw 'Single item over 2KG!';
                return;
            }

            // If total weight is greater than 2KG, SO needs to be splitted into several fulifllments.
            var orderTotalWeight = soRec.getFieldValue('custbody_total_weight');
            //nlapiLogExecution('debug', 'fakeFulfilSO', 'Order Total Weight: ' + orderTotalWeight);

            var csldtShipLbInfo = soRec.getFieldValue('custbody_shippinglabel_info');
            //nlapiLogExecution('debug', 'szFulfill', 'csldtShipLbInfo: ' + csldtShipLbInfo);
            csldtShipLbInfo = JSON.parse(csldtShipLbInfo);

            var csldtFulfillInfo = soRec.getFieldValue('custbody_zake_fulfillmentjson');
            //nlapiLogExecution('debug', 'szFulfill', 'csldtFulfillInfo: ' + csldtFulfillInfo);
            csldtFulfillInfo = JSON.parse(csldtFulfillInfo);
            //nlapiLogExecution('debug', 'szFulfill', 'csldtFulfillInfo.length: ' + csldtFulfillInfo.length);

            for (var i = 0; i < csldtFulfillInfo.length; i++) {
                var mapping = {};
                var fulfillRec = nlapiTransformRecord('salesorder', soId, 'itemfulfillment');
                fulfillRec.setFieldValue('shipstatus', 'B');
                fulfillRec.setFieldValue('custbody_has_issues', 'F');
                fulfillRec.setFieldValue('custbody_script_memo', '生成好了包裹记录！');
                fulfillRec.setFieldValue('custbody_pending_print', 'T');
                fulfillRec.setFieldValue('custbody_tw_fulfillment_status', 3);
                fulfillRec.setFieldValue('custbody_sz_carrier', csldtFulfillInfo[i].carrierId);
                fulfillRec.setFieldValue('custbody_ship_method_sz', csldtFulfillInfo[i].shippingMethod);
                //nlapiLogExecution('debug', 'fakeFulfilSO', i + ', csldtShipLbInfo: ' + csldtShipLbInfo[i]);
                //nlapiLogExecution('debug', 'fakeFulfilSO', i + ', sum csldtShipLbInfo: ' + csldtShipLbInfo);
                //var shpgLb = isJson(csldtShipLbInfo[i]) ? csldtShipLbInfo[i] : JSON.parse(csldtShipLbInfo[i]);
                var shpgLb = isNull(csldtShipLbInfo[i]) ? csldtShipLbInfo : csldtShipLbInfo[i];
                //nlapiLogExecution('debug', 'fakeFulfilSO', i + ', shpgLb: ' + shpgLb);
                //nlapiLogExecution('debug', 'fakeFulfilSO', i + ', track#: ' + shpgLb.tracking_number);
                fulfillRec.setFieldValue('custbody_sz_carrier_trackingnumber', shpgLb.tracking_number);

                // Unmark all checkboxes
                for (var j = 1; j <= fulfillRec.getLineItemCount('item') ; j++) {
                    fulfillRec.setLineItemValue('item', 'itemreceive', j, 'F');
                }

                //csldtFulfillInfo[i] = isJson(csldtFulfillInfo[i]) ? csldtFulfillInfo[i] : JSON.parse(csldtFulfillInfo[i]);
                var csldtFulfillInfoI = JSON.parse(JSON.stringify(csldtFulfillInfo[i]));
                //nlapiLogExecution('debug', 'test', 'csldtFulfillInfo[' + i + ']: ' + csldtFulfillInfoI);
                for (var j = 1; j <= fulfillRec.getLineItemCount('item') ; j++) {
                    //nlapiLogExecution('debug', 'i+j', 'i, j: ' + i + ', ' + j);
                    var lineItemId = fulfillRec.getLineItemValue('item', 'item', j);

                    //nlapiLogExecution('debug', 'i+j', 'csldtFulfillInfo[' + i + '].length: ' + csldtFulfillInfoI.lines.length);
                    for (var k = 0; k < csldtFulfillInfoI.lines.length; k++) {
                        //nlapiLogExecution('debug', 'i+j+k', 'i, j, k: ' + i + ', ' + j + ', ' + k);
                        var JSONItemId = csldtFulfillInfoI.lines[k].itemId;
                        //nlapiLogExecution('debug', 'szFulfill', i + ', ' + j + ', ' + k + ', head item id: ' + lineItemId);
                        if (lineItemId == JSONItemId) {
                            //nlapiLogExecution('debug', 'szFulfill', i + ', ' + k + ', itemId: ' + JSONItemId);
                            //nlapiLogExecution('debug', 'szFulfill', i + ', ' + k + ', fulfillQty: ' + csldtFulfillInfoI.lines[k].fulfillQty);
                            //nlapiLogExecution('debug', 'szFulfill', i + ', ' + k + ', binId: ' + csldtFulfillInfoI.lines[k].binId);
                            fulfillRec.selectLineItem('item', j);
                            fulfillRec.setCurrentLineItemValue('item', 'itemreceive', 'T');
                            fulfillRec.setCurrentLineItemValue('item', 'quantity', csldtFulfillInfoI.lines[k].fulfillQty);
                            var subRec = fulfillRec.createCurrentLineItemSubrecord('item', 'inventorydetail');
                            subRec.selectLineItem('inventoryassignment', 1);
                            subRec.setCurrentLineItemValue('inventoryassignment', 'binnumber', csldtFulfillInfoI.lines[k].binId);
                            subRec.setCurrentLineItemValue('inventoryassignment', 'quantity', csldtFulfillInfoI.lines[k].fulfillQty);
                            subRec.commitLineItem('inventoryassignment');
                            subRec.commit();
                            fulfillRec.commitLineItem('item');
                            mapping[j + '_' + csldtFulfillInfoI.lines[k].itemId] = csldtFulfillInfoI.lines[k].binNumber;
                            //nlapiLogExecution('debug', 'szFulfill', j + '_' + csldtFulfillInfoI.lines[k].itemId + '_' + csldtFulfillInfoI.lines[k].binNumber);
                        }
                    }
                }

                //nlapiLogExecution('debug', 'test', '22222222');
                shpgLb.items.forEach(function (item) { item.binNumber = mapping[item._id]; });
                fulfillRec.setFieldValue('custbody_shippinglabel_info', JSON.stringify(shpgLb));
                //nlapiLogExecution('debug', 'fakeFulfilSO', i + ', info: ' + JSON.stringify(shpgLb));

                var fulfillId = nlapiSubmitRecord(fulfillRec, true, true);
                nlapiLogExecution('debug', 'fakeFulfilSO', i + ', Fulfill ID: ' + fulfillId);
                fulfillListStr += fulfillId + ',';
                trackingStr += shpgLb.tracking_number + ',';
            }

            fulfillListStr = fulfillListStr.substring(0, fulfillListStr.length - 1);
            trackingStr = trackingStr.substring(0, trackingStr.length - 1);
            soRec.setFieldValue('custbody_taiwu_fulfill_status_code', 12); // 12 = OK
            soRec.setFieldValue('custbody_zake_fulfilidlist', fulfillListStr);
            //soRec.setFieldValue('custbody_sz_carrier_trackingnumber', trackingStr);
            nlapiSubmitRecord(soRec);
        }
        catch (e) {
            throw e;
        }
    }
}

var deploymentId = nlapiGetContext().getDeploymentId();
_audit('deploymentId', deploymentId);

/* 深圳用, Fulfill 脚本是闸口， 后面所有的记录从这里放出 */
function run() {
    try {
        var P = new Profiling();
        var processedList = [];
        var search = null;
        var size = 0;
        //var columns = new Array();
        //columns.push(new nlobjSearchColumn('custbody_marketplace'));
        //columns.push(new nlobjSearchColumn('internalid'));
        //columns.push(new nlobjSearchColumn('datecreated').setSort());

        if (['customdeploy_sc_shenzhen_fulfill_dan'].indexOf(deploymentId) != -1) {

            search = nlapiSearchRecord('salesorder', 1240);

            if (search != null) {
                var i = 0, len = search.length;
                //len = len > 1 ? 1 : len;
                len = len > 30 ? 30 : len;
                size = len;
                _audit('SO List Pending Fulfill', len);
                for (; i < len; i++) {
                    var id = search[i].getId();
                    _log('i: ' + i, id);
                    processedList.push(search[i].getRecordType() + ': ' + search[i].getId());
                    _processSalesOrderFulfill(id);
                    checkGovernance(); // 都用这个吧
                }
            }
            else {
                _log('太武国际 No search order to fulfill.')
            }
            return;

            // Check back order sales order, if it's not back ordered, put it into pending list.
            if (false) {
                var backOrderList = nlapiSearchRecord('salesorder', 1486);
                if (!isNull(backOrderList)) {
                    var len = backOrderList.length > 50 ? 50 : backOrderList.length;
                    for (var i = 0; i < len; i++) {
                        var recId = backOrderList[i].getId();
                        var rec = nlapiLoadRecord('salesorder', recId); //10 usage
                        if (isBackOrder(rec)) continue;
                        rec.setFieldValue('custbody_script_memo', '');
                        rec.setFieldValue('custbody_taiwu_fulfill_status_code', '');
                        rec.setFieldValue('custbody_ship_method_sz', '');
                        rec.setFieldValue('custbody_sz_carrier', '');
                        rec.setFieldValue('custbody_shippinglabel_info', '');
                        rec.setFieldValue('custbody_tw_fulfillment_status', '');
                        rec.setFieldValue('custbody_sz_carrier_trackingnumber', '');
                        rec.setFieldValue('custbody_carrier_shipment_number', '');
                        rec.setFieldValue('custbody_zake_fulfillmentjson', '');
                        nlapiSubmitRecord(rec); //20 usage
                    }
                    checkGovernance(); // 都用这个吧
                }
            }
        }
        else {
            _log_email('没有这个配置啊', deploymentId);
        }
        var remainUsage = nlapiGetContext().getRemainingUsage();
        nlapiLogExecution('debug', 'remainUsage', 'remainUsage: ' + remainUsage);
        P.end('Size: ' + size + ' - ' + deploymentId + '\r\n' + JSON.stringify(processedList, null, 2), true);
    }
    catch (e) {
        processException(e, 'Out side SOID: ' + id);
    }
    _log('Batch fulfill and bill script end.', deploymentId)
}

function splitSalesOrderByWeight(oldSORec, maxWeight) {
    try {
        // Get item list information from sales order
        var oldSOId = oldSORec.getId();
        var soLineInfo = getSOLineInfo(oldSORec, maxWeight); // 15 usage
        var soListStr = '';
        var parentId = oldSORec.getFieldValue('custbody_parent_sales_order');
        parentId = isNull(parentId) ? oldSOId : parentId;

        // Check back order & overweight
        if (soLineInfo.overWeight) {
            oldSORec.setFieldValue('custbody_taiwu_fulfill_status_code', 17);
            nlapiSubmitRecord(oldSORec);
            throw 'Single item over 2KG!';
            return;
        }

        // If total weight is greater than 2KG, SO needs to be splitted into several SO
        var orderTotalWeight = oldSORec.getFieldValue('custbody_total_weight');
        nlapiLogExecution('debug', 'splitSalesOrder', 'Order Total Weight: ' + orderTotalWeight);

        // Break SO line into minimum levels by total quantity
        var breakDownItemList = breakSOLine(soLineInfo.itemList);
        nlapiLogExecution('debug', 'splitSalesOrder', 'Getting Fulfill Summary');
        var fulfillSummary = getFulfillSummary(breakDownItemList, maxWeight);
        nlapiLogExecution('debug', 'splitSalesOrder', 'Loop Fulfill Summary');
        var fulfillJsonList = new Array();
        for (var i = 0; i < fulfillSummary.length; i++) {
            //var fulfillRec = nlapiTransformRecord('salesorder', soId, 'itemfulfillment');
            fulfillJsonList[i] = new Array();
            var newSORec = nlapiCopyRecord('salesorder', oldSOId, 'itemfulfillment');
            newSORec.setFieldValue('orderstatus', 'B');
            newSORec.setFieldValue('custbody_parent_sales_order', parentId);
            newSORec.setFieldValue('custbody_ship_method_sz', oldSORec.getFieldValue('custbody_ship_method_sz'));
            newSORec.setFieldValue('custbody_sz_carrier', oldSORec.getFieldValue('custbody_sz_carrier'));
            newSORec.setFieldValue('custbody_csm_sublocationorder', 'F');

            // Remove all existing lines
            var lineCount = newSORec.getLineItemCount('item');
            for (var j = 1; j <= lineCount; j++) newSORec.removeLineItem('item', 1);

            for (var k = 0; k < fulfillSummary[i].length; k++) {
                //fulfillJsonList[i][k] = new Array();
                var fulfillLineObj = new Object();
                fulfillLineObj.itemId = fulfillSummary[i][k].itemId;
                fulfillLineObj.fulfillQty = fulfillSummary[i][k].fulfillQty;
                fulfillLineObj.binNumber = fulfillSummary[i][k].binNumber;
                fulfillLineObj.binId = fulfillSummary[i][k].binId;
                fulfillLineObj.locationId = fulfillSummary[i][k].locationId;
                fulfillLineObj.salesPrice = fulfillSummary[i][k].salesPrice;
                //fulfillJsonList[i][k].push(fulfillLineObj);
                fulfillJsonList[i].push(fulfillLineObj);

                newSORec.selectNewLineItem('item');
                newSORec.setCurrentLineItemValue('item', 'item', fulfillLineObj.itemId);
                newSORec.setCurrentLineItemValue('item', 'quantity', fulfillLineObj.fulfillQty);
                newSORec.setCurrentLineItemValue('item', 'rate', fulfillLineObj.salesPrice);
                newSORec.setCurrentLineItemValue('item', 'location', fulfillLineObj.locationId);
                newSORec.setCurrentLineItemValue('item', 'isclosed', 'T');
                newSORec.commitLineItem('item');
                newSORec.setFieldValue('location', fulfillLineObj.locationId);
            }

            var fulfillJsonStr = JSON.stringify(fulfillJsonList[i]);
            //fulfillJsonStr = fulfillJsonStr.replace(/\"/g, "\\\"");
            newSORec.setFieldValue('custbody_zake_fulfillmentjson', fulfillJsonStr);
            var newSOId = nlapiSubmitRecord(newSORec);
            nlapiLogExecution('debug', 'splitSalesOrder', i + ', fulfillJsonStr: ' + fulfillJsonStr);
            soListStr += newSOId + ',';
        }
        soListStr = soListStr.substring(0, soListStr.length - 1);
        return soListStr;
    }
    catch (ex) {
        nlapiLogExecution('debug', 'splitSalesOrder', ex);
    }
}

function isNull(str) {
    if (str == '' || str == null) return true;
    else return false;
}

function getSOLineInfo(soRec, maxWeight) {
    var soLineInfo = new Array();
    var itemSearchFilters = new Array();
    var itemList = new Array();
    var totalQty = 0;
    var backOrder = false;
    var lineCount = soRec.getLineItemCount('item');
    for (var i = 1; i <= soRec.getLineItemCount('item') ; i++) {
        var itemType = soRec.getLineItemValue('item', 'itemtype', i);
        if (itemType != 'Kit' && itemType != 'InvtPart') continue;
        var itemLine = new Object();
        itemLine.itemId = soRec.getLineItemValue('item', 'item', i);
        itemLine.salesQty = soRec.getLineItemValue('item', 'quantity', i);
        itemLine.salesPrice = soRec.getLineItemValue('item', 'rate', i);
        totalQty += parseFloat(itemLine.salesQty);
        itemLine.backOrderQty = soRec.getLineItemValue('item', 'quantitybackordered', i);
        if (itemLine.backOrderQty > 0) backOrder = true;
        itemLine.locationId = soRec.getLineItemValue('item', 'location', i);
        itemList.push(itemLine);

        // Generate new search filter for current sales order

        //nlapiLogExecution('debug', 'getSOLineInfo', i + ', itemLine.itemId: ' + itemLine.itemId);
        itemSearchFilters.push([['internalid', 'is', itemLine.itemId], 'AND', ['inventorylocation', 'anyof', itemLine.locationId]]);
        itemSearchFilters.push('OR');
    }
    itemSearchFilters.splice(itemSearchFilters.length - 1, 1)
    //nlapiLogExecution('debug', 'getSOLineInfo, itemSearchFilters', itemSearchFilters);

    var itemSearchObj = nlapiLoadSearch('item', 'customsearch_taiwu_itembinweight'); //5 usage
    var filterExpression = new Array();
    filterExpression.push(itemSearchObj.getFilterExpression());
    filterExpression.push('AND');
    filterExpression.push(itemSearchFilters);
    itemSearchObj.setFilterExpression(filterExpression);
    var itemBinWeightList = itemSearchObj.runSearch();
    itemBinWeightList = itemBinWeightList.getResults(0, 1000); //10 usage

    // Get item weight & bin information from the new search
    var overWeight = false;
    if (isNull(itemBinWeightList)) nlapiLogExecution('debug', 'getSOLineInfo', 'itemBinWeightList is null, NO PREFERRED BIN');
    for (var i = 0; i < itemBinWeightList.length; i++) {
        var itemIdInSearch = itemBinWeightList[i].getId();
        for (var j = 0; j < itemList.length; j++) {
            var itemIdinJSon = itemList[j].itemId;
            if (itemIdinJSon == itemIdInSearch) {
                itemList[j].binId = itemBinWeightList[i].getValue('internalid', 'binNumber');
                itemList[j].binNumber = itemBinWeightList[i].getValue('binNumber');
                itemList[j].weight = itemBinWeightList[i].getValue('weight');
                if (parseFloat(itemList[j].weight) > parseFloat(maxWeight)) {
                    overWeight = true;
                    nlapiLogExecution('debug', 'getSOLineInfo', 'itemList[' + j + '].binId: ' + itemList[j].binId + ', ' + itemIdinJSon);
                }
                itemList[j].cost = itemBinWeightList[i].getValue('cost');
            }
        }
    }

    soLineInfo.itemList = itemList;
    //nlapiLogExecution('debug', 'getSOLineInfo', 'itemList.length: ' + itemList.length);
    soLineInfo.backOrder = backOrder;
    soLineInfo.overWeight = overWeight;
    soLineInfo.totalQty = totalQty;
    return soLineInfo;
}

function breakSOLine(itemList) {
    var breakDownItemList = new Array();
    //nlapiLogExecution('debug', 'breakSOLine','itemList.length: ' + itemList.length);
    for (var i = 0; i < itemList.length; i++) {
        nlapiLogExecution('debug', 'breakSOLine', i + ', ' + itemList[i].itemId + ', ' + itemList[i].weight + ', ' + itemList[i].salesQty);
        for (var j = 0; j < itemList[i].salesQty; j++) {
            var breakDownLine = new Object();
            breakDownLine.itemId = itemList[i].itemId;
            breakDownLine.weight = itemList[i].weight;
            breakDownLine.salesQty = itemList[i].salesQty;
            breakDownLine.salesPrice = itemList[i].salesPrice;
            breakDownLine.binId = itemList[i].binId;
            breakDownLine.locationId = itemList[i].locationId;
            breakDownLine.binNumber = itemList[i].binNumber;
            breakDownLine.fulfillQty = 0;
            breakDownItemList.push(breakDownLine);
        }
    }
    return breakDownItemList;
}

function getFulfillSummary(breakDownItemList, maxWeight) {
    //nlapiLogExecution('debug', 'getFulfillSummary', 'getFulfillSummary begin');
    fulfillRecList = new Array();
    fulfillRecList.push(new Object());
    fulfillRecList[0].totalWeight = 0.00;
    fulfillRecList[0].itemLine = new Array();

    for (var i = 0; i < breakDownItemList.length; i++) {
        var lastFulfillRec = fulfillRecList[fulfillRecList.length - 1];
        var fTotalWeight = lastFulfillRec.totalWeight + parseFloat(breakDownItemList[i].weight);
        if (fTotalWeight > maxWeight) {
            // If fulfillment total weight is over max weight, create a space for new fulfillment
            fulfillRecList.push(new Object());
            fulfillRecList[fulfillRecList.length - 1].totalWeight = 0.00;
            fulfillRecList[fulfillRecList.length - 1].itemLine = new Array();
            i--;
        }
        else {
            lastFulfillRec.totalWeight = parseFloat(fTotalWeight);
            lastFulfillRec.itemLine.push(breakDownItemList[i]);
        }
        //nlapiLogExecution('debug', 'getFulfillSummary', fulfillRecList.length + ', ttlWT: ' + lastFulfillRec.totalWeight + ', ' + lastFulfillRec.itemLine.length);
    }

    // Re-group the fulfillment record, to sum up the fulfill quantity
    var fulfillSummary = new Array();

    for (var i = 0; i < fulfillRecList.length; i++) {
        //nlapiLogExecution('debug', 'breakSOLine', i + ', Is Null, Length: ' + isNull(fulfillRecList[i]) + ', ' + fulfillRecList.length);
        var itemLine = fulfillRecList[i].itemLine;
        //nlapiLogExecution('debug', 'getFulfillSummary', i + ', itemLine.length: ' + itemLine.length);

        for (var j = 0; j < itemLine.length; j++) {
            if (isNull(fulfillSummary[i])) {
                fulfillSummary[i] = new Array();
                fulfillSummary[i].push(itemLine[j]);
            }

            var itemExist = false;
            var itemId = itemLine[j].itemId;
            for (var k = 0; k < fulfillSummary[i].length; k++) {
                if (itemId == fulfillSummary[i][k].itemId) {
                    fulfillSummary[i][k].fulfillQty++;
                    itemExist = true;
                }
            }

            if (!itemExist) {
                fulfillSummary[i].push(fulfillRecList[i].itemLine[j]);
                fulfillSummary[i][fulfillSummary[i].length - 1].fulfillQty = 1;
            }
        }
    }

    return fulfillSummary;
}

function hasDifferentLocation(so) {
    var lineCount = so.getLineItemCount('item');
    if (lineCount == 1) return false;
    var locationId = so.getLineItemValue('item', 'location', 1);
    for (var i = 2; i <= lineCount; i++) {
        var itemType = so.getLineItemValue('item', 'itemtype', i);
        if (itemType == 'Kit' || itemType == 'InvtPart') {
            var lineId = so.getLineItemValue('item', 'location', i);
            if (locationId != lineId) return true;
        }
    }
    return false;
}

function isBackOrder(so) {
    var linecount = so.getLineItemCount("item");
    var isBackOrder = false;
    for (var line = 1; line <= linecount; line++) {
        var quantitybackordered = so.getLineItemValue("item", "quantitybackordered", line);
        quantitybackordered = parseInt(quantitybackordered);
        if (quantitybackordered > 0) {
            nlapiLogExecution('debug', '_fulfill', 'Back ordered!');
            isBackOrder = true;
        }
    }
    return isBackOrder;
}

function splitLocation(soRec) {
    var SOID = soRec.getId();
    if (hasDifferentLocation(soRec)) {
        var lineCount = soRec.getLineItemCount('item');
        var locationList = new Array();
        for (var i = 1; i <= lineCount; i++) {
            var itemType = soRec.getLineItemValue('item', 'itemtype', i);
            if (itemType == 'Kit' || itemType == 'InvtPart') {
                var locationId = soRec.getLineItemValue('item', 'location', i);
                var exist = false;
                for (var j = 0; j < locationList.length; j++) {
                    if (locationId == locationList[j]) {
                        exist = true;
                    }
                }
                if (!exist) locationList.push(locationId);
            }
        }

        var soIdStr = '';
        var soList = new Array();
        for (var i = 0; i < locationList.length; i++) {
            var locationId = locationList[i];
            var newRec = nlapiCopyRecord('salesorder', SOID);
            newRec.setFieldValue('custbody_csm_sublocationorder', 'T');
            newRec.setFieldValue('custbody_parent_sales_order', SOID);
            newRec.setFieldValue('location', locationId);

            var newCount = newRec.getLineItemCount('item');
            for (var j = 1; j <= newCount; j++) {
                var lineLocation = newRec.getLineItemValue('item', 'location', j);
                newRec.setLineItemValue('item', 'isclosed', j, 'T');
                var itemType = newRec.getLineItemValue('item', 'itemtype', j);
                if ((lineLocation != locationId) || (itemType != 'Kit' && itemType != 'InvtPart')) {
                    newRec.removeLineItem('item', j);
                    j--
                    newCount--;
                }
            }

            var newRecId = nlapiSubmitRecord(newRec);
            soIdStr += newRecId + ',';
            soList.push(newRec);
        }

        soIdStr = soIdStr.substring(0, soIdStr.length - 1);
        return soIdStr;
    }
    else return SOID;
}

function isJson(obj) {
    var isjson = typeof (obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length;
    return isjson;
}