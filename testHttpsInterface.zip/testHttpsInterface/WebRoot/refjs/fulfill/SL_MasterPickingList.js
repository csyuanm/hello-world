/*
 * Master Picking List Report ( description added by Hamilton )
 *
 * Type    Client / Suitelet script
 *
 * Author Cheng Li Hou
 *
 * Revisions:
 *
 * ==== 1 ====
 * 
 * Hamilton Nieri ( Email: hamiltonnieri8755@yahoo.com, Skype: hamiltonnieri8755 )
 *
 * Purpose Pagination and Add new column - 3b legacy sku
 *
 * Date    8/9/2016
 *
 * ==== 2 ====
 *
 * Hamilton Nieri
 * 
 * Purpose Populate MPL number of item fulfillment record 
 *
 * Date 8/30/2016
 * ==== 3 ====
 *
 * Hamilton Nieri
 * 
 * Purpose Add a running counter of fulfillments selected to Master Picking List page
 *
 * Date 12/6/2016
 */

var ONES_MAX_MASTER_PICK_FULFILLMENTS_QUANTITY = 1000;
var ROWS_PER_PAGE = 80;

function run(request, response) {

    var userLocation = nlapiGetLocation();
    // 72 3B LA Warehouse
    // compatible with OLD
    if (!userLocation) {
        // This is default location
        userLocation = '2';// 2 South Bend Primary
    } else if (userLocation != '72') {
        // This is default location
        userLocation = '2';// 2 South Bend Primary
    }
    _audit('location id', userLocation);


    try {

        var base_url = "/app/site/hosting/scriptlet.nl?";

        var custpage_mpl_category = request.getParameter("custpage_mpl_category");
        var inpt_custpage_mpl_category = request.getParameter("inpt_custpage_mpl_category");
        var custpage_mpl_allow_reprinting = request.getParameter("custpage_mpl_allow_reprinting");
        if (custpage_mpl_allow_reprinting == "") custpage_mpl_allow_reprinting = "F";
        var ACTION = request.getParameter("action");
        //logparams(request);
        var SELECT_FILTER = request.getParameter("custpage_mpl_ff_select");
        _log("SELECT_FILTER", SELECT_FILTER);

        // Pagination
        var inpt_page_index = ROWS_PER_PAGE;
        if (request.getParameter("p_index") != 'null' && request.getParameter("p_index"))
            inpt_page_index = request.getParameter("p_index");

        var inpt_filter_index = 0;
        if (request.getParameter("f_index") != 'null' && request.getParameter("f_index"))
            inpt_filter_index = request.getParameter("f_index");

        var inpt_is_asc = false;
        if (request.getParameter("is_asc") != 'null' && request.getParameter("is_asc")) {
            inpt_is_asc = request.getParameter("is_asc");
            if (inpt_is_asc == 'true')
                inpt_is_asc = true;
            else
                inpt_is_asc = false;
        }

        if (request.getMethod() == "GET") {

            if (!ACTION) {

                var form = nlapiCreateForm("Master Picking List", false);
                form.setScript("customscript_cs_masterpickinglist");

                form.addButton("custpage_mpl_search", "Search", "search();");
                

                var category = form.addField("custpage_mpl_category", "select", "MPL Category");
                var col = new Array();
                col[0] = new nlobjSearchColumn("name");
                col[1] = new nlobjSearchColumn("internalId");
                col[1].setSort();
                var list = [];
                var shippingSearchResults = nlapiSearchRecord("customlist_mpl_shipping_category", null, null, col);
                for (var x = 0; x < shippingSearchResults.length; x++) {
                    var res = shippingSearchResults[x];
                    var listValue = res.getValue("name");
                    var listID = res.getValue("internalId");
                    category.addSelectOption(listID, listValue);
                }
                if (custpage_mpl_category) {
                    category.setDefaultValue(custpage_mpl_category);
                } else {
                    category.setDefaultValue("1");
                }

                var allowReprinting = form.addField("custpage_mpl_allow_reprinting", "checkbox", "ALLOW REPRINTING");
                allowReprinting.setBreakType("startrow");
                allowReprinting.setDefaultValue(custpage_mpl_allow_reprinting);

                if (custpage_mpl_category) {
                    var searchFilter = [
                        new nlobjSearchFilter("subsidiary", null, "is", Subsidiaries.ZakeInternational),
                        new nlobjSearchFilter("type", "createdfrom", "anyof", ["SalesOrd", "TrnfrOrd"]),
                        new nlobjSearchFilter("status", null, "anyof", ["ItemShip:B"]),
                        new nlobjSearchFilter("mainline", null, "is", "T"),
                        new nlobjSearchFilter("status", "createdfrom", "anyof", ["SalesOrd:B"]),

                        new nlobjSearchFilter("custbody_has_issues", "createdfrom", "is", "F"),
                        new nlobjSearchFilter("custbody_delay_fulfill", "createdfrom", "is", "F"),

                        //new nlobjSearchFilter('location', null, 'is', userLocation),

                        new nlobjSearchFilter('custbody_is_dropship_so', 'createdfrom', 'is', 'F')

                        // For testing
                        //new nlobjSearchFilter('createdfrom', null, 'is', '8522796')
                    ];
                    if (SELECT_FILTER) {
                        if (isNaN(SELECT_FILTER)) {
                            //ONES_MAX_MASTER_PICK_FULFILLMENTS_QUANTITY = 1000;
                            SELECT_FILTER = unescape(SELECT_FILTER);
                            searchFilter.push(new nlobjSearchFilter("custbody_shipment_label", null, "is", SELECT_FILTER));
                            searchFilter.push(new nlobjSearchFilter("custbody_ships_individually", "createdfrom", "is", "T"));
                        } else {
                            if (SELECT_FILTER == -1)
                                searchFilter.push(new nlobjSearchFilter("custbody_ships_individually", "createdfrom", "is", "F"));
                            else if (SELECT_FILTER == 1)
                                searchFilter.push(new nlobjSearchFilter("custbody_ships_individually", "createdfrom", "is", "T"));
                        }
                    }
                    if (custpage_mpl_allow_reprinting == "F") {
                        searchFilter.push(new nlobjSearchFilter("custbody_mpl_number", "createdfrom", "isempty"));
                    }
                    if (custpage_mpl_category == "1") {
                        searchFilter.push(new nlobjSearchFilter("shipcountry", null, "anyof", ["US"]));
                        searchFilter.push(new nlobjSearchFilter("shippingcost", null, "equalto", "0"));
                    } else if (custpage_mpl_category == "2") {
                        searchFilter.push(new nlobjSearchFilter("shipcountry", null, "anyof", ["US"]));
                        searchFilter.push(new nlobjSearchFilter("shippingcost", null, "greaterthan", "0"));
                    } else if (custpage_mpl_category == "3") {
                        searchFilter.push(new nlobjSearchFilter("shipcountry", null, "noneof", ["US", "CA"]));
                    } else if (custpage_mpl_category == "4") {
                        searchFilter.push(new nlobjSearchFilter("shipcountry", null, "anyof", ["CA"]));
                    } else {
                        response.writePage(form);
                        return;
                    }

                    var SEARCH_COLUMNS = [];
                    SEARCH_COLUMNS[0] = new nlobjSearchColumn("internalid");
                    SEARCH_COLUMNS[1] = new nlobjSearchColumn("custbody_ships_individually", "createdfrom");
                    SEARCH_COLUMNS[2] = new nlobjSearchColumn("tranid");
                    SEARCH_COLUMNS[3] = new nlobjSearchColumn("trackingnumbers");
                    SEARCH_COLUMNS[4] = new nlobjSearchColumn("status");
                    SEARCH_COLUMNS[5] = new nlobjSearchColumn("createdfrom");
                    SEARCH_COLUMNS[6] = new nlobjSearchColumn("custbody_mpl_number", "createdfrom");
                    SEARCH_COLUMNS[7] = new nlobjSearchColumn("custbody_marketplace");
                    SEARCH_COLUMNS[8] = new nlobjSearchColumn("custbody_shipment_label");
                    SEARCH_COLUMNS[9] = new nlobjSearchColumn("custitem_legacy_3b_sku", "item");
                    SEARCH_COLUMNS[10] = new nlobjSearchColumn("custbody_storefront_list");
                    SEARCH_COLUMNS[11] = new nlobjSearchColumn("location");
                    SEARCH_COLUMNS[inpt_filter_index].setSort(inpt_is_asc);
                    var search = nlapiCreateSearch("itemfulfillment", searchFilter, SEARCH_COLUMNS);
                    //var savedsearch = search.saveSearch('My Opportunities in Last 90 Days1');
                    search = search.runSearch();
                    //nlapiLogExecution('audit', 'savedsearch', savedsearch);
                    //nlapiLogExecution( 'audit', 'input_filter_index;;' + inpt_filter_index, inpt_is_asc );

                    var ff_count = 0,
                        labelCount = 0 /* count of different labels*/,
                        LabelCount = 0 /* count of IFs with labels */,
                        noLabelCount = 0;

                    var shipmentLabels = [];

                    // added by Hamilton, I replaced the above code with the following one. 
                    var resultIndex = 0;
                    var resultStep = 1000; // Number of records returned in one step (maximum is 1000)
                    var resultSet; // temporary variable used to store the result set
                    do {
                        // fetch one result set
                        resultSet = search.getResults(resultIndex, resultIndex + resultStep);

                        // increase pointer
                        resultIndex = resultIndex + resultStep;

                        // process or log the results

                        for (var i = 0; i < resultSet.length; i++) {
                            var searchResult = resultSet[i];
                            var ships_individually = searchResult.getValue("custbody_ships_individually", "createdfrom");
                            var labelName = searchResult.getValue(SEARCH_COLUMNS[8]);
                            //_log(searchResult.getId(), ships_individually);
                            if (labelName && ships_individually == "T") {
                                var has = shipmentLabels.filter(function (label) {
                                    return label._name == labelName;
                                });
                                if (!has.length) {
                                    labelCount++;
                                    shipmentLabels.push({
                                        _id: labelName,
                                        _name: labelName,
                                        _count: 1
                                    });
                                } else {
                                    has[0]._count++;
                                }
                                LabelCount++; // increase the count of IFs with shipment label
                            } else {
                                noLabelCount++;
                            }
                            ff_count++;
                        }
                    } while (resultSet.length > 0);

                    // var max = ff_count == 4e3 ? "4000+" : ff_count;
                    var max = ff_count;
                    _log("ff_count", ff_count);

                    if (ff_count) {

                        //var inline_style = [ "<style>", "    .uir-list-row-tr > td, .uir-machine-row > td, .uir-machine-totals-row > td {", "        white-space: nowrap;", "    }", ".uir-list-header-td, .uir-machine-headerrow > td {" + "    padding: 6px 5px !important;" + "}", "#custpage_mpl_list_form .listheader { white-space: nowrap; }", "</style>","<script>jQuery(function() { })</script>" ].join("");
                        var inline_style = "<style> .uir-list-row-tr > td, .uir-machine-row > td, .uir-machine-totals-row > td { white-space: nowrap; }.uir-list-header-td, .uir-machine-headerrow > td { padding: 6px 5px !important;}#custpage_mpl_list_form .listheader { white-space: nowrap; } .uir-outside-fields-table { margin-top: 20px; } #custpage_mpl_listheader > td {cursor: pointer;}</style>";
                        form.addField("custpage_mpl_style", "inlinehtml").setDefaultValue(inline_style);

                        var mplList = form.addSubList("custpage_mpl_list", "list", "MPL Search Results");
                        
                        //updated by RT 6.04.17
                        
                        //if (SELECT_FILTER) {
                            form.addButton("custpage_mpl_print", "Print", "print();");
                            mplList.addMarkAllButtons();
                            mplList.addField("mpl_checkbox", "checkbox", "Select", null);
                        //}

                        mplList.addField("mpl_ffid_hidden", "text", "Fulfillment ID Hidden", null).setDisplayType("hidden");
                        mplList.addField("mpl_ffid", "text", "Fulfillment ID", null);
                        mplList.addField("mpl_ships_individually", "text", "Ships Individually", null);
                        mplList.addField("mpl_tranid", "text", "Fulfillment#", null);
                        mplList.addField("mpl_trackingnumbers", "text", "Tracking Numbers", null);
                        mplList.addField("mpl_status", "text", "Status", null);
                        mplList.addField("mpl_so", "text", "SO#", null);
                        mplList.addField("mpl_so_mplnumber", "text", "SO MPL#", null);
                        mplList.addField("mpl_marketplaces", "text", "Marketplaces", null);
                        mplList.addField("mpl_storefront", "text", "STOREFRONT", null);
                        mplList.addField("mpl_ship_label", "text", "Shipment Label", null);
                        mplList.addField("mpl_legacy_sku", "text", "3B Legacy SKU", null);
                        mplList.addField("mpl_location", "text", "Location", null);
                        
                        //var page_search = search.getResults(0, ONES_MAX_MASTER_PICK_FULFILLMENTS_QUANTITY);
                        var page_search = search.getResults(inpt_page_index - ROWS_PER_PAGE, inpt_page_index);

                        form.addField("custpage_searchresults",
                            "label",
                            "Pending Pick Fulfillment / All Fulfillment: " + page_search.length + "/" + max).setLayoutType("startrow");

                        if (page_search.length) {
                            var i = 0, len = page_search.length;
                            for (; i < len; i++) {
                                var searchResult = page_search[i];
                                var line = i + 1;
                                // internalid
                                mplList.setLineItemValue("mpl_ffid_hidden", line, searchResult.getValue(SEARCH_COLUMNS[0]));
                                mplList.setLineItemValue("mpl_ffid", line, '<a href="' + nlapiResolveURL("record", "itemfulfillment", searchResult.getValue(SEARCH_COLUMNS[0])) + '">' + searchResult.getValue(SEARCH_COLUMNS[0]) + "</a>");
                                // tracking numbers
                                mplList.setLineItemValue("mpl_trackingnumbers", line, searchResult.getValue(SEARCH_COLUMNS[3]));
                                // ships individually
                                mplList.setLineItemValue("mpl_ships_individually", line, searchResult.getValue(SEARCH_COLUMNS[1]));
                                // marketplaces
                                mplList.setLineItemValue("mpl_marketplaces", line, searchResult.getText(SEARCH_COLUMNS[7]));
                                // shipment label
                                var labelName = searchResult.getValue(SEARCH_COLUMNS[8]);
                                mplList.setLineItemValue("mpl_ship_label", line, labelName);
                                // mpl number
                                var mplNumber = searchResult.getValue(SEARCH_COLUMNS[6]);
                                mplList.setLineItemValue("mpl_so_mplnumber", line, '<a target="blank" href="https://system.na1.netsuite.com/app/common/custom/custrecordentry.nl?rectype=157&id=' + mplNumber + '">' + mplNumber + "</a>");
                                // tranid
                                mplList.setLineItemValue("mpl_tranid", line, searchResult.getValue(SEARCH_COLUMNS[2]));
                                // status
                                mplList.setLineItemValue("mpl_status", line, searchResult.getText(SEARCH_COLUMNS[4]));
                                // sales order
                                mplList.setLineItemValue("mpl_so", line, '<a href="' + nlapiResolveURL("RECORD", "salesorder", searchResult.getValue(SEARCH_COLUMNS[5])) + '">' + searchResult.getText(SEARCH_COLUMNS[5]) + "</a>");
                                // 3b legacy sku
                                mplList.setLineItemValue("mpl_legacy_sku", line, searchResult.getValue(SEARCH_COLUMNS[9]));
                                //Storefront added by Govind 21Apr
                                mplList.setLineItemValue("mpl_storefront", line, searchResult.getText(SEARCH_COLUMNS[10]));

                                mplList.setLineItemValue("mpl_location", line, searchResult.getText(SEARCH_COLUMNS[11]));

                            }
                        }
                        _log("shipmentLabels", shipmentLabels);

                        // SELECT_FILTER

                        var fulfillmentSelectUI = form.addField("custpage_mpl_ff_select", "select");

                        var page_selectUI = form.addField('custpage_rows', 'select', 'View Row Numbers').setLayoutType("outsidebelow", "startcol"); // added by Hamilton
                        var sort_selectUI = form.addField('custpage_sort', 'select', 'Sort By').setLayoutType("outsidebelow");

                        // Add sort by options
                        sort_selectUI.addSelectOption("0", "FULFILLMENT ID");
                        sort_selectUI.addSelectOption("1", "SHIPS INDIVIDUALLY");
                        sort_selectUI.addSelectOption("2", "FULFILLMENT#");
                        sort_selectUI.addSelectOption("3", "TRACKING NUMBERS");
                        sort_selectUI.addSelectOption("4", "STATUS");
                        sort_selectUI.addSelectOption("5", "SO#");
                        sort_selectUI.addSelectOption("6", "SO MPL#");
                        sort_selectUI.addSelectOption("7", "MARKETPLACES");
                        sort_selectUI.addSelectOption("8", "SHIPMENT LABEL");
                        sort_selectUI.addSelectOption("9", "3B LEGACY SKU");
                        sort_selectUI.addSelectOption("10", "STOREFRONT");

                        form.addField('custpage_is_asc', 'radio', 'ASC', 'false').setLayoutType("outsidebelow").setDefaultValue('false');
                        form.addField('custpage_is_asc', 'radio', 'DESC', 'true').setLayoutType("outsidebelow");

                        var selected_count = form.addField('custpage_selected', 'text', '# OF FULFILLMENTS SELECTED', null).setLayoutType('startrow', 'startrow');
                        selected_count.setDefaultValue('0');
                        selected_count.setDisplayType('inline');

                        // Add page indexes
                        var j = 0;
                        do {
                            if ((j + 1) * ROWS_PER_PAGE < ff_count)
                                page_selectUI.addSelectOption((j + 1) * ROWS_PER_PAGE, (j * ROWS_PER_PAGE + 1) + " to " + (j + 1) * ROWS_PER_PAGE);
                            else
                                page_selectUI.addSelectOption((j + 1) * ROWS_PER_PAGE, (j * ROWS_PER_PAGE + 1) + " to " + ff_count);
                            j++;
                        } while (j * ROWS_PER_PAGE < ff_count);

                        // added by Hamilton, set default value for custpage_rows
                        page_selectUI.setDefaultValue(inpt_page_index);
                        sort_selectUI.setDefaultValue(inpt_filter_index);
                        form.setFieldValues({custpage_is_asc: inpt_is_asc});

                        if (!SELECT_FILTER) {
                            fulfillmentSelectUI.addSelectOption("0", "--- Please select filter ---", true);
                            fulfillmentSelectUI.addSelectOption("-1", "*** All NONE OF SHIP INDIVIDUALLY fulfillments (" + noLabelCount + ") ***");
                            fulfillmentSelectUI.addSelectOption("1", "*** All OF SHIP INDIVIDUALLY fulfillments (" + LabelCount + ") ***");
                        }

                        var optionSelected = false;
                        if (shipmentLabels.length) {
                            shipmentLabels.forEach(function (item) {
                                if (SELECT_FILTER && SELECT_FILTER == item._name) {
                                    // Only 1 match here
                                    fulfillmentSelectUI.addSelectOption(item._id, item._name + " (" + item._count + ")", true);
                                    optionSelected = true;
                                } else {
                                    fulfillmentSelectUI.addSelectOption(item._id, item._name + " (" + item._count + ")");
                                }
                            });
                        }

                        if (SELECT_FILTER) {
                            fulfillmentSelectUI.addSelectOption("0", "*** Search all items ***");
                            if (!optionSelected) {
                                if (!isNaN(SELECT_FILTER)) {
                                    if (SELECT_FILTER == -1)
                                        fulfillmentSelectUI.addSelectOption("-1", "*** All NONE OF SHIP INDIVIDUALLY fulfillments (" + noLabelCount + ") ***", true);
                                    else if (SELECT_FILTER == 1)
                                        fulfillmentSelectUI.addSelectOption("1", "*** All OF SHIP INDIVIDUALLY fulfillments (" + LabelCount + ") ***", true);
                                } else {
                                    fulfillmentSelectUI.addSelectOption("-1", "*** All NONE OF SHIP INDIVIDUALLY fulfillments (" + noLabelCount + ") ***");
                                    fulfillmentSelectUI.addSelectOption("1", "*** All OF SHIP INDIVIDUALLY fulfillments (" + LabelCount + ") ***");
                                }
                            }
                        }
                    } else {
                        form.addField("custpage_searchresults", "label", "No found search results.").setLayoutType("startrow");
                    }
                    response.writePage(form);
                } else {
                    response.writePage(form);
                }
            } else if (ACTION == "print") {
                var ffSelectedList = JSON.parse(request.getParameter("ffSelectedList"));
                _log("ffSelectedList", ffSelectedList);
                var columns = [
                    new nlobjSearchColumn("location", null, "GROUP"),
                    new nlobjSearchColumn("item", null, "GROUP"),
                    new nlobjSearchColumn("salesdescription", "item", "GROUP"),
                    new nlobjSearchColumn("quantity", null, "SUM"),
                    new nlobjSearchColumn("custitem_legacy_3b_sku", "item", "GROUP").setSort()
                ];
                var printFilter = [
                    new nlobjSearchFilter("type", "createdfrom", "anyof", ["SalesOrd", "TrnfrOrd"]),
                    new nlobjSearchFilter("status", null, "anyof", ["ItemShip:B"]),
                    new nlobjSearchFilter("type", "item", "anyof", ["InvtPart", "Kit"])
                ];
                printFilter.push(new nlobjSearchFilter("internalid", null, "anyof", ffSelectedList));
                var printResults = nlapiSearchRecord("itemfulfillment", null, printFilter, columns);
                var masterList = printResults.map(function (searchResult) {
                    var sku = searchResult.getText(columns[1]);
                    if (sku.indexOf(":") != -1) {
                        sku = sku.substring(sku.indexOf(":") + 1).trim();
                    }
                    return {
                        location: searchResult.getText(columns[0]),
                        item: sku,
                        legacysku: searchResult.getValue(columns[4]),
                        salesdescription: searchResult.getValue(columns[2]),
                        quantity: searchResult.getValue(columns[3]),
                        sum: searchResult.getValue(columns[3])
                    };
                });
                if (masterList.length) {
                    var data = {
                        masterList: masterList
                    };
                    var masterRecord = nlapiCreateRecord("customrecord_mpl_record");
                    masterRecord.setFieldValue("custrecord_mpl_subsidiary", Subsidiaries.ZakeInternational);
                    masterRecord.setFieldValue("custrecord_mpl_shipping_category", custpage_mpl_category);
                    masterRecord.setFieldValue("custrecord_mpl_data", JSON.stringify(data));
                    var masterRecordId = nlapiSubmitRecord(masterRecord);
                    printFilter.push(new nlobjSearchFilter("mainline", null, "is", "T"));
                    var pSearch = nlapiSearchRecord("itemfulfillment", null, printFilter,
                        [
                            new nlobjSearchColumn("createdfrom"),
                            new nlobjSearchColumn("internalid")
                        ]);

                    var selected_so_list = new Array();
                    pSearch.forEach(function (pSearchResult) {
                        selected_so_list.push(pSearchResult.getValue("createdfrom"));
                    });
                    nlapiSubmitField("customrecord_mpl_record", masterRecordId, "custrecord_fulfillments_mpl", JSON.stringify(selected_so_list));

                    //pSearch.forEach(function (pSearchResult) {
                    //    nlapiSubmitField("salesorder", pSearchResult.getValue("createdfrom"), "custbody_mpl_number", masterRecordId);
                    //    //nlapiSubmitField("itemfulfillment", pSearchResult.getValue("internalid"), "custbody_mpl_number", masterRecordId);
                    //    //nlapiLogExecution('debug', 'itemfulfillment#', pSearchResult.getValue("internalid"));
                    //});

                    for (var k = 0, klen = pSearch.length; k < klen; k++) {
                        var pSearchResult = pSearch[k];
                        _mustSubmit(pSearchResult, masterRecordId);
                    }

                    _auditUsage();

                    response.writeLine(JSON.stringify({
                        mpl_id: masterRecordId,
                        remainingUsage: nlapiGetContext().getRemainingUsage()
                    }));
                } else {
                    response.write("No Master List for Print.");
                }
            } else if (ACTION == "showMPLPDF") {
                response.setContentType("PDF", null, "inline");
                response.write(nlapiLoadFile(request.getParameter("fileId")));
            } else if (ACTION == "showMPLPDF2") {
                printMPLPDF(request, response);
            }
        } else {
            _log("------------------------------------post");
            if (request.getParameter("action") == "showMPLPDF") {
                response.setContentType("PDF", null, "inline");
                response.write(nlapiLoadFile(request.getParameter("fileId")));
            } else if (ACTION == "showMPLPDF2") {
                printMPLPDF(request, response);
            }
        }
    } catch (e) {
        e = processException(e);
        response.write(e.getUserMessage());
    }
}

function _mustSubmit(pSearchResult, masterRecordId) {

    // 最多3次一定要成功
    var count = 0;
    var yes = false;
    do {
        count++;
        try {
            nlapiSubmitField("salesorder", pSearchResult.getValue("createdfrom"), "custbody_mpl_number", masterRecordId);
            yes = true;
        } catch (e) {
            processException(e, count);
        }
    } while (!yes && count < 3);

}


function printMPLPDF(request, response) {
    var pdfHTML = nlapiLoadFile("SuiteScripts/FulfillManagement/SL_MasterPickingListPDF.html").getValue();
    var template = Handlebars.compile(pdfHTML);
    var mpl_id = request.getParameter("mpl_id");
    var mpl_record = nlapiLoadRecord("customrecord_mpl_record", mpl_id);
    var custrecord_mpl_data = mpl_record.getFieldValue("custrecord_mpl_data");
    custrecord_mpl_data = JSON.parse(custrecord_mpl_data);
    var xml = template({
        number: mpl_id,
        itemlist: custrecord_mpl_data.masterList
    });
    var file = nlapiXMLToPDF(xml);
    response.setContentType("PDF", mpl_id + ".pdf", "inline");
    response.write(file);
}