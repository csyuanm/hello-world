// Every 15min for RUN...
//var SALES_ORDER_CHANGED = false; //: 这个基本上也没啥用了， 等待修理
var deploymentId = nlapiGetContext().getDeploymentId();
_audit('deploymentId---', deploymentId);

function _processException(e, info) {

    e = parseException(e);

    var code = e.code;
    var message = e.message;

    var __id = info.__id;

    if (info) {
        if (typeof info == 'object') {
            info = JSON.stringify(info);
        }
        message += '\r\n' + info;
    }

    //if (deploymentId == 'customdeploy_sz_batchfulfill' || deploymentId == 'customdeploy_sz_batchfulfill_fix') {
    //    nlapiSendEmail(530, 'allan@zakeusa.com', deploymentId + ' - ' + code + ' - ' + __id,
    //        message +
    //        '\r\n' + '<a target="_blank" href="https://system.na1.netsuite.com' + nlapiResolveURL('record', 'salesorder', __id) + '">View</a>');
    //
    //}

    _log(code, message);

    return {
        code: code,
        errorId: e.errorId,
        message: message,
        getMessage: function () {
            return code + ': ' + message;
        },
        getUserMessage: function () {
            return e.userMessage;
        }
    };
}

// 兼容 Error code 写法！！！
// 有需要 Fix from Error ID 的时候，才从 ID 的条件开始 -- 但是也可以随便
function _createTaiwuFulfillException(errorId, details) {
    //if (isNaN(parseInt(errorId))) {
    //    // errorId as details
    //    return new Exception(null, 'TAIWU_FULFILL_EXCEPTION', errorId);
    //} else {
    //    return new Exception(errorId, 'TAIWU_FULFILL_EXCEPTION', details);
    //}

    if (isNaN(errorId)) {
        details = errorId;
        errorId = 8;
    }
    return new Exception(errorId, 'TAIWU_FULFILL_EXCEPTION', details);
}

function _createTaiwuBillException(errorId, details) {
    //if (isNaN(parseInt(errorId))) {
    //    // errorId as details
    //    return new Exception(null, 'TAIWU_BILL_EXCEPTION', errorId);
    //} else {
    //    return new Exception(errorId, 'TAIWU_BILL_EXCEPTION', details);
    //}

    return new Exception(errorId, 'TAIWU_BILL_EXCEPTION', details);
}

// 物流部门去发货
function _processSalesOrderFulfill(id) {

    _log('-------- Sales Order ID -----_processSalesOrderFulfill------', id);

    var so = nlapiLoadRecord('salesorder', id);
    var tranid = so.getFieldValue('tranid');
    var salesOrderStatus = so.getFieldValue('statusRef');
    var market = so.getFieldValue('custbody_marketplace');

    var message = '';
    try {


        switch (salesOrderStatus) {

            case 'pendingApproval':

                // if (market != MarketplaceShipName.Wish) {
                if (![MarketplaceShipName.Wish, MarketplaceShipName.eBay].contains(market)) {
                    _approve(so);
                    message = _fulfill(nlapiLoadRecord('salesorder', so.getId()));
                }

                break;

            case 'pendingFulfillment':
            case 'partiallyFulfilled':
                message = _fulfill(so);
                break;

            default:
                throw createError('----------- Not process this status: ' + salesOrderStatus);
        }


    } catch (e) {

        var ex = _processException(e, {__id: id});

        var code = 8;
        if (ex.errorId) code = ex.errorId;

        //so = nlapiLoadRecord("salesorder", id);
        _updateFulfillError(null, code, _cutText(ex.getUserMessage()), id);


        //so = nlapiLoadRecord("salesorder", id);
        //
        //if (ex.errorId) {
        //    so.setFieldValue("custbody_taiwu_fulfill_status_code", ex.errorId);
        //} else {
        //    // 未知问题
        //    so.setFieldValue("custbody_taiwu_fulfill_status_code", 8);
        //}
        //
        //// 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
        //so.setFieldValue("custbody_script_memo", _cutText(ex.message));
        //nlapiSubmitRecord(so, false, true);

        message = ex.getUserMessage() + ' - ' + so.getFieldValue('custbody_carrier_message');

    } finally {

        // 这个 IF 用的好！
        if (so.getFieldValue('custbody_automated_processed') == 'F') {
            _mustSubmitField(id, ['custbody_automated_processed', 'T'])
        }

        message += ' - processed.';
    }

    return tranid + ' - ' + so.getFieldValue('trandate') + ' - ' +
        so.getFieldText('custbody_marketplace') + ' - ' +
        so.getFieldText('location') + ' - ' + message;

}

function _updateFulfillError(so, code, msg, id) {

    if (!msg) {
        code = 8;
        msg = code; //'未知问题';
    }

    if (id) {
        nlapiSubmitField('salesorder', id, [
            'custbody_taiwu_fulfill_status_code',
            'custbody_script_memo'
        ], [
            code,
            msg
        ])
    } else {
        //var so = nlapiLoadRecord("salesorder", id);

        // 设置各种Bill Error Code
        so.setFieldValue("custbody_taiwu_fulfill_status_code", code);

        // 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
        so.setFieldValue("custbody_script_memo", msg);

        //TODO: Code: RCRD_HAS_BEEN_CHANGED
        nlapiSubmitRecord(so, false, true);
    }


    return msg;

}

// 财务部门去结算
function _processSalesOrderBill(id) {


    try {

        var so = nlapiLoadRecord('salesorder', id);

        _bill(so);

        // Bill OK
        nlapiSubmitField('salesorder', id, 'custbody_taiwu_bill_status_code', '13', true);

        return 'OK ' + id;

    } catch (e) {

        var ex = _processException(e, {__id: id});

        var code = 8;
        if (ex.errorId) code = ex.errorId;
        _updateBillError(nlapiLoadRecord("salesorder", id), code, _cutText(ex.getUserMessage()));

        return 'Exception - ' + id + ' - ' + ex.code + ' ' + ex.message; // + ' ' + id;
    }

}

function _mustSubmitField(id, arr) {

    // 最多3次一定要成功
    var count = 0;
    var yes = false;
    do {
        count++;
        try {
            nlapiSubmitField('salesorder', id, arr[0], arr[1]);
            yes = true;
        } catch (e) {
            processException(e, count);
        }
    } while (!yes && count < 3);

}

function _updateBillError(so, code, msg) {

    if (!msg) {
        msg = code; //'BILL未知问题';
        code = 8;
    }

    //var so = nlapiLoadRecord("salesorder", id);

    // 设置各种Bill Error Code
    so.setFieldValue("custbody_taiwu_bill_status_code", code);

    // 这个可能因为 有 Fulfill 和 Bill的Exception 可能会重复的设置， 不过没有关系， 有指定的Code呢
    so.setFieldValue("custbody_script_memo", msg);
    nlapiSubmitRecord(so, true, true);

}

function _approve(so) {
    // --------------- Approve --------------------
    _log('start---- Approve');
    var id = so.getId();
    so.setFieldValue('orderstatus', 'B');
    nlapiSubmitRecord(so, true);

}

function _fulfill(so) {

    _log('start---- fulfill');
    _log('custbody_tw_fulfillment_status', so.getFieldValue('custbody_tw_fulfillment_status'));
    _log('custbody_taiwu_fulfill_status_code', so.getFieldValue('custbody_taiwu_fulfill_status_code'));

    var custbody_shiping_changed = so.getFieldValue('custbody_shiping_changed');
    _log('custbody_shiping_changed', custbody_shiping_changed);

    var id = so.getId();

    // Fulfill OK 而且不需要物流变更
    //if (so.getFieldValue('custbody_taiwu_fulfill_status_code') == '12' && so.getFieldValue('custbody_shiping_changed') == 'F') {
    //    return;
    //}

    var location = so.getFieldValue('location');
    // 对于海外仓
    if (location == '73' || location == '84' || location == '85' || location == '86') {

        var overseaTrackingNo = so.getFieldValue('custbody_sz_carrier_trackingnumber');
        if (overseaTrackingNo) {
            szFulfill(id, {
                location: location
            }, true);
        } else {
            //throw _createTaiwuFulfillException("海外仓等待Tracking Number 的导入， 才能继续的Fulfill！");
            return _updateFulfillError(so, "海外仓等待Tracking Number 的导入， 才能继续的Fulfill！");
        }

    }
    else if (location == '36') { // 深圳本地仓转到FBA发货--- 只从SO Button 上面触发
        szFulfill(id, {
            location: location
        }, true);
    }
    else if (location == 34 || location == 35) {

        var totalWeight = so.getFieldValue('custbody_total_weight');
        if (!totalWeight) {
            // 异常
            return _updateFulfillError(so, '木有订单总重量字段！');
            //return;
        }

        var custbody_tw_fulfillment_status = so.getFieldValue('custbody_tw_fulfillment_status');

        // - 第一步选择 合适的Ship Item
        // _log('第一步选择 合适的Ship Item');
        var shipItem = null;

        var orderType = so.getFieldValue('custbody_order_type');
        if (orderType == 2 || orderType == 3 || orderType == 4) {
            if (so.getFieldValue('custbody_sz_carrier') && so.getFieldValue('custbody_ship_method_sz')) {
                shipItem = _userSelectShippingItem(so);
            } else {
                // 异常
                return _updateFulfillError(so, '补发单/合单/分单的请自己手动的选择物流商和物流方式，多谢！');
                // return;
            }
        } else {
            if (so.getFieldValue('custbody_sz_carrier') && so.getFieldValue('custbody_ship_method_sz')) {
                if (custbody_shiping_changed == 'T') {
                    shipItem = _userSelectShippingItem(so);
                } else {
                    if (custbody_tw_fulfillment_status != 3) { // 3: 最后的成功！
                        shipItem = _scriptSelectShippingItem(so);
                    } else {
                        shipItem = _userSelectShippingItem(so);
                    }
                }
            } else {
                shipItem = _scriptSelectShippingItem(so);
                //so.setFieldValue('custbody_script_memo', '已经根据物流规则分配好了相应的物流商和物流方式');
            }
        }


        // 重量检查 - with Ship Item
        //_log('重量检查 - with Ship Item');
        if (parseFloat(totalWeight) > parseFloat(shipItem.custrecord_sz_sm_max_weight)) {
            throw _createTaiwuFulfillException(5, '找到了物流方式但是不行 --- SO 的商品总重量大于物流方式的重量上限 --拆单！！ ' + shipItem.custrecord_sz_sm_max_weight + 'g. ID: ' + so.getId());
        }

        // backorder check
        var backOrderFlag = false;
        var linecount = so.getLineItemCount("item");
        for (var line = 1; line <= linecount; line++) {
            var quantitybackordered = so.getLineItemValue("item", "quantitybackordered", line);
            var isclosed = so.getLineItemValue("item", "isclosed", line);
            if (isclosed == 'T') continue;
            quantitybackordered = parseInt(quantitybackordered);
            if (quantitybackordered > 0) { // 只有一个 Item 是Backorder 我们就停下来
                backOrderFlag = true;
                break;
            }
        }
        _log('backOrderFlag', backOrderFlag);
        if (backOrderFlag) {
            so.setFieldValue('custbody_out_of_stock', 'T');
        } else {
            so.setFieldValue('custbody_out_of_stock', 'F');
        }
        nlapiSubmitRecord(so, true);

        //if (backOrderFlag && deploymentId == 'customdeploy_sz_batchfulfill_backorder') {
        //    return; // 只是缺货检查不处理了。
        //}

        // ------------- 订单伪发货， 先获取跟踪单号 ------------------

        //var carrierAPIFlag = false;

        var trackingNo = so.getFieldValue('custbody_sz_carrier_trackingnumber');

        if (trackingNo && custbody_tw_fulfillment_status == 3
            && so.getFieldValue('custbody_shiping_changed') == 'F') {

            // 如果面单有问题的话修复一下
            if (!so.getFieldValue('custbody_shippinglabel_info')) {
                var shipment = new Shipment(id);
                var labelDetails = shipment.getShippingLabelDetails();
                labelDetails.tracking_number = trackingNo; //so.getFieldValue('custbody_sz_carrier_trackingnumber');
                nlapiSubmitField('salesorder', id, 'custbody_shippinglabel_info', JSON.stringify(labelDetails));
            }

            // 亚太需要交运确认
            var carrier = shipItem.custrecord_sz_sm_carrier;
            if (carrier == 3 || carrier == 4) { // APACShipping
                var custbody_shipconfirm = so.getFieldValue('custbody_shipconfirm');
                if (custbody_shipconfirm == 'F') {
                    var apacshipping = new APACShipping(id);
                    var confirm = apacshipping.ConfirmAPACShippingPackage(trackingNo);
                    if (confirm == false) {
                        throw _createTaiwuFulfillException(15,
                            so.getFieldText('custbody_sz_carrier') + ': ' + so.getFieldText('custbody_ship_method_sz') +
                            " 亚太交运失败！");
                    }
                }
            }

            // carrierAPIFlag = true;

        } else {
            // 物流商获取面单成功之后 设置3: 最后的成功！
            // 最重要的是获取跟跟踪代码， 如果面单不成功可以在fulfillment上面获取一把
            var carrierAPIFlag = _carrierAPI(id, shipItem.custrecord_sz_sm_carrier, shipItem.custrecord_sz_rule_shippingmethod);
            _log('Carrier API Flag', carrierAPIFlag);

            if (typeof carrierAPIFlag == 'object') {
                if (carrierAPIFlag.flag == false) {
                    throw _createTaiwuFulfillException(15,
                        so.getFieldText('custbody_sz_carrier') + ': ' + so.getFieldText('custbody_ship_method_sz') +
                        " " + carrierAPIFlag.message);
                }
            } else if (typeof carrierAPIFlag == 'boolean') {
                if (carrierAPIFlag === true) {
                    // TODO: 应该转移到物流商对接代码中--- 以后做了， 先浪费个Usage
                    nlapiSubmitField('salesorder', id, 'custbody_shiping_changed', 'F', true);
                } else {
                    throw _createTaiwuFulfillException(15,
                        so.getFieldText('custbody_sz_carrier') + ': ' + so.getFieldText('custbody_ship_method_sz') +
                        " 物流商系统对接失败");
                }
            }

        }

        //_log('carrierAPIFlag', carrierAPIFlag);
        //
        //if (carrierAPIFlag == false) {
        //    throw _createTaiwuFulfillException(15,
        //        so.getFieldText('custbody_sz_carrier') + ': ' + so.getFieldText('custbody_ship_method_sz') +
        //        " 物流商系统对接失败");
        //}

        // 深圳 Fulfill
        if (backOrderFlag) {
            throw _createTaiwuFulfillException(3, "订单有缺货的产品")
        } else {
            szFulfill(id, {
                location: so.getFieldValue('location')
            });
        }

    } else {
        throw createError('未知的Location');
    }

    return '正常Fulfill处理！';

}

function _scriptSelectShippingItem(so) {

    _log('_scriptSelectShippingItem');

    // TODO: 后台Debug 物流方式规则
    var shipItem = getNSShipItem(so, false, false);
    _log('shipItem', shipItem);
    if (shipItem == null) {
        // 如果没有找到和是的物流方式就 不生成 fulfillment， 生成了就代表 分配物流商成功了
        throw _createTaiwuFulfillException(4, '没有找到合适Shipping Item -- 未发现合适的物流方式');
    }

    //custbody_taiwu_carrier 物流商 -- SO fulfill时候会自动的带入Fulfillment record
    so.setFieldValue('custbody_sz_carrier', shipItem.custrecord_sz_sm_carrier);
    // custbody_ship_method_sz 物流方式 -- SO fulfill时候会自动的带入Fulfillment record
    so.setFieldValue('custbody_ship_method_sz', shipItem.custrecord_sz_rule_shippingmethod);

    return shipItem;

}

function _userSelectShippingItem(so) {
    _log('_userSelectShippingItem');
    var maxWeight = nlapiLookupField('customrecord_sz_shippingmethod', so.getFieldValue('custbody_ship_method_sz'), 'custrecord_sz_sm_max_weight');
    return {
        custrecord_sz_sm_max_weight: maxWeight,
        custrecord_sz_sm_carrier: so.getFieldValue('custbody_sz_carrier'),
        custrecord_sz_rule_shippingmethod: so.getFieldValue('custbody_ship_method_sz')
    };
}

//function _updateSOTracking(id) {
//
//    var salesOrderRecord = nlapiLoadRecord('salesorder', id);
//    var carrierId = search[i].getValue('custbody_sz_carrier');
//    var custbody_carrier_api_response = search[i].getValue('custbody_carrier_api_response');
//    custbody_carrier_api_response = JSON.parse(custbody_carrier_api_response);
//
//    if (carrierId == 1 || carrierId == 2) { // Yanwen
//        var jsonData = custbody_carrier_api_response;
//        if (custbody_carrier_api_response.CreateExpressResponseType.CallSuccess == "true") {
//            //"ReferenceNo": "RM123456789CN",
//            //    "YanwenNumber": "UR123456789YP",
//            salesOrderRecord.setFieldValue('custbody_carrier_shipment_number', jsonData.CreateExpressResponseType.CreatedExpress.YanwenNumber);
//            salesOrderRecord.setFieldValue('custbody_sz_carrier_trackingnumber', jsonData.CreateExpressResponseType.CreatedExpress.Epcode);
//        }
//    }
//
//    // 2016/8/18 取消Anjun 物流！
//    //else if (carrierId == 5) { // Anjun
//    //    var anjun = new Anjun();
//    //    anjun.newShipment(fulfillment.getId());
//    //}
//
//    else if (carrierId == 3 || carrierId == 4) { // APACShipping
//        var response = custbody_carrier_api_response;
//        // 返回的Tracking Number
//        salesOrderRecord.setFieldValue('custbody_sz_carrier_trackingnumber', response.Envelope.Body.AddAPACShippingPackageResponse.AddAPACShippingPackageResult.TrackCode);
//        // 物流商流水号
//        salesOrderRecord.setFieldValue('custbody_carrier_shipment_number', response.Envelope.Body.AddAPACShippingPackageResponse.AddAPACShippingPackageResult.InvocationID)
//    }
//
//    else if (carrierId == 6) { // Guoyang
//
//        var resbody = custbody_carrier_api_response;
//        var order = resbody.orderlist[0];
//        var custbody_ship_method_sz = shipmentInfo.getValue('custbody_ship_method_sz');
//        if (order.status == "1") {
//
//            if (custbody_ship_method_sz == '21') { // 平邮 荷兰
//                salesOrderRecord.setFieldValue('custbody_sz_carrier_trackingnumber', order.ordercode);
//                salesOrderRecord.setFieldValue('custbody_carrier_shipment_number', order.billid);
//            } else if (custbody_ship_method_sz == '20') { // 挂号 荷兰
//                salesOrderRecord.setFieldValue('custbody_sz_carrier_trackingnumber', order.billid);
//                salesOrderRecord.setFieldValue('custbody_carrier_shipment_number', order.ordercode);
//            } else {
//                salesOrderRecord.setFieldValue('custbody_sz_carrier_trackingnumber', order.ordercode);
//                salesOrderRecord.setFieldValue('custbody_carrier_shipment_number', order.billid);
//            }
//        }
//    }
//
//    nlapiSubmitRecord(salesOrderRecord, true);
//
//}
//shipstatus
//Item Fulfillment:Picked	 ItemShip:A
//Item Fulfillment:Packed	 ItemShip:B
//Item Fulfillment:Shipped	 ItemShip:C

function szFulfill(so_id, obj, isOverseaLocation) {

    var id = so_id;

    //if (!isOverseaLocation) {
    //    var trackno = nlapiLookupField('salesorder', id, 'custbody_sz_carrier_trackingnumber');
    //    if (!trackno) throw _createTaiwuFulfillException('没有跟踪代码， 暂时不能Fulfill');
    //}

    var existingFulfillmentSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', id),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);

    var fulfillment = null;
    var comment = '';
    if (existingFulfillmentSearch != null) {
        if (existingFulfillmentSearch.length == 1) {
            nlapiDeleteRecord('itemfulfillment', existingFulfillmentSearch[0].getId());
        } else {
            throw _createTaiwuFulfillException('咋整的，发现了好几个已经存在的Fulfillment 发货记录');
        }
    }

    try {

        // 太武国际包裹发货状态
        //分配物流商/物流方式 - 成功	1 ----------- 这个2个标记从SO 那边直接带过来的
        //分配物流商/物流方式 - 失败	2
        //获取物流商跟踪代码（包含交运）- 成功	3
        //获取物流商跟踪代码（包含交运）- 失败	4
        //已经打印主拣货单	5
        //主拣货单验证通过	6
        //已经打印面单	7
        //验证通过已经发货	8
        // Created in Packed	 	9

        // 因为是一个 Item一个Bin 所以是自动 config了 Inventory Detail 如果有2个Bin 的话， 需要脚本来写 TODO:
        fulfillment = nlapiTransformRecord('salesorder', so_id, 'itemfulfillment');

        fulfillment.setFieldValue('custbody_location', obj.location);
        if (isOverseaLocation) {

            // Bin
            if (obj.location == 36) { // FBA

                var count = fulfillment.getLineItemCount('item');
                if (count == 1) {

                    var binSearch = nlapiSearchRecord('item', null, [
                        new nlobjSearchFilter('internalid', null, 'is', fulfillment.getLineItemValue('item', 'item', 1)),
                        new nlobjSearchFilter('location', 'binonhand', 'is', obj.location),
                        new nlobjSearchFilter('quantityavailable', 'binonhand', 'greaterthan', 0)
                        // new nlobjSearchFilter('binnumber', 'binonhand', 'is', fulfillment.getLineItemValue('item', 'custcol_bin', 1))
                    ], [
                        new nlobjSearchColumn('location', 'binOnHand'),
                        new nlobjSearchColumn('quantityavailable', 'binOnHand')
                    ]);
                    if (binSearch != null && binSearch.length == 1 && parseFloat(binSearch[0].getValue('quantityavailable', 'binOnHand')) > parseFloat(fulfillment.getLineItemValue('item', 'quantity', 1))) {
                        // freestyle...
                        _log('freestyle of the item fulfillment from SO ' + so_id, so_id);
                    } else {
                        createItemInventoryDetail(fulfillment, count);
                    }

                } else {
                    createItemInventoryDetail(fulfillment, count);
                }

            }


            fulfillment.setFieldValue('shipstatus', 'C'); // Shipped
        } else {
            fulfillment.setFieldValue('shipstatus', 'B'); // Packed
        }

        fulfillment.setFieldValue('custbody_has_issues', 'F');
        fulfillment.setFieldValue('custbody_script_memo', '生成好了包裹记录！');
        fulfillment.setFieldValue('custbody_taiwu_fulfill_status_code', 12);

        comment = '新建包裹记录成功';
    } catch (e) {
        throw e;
    }

    var ffId = nlapiSubmitRecord(fulfillment, true);
    _log('Fulfillment has been submitted. ' + comment, ffId);

    // ~~~Fulfill OK
    // custbody_out_of_stock for true - 不用标志缺货
    //var so = nlapiLoadRecord('salesorder', id);
    //so.setFieldValue('custbody_taiwu_fulfill_status_code', '12');
    //so.setFieldValue('custbody_out_of_stock', 'F');
    //nlapiSubmitRecord(so, true);

    // ~~~Fulfill OK
    //nlapiSubmitField('salesorder', id, 'custbody_taiwu_fulfill_status_code', 12);
    // custbody_script_memo

    var so = nlapiLoadRecord('salesorder', id);
    so.setFieldValue('custbody_taiwu_fulfill_status_code', 12);
    so.setFieldValue('custbody_script_memo', '新建包裹记录成功');
    nlapiSubmitRecord(so, true);

    // --- 只能写在这里
    if (!isOverseaLocation) {

        // 更新面单信息
        var mapping = _getItemBinMapping(ffId);
        var ffRec = nlapiLoadRecord('itemfulfillment', ffId);
        var info = JSON.parse(ffRec.getFieldValue('custbody_shippinglabel_info'));
        info.items.forEach(function (item) {
            item.binnumber = mapping[item._id];
        });

        // E邮宝分拣码更新
        var isEPacket = nlapiLookupField('customrecord_sz_shippingmethod', ffRec.getFieldValue('custbody_ship_method_sz'), 'custrecord_is_epacket');
        if (isEPacket == 'T') {
            var ePackePickCode = getEPacketCode(ffRec.getFieldValue('shipcountry'), ffRec.getFieldValue('shipzip'));
            if (ePackePickCode == null) {
                ffRec.setFieldValue('custbody_tw_fulfillment_status', 19); // 包裹错误
                ffRec.setFieldValue('memo', 'ePacket 包裹 不过没有找到Pick Code，请注意！');
            } else {
                info.ePackePickCode = ePackePickCode;
                ffRec.setFieldValue('custbody_tw_fulfillment_status', 3); // 成功
                ffRec.setFieldValue('memo', 'ePacket 包裹 Pick Code 添加！');
            }
        }

        ffRec.setFieldValue('custbody_shippinglabel_info', JSON.stringify(info));
        nlapiSubmitRecord(ffRec, true);
    }


    return ffId;


}


function createItemInventoryDetail(fulfillment, count) {
    for (var linenum = 1; linenum <= count; linenum++) {

        var bin = fulfillment.getLineItemValue('item', 'custcol_bin', linenum);
        var quantity = fulfillment.getLineItemValue('item', 'quantity', linenum);

        _audit(fulfillment.getLineItemText('item', 'item', linenum),
            fulfillment.getLineItemText('item', 'custcol_bin', linenum) + ': ' + bin + ': ' + quantity);


        fulfillment.selectLineItem('item', linenum);
        // setCurrentLineItemValue(group, name, value)
        // fulfillment.setCurrentLineItemValue('item', 'itemreceive', 'T');
        // fulfillment.setCurrentLineItemValue('item', 'location', obj.location);

        var ifDetail = fulfillment.createCurrentLineItemSubrecord('item', 'inventorydetail');
        ifDetail.selectNewLineItem('inventoryassignment');
        //ifDetail.setCurrentLineItemValue('inventoryassignment', 'issueinventorynumber', 25); //lot number's Internal ID
        ifDetail.setCurrentLineItemValue('inventoryassignment', 'binnumber', bin); //bin number's Internal ID
        ifDetail.setCurrentLineItemValue('inventoryassignment', 'quantity', quantity);
        ifDetail.commitLineItem('inventoryassignment');
        ifDetail.commit();

        fulfillment.commitLineItem('item');
    }
}

function _getItemBinMapping(ffId) {
    var search = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('internalid', null, 'is', ffId),
        new nlobjSearchFilter('type', 'item', 'anyof', [
            'InvtPart', 'Kit'
        ]),
        // new nlobjSearchFilter('accounttype', null, 'is', 'COGS')
        new nlobjSearchFilter('accounttype', null, 'is', '@NONE@')
    ], [
        new nlobjSearchColumn('item'),
        new nlobjSearchColumn('quantity'),
        new nlobjSearchColumn('binnumber', 'inventoryDetail')
    ]);

    var mapping = {};
    search.forEach(function (searchResult, index) {
        var linenumber = index + 1;

        mapping[linenumber + '_' + searchResult.getValue('item')] = searchResult.getText('binnumber', 'inventoryDetail');
        //return {
        //    _id: linenumber + '_' + searchResult.getValue('item'),
        //    binnumber: searchResult.getText('binnumber', 'inventoryDetail')
        //}
    });

    return mapping;
}
function __closeSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'T');
    }
    nlapiSubmitRecord(soRec, true);
}

function __openSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'F');
    }
    nlapiSubmitRecord(soRec, true);
}

function _bill(so) {

    var id = so.getId();
    var existingInvoiceSearch = nlapiSearchRecord('invoice', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', so.getId()),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);
    if (existingInvoiceSearch != null) {
        if (existingInvoiceSearch.length == 1) {
            nlapiSubmitField('invoice', existingInvoiceSearch[0].getId(), 'custbody_taiwu_bill_status_code', '13', true);
            //nlapiDeleteRecord('invoice', existingInvoiceSearch[0].getId());
        } else {
            _log_email('Invoice的个数不是 1， 是' + existingInvoiceSearch.length, so.getId());
            return;
        }
    } else {

        var orderstatus = so.getFieldValue('orderstatus');
        if (orderstatus == 'H') {
            __openSORec(id);
            _bill2Invoice(id, so.getFieldValue('shippingcost'), so.getFieldValue('trandate'));
            __closeSORec(id)
        } else {
            _bill2Invoice(id, so.getFieldValue('shippingcost'), so.getFieldValue('trandate'));
        }

    }

}

/**
 * 注意这里再Bill 时候 调用 FulfillManagement 下面的 ue.bill.js 分配 AR 账户
 */
function _bill2Invoice(id, shippingcost, trandate) {

    // nlapiSetFieldValue('account', '1384'); // Ebay China Store - AR
    // In User Event

    //var id = so.getId();
    var invoice = nlapiTransformRecord('salesorder', id, 'invoice', {
        recordmode: 'dynamic',
        customform: 409
    });

    // 已经移动到User Event 里面
    //if (so.getFieldValue('custbody_marketplace') == MarketplaceShipName.eBay) {
    //    // 1384	Ebay China Store - AR
    //    invoice.setFieldValue('account', '1384');
    //}
    var custbody_paidtime = invoice.getFieldValue('custbody_paidtime');
    if (custbody_paidtime) {
        invoice.setFieldValue('trandate', nlapiDateToString(nlapiStringToDate(custbody_paidtime), 'date'));
    } else {
        invoice.setFieldValue('trandate', trandate);
    }

    //shippingcost
    if (shippingcost) {
        invoice.setFieldValue('shippingcost', shippingcost);
    }

    // 收款OK用 Invoice原生的状态来标识
    invoice.setFieldValue('custbody_taiwu_bill_status_code', '13'); // Bill OK
    invoice.setFieldValue('custbody_script_memo', 'Billed by script. 太武国际');
    nlapiSubmitRecord(invoice, true);
    _log('SO ' + id + ' has been billed.');
}

function _billFixSearch() {
    var s = nlapiSearchRecord(null, '1931'); // 假设fix的不会超过1000
    if (s != null) {
        var l = [];
        for (var j = 0, size = s.length; j < size; j++) {
            l.push(s[j].getId());
        }
        return l;
    }

    return [];


    //var lastId = 0;
    //var list = [];
    //
    //var count = 0;
    //do {
    //    count++;
    //    var search = nlapiLoadSearch(null, '1931');
    //    if (lastId) {
    //        filter.push(new nlobjSearchFilter('internalidnumber', null, 'greaterthan', lastId));
    //    }
    //
    //    var search = nlapiSearchRecord('salesorder', null, filter, columns);
    //
    //    if (search != null) {
    //        for (var i = 0, len = search.length; i < len; i++) {
    //            list.push(search[i].getId());
    //        }
    //        lastId = search[search.length - 1].getId();
    //    }
    //} while (search != null && search.length == 1000);
    //
    //return list;
}

function searchBillList() {

    if (deploymentId == 'customdeploy_sz_batchbill_fix') { // Bill fix
        var pendingBillingList = _billFixSearch(); // 专注所有Pending Billing的SO

        // Diff for Closed/Cancelled SO's invoices - both are start of last month
        var diff1 = nlapiLoadSearch(null, 2445).runSearch().getResults(0, 1000).map(function (sr) {
            return sr.getId();
        });
        var diff2 = nlapiLoadSearch(null, 2446).runSearch().getResults(0, 1000).map(function (sr) {
            return sr.getValue('internalid', 'createdfrom');
        });
        var diff = diff1.diff(diff2);
        _audit('diff', diff);
        //_log_email('Diff results', JSON.stringify(diff, null, 2));
        return pendingBillingList.concat(diff);

        // 这个search不行， 始终有问题你。。。F**K
        //var search2 = nlapiLoadSearch(null, 2447);
        //var col = search2.getColumns();
        //return pendingBillingList.concat(search2.runSearch().getResults(0, 1000).map(function (sr) {
        //    return sr.getValue(col[0]);
        //}));

    } else { // 正规Bill

        var columns = [
            new nlobjSearchColumn('custbody_marketplace'),
            new nlobjSearchColumn('internalid').setSort(),
            new nlobjSearchColumn('datecreated') //.setSort()
        ];

        var filter = [

            new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
            new nlobjSearchFilter('mainline', null, 'is', 'T'),
            new nlobjSearchFilter('trandate', null, 'before', 'threeDaysAgo'),
            new nlobjSearchFilter('custbody_manually_payment_hold', null, 'is', 'F'),
            new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
                MarketplaceShipName.eBay
            ]),
            new nlobjSearchFilter('custbody_delay_bill', null, 'is', 'F'),
            new nlobjSearchFilter('status', null, 'anyof', [
                'SalesOrd:E', // Sales Order:Partially Fulfilled	 SalesOrd:D
                'SalesOrd:D', // Sales Order:Pending Billing/Partially Fulfilled	 SalesOrd:E
                'SalesOrd:B' // Pending Fulfillment
                //'SalesOrd:F' // Sales Order:Pending Billing	 SalesOrd:F
            ]),

            new nlobjSearchFilter('custbody_taiwu_bill_status_code', null, 'noneof', '13')

        ];
        // filter.push(new nlobjSearchFilter('custbody_taiwu_bill_status_code', null, 'noneof', '13')); // 不是 BILL OK 的

        var lastId = 0;
        var list = [];

        var count = 0;
        do {
            count++;
            if (lastId) {
                filter.push(new nlobjSearchFilter('internalidnumber', null, 'greaterthan', lastId));
            }

            var search = nlapiSearchRecord('salesorder', null, filter, columns);

            if (search != null) {
                for (var i = 0, len = search.length; i < len; i++) {
                    list.push(search[i].getId());
                }
                lastId = search[search.length - 1].getId();
            }

            //if (count == 10) break; // : 每次处理 2000 条 -- Usage 之后会自动的腾出来 给其他的， 需要review

        } while (search != null && search.length == 1000);

        _audit('list total size', list.length);


        var search2 = nlapiSearchRecord('salesorder', null, [

            new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
            new nlobjSearchFilter('mainline', null, 'is', 'T'),
            // new nlobjSearchFilter('trandate', null, 'before', 'threeDaysAgo'),
            new nlobjSearchFilter('custbody_manually_payment_hold', null, 'is', 'F'),
            new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
                MarketplaceShipName.eBay
            ]),
            new nlobjSearchFilter('custbody_delay_bill', null, 'is', 'F'),
            new nlobjSearchFilter('status', null, 'anyof', [
                //'SalesOrd:E', // Sales Order:Partially Fulfilled	 SalesOrd:D
                //'SalesOrd:D', // Sales Order:Pending Billing/Partially Fulfilled	 SalesOrd:E
                //'SalesOrd:B', // Pending Fulfillment
                'SalesOrd:F' // Sales Order:Pending Billing	 SalesOrd:F
            ]),

            new nlobjSearchFilter('custbody_taiwu_bill_status_code', null, 'noneof', '13')

        ], columns);

        if (search2 != null) {
            _log('search2 size', search2.length);
            for (var a = 0; a < search2.length; a++) {
                list.push(search2[a].getId());
            }
        }

        return list;
    }

}

function _fulfillCheck() {

    var lastId = 0;
    var list = [];

    var columns = [
        new nlobjSearchColumn('custbody_marketplace'),
        new nlobjSearchColumn('internalid').setSort(),
        new nlobjSearchColumn('datecreated') //.setSort()
    ];

    do {

        var search = null;

        var filter = [];

        if (lastId) {
            filter.push(new nlobjSearchFilter('internalidnumber', null, 'greaterthan', lastId));
        }

        search = nlapiSearchRecord('salesorder', null,
            filter.concat([
                new nlobjSearchFilter('subsidiary', null, 'is', '3'),
                new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'is', '12'), // FF OK

                new nlobjSearchFilter('status', null, 'anyof', [
                    'SalesOrd:A', // Pending Approval
                    'SalesOrd:B', // Pending Fulfillment
                    'SalesOrd:D', // 部分Fulfill
                    'SalesOrd:E'
                ]),
                new nlobjSearchFilter('mainline', null, 'is', 'T'),
                new nlobjSearchFilter('custbody_manually_payment_hold', null, 'is', 'F'),
                new nlobjSearchFilter('custbody_delay_fulfill', null, 'is', 'F'),

                new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
                    MarketplaceShipName.eBay,
                    MarketplaceShipName.Amazon,
                    MarketplaceShipName.AliExpress,
                    MarketplaceShipName.Wish,
                    22 // 分销
                ])


            ]),
            columns);

        if (search != null) {
            for (var i = 0, len = search.length; i < len; i++) {
                list.push(search[i].getId());
            }
            lastId = search[search.length - 1].getId();
        }

    } while (search != null && search.length == 1000);

    _log('list size: ', list.length);

    // :
    list = list.slice(0, 100);
    var plist = [];
    if (list.length) {
        for (var j = 0, size = list.length; j < size; j++) {
            var soId = list[j];
            var ffSearch = nlapiSearchRecord('itemfulfillment', null, [new nlobjSearchFilter('createdfrom', null, 'is', soId)]);
            if (ffSearch == null) {

                var so = nlapiLoadRecord('salesorder', soId);
                so.setFieldValue('custbody_taiwu_fulfill_status_code', 8);
                // so.setFieldValue('custbody_script_memo', '未找到包裹记录需要重新处理');
                nlapiSubmitRecord(so, true);

                plist.push(soId + ' - ' + so.getFieldText('custbody_marketplace'));
            }
        }
    }
    _log_email('重新标志了 ' + plist.length + ' 个包裹， 需要进行重新处理，请注意！', JSON.stringify(plist, null, 2));

}

function _dealFulfill() {

    var lastId = 0;
    var list = [];

    var columns = [
        new nlobjSearchColumn('entity'),
        new nlobjSearchColumn('custbody_order_type'),

        new nlobjSearchColumn('location'),
        new nlobjSearchColumn('currency'),
        new nlobjSearchColumn('shipaddress'),

        new nlobjSearchColumn('custbody_automated_processed'),
        new nlobjSearchColumn('custbody_marketplace'),
        new nlobjSearchColumn('internalid').setSort(),
        new nlobjSearchColumn('datecreated') //.setSort()
    ];

    var P = new Profiling();

    do {

        var search = null;

        var filter = [];

        if (deploymentId == 'customdeploy_sz_batchfulfill') {
            filter = [
                new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
                new nlobjSearchFilter('custbody_automated_processed', null, 'is', 'F')
                //new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'is', '@NONE@'),
                //new nlobjSearchFilter('custbody_tw_fulfillment_status', null, 'is', '@NONE@'),
            ];
        }

        // 有个问题， 如果产品本身缺货， 第一次物流对接不能成功的话， 以后第二次进来检查还是缺货的话， 还是对接物流不成功
        else if (deploymentId == 'customdeploy_sz_batchfulfill_fix') { //
            filter = [
                new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
                new nlobjSearchFilter('custbody_out_of_stock', null, 'is', 'F'),
                new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'noneof', [
                    // '@NONE@',
                    2, // Location 不同
                    5, // 太重了
                    12 // Fulfill OK
                ]),
                new nlobjSearchFilter('custbody_automated_processed', null, 'is', 'T'),
                new nlobjSearchFilter('location', null, 'anyof', [34, 35]) // ：本地仓
            ];
        }

        else if (deploymentId == 'customdeploy_sz_batchfulfill_backorder') { //
            filter = [
                new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
                new nlobjSearchFilter('custbody_out_of_stock', null, 'is', 'T'),
                new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'noneof', [
                    //'@NONE@',
                    2, // Location 不同
                    5, // 太重了
                    12 // Fulfill OK
                ]),
                new nlobjSearchFilter('custbody_automated_processed', null, 'is', 'T')
            ];
        }

        else if (deploymentId == 'customdeploy_sz_batchfulfill_haiwai') { //
            filter = [
                new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
                new nlobjSearchFilter('custbody_out_of_stock', null, 'is', 'F'),
                new nlobjSearchFilter('custbody_taiwu_fulfill_status_code', null, 'noneof', [
                    '@NONE@',
                    2, // Location 不同
                    5, // 太重了
                    12 // Fulfill OK
                ]),
                new nlobjSearchFilter('custbody_automated_processed', null, 'is', 'T'),
                new nlobjSearchFilter('location', null, 'anyof', [73, 84, 85, 86]) //
            ];
        }

        else {
            _log_email('No the deployment id...');
            return;
        }

        if (lastId) {
            filter.push(new nlobjSearchFilter('internalidnumber', null, 'greaterthan', lastId));
        }

        if (deploymentId == 'customdeploy_sz_batchfulfill_haiwai') {
            // 无时间限制
        } else {
            //new nlobjSearchFilter('trandate', null, 'after', 'thirtydaysago'),
            filter.push(new nlobjSearchFilter('trandate', null, 'after', 'weekbeforelasttodate'));
        }

        search = nlapiSearchRecord('salesorder', null,
            filter.concat([
                new nlobjSearchFilter('status', null, 'anyof', [
                    //'SalesOrd:A', // Pending Approval
                    'SalesOrd:B', // Pending Fulfillment
                    'SalesOrd:D'  // 部分Fulfill
                ]),
                new nlobjSearchFilter('mainline', null, 'is', 'T'),
                new nlobjSearchFilter('custbody_delay_fulfill', null, 'is', 'F'),
                new nlobjSearchFilter('custbody_marketplace', null, 'anyof', [
                    MarketplaceShipName.eBay,
                    MarketplaceShipName.Amazon,
                    MarketplaceShipName.AliExpress,
                    MarketplaceShipName.Wish,
                    22 // 分销
                ])
            ]),
            columns);

        if (search != null) {
            for (var i = 0, len = search.length; i < len; i++) {
                list.push({
                    id: search[i].getId(),
                    market: search[i].getValue('custbody_marketplace'),

                    name: search[i].getValue('entity'),
                    location: search[i].getValue('location'),
                    currency: search[i].getValue('currency'),
                    shipaddress: search[i].getValue('shipaddress'),

                    custbody_order_type: search[i].getValue('custbody_order_type'),
                    custbody_automated_processed: search[i].getValue('custbody_automated_processed')
                });
            }
            lastId = search[search.length - 1].getId();
        }

    } while (search != null && search.length == 1000);

    // list 把这里面Wish 有重复Customer挑出来， 手动的合单处理Fulfill

    var fulList = [], mergeList = [], nonMergeList = [];

    // :
    mergeList = list.filter(function (item) {
        return item.market == MarketplaceShipName.Wish || item.market == MarketplaceShipName.eBay;
    });
    var mergeListCustomer = mergeList.map(function (item) {
        // Setp1: 过滤条件
        return item.name + item.location + item.currency + item.shipaddress;
    });

    // 过滤下
    var mergeListSameCustomer = mergeListCustomer.filter(function (item, pos) {
        return mergeListCustomer.indexOf(item) != pos;
    });
    mergeListSameCustomer = mergeListSameCustomer.unique();

    var needMerges = mergeList.filter(function (item) {
        // Setp2: 过滤条件 -- 再次过滤 和Step1 条件一致。
        return mergeListSameCustomer.indexOf(item.name + item.location + item.currency + item.shipaddress) != -1 && item.custbody_order_type == 1 && item.custbody_automated_processed == 'F'; // 1. 正常单
    });
    if (needMerges.length) { // 先变成Pending Approval 然后合单处理。。。
        needMerges.forEach(function (item) {
            nlapiSubmitField('salesorder', item.id, 'orderstatus', 'A', true);
        });
        // _log_email('Wish 需要合并客人的List - for keep eyes', JSON.stringify(wishMerges, null, 2));
    }

    //nonWishList = list.filter(function (item) {
    //    return item.market != MarketplaceShipName.Wish;
    //});

    fulList = list;
    //fulList = fulList.concat(nonWishList);

    var fulfillList = [];
    if (fulList.length) {
        var size = fulList.length;
        _audit('FULFILL SIZE: ' + size, JSON.stringify(fulList.map(function (item) {
            return item.id;
        })));
        var j = 0;
        for (; j < size; j++) {
            fulfillList.push(_processSalesOrderFulfill(fulList[j].id));
            checkGovernance(); // 都用这个吧
        }

    }

    //else {
    //    _log_email('太武国际 No search order to process.')
    //}

    if (size > 1200) {
        _log_email(size + '/' + fulfillList.length + ' - time: ' + P.end(), JSON.stringify(fulfillList, null, 2));
    } else {
        _log(size + '/' + fulfillList.length + ' - time: ' + P.end(), JSON.stringify(fulfillList, null, 2));
    }

    if (deploymentId == 'customdeploy_sz_batchfulfill_haiwai') {
        _log_email(size + '/' + fulfillList.length + ' - time: ' + P.end(), JSON.stringify(fulfillList, null, 2));
    }
    // P.end('Size: ' + size + '/' + processedList.length + deploymentId + '\r\n' + JSON.stringify(processedList, null, 2), true);
}

/**
 * 深圳用
 * Fulfill 脚本是闸口， 后面所有的记录从这里放出
 */
function run() {

    try {


        var search = null;
        var size = 0;

        var columns = [
            new nlobjSearchColumn('custbody_marketplace'),
            new nlobjSearchColumn('internalid').setSort(),
            new nlobjSearchColumn('datecreated') //.setSort()
        ];

        // BILL 用
        if ([
                'customdeploy_sz_batchbill',
                'customdeploy_sz_batchbill_fix'
            ].indexOf(deploymentId) != -1) { // Bill 找推迟一个小时的PP 单， 如果有PP 有记录那么就 Bill 结算

            var billList = searchBillList();

            if (billList.length) {
                var i = 0, len = billList.length;
                var billListReport = [];
                size = len;

                _audit('太武国际 Pending bill process sales order size is', len);

                for (; i < len; i++) {
                    var id = billList[i];
                    _log('第' + (i + 1) + '个', id);
                    billListReport.push(_processSalesOrderBill(id));
                    checkGovernance(); // 都用这个吧 TODO: 以后可以考虑先用Chuck array 循环中
                }

                _log('Ebay SO bill to invoice report. size: ' + billListReport.length, JSON.stringify(billListReport, null, 2));

            } else {
                _log('太武国际 No billList to process.')
            }

        }

        // FULFILL用
        else if ([

                // Scheduled
                'customdeploy_sz_batchfulfill',
                'customdeploy_sz_batchfulfill_fix',
                'customdeploy_sz_batchfulfill_backorder',
                'customdeploy_sz_batchfulfill_haiwai',

                // debug or test
                'customdeploy_sz_batchfulfill_debug'
            ].indexOf(deploymentId) != -1) { // Fulfill

            _dealFulfill();

        }

        else if (deploymentId == 'customdeploy_sz_batchfulfill_check') {
            _fulfillCheck()
        }

        else {
            _log_email('没有这个配置啊', deploymentId);
        }


    } catch (e) {
        processException(e, 'Out side Error');
    }

    _log('Batch fulfill and bill script end.', deploymentId)
}
