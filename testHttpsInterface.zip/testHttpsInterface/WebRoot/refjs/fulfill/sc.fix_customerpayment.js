function run() {

    // customsearch1122
    var search = nlapiLoadSearch(null, 'customsearch1122');
    var resultSet = search.runSearch();
    var searchResults = resultSet.getResults(0, 1000);
    _log('searchResults size', searchResults.length);

    for (var i = 0, len = searchResults.length; i < len; i++) {
        var searchResult = searchResults[i];

        var rec = nlapiLoadRecord(searchResult.getRecordType(), searchResult.getId());
        var arAccount = rec.getFieldValue('aracct');

        if (arAccount) {

            // 要和  SSUtils 这里对应哦
            if ([
                    // Ebay系列
                    1127,
                    1190,
                    1192,
                    1193,

                    1151, // HB

                    //Three storefronts still need to have payment applied to their individual cash account:
                    //1) Newegg: “Newegg Cash Account”
                    //2) 3Btech.net: paypal@3btech.net
                    //3) Buy.com/Rakuten: “Buy.com Cash Account”
                    1128, // Newegg
                    1130, // 3BTech
                    1129 // Buy.com/Rakuten

                ].contains(arAccount)) {
                var paymentAccount = nlapiLookupField('account', arAccount, 'custrecord_ar_linked_payment_account');

                _log('paymentAccount', paymentAccount);
                if (paymentAccount) {


                    rec.setFieldValue('undepfunds', 'F');
                    rec.setFieldValue('account', paymentAccount);
                    nlapiSubmitRecord(rec, true);

                    _audit('AccountChanged', searchResult.getId());
                }
            }


        }

        checkGovernance();
    }


}