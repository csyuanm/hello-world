function run() {
    ePacketFix();
    //guoyangFix();
}

function ePacketFix() {

    var search = nlapiSearchRecord(null, '1795');

    if (search != null) {
        for (var i = 0; i < search.length; i++) {
            // if (i == 1) break;
            _log('Search Result', search[i].getId());
            var fulSR = search[i];

            //_log('getDeploymentId', nlapiGetContext().getDeploymentId());

            //var oldRec = nlapiGetOldRecord();
            //if (oldRec.getFieldValue('subsidiary') == Subsidiaries.TaiwuInternational) {
            //
            var soid = fulSR.getValue('createdfrom');

            //
            //}

            nlapiDeleteRecord('itemfulfillment', fulSR.getId());

            var soRec = nlapiLoadRecord('salesorder', soid);
            soRec.setFieldValue("custbody_taiwu_fulfill_status_code", 8);
            soRec.setFieldValue("memo", '包裹被删除！ - EPacket 需要重新的处理一下');
            nlapiSubmitRecord(soRec);

            checkGovernance();
        }
    }


    //var search = nlapiSearchRecord(null, '1791');
    //if (search != null) {
    //    for (var i = 0; i < search.length; i++) {
    //         if (i == 1) break;
    //        var soSR = search[i];
    //        _log('SOID', soSR.getId());
    //        var so = nlapiLoadRecord('salesorder', soSR.getId());
    //        so.setFieldValue('custbody_sz_carrier', '');
    //        so.setFieldValue('custbody_ship_method_sz', '');
    //        so.setFieldValue('custbody_sz_carrier_trackingnumber', '');
    //        so.setFieldValue('custbody_carrier_shipment_number', '');
    //
    //        so.setFieldValue('custbody_taiwu_fulfill_status_code', 8);
    //        so.setFieldValue('custbody_tw_fulfillment_status', 12);
    //
    //        nlapiSubmitRecord(so, true);
    //        var ful = nlapiSearchRecord('itemfulfillment', null, [
    //            new nlobjSearchFilter('createdfrom', null, 'is', so.getId()),
    //            new nlobjSearchFilter('mainline', null, 'is', 'T')
    //        ]);
    //        if (ful != null) {
    //            ful.forEach(function (fulSR) {
    //                nlapiDeleteRecord('itemfulfillment', fulSR.getId());
    //            });
    //        }
    //    }
    //}

}


// 更新SO 上面缺失的tracking number, 然后再同步到Fulfillment 上面


// 国洋荷兰挂号修复 -- on Fulfillment
function guoyangFix() {

    var search = nlapiSearchRecord(null, '1689');
    if (search != null) {

        _log('start....');
        for (var i = 0; i < search.length; i++) {

            //  if (i == 1) break;

            _log(i, search[i].getId());
            var searchResult = search[i];


            var so = nlapiLoadRecord('salesorder', searchResult.getId());

            var shipmentNumber = searchResult.getValue('custbody_carrier_shipment_number');
            var trackingNumber = searchResult.getValue('custbody_sz_carrier_trackingnumber');

            so.setFieldValue('custbody_sz_carrier_trackingnumber', shipmentNumber);
            so.setFieldValue('custbody_carrier_shipment_number', trackingNumber);

            var info = so.getFieldValue('custbody_shippinglabel_info');
            info = JSON.parse(info);
            info.tracking_number = shipmentNumber;

            so.setFieldValue('custbody_shippinglabel_info', JSON.stringify(info));

            nlapiSubmitRecord(so, true);


            var ful = nlapiSearchRecord('itemfulfillment', null, [
                new nlobjSearchFilter('createdfrom', null, 'is', searchResult.getId())
            ]);

            if (ful != null) {
                if (ful.length == 1) {
                    var ffSR = ful[0];
                    var ffRec = nlapiLoadRecord('itemfulfillment', ffSR.getId());
                    ffRec.setFieldValue('custbody_sz_carrier_trackingnumber', shipmentNumber);
                    ffRec.setFieldValue('custbody_carrier_shipment_number', trackingNumber);

                    var info = ffRec.getFieldValue('custbody_shippinglabel_info');
                    info = JSON.parse(info);
                    info.tracking_number = shipmentNumber;

                    ffRec.setFieldValue('custbody_shippinglabel_info', JSON.stringify(info));
                    nlapiSubmitRecord(ffRec, true);
                }
                //ful.forEach(function (ffSR) {
                //
                //
                //
                //})
            }

            checkGovernance();

        }
    }
}