var ITEM_TYPE = {

    //KIT: {
    //    name: 'Kit',
    //    type: 'kititem'
    //},
    //INVT_PART: {
    //    name: 'InvtPart',
    //    type: 'inventoryitem'
    //},

    Kit: 'kititem',
    InvtPart: 'inventoryitem'
};

function getNSShipItem(so, ignoreCheck, __debug) {

    var iteminfo = [];
    var linecount = so.getLineItemCount('item');
    var alltags = [];
    for (var line = 1; line <= linecount; line++) {

        var itemid = so.getLineItemValue('item', 'item', line);
        var itemtype = so.getLineItemValue('item', 'itemtype', line);
        var isclosed = so.getLineItemValue('item', 'isclosed', line);

        if (isclosed == 'T') continue;

        if (itemtype == 'Kit' || itemtype == 'InvtPart') {
            var tags = nlapiLookupField(ITEM_TYPE[itemtype], itemid, 'custitem_sz_item_tags');
            if (tags) {
                tags = tags.split(",");
                alltags = alltags.concat(tags);
            }

            iteminfo.push({
                location: so.getLineItemValue('item', 'location', line),
                quantity: so.getLineItemValue('item', 'quantity', line),
                custcol_item_weight: so.getLineItemValue('item', 'custcol_item_weight', line),
                //custcol_weightunit: so.getLineItemValue('item', 'custcol_weightunit', line),
                tags: tags
            })

        }


    }
    //_log('iteminfo', iteminfo);
    //_log('alltags', alltags);

    if (!ignoreCheck) {
        if (!allTheSame(iteminfo.map(function (item) {
                return item.location;
            }))) {
            throw _createTaiwuFulfillException(2, " Line Item 在不同的Warehouse 里面， 请注意， 可能需要拆单。");
        }
    }


    //var totalWeight = 0;
    //iteminfo.forEach(function (item) {
    //    totalWeight += parseInt(item.quantity) * parseFloat(item.custcol_item_weight);
    //});
    //
    //// 1 lb = 453.59237 克
    //if (iteminfo[0].custcol_weightunit == 'lb') {
    //    totalWeight = 453.59237 * parseFloat(totalWeight)
    //}
    //totalWeight = _mathround(totalWeight);

    var totalWeight = so.getFieldValue('custbody_total_weight');
    totalWeight = parseFloat(totalWeight);

    if (!so.getFieldValue('location')) {
        throw _createTaiwuFulfillException(16, " SO 需要在Mainline or Line item 上面设置Location！");
    }

    // 第一步 根据Location 来确定 Shipping Rules
    var shipItemRuleSearch = nlapiSearchRecord('customrecord_sz_shipping_rule', null, [
        // new nlobjSearchFilter('custrecord_sz_rule_location', null, 'is', so.getFieldValue('location')),
        new nlobjSearchFilter('isinactive', null, 'is', 'F')
    ], [
        // 按照物流规则record 的优先级来输出
        new nlobjSearchColumn('custrecord_sz_rule_priority').setSort(),

        //new nlobjSearchColumn('custrecord_sz_sm_carrier', 'custrecord_sz_rule_shippingmethod'),
        //new nlobjSearchColumn('custrecord_sz_sm_ns_shippingitem', 'custrecord_sz_rule_shippingmethod'),
        new nlobjSearchColumn('custrecord_sz_rule_shippingmethod'),
        new nlobjSearchColumn('name'),

        // 规则 Here
        new nlobjSearchColumn('custrecord_sz_rule_ea_register_country'),
        //new nlobjSearchColumn('custrecord_ebay_cs_country_code', 'custrecord_sz_rule_dest_country'),
        new nlobjSearchColumn('custrecord_sz_rule_destination_country'),

        new nlobjSearchColumn('custrecord_sz_rule_tags'),
        new nlobjSearchColumn('custrecord_sz_rule_total_weight'),
        new nlobjSearchColumn('custrecord_sz_rule_total_amount'),

        new nlobjSearchColumn('custrecord_sz_sm_carrier', 'custrecord_sz_rule_shippingmethod'),
        new nlobjSearchColumn('custrecord_sz_sm_max_weight', 'custrecord_sz_rule_shippingmethod'),

        new nlobjSearchColumn('custrecord_sz_rule_marketplace'),
        new nlobjSearchColumn('custrecord_sz_rule_amazon_accounts'),
        new nlobjSearchColumn('custrecord_sz_rule_ebay_accounts'),
        new nlobjSearchColumn('custrecord_sz_rule_ali_shipping_type'),

        new nlobjSearchColumn('custrecord_sz_rule_location')
    ]);

    if (shipItemRuleSearch != null) {
        shipItemRuleSearch = shipItemRuleSearch.map(function (searchResult) {

            var szTagsArray = [];
            var szTags = searchResult.getValue('custrecord_sz_rule_tags');
            if (szTags) {
                szTagsArray = szTags.split(',')
            }

            return {

                id: searchResult.getId(),
                name: searchResult.getValue('name'),

                custrecord_sz_rule_location: searchResult.getValue('custrecord_sz_rule_location'),
                custrecord_sz_rule_priority: searchResult.getValue('custrecord_sz_rule_priority'),

                //custrecord_sz_sm_carrier: searchResult.getValue('custrecord_sz_sm_carrier', 'custrecord_sz_rule_shippingmethod'),
                //custrecord_sz_sm_ns_shippingitem: searchResult.getValue('custrecord_sz_sm_ns_shippingitem', 'custrecord_sz_rule_shippingmethod'), // 原生的NS Ship Item
                custrecord_sz_rule_shippingmethod: searchResult.getValue('custrecord_sz_rule_shippingmethod'), // Custom Ship Item

                // eBay 注册国家
                custrecord_sz_rule_ea_register_country: searchResult.getValue('custrecord_sz_rule_ea_register_country'),

                // Legacy Ebay 目的地国家
                //custrecord_sz_rule_dest_country: searchResult.getValue('custrecord_ebay_cs_country_code', 'custrecord_sz_rule_dest_country'),
                custrecord_sz_rule_destination_country: searchResult.getText('custrecord_sz_rule_destination_country'),

                custrecord_sz_rule_marketplace: searchResult.getValue('custrecord_sz_rule_marketplace'),
                custrecord_sz_rule_amazon_accounts: searchResult.getValue('custrecord_sz_rule_amazon_accounts'),
                custrecord_sz_rule_ebay_accounts: searchResult.getValue('custrecord_sz_rule_ebay_accounts'),
                custrecord_sz_rule_ali_shipping_type: searchResult.getValue('custrecord_sz_rule_ali_shipping_type'),

                custrecord_sz_rule_tags: szTagsArray,
                custrecord_sz_rule_total_weight: searchResult.getValue('custrecord_sz_rule_total_weight'),
                custrecord_sz_rule_total_amount: searchResult.getValue('custrecord_sz_rule_total_amount'),

                custrecord_sz_sm_carrier: searchResult.getValue('custrecord_sz_sm_carrier', 'custrecord_sz_rule_shippingmethod'),
                custrecord_sz_sm_max_weight: searchResult.getValue('custrecord_sz_sm_max_weight', 'custrecord_sz_rule_shippingmethod')

            };
        });

        var destCountry = so.getFieldValue('shipcountry'); // US/HK 两个字母的国家Code

        // alltags
        // totalWeight
        //var total = so.getFieldValue('total');
        //total = parseFloat(total);

        // custbody_ebay_so_total
        //var total = parseFloat(so.getFieldValue('custbody_ebay_so_total')); // 美金！
        var total = parseFloat(so.getFieldValue('custbody_us_dollar_total')); // 美金！

        if (!ignoreCheck) {
            if (!total) {
                throw _createTaiwuBillException(14, 'No US dollar in here!');
            }
        }

        var location = so.getFieldValue('location');
        var soMarketplace = so.getFieldValue('custbody_marketplace');

        // 开始匹配每一条规则， 有一个OK 就Return
        for (var i = 0; i < shipItemRuleSearch.length; i++) {
            var shipItemRule = shipItemRuleSearch[i];

            // : 需要debug 的时候开启这个
            if (__debug === true) {
                _log('shipItemRule 优先级: ' + shipItemRule.custrecord_sz_rule_priority, shipItemRule);
            }


            var ruleDestCountry = shipItemRule.custrecord_sz_rule_destination_country;
            var ruleLocation = shipItemRule.custrecord_sz_rule_location;

            // 分不开 用indexof
            // if (ruleDestCountry) ruleDestCountry = ruleDestCountry.split('\u0005');
            // if (ruleDestCountry) ruleDestCountry = ruleDestCountry.split(',');

            //if (soMarketplace == MarketplaceShipName.eBay) {
            //    var custrecord_sz_rule_dest_country = shipItemRule.custrecord_sz_rule_dest_country;
            //    ruleDestCountry = custrecord_sz_rule_dest_country;
            //    if (ruleDestCountry) {
            //        ruleDestCountry = [ruleDestCountry];
            //    }
            //}


            var _commonCheck = _commonRule(shipItemRule,
                ruleDestCountry, destCountry,
                ruleLocation, location,
                alltags,
                totalWeight,
                total,
                soMarketplace);
            //_log('_commonCheck', _commonCheck);

            if (soMarketplace == MarketplaceShipName.eBay) {
                // 订单上面的属性
                var registered_county = nlapiLookupField('customrecord_ebay_account', so.getFieldValue('custbody_linked_ebay_account'), 'custrecord_ea_registered_county');
                var ebayAccount = so.getFieldValue('custbody_linked_ebay_account');

                var ebaycheck1 = _rule5(shipItemRule.custrecord_sz_rule_ea_register_country, registered_county);
                var ebaycheck2 = _rule5(shipItemRule.custrecord_sz_rule_ebay_accounts, ebayAccount);
                //_log('ebaycheck1', ebaycheck1);
                //_log('ebaycheck2', ebaycheck2);

                if (_commonCheck &&
                    ebaycheck1 &&
                    ebaycheck2) {

                    return shipItemRule;
                }
            } else if (soMarketplace == MarketplaceShipName.Amazon) {
                var amazonAccount = so.getFieldValue('custbody_orderfrom');

                var amazoncheck = _rule5(shipItemRule.custrecord_sz_rule_amazon_accounts, amazonAccount);
                //_log('amazoncheck', amazoncheck);

                if (_commonCheck &&
                    amazoncheck) {

                    return shipItemRule;
                }
            } else if (soMarketplace == MarketplaceShipName.AliExpress) {

                var aliShippingType = so.getFieldValue('custbody_zake_alilogistictype');
                var aliCheck = _rule6(shipItemRule.custrecord_sz_rule_ali_shipping_type, aliShippingType);
                //_log('aliCheck', aliCheck);

                if (_commonCheck &&
                    aliCheck) {
                    return shipItemRule;
                }

            } else {
                if (_commonCheck) {
                    return shipItemRule;
                }
                //if (_commonRule(shipItemRule, ruleDestCountry, destCountry, alltags, totalWeight, total)) {
                //    return shipItemRule;
                //}
            }

        }
    }


    return null;

}


function _rule1(a, b) {
    //_log('_rule1', arguments);
    if (a) {
        return b == a;
    } else {
        return true;
    }
}


function _rule2(ruleTags, itemtags) {
    //_log('_rule2', arguments);
    if (ruleTags.length) {
        if (itemtags.length) {
            for (var i = 0; i < itemtags.length; i++) {
                var itemtag = itemtags[i];
                if (ruleTags.contains(itemtag)) {
                    return true;
                }
            }

            return false;

        } else {
            return false;
        }
    } else {
        return true;
    }

}

// {"0":">=5","1":40.35}
// http://tool.chinaz.com/tools/unicode.aspx
function _verifyNumericRule(numericRule, value) {
    var limitValue = numericRule.replace(/\D/g, '');
    limitValue = parseFloat(limitValue);
    var numericOperator = numericRule.replace(limitValue, '');

    //_log('numericOperator --- ' + typeof numericOperator, numericOperator);
    //_log('value == ' + typeof value, value);
    //_log('limitValue == ' + typeof limitValue, limitValue);

    if (numericOperator == '\u0026\u006c\u0074\u003b') {
        return value < limitValue;
    }
    else if (numericOperator == '\u0026\u006c\u0074\u003b\u003d') {
        return value <= limitValue;
    }
    else if (numericOperator == '\u003d' || numericOperator == '') {
        return value == limitValue;
    }
    else if (numericOperator == '\u0026\u0067\u0074\u003b') {
        return value > limitValue;
    }
    else if (numericOperator == '\u0026\u0067\u0074\u003b\u003d') {
        return value >= limitValue;
    }
    else {
        //_log('不可能');
        return false;
    }

    //switch (numericOperator) {
    //    case '<':
    //        return value < limitValue;
    //    case '<=':
    //        return value <= limitValue;
    //    case '=':
    //    case '':
    //        return value == limitValue;
    //    case '>':
    //        return value > limitValue;
    //    case '>=':
    //        return value >= limitValue;
    //    default :
    //       //_log('Default!');
    //        return false;
    //}
}

function _rule3(weightRule, totalWeight) {
    //_log('_rule3', arguments);
    if (weightRule) {
        return _verifyNumericRule(weightRule, totalWeight);

    } else {
        return true;
    }
}

function _rule4(arrayRule, value) {
    //_log('_rule4', arguments);
    if (arrayRule && Array.isArray(arrayRule) && arrayRule.length) {
        return arrayRule.contains(value);
    }

    return true;
}


function _rule5(nativeArrayField, value) {

    //_log('_rule5', arguments);
    if (nativeArrayField) {
        nativeArrayField = nativeArrayField.split('\u0005');
        if (nativeArrayField.length) {
            return nativeArrayField.contains(value);
        }
    }

    return true;
}

function _rule6(ruleValue, value) {

    //_log('_rule6', arguments);

    if (ruleValue) {
        ruleValue = ruleValue.split(',');

        // var flag = false;
        for (var i = 0; i < ruleValue.length; i++) {
            if (value.indexOf(ruleValue[i]) != -1) {
                return true
            }
        }

        return false;
    }


    return true;
}

function _rule7(rule, value) {

    //_log('_rule7', arguments);

    if (rule) {
        return rule.indexOf(value) != -1;
    }

    return true;
}

function _commonRule(shipItemRule,
                     ruleDestCountry, destCountry,
                     ruleLocation, location,
                     alltags,
                     totalWeight,
                     total,
                     soMarketplace) {
    //_log('_commonRule', arguments);

    var c1 = _rule2(shipItemRule.custrecord_sz_rule_tags, alltags);
    //_log('c1', c1);
    var c2 = _rule3(shipItemRule.custrecord_sz_rule_total_weight, totalWeight);
    //_log('c2', c2);
    var c3 = _rule3(shipItemRule.custrecord_sz_rule_total_amount, total);
    //_log('c3', c3);
    var c4 = _rule7(ruleDestCountry, destCountry);
    //_log('c4', c4);
    var c5 = _rule5(shipItemRule.custrecord_sz_rule_marketplace, soMarketplace);
    //_log('c5', c5);
    var c6 = _rule1(ruleLocation, location);
    //_log('c6', c6);
    return c1 &&
        c2 &&
        c3 &&
        c4 &&
        c5 &&
        c6;
}
