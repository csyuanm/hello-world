var SL_MPL_URL = "/app/site/hosting/scriptlet.nl?script=583&deploy=1";

NProgressInit();

function search() {
    var searchURL = window.location.origin + "/app/site/hosting/scriptlet.nl?script=583&deploy=1&compid=277620&whence=";
    searchURL += "&custpage_mpl_allow_reprinting=" + nlapiGetFieldValue("custpage_mpl_allow_reprinting");
    window.location = searchURL;
}

function onPageInit() {}

function print() {
    var ffCount = nlapiGetLineItemCount("custpage_mpl_list");
    var ffSelectedList = [];
    for (var line = 1; line <= ffCount; line++) {
        var checked = nlapiGetLineItemValue("custpage_mpl_list", "mpl_checkbox", line);
        var ffid = nlapiGetLineItemValue("custpage_mpl_list", "mpl_ffid_hidden", line);
        if (checked == "T") {
            ffSelectedList.push(ffid);
        }
    }
    if (ffSelectedList.length) {
        console.log(JSON.stringify(ffSelectedList));
        jQuery.ajax({
            url: SL_MPL_URL,
            data: {
                action: "print",
                ffSelectedList: JSON.stringify(ffSelectedList)
            },
            success: function(data) {
                console.log(data);
                PageOverlay.removeOverlay();
                NProgress.done(true);
                data = parseToJSON(data);
                if (data.mpl_id) {
                    post_to_url(SL_MPL_URL, {
                        action: "showMPLPDF2",
                        mpl_id: data.mpl_id
                    });
                    window.setTimeout(function() {
                        window.location.reload();
                    }, 1e3);
                } else {
                    alert("Not to created the PDF file YET!");
                }
            },
            beforeSend: function() {
                PageOverlay.showOverlay();
                NProgress.start();
            }
        });
    } else {
        alert("Please select records for print.");
    }
}

window.page_unload = null;