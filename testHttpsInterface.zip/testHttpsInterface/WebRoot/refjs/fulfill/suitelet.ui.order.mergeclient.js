var SUITELET_URL = '/app/site/hosting/scriptlet.nl?script=956&deploy=2';
initNProgress();
function _isPageVerified() {
    // NS验证
    var flag = save_record(true);
    console.log(flag);
    return flag;
}
function searchSO() {
    if (_isPageVerified()) {
        PageOverlay.showOverlay();
        NProgress.start();
        window.location = SUITELET_URL + '&' + serializeURL({
            action: 'search',
            custpage_merge_customer: nlapiGetFieldValue('custpage_merge_customer')
        });
    }
}


function fieldChanged(type, name, linenum) {
    console.log('fieldChanged');
    console.log(arguments);
    if (name == 'sm_checkbox' && type == 'custpage_so_list') {
        jQuery('#custpage_total_weight_fs_lbl').children('a').html('重量: ' + calTotal() + 'G');
    }
}

function calTotal() {
    var count = nlapiGetLineItemCount("custpage_so_list");

    var weight = 0;
    for (var line = 1; line <= count; line++) {
        var checked = nlapiGetLineItemValue("custpage_so_list", "sm_checkbox", line);
        var w = nlapiGetLineItemValue("custpage_so_list", "sm_weight", line);
        if (checked == "T") {
            weight += parseFloat(w);
        }
    }

    return _mathround(weight);
}

jQuery("#custpage_so_listmarkall").click(function () {
    jQuery('#custpage_total_weight_fs_lbl').children('a').html('重量: ' + calTotal() + 'G');
});

jQuery("#custpage_so_listunmarkall").click(function () {
    jQuery('#custpage_total_weight_fs_lbl').children('a').html('重量: 0G');
});

function mergeSO() {
    var count = nlapiGetLineItemCount("custpage_so_list");
    var list = [];
    for (var line = 1; line <= count; line++) {
        var checked = nlapiGetLineItemValue("custpage_so_list", "sm_checkbox", line);
        var id = nlapiGetLineItemValue("custpage_so_list", "sm_internalid", line);
        var address = nlapiGetLineItemValue("custpage_so_list", "sm_shipaddress", line);
        if (checked == "T") {
            list.push({
                id: id,
                address: address,
                sm_custbody_marketplace: nlapiGetLineItemValue("custpage_so_list", "sm_custbody_marketplace", line),
                sm_otherrefnum: nlapiGetLineItemValue("custpage_so_list", "sm_otherrefnum", line),
                sm_currency: nlapiGetLineItemValue("custpage_so_list", "sm_currency", line)
            });
        }
    }

    if (calTotal() > 2000) {
        var userConfirm = confirm('合单的重量超过了常规的物流匹配方式的限制2000G，你还要继续操作吗？');
        if (!userConfirm) {
            return;
        }
        //alert('重量太大了（max weight is 2000G）请重新选择！');
        //return false;
    }

    // return false;


    if (list.length) {

        if (list.length > 10) {
            alert('最多运行合并10条， 请重新调整！ 再多就实在不行了。。');
            return;
        }

        if (!allTheSame(list.map(function (item) {
                return item.sm_currency;
            }))) {
            alert('必须是相同币种的单才能合哦， 否则Approve 订单把');
            return;
        }
        var one = list[0];
        // Like: 	COC-116122
        if (one.sm_custbody_marketplace == 'eBay' && !allTheSame(list.map(function (item) {
                var num = item.sm_otherrefnum;
                return num.substring(0, num.indexOf('-'));
            }))) {
            alert('eBay平台请注意， 不是相同账号下面的单是不能合滴！');
            return;
        }

        if (allTheSame(list.map(function (item) {
                return item.address;
            }))) {
            PageOverlay.showOverlay();
            NProgress.start();
            var url = SUITELET_URL + '&action=doMerge' + '&' + serializeURL({
                    list: list.map(function (item) {
                        return item.id;
                    }).join(',')
                });
            console.log(url);

            window.location = url;
        } else {
            alert('有的Address 都不一样， 请仔细检查之后再合并！多谢！');
            return;
        }


    } else {
        alert('请选择要Merge的记录');
    }
}

window.page_unload = null;