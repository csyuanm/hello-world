/**
 * ---------------------------------------------------------- Edit Status ----------------------------------------------------------
 * @private
 */
var __CARRIER = nlapiGetFieldValue('custbody_sz_carrier');
var __METHOD = nlapiGetFieldValue('custbody_ship_method_sz');
var __TRACKNO = nlapiGetFieldValue('custbody_sz_carrier_trackingnumber');
var __SHIPMENTNO = nlapiGetFieldValue('custbody_carrier_shipment_number');
var __TOTAL = nlapiGetFieldValue('total');
var __LOCATION = nlapiGetFieldValue('location');
var __SUBSIDIARY = nlapiGetFieldValue('subsidiary');

var __shipaddress = nlapiGetFieldValue('shipaddress');
console.log(__shipaddress);

var ITEMS = [];

// 480	Shenzhen B2B Sales Order - Invoice
//function _isShenznB2B() {
//    var formid = nlapiGetFieldValue('customform');
//    console.log(formid);
//    return formid == 480;
//}

function fieldChanged(type, name, linenum) {
    console.log('type: ' + type + ' name: ' + name + ' linenum: ' + linenum);
    var subs = nlapiGetFieldValue('subsidiary');
    if (subs == Subsidiaries.TaiwuInternational) {
        if (name == 'custbody_sz_carrier' || name == 'custbody_ship_method_sz') {
            var carrier = nlapiGetFieldValue('custbody_sz_carrier');
            var method = nlapiGetFieldValue('custbody_ship_method_sz');
            if (carrier == __CARRIER && method == __METHOD) {
                nlapiSetFieldValue('custbody_sz_carrier_trackingnumber', __TRACKNO);
                nlapiSetFieldValue('custbody_carrier_shipment_number', __SHIPMENTNO);
                nlapiSetFieldValue('custbody_shiping_changed', 'F');
            } else {
                nlapiSetFieldValue('custbody_sz_carrier_trackingnumber', '');
                nlapiSetFieldValue('custbody_carrier_shipment_number', '');
                nlapiSetFieldValue('custbody_shiping_changed', 'T');
            }
        } else if (!type) {

            if (name == 'location') {
                var mainLocation = nlapiGetFieldValue('location');

                var bin = false;
                if (mainLocation == 36) { // FBA warehouse
                    bin = nlapiLookupField('customrecord_amazon_accounts', nlapiGetFieldValue('custbody_orderfrom'), 'custrecord_fba_bin_to_use');
                }

                var count = nlapiGetLineItemCount('item');
                for (var line = 1; line <= count; line++) {
                    nlapiSelectLineItem('item', line);
                    var itemtype = nlapiGetCurrentLineItemValue('item', 'itemtype', line);
                    console.log(itemtype);
                    if (itemtype == 'InvtPart') {
                        nlapiSetCurrentLineItemValue('item', 'location', mainLocation, true, true);
                        if (bin !== false) {
                            nlapiSetCurrentLineItemValue('item', 'custcol_bin', bin);
                        }
                        nlapiCommitLineItem('item');
                    } else {
                        nlapiCancelLineItem('item')
                    }
                }
            } else if (name == 'shipaddress') {
                nlapiSetFieldValue('custbody_sz_carrier_trackingnumber', '');
                nlapiSetFieldValue('custbody_carrier_shipment_number', '');
                nlapiSetFieldValue('custbody_shiping_changed', 'T');
            }


        }
        //else if (type == 'item' && name == 'isclosed') {
        //    alert('不能关闭Item， 如有需要请考虑分单， 多谢！')
        //}
    } else if (subs == Subsidiaries.ShenzhenB2B) {
        //if (!type) {
        //    if (name == 'entity') {
        //        console.log('Shenzhen B2B here field change');
        //        nlapiSetFieldValue('department', nlapiGetDepartment());
        //        //var entity = nlapiGetFieldValue('entity');
        //        //if (entity) {
        //        //    var ent = nlapiLookupField('customer', entity, [
        //        //        'custentity_department'
        //        //    ]);
        //        //    if (ent.custentity_department) {
        //        //        nlapiSetFieldValue('department', ent.custentity_department);
        //        //    }
        //        //}
        //    }
        //}

    }

    //var shippngFields = [
    //    'custbody_sz_carrier',
    //    'custbody_ship_method_sz'
    //];
    //
    //var oldRecord = nlapiGetOldRecord();
    //var is_changed = false;
    //
    //for (var j = 0; j < shippngFields.length; j++) {
    //    var field = shippngFields[j];
    //    var oldValue = oldRecord.getFieldValue(field);
    //    var currentValue = nlapiGetFieldValue(field);
    //    if (!oldValue) oldValue = null;
    //    if (!currentValue) currentValue = null;
    //    if (oldValue !== currentValue) {
    //        is_changed = true;
    //        break;
    //    }
    //}
    //
    //if (is_changed) {
    //    nlapiSetFieldValue('custbody_shiping_changed', 'T');
    //    //nlapiSetFieldValue('custbody_sz_carrier_trackingnumber', '');
    //    //nlapiSetFieldValue('custbody_carrier_shipment_number', '');
    //}
}

function validateField(type, name, linenum) {

    if (__SUBSIDIARY == Subsidiaries.TaiwuInternational) {

        //var role = nlapiGetRole();
        //if (![3, 1138, 1139].contains(role)) {
        //    if (type == 'item' && name == 'isclosed') {
        //        alert('不能关闭Item， 如有需要请考虑分单， 多谢！');
        //        return false;
        //    }
        //}
    }

    // _log('validateField', arguments);

    //var hs_class = nlapiGetLineItemValue('item', 'custcol_hs_class', linenum);
    ////nlapiRefreshLineItems('item');
    //console.log(hs_class);

    return true;
}

function saveRecord() {
    if (__SUBSIDIARY == Subsidiaries.TaiwuInternational) {
        var custbody_order_type = nlapiGetFieldValue('custbody_order_type');
        if (custbody_order_type == 2) {
            var total = nlapiGetFieldValue('total');
            total = parseFloat(total);
            if (total !== 0) {
                alert('补发单的订单必须调整到Total 为0， 请调整Line item， 同时删除Paypal line item fee（如果有的话）。');
                return false;
            }
        }

        else if (custbody_order_type == '1' || custbody_order_type == '' || custbody_order_type == null) { // 正常单
            if (parseFloat(__TOTAL) != parseFloat(nlapiGetFieldValue('total'))) {
                var userConfirm = confirm('订单金额的总价被改变了！原价：' + __TOTAL + ' 现价：' + nlapiGetFieldValue('total') + '，在一般情况下绝对不允许订单总价被改变，除非某些特殊情况！你确认要继续保存吗？？' +
                '继续操作保存成功的话， 请删除Invoice（如果有的话）， 然后手动的结算订单， 多谢！！');
                if (userConfirm) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        //else if (custbody_order_type == '3') { // 分单
        //    if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.eBay) {
        //        //var os = nlapiSearchRecord('salesorder', null, [
        //        //    new nlobjSearchFilter('custbody_ebay_order_id', null, 'is', nlapiGetFieldValue('custbody_ebay_order_id')),
        //        //    new nlobjSearchFilter('mainline', null, 'is', 'T')
        //        //], [
        //        //    new nlobjSearchColumn('fxamount')
        //        //]);
        //
        //
        //    }
        //}
        else if (!nlapiGetFieldValue('location')) {
            alert('表头没有Location不行啊，请填好Location之后再保存，多谢！');
            return false;
        }


        var newITEMS = [];
        var line = 1;
        var linecount = nlapiGetLineItemCount('item');
        for (; line <= linecount; line++) {
            var itemtype = nlapiGetLineItemValue('item', 'itemtype', line);
            if (itemtype == 'InvtPart' || itemtype == 'Kit') {
                newITEMS.push(nlapiGetLineItemValue('item', 'item', line));
            }
        }

        // var notice = false;
        if (JSON.stringify(ITEMS) != JSON.stringify(newITEMS) ||
            __LOCATION != nlapiGetFieldValue('location') ||
            __TRACKNO != nlapiGetFieldValue('custbody_sz_carrier_trackingnumber')) {
            //  notice = true;

            var soId = nlapiGetRecordId();
            if (soId) {
                try {
                    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
                        new nlobjSearchFilter('createdfrom', null, 'is', soId)
                    ]);

                    if (ffSearch != null) {
                        //if (notice) {
                        return confirm('订单重要信息被更改，保存之后包裹会被删除！请务必通知到仓库相关操作人员！如果面单已经打印要作废包裹面单， 重新打印生成！！切记！！再说一遍，务必通知到！！');
                        //}
                    }
                } catch (e) {
                    processException(e);
                    alert('有点问题！请重新提交！');
                    return false;
                }

            }

        }

        var custbody_marketplace = nlapiGetFieldValue('custbody_marketplace');
        if (custbody_marketplace == MarketplaceShipName.Amazon) {
            var custbody_orderfrom = nlapiGetFieldValue('custbody_orderfrom');
            if (!custbody_orderfrom) {
                alert('Please select Amazon account');
                return false;
            }
        }
        else if (custbody_marketplace == MarketplaceShipName.eBay) {
            var custbody_linked_ebay_account = nlapiGetFieldValue('custbody_linked_ebay_account');
            if (!custbody_linked_ebay_account) {
                alert('Please select eBay account');
                return false;
            }
        }
        else if (custbody_marketplace == MarketplaceShipName.Wish) {
            var custbody_wishmerchant = nlapiGetFieldValue('custbody_wishmerchant');
            if (!custbody_wishmerchant) {
                alert('Please select Wish Merchant');
                return false;
            }
        }
        else if (custbody_marketplace == MarketplaceShipName.AliExpress) {
            var custbody_ali_account = nlapiGetFieldValue('custbody_ali_account');
            if (!custbody_ali_account) {
                alert('Please select Ali account');
                return false;
            }
        }

    }

    //else if (__SUBSIDIARY == Subsidiaries.ShenzhenB2B) {
    //
    //}

    return true;
}


function pageInit(type) {
    console.log(type);
    if (!__SUBSIDIARY) {
        __SUBSIDIARY = nlapiGetFieldValue('subsidiary');
    }

    if (__SUBSIDIARY == Subsidiaries.TaiwuInternational) {

        nlapiDisableField('custbody_tw_fulfillment_status', true);
        nlapiDisableField('custbody_taiwu_fulfill_status_code', true);
        nlapiDisableField('custbody_taiwu_bill_status_code', true);
        if (type == 'edit') {
            nlapiDisableField('otherrefnum', true);

            var line = 1;
            var linecount = nlapiGetLineItemCount('item');
            for (; line <= linecount; line++) {
                var itemtype = nlapiGetLineItemValue('item', 'itemtype', line);
                if (itemtype == 'InvtPart' || itemtype == 'Kit') {
                    ITEMS.push(nlapiGetLineItemValue('item', 'item', line));
                }
            }

        }

    } else if (__SUBSIDIARY == Subsidiaries.ShenzhenB2B) {
        console.log('Shenzhen B2B SO page init type: ' + type);
        if (type == 'create') {
            nlapiSetFieldValue('department', nlapiGetDepartment());
        }


        //var entity = nlapiGetFieldValue('entity');
        //if (entity) {
        //    var ent = nlapiLookupField('customer', entity, [
        //        'custentity_department'
        //    ]);
        //    if (ent.custentity_department) {
        //        nlapiSetFieldValue('department', ent.custentity_department);
        //    }
        //}
    }

}
/**
 * ---------------------------------------------------------- View Status ----------------------------------------------------------
 * @private
 */
//function _pageInit() {
//    // 单据状态
//    var status = jQuery('#main_form').find('uir-record-status');
//    var statusValue = status.html();
//    console.log(status);
//    // status.html(statusValue + '')
//}
//
//_pageInit();

function bufaGift() {
    var giftId = prompt('请写入小礼物的Internal ID：');
    giftId = giftId.trim();
    if (giftId) {
        console.log(giftId);

        hitButton();
        window.location = '/app/site/hosting/scriptlet.nl?script=956&deploy=1&' + serializeURL({
            action: 'bufaGift',
            giftId: giftId,
            order_id: nlapiGetRecordId()
        });

    } else {
        alert('没有小礼物ID！');
    }
}

function closeSalesOrder() {


    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', nlapiGetRecordId()),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ], [
        new nlobjSearchColumn('custbody_tw_fulfillment_status')
    ]);

    var allowClose = false;
    if (ffSearch != null) {
        for (var i = 0; i < ffSearch.length; i++) {
            if (ffSearch[i].getValue('custbody_tw_fulfillment_status') == 3) {
                allowClose = true;
            } else {
                allowClose = false;
                break;
            }
        }
    } else {
        allowClose = true;
    }

    // var ffSearch = nlapiSearchRecord('itemfulfillment', null, [new nlobjSearchFilter('createdfrom', null, 'is', nlapiGetRecordId())]);
    if (allowClose == false) {
        alert('订单有包裹记录产生了， 而且都面单不是初始状态！请联系仓库处理这个订单！您不能操作！');
        return false;
    } else {
        var userConfirm = confirm('订单即将被关闭，请确认是否继续？');
        if (userConfirm) {
            hitButton();
            window.location = "/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=closeSO&soId=" + nlapiGetRecordId(); // + "'"
        }
    }

}

function openSalesOrder() {
    var userConfirm = confirm('订单即将被开启，请确认是否继续？');
    if (userConfirm) {
        hitButton();
        window.location = "/app/site/hosting/scriptlet.nl?script=824&deploy=1&action=openOrder&soId=" + nlapiGetRecordId(); // + "'"
    }
}

function bufaSalesOrder() {
    var userConfirm = confirm('确定要补发这个订单吗，点击【确定】之后会自动的生成一个新的当前订单的补发单哦！');
    if (userConfirm) {
        hitButton();
        window.location = '/app/site/hosting/scriptlet.nl?script=956&deploy=1&' + serializeURL({
            action: 'bufa',
            order_id: nlapiGetRecordId()
        });
    }
}


function _mark(tag) {
    nlapiSetFieldValue('custbody_tracked', 'T');
    var carrierId = nlapiGetFieldValue('custbody_sz_carrier');
    if (carrierId == 7) { // 7 = 速卖通线上物流
        nlapiSetFieldValue('custbody_zake_alilogistictype', '');
    } else {
        nlapiSetFieldValue('otherrefnum', nlapiGetFieldValue('otherrefnum') + '-' + tag);
    }

    // var id = getURLParameter('id');
    var parentId = getURLParameter('id'); //GetRequest()['id'];
    if (parentId) nlapiSetFieldValue('custbody_parent_sales_order', parentId); // 速卖通看这个标志
    nlapiSetFieldValue('custbody_zake_ischildorder', 'T');

    console.log(this.id);
    var custpage_btn_fen = nlapiGetField('custpage_btn_fen');
    custpage_btn_fen.setDisplayType('disabled');

    var custpage_btn_bu = nlapiGetField('custpage_btn_bu');
    custpage_btn_bu.setDisplayType('disabled');
}

function markSplitSalesOrder() {
    _mark('split');
    nlapiSetFieldValue('custbody_zake_ischildorder', 'T');
    nlapiSetFieldValue('custbody_order_type', 3); // 3 分单
}

function markReshipSalesOrder() {
    _mark('BUFA');
    nlapiSetFieldValue('custbody_order_type', 2); // 2 补发单
    // 清0;
    //for (var line = 0, count = nlapiGetLineItemCount('item'); line <= count; line++) {
    //    nlapiSelectLineItem('item', line);
    //    nlapiSetCurrentLineItemValue('item', 'rate', 0, true, true);
    //    nlapiCommitLineItem('item');
    //}
}


function GetRequest() {
    var url = location.search;
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}