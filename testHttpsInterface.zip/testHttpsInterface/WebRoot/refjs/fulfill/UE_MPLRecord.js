function beforeLoad(type, form, request) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("beforeLoad____________ id: " + id + " recType: " + recType + " type: " + type);
        if (type == "view" || type == "edit") {
            var tab = form.addTab("custpage_linked_fulfillment", "Linked Fulfillments");
            var list = form.addSubList("custpage_linked_fulfillments", "list", "Fulfillment List", "custpage_linked_fulfillment");
            list.addField("lf_no", "text", "#", null);
            list.addField("lf_date", "text", "Date", null);
            list.addField("lf_id", "text", "Internal ID", null);
            list.addField("lf_number", "text", "Number", null);
            list.addField("lf_status", "text", "Status", null);
            list.addField("lf_so", "text", "SO#", null);
            list.addField("lf_carrier", "text", "Carrier", null);
            list.addField("lf_shipmethod", "text", "Ship Method", null);
            var custrecord_mpl_subsidiary = nlapiGetFieldValue("custrecord_mpl_subsidiary");
            var filter = [ new nlobjSearchFilter("mainline", null, "is", "T") ];
            if (custrecord_mpl_subsidiary && custrecord_mpl_subsidiary == Subsidiaries.TaiwuInternational) {
                filter.push(new nlobjSearchFilter("custbody_mpl_number", null, "is", id));
            } else {
                filter.push(new nlobjSearchFilter("custbody_mpl_number", "createdfrom", "is", id));
            }
            var searchResults = nlapiSearchRecord("itemfulfillment", null, filter, [ new nlobjSearchColumn("tranid"), new nlobjSearchColumn("trandate"), new nlobjSearchColumn("status"), new nlobjSearchColumn("location"), new nlobjSearchColumn("createdfrom"), new nlobjSearchColumn("item"), new nlobjSearchColumn("salesdescription", "item"), new nlobjSearchColumn("shipcarrier"), new nlobjSearchColumn("shipmethod") ]);
            if (searchResults != null) {
                searchResults.forEach(function(searchResult, index) {
                    var _line = index + 1;
                    list.setLineItemValue("lf_no", _line, _line.toString());
                    list.setLineItemValue("lf_date", _line, searchResult.getValue("trandate"));
                    list.setLineItemValue("lf_id", _line, '<a href="' + nlapiResolveURL("Record", "itemfulfillment", searchResult.getId()) + '" target="_blank">' + searchResult.getId() + "</a>");
                    list.setLineItemValue("lf_number", _line, searchResult.getValue("tranid"));
                    list.setLineItemValue("lf_status", _line, searchResult.getText("status"));
                    list.setLineItemValue("lf_so", _line, searchResult.getText("createdfrom"));
                    list.setLineItemValue("lf_carrier", _line, searchResult.getText("shipcarrier"));
                    list.setLineItemValue("lf_shipmethod", _line, searchResult.getText("shipmethod"));
                });
            }
        }
        if (type == "view") {
            var scriptId = 186;
            if (custrecord_mpl_subsidiary && custrecord_mpl_subsidiary == Subsidiaries.TaiwuInternational) {
                scriptId = 583;
            }
            form.addField("custpage_mpl_pdf_link", "url").setDisplayType("inline").setLinkText("View Master Picking List PDF").setDefaultValue("/app/site/hosting/scriptlet.nl?script=" + scriptId + "&deploy=1&mpl_id=" + id + "&action=showMPLPDF2");
        }
        _log("beforeLoad____________end");
    } catch (e) {
        processException(e);
    }
}