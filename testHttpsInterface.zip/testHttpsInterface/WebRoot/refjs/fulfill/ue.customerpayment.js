/**
 * 这个脚本现在只是给Zake 用的哦！！！
 * @param type
 * @param form
 * @param request
 */
function beforeLoad(type, form, request) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();

    var envContext = nlapiGetContext().getExecutionContext();
    _log('envContextbeforeLoad', envContext);

    try {

        var subs = nlapiGetFieldValue('subsidiary');
        if (subs == Subsidiaries.TaiwuInternational) {
            if (envContext == 'userinterface') {

                if ("1384" == nlapiGetFieldValue('aracct')) { // Ebay China Store - AR
                    var applyItems = [];
                    var count = nlapiGetLineItemCount('apply');
                    for (var line = 1; line <= count; line++) {
                        applyItems.push({
                            internalid: nlapiGetLineItemValue('apply', 'internalid', line),
                            trantype: nlapiGetLineItemValue('apply', 'trantype', line)
                        });
                    }
                    if (applyItems.length == 1) {
                        if (applyItems[0].trantype == 'CustInvc') {

                            nlapiSetFieldValue('undepfunds', 'F');
                            var fieldObject = nlapiLookupField('invoice', applyItems[0].internalid, [
                                'custbody_ebay_order_id',
                                'custbody_storefront_order',
                                'custbody_marketplace',
                                'custbody_linked_ebay_account',
                                'otherrefnum',
                                'custbody_paypal_transaction_id',
                                'custbody_bank_account'
                                //'custbody_orderfrom',
                                //'custbody_ali_account',
                                //'custbody_wishmerchant'
                            ]);
                            _log('fieldObject', fieldObject);
                            for (var name in fieldObject) {
                                if (name == 'otherrefnum') {
                                    nlapiSetFieldValue('custbody_ref_number', fieldObject['otherrefnum']);
                                }
                                else if (name == 'custbody_bank_account') {
                                    nlapiSetFieldValue('account', fieldObject['custbody_bank_account']); // custbody_bank_account 是在Bill 的时候设置的哦
                                }
                                else {
                                    nlapiSetFieldValue(name, fieldObject[name]);
                                }
                            }


                        }
                    }

                }


            }
        } else {
            zakeSetPaymentAccount(type, 'beforeLoad');
        }


    } catch (e) {


        if (envContext == 'scheduled') {
            throw e;
        } else {
            processException(e, 'id: ' + id + ' type: ' + recType);
        }

    }

}

function beforeSubmit(type) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    try {
        if (type == 'create' || type == 'edit') {
            var subs = nlapiGetFieldValue('subsidiary');
            if (subs == Subsidiaries.TaiwuInternational) {
                if (!nlapiGetFieldValue('account')) {
                    throw new UIException('没有Account， 不能生成 Payment Record. customer payment id: ' + id);
                }
            } else {
                zakeSetPaymentAccount(type, 'beforeSubmit');
            }
        }


    } catch (e) {

        var envContext = nlapiGetContext().getExecutionContext();
        _log('envContextbeforeSubmit', envContext);

        if (envContext == 'scheduled') {
            throw e;
        } else {
            processException(e, 'id: ' + id + ' type: ' + recType);
        }

    }

}

function zakeSetPaymentAccount(type, from) {

    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    _log("zakeSetPaymentAccount id: " + id + " recType: " + recType + " type: " + type + from);

    //if (type == 'create' && recType == 'invoice') { //
    //    // 160	Swagway Product Invoice
    //    //if (nlapiGetFieldValue('customform') == '160') {
    //    if (nlapiGetFieldValue('custbody_marketplace') == MarketplaceShipName.Swagway) {
    //        // 177	Swagway Credit Card	Accounts Receivable
    //        nlapiSetFieldValue('account', 177);
    //    }
    //}

    var subs = nlapiGetFieldValue('subsidiary');
    if (subs == Subsidiaries.ZakeInternational) {
        if (type == 'create' && recType == 'customerpayment') {


            var envContext = nlapiGetContext().getExecutionContext();
            _log('envContext', envContext);

            //if (envContext == 'userinterface') {


            var arAccount = nlapiGetFieldValue('aracct');
            if (arAccount) {


                // 要和  SSUtils 这里对应哦
                if ([
                        2330, // Jet

                        // Ebay系列
                        1127,
                        1190,
                        1192,
                        1193,

                        1151, // HB

                        //Three storefronts still need to have payment applied to their individual cash account:
                        //1) Newegg: “Newegg Cash Account”
                        //2) 3Btech.net: paypal@3btech.net
                        //3) Buy.com/Rakuten: “Buy.com Cash Account”
                        1128, // Newegg
                        1130, // 3BTech
                        1129 // Buy.com/Rakuten

                    ].contains(arAccount)) {
                    var paymentAccount = nlapiLookupField('account', arAccount, 'custrecord_ar_linked_payment_account');

                    _log('paymentAccount', paymentAccount);
                    if (paymentAccount) {
                        nlapiSetFieldValue('undepfunds', 'F');
                        nlapiSetFieldValue('account', paymentAccount, true, true);
                    }
                }


            }

            //}

        }
    }


}