var ONES_MAX_MASTER_PICK_FULFILLMENTS_QUANTITY = 80;

function run(request, response) {
    try {
        logparams(request);
        var custpage_mpl_allow_reprinting = request.getParameter("custpage_mpl_allow_reprinting");
        _log("custpage_mpl_allow_reprinting", custpage_mpl_allow_reprinting);
        if (!custpage_mpl_allow_reprinting) custpage_mpl_allow_reprinting = "F";
        var ACTION = request.getParameter("action");
        if (request.getMethod() == "GET") {
            if (!ACTION) {
                var form = nlapiCreateForm("太武国际 - 打印主拣货单", false);
                form.setScript("customscript_client_sz_mpl");
                form.addButton("custpage_mpl_search", "搜索", "search();");
                var allowReprinting = form.addField("custpage_mpl_allow_reprinting", "checkbox", "允许重复打印");
                allowReprinting.setBreakType("startrow");
                allowReprinting.setDefaultValue(custpage_mpl_allow_reprinting);
                var searchFilter = [ new nlobjSearchFilter("subsidiary", null, "is", Subsidiaries.TaiwuInternational), new nlobjSearchFilter("type", "createdfrom", "anyof", [ "SalesOrd", "TrnfrOrd" ]), new nlobjSearchFilter("status", null, "anyof", [ "ItemShip:B" ]), new nlobjSearchFilter("mainline", null, "is", "T"), new nlobjSearchFilter("status", "createdfrom", "anyof", [ "SalesOrd:B" ]), new nlobjSearchFilter("custbody_has_issues", "createdfrom", "is", "F"), new nlobjSearchFilter("custbody_pending_print", null, "is", "T") ];
                if (custpage_mpl_allow_reprinting == "F") {
                    searchFilter.push(new nlobjSearchFilter("custbody_mpl_number", null, "isempty"));
                }
                var SEARCH_COLUMNS = [ new nlobjSearchColumn("custbody_marketplace"), new nlobjSearchColumn("trandate"), new nlobjSearchColumn("tranid"), new nlobjSearchColumn("custbody_mpl_number"), new nlobjSearchColumn("status"), new nlobjSearchColumn("createdfrom"), new nlobjSearchColumn("custbody_sz_carrier_trackingnumber"), new nlobjSearchColumn("custbody_ships_individually", "createdfrom"), new nlobjSearchColumn("custbody_shipment_label"), new nlobjSearchColumn("custbody_item_type_quantity").setSort(), new nlobjSearchColumn("custbody_shipment_sku").setSort() ];
                var listSearch = nlapiSearchRecord("itemfulfillment", null, searchFilter, SEARCH_COLUMNS);
                if (listSearch != null) {
                    var inline_style = [ "<style>", "    .uir-list-row-tr > td, .uir-machine-row > td, .uir-machine-totals-row > td {", "        white-space: nowrap;", "    }", ".uir-list-header-td, .uir-machine-headerrow > td {" + "    padding: 6px 5px !important;" + "}", "#custpage_mpl_list_form .listheader { white-space: nowrap; }", "</style>" ].join("");
                    form.addField("custpage_mpl_style", "inlinehtml").setDefaultValue(inline_style);
                    var mplList = form.addSubList("custpage_mpl_list", "list", "搜索结果", null);
                    form.addButton("custpage_mpl_print", "打印", "print();");
                    mplList.addMarkAllButtons();
                    mplList.addField("mpl_checkbox", "checkbox", "Select", null);
                    mplList.addField("mpl_ffid_hidden", "text", "Fulfillment ID Hidden", null).setDisplayType("hidden");
                    mplList.addField("mpl_marketplaces", "text", "Marketplaces", null);
                    mplList.addField("mpl_ffid", "text", "包裹ID", null);
                    mplList.addField("mpl_trandate", "text", "日期", null);
                    mplList.addField("mpl_tranid", "text", "包裹Number", null);
                    mplList.addField("mpl_mplnumber", "text", "主拣货单单号 MPL Number", null);
                    mplList.addField("mpl_status", "text", "状态", null);
                    mplList.addField("mpl_so", "text", "订单号", null);
                    mplList.addField("mpl_trackingnumbers", "text", "包裹跟踪号", null);
                    mplList.addField("mpl_ship_label", "text", "包裹产品描述", null);
                    mplList.addField("mpl_item_type_quantity", "text", "发货产品种类数量", null);
                    var i = 0, len = listSearch.length;
                    for (;i < len; i++) {
                        var searchResult = listSearch[i];
                        var line = i + 1;
                        mplList.setLineItemValue("mpl_ffid_hidden", line, searchResult.getId());
                        mplList.setLineItemValue("mpl_ffid", line, '<a target="_blank" href="' + nlapiResolveURL("record", "itemfulfillment", searchResult.getId()) + '">' + searchResult.getId() + "</a>");
                        mplList.setLineItemValue("mpl_trackingnumbers", line, searchResult.getValue("custbody_sz_carrier_trackingnumber"));
                        mplList.setLineItemValue("mpl_marketplaces", line, searchResult.getText("custbody_marketplace"));
                        mplList.setLineItemValue("mpl_ship_label", line, searchResult.getValue("custbody_shipment_label"));
                        mplList.setLineItemValue("mpl_item_type_quantity", line, searchResult.getValue("custbody_item_type_quantity"));
                        var mplNumber = searchResult.getValue("custbody_mpl_number");
                        mplList.setLineItemValue("mpl_mplnumber", line, '<a target="blank" href="/app/common/custom/custrecordentry.nl?rectype=157&id=' + mplNumber + '">' + mplNumber + "</a>");
                        mplList.setLineItemValue("mpl_tranid", line, searchResult.getValue("tranid"));
                        mplList.setLineItemValue("mpl_status", line, searchResult.getText("status"));
                        mplList.setLineItemValue("mpl_so", line, '<a href="' + nlapiResolveURL("RECORD", "salesorder", searchResult.getValue("createdfrom")) + '">' + searchResult.getText("createdfrom") + "</a>");
                        mplList.setLineItemValue("mpl_trandate", line, searchResult.getValue("trandate"));
                    }
                } else {
                    form.addField("custpage_searchresults", "label", "暂时还没有包裹可打印。。").setLayoutType("startrow");
                }
                response.writePage(form);
            } else if (ACTION == "print") {
                var ffSelectedList = JSON.parse(request.getParameter("ffSelectedList"));
                _log("ffSelectedList", ffSelectedList);
                var columns = [ new nlobjSearchColumn("location", null, "GROUP"), new nlobjSearchColumn("item", null, "GROUP"), new nlobjSearchColumn("salesdescription", "item", "GROUP"), new nlobjSearchColumn("custitem_legacy_tong_sku", "item", "GROUP"), new nlobjSearchColumn("quantity", null, "SUM"), new nlobjSearchColumn("binnumber", "inventoryDetail", "GROUP"), new nlobjSearchColumn("quantity", "inventoryDetail", "SUM") ];
                var printFilter = [ new nlobjSearchFilter("type", "createdfrom", "anyof", [ "SalesOrd", "TrnfrOrd" ]), new nlobjSearchFilter("status", null, "anyof", [ "ItemShip:B" ]), new nlobjSearchFilter("type", "item", "anyof", [ "InvtPart", "Kit" ]), new nlobjSearchFilter("accounttype", null, "is", "@NONE@") ];
                printFilter.push(new nlobjSearchFilter("internalid", null, "anyof", ffSelectedList));
                var printResults = nlapiSearchRecord("itemfulfillment", null, printFilter, columns);
                var masterList = printResults.map(function(searchResult) {
                    var sku = searchResult.getText(columns[1]);
                    if (sku.indexOf(":") != -1) {
                        sku = sku.substring(sku.indexOf(":") + 1).trim();
                    }
                    return {
                        location: searchResult.getText(columns[0]),
                        item: sku,
                        legacysku: searchResult.getValue(columns[3]),
                        salesdescription: searchResult.getValue(columns[2]),
                        quantity: searchResult.getValue(columns[4]),
                        sum: searchResult.getValue(columns[4]),
                        binnumber: searchResult.getValue(columns[5]),
                        binnumber_quantity: searchResult.getValue(columns[6])
                    };
                });
                _log("masterList", masterList);
                if (masterList.length) {
                    var data = {
                        masterList: masterList
                    };
                    var mplRecord = nlapiCreateRecord("customrecord_mpl_record");
                    mplRecord.setFieldValue("custrecord_mpl_subsidiary", Subsidiaries.TaiwuInternational);
                    mplRecord.setFieldValue("custrecord_mpl_data", JSON.stringify(data));
                    var mplRecordId = nlapiSubmitRecord(mplRecord);
                    printFilter.push(new nlobjSearchFilter("mainline", null, "is", "T"));
                    var mplFulfillmentSearch = nlapiSearchRecord("itemfulfillment", null, printFilter);
                    mplFulfillmentSearch.forEach(function(searchResult) {
                        _log("ff id", searchResult.getId());
                        nlapiSubmitField("itemfulfillment", searchResult.getId(), "custbody_mpl_number", mplRecordId);
                    });
                    response.writeLine(JSON.stringify({
                        mpl_id: mplRecordId,
                        remainingUsage: nlapiGetContext().getRemainingUsage()
                    }));
                } else {
                    response.write("No Master List for Print.");
                }
            } else if (ACTION == "showMPLPDF") {
                response.setContentType("PDF", null, "inline");
                response.write(nlapiLoadFile(request.getParameter("fileId")));
            } else if (ACTION == "showMPLPDF2") {
                printMPLPDF(request, response);
            }
        } else {
            _log("------------------------------------post");
            if (request.getParameter("action") == "showMPLPDF") {
                response.setContentType("PDF", null, "inline");
                response.write(nlapiLoadFile(request.getParameter("fileId")));
            } else if (ACTION == "showMPLPDF2") {
                printMPLPDF(request, response);
            }
        }
    } catch (e) {
        e = processException(e);
        response.write(e.getUserMessage());
    }
}

function printMPLPDF(request, response) {
    var pdfHTML = nlapiLoadFile("SuiteScripts/FulfillManagement/SL_MasterPickingListPDF_Shenzhen.html").getValue();
    var template = Handlebars.compile(pdfHTML);
    var mpl_id = request.getParameter("mpl_id");
    var mpl_record = nlapiLoadRecord("customrecord_mpl_record", mpl_id);
    var custrecord_mpl_data = mpl_record.getFieldValue("custrecord_mpl_data");
    custrecord_mpl_data = JSON.parse(custrecord_mpl_data);
    var xml = template({
        number: mpl_id,
        itemlist: custrecord_mpl_data.masterList
    });
    var file = nlapiXMLToPDF(xml);
    response.setContentType("PDF", mpl_id + ".pdf", "inline");
    response.write(file);
}