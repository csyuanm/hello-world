function start(request, response) {

    // _log('request.getMethod()', request.getMethod());
    logparams(request);

    var context = nlapiGetContext();
    var depId = context.getDeploymentId();
    _log('depId', depId);

    if (depId == 'customdeploy_sl_ui_order') {
        var action = request.getParameter('action');
        var order_id = request.getParameter('order_id');
        if (request.getMethod() == 'GET') { // GET
            if (action == 'split') {

                var form = nlapiCreateForm("分单", false);
                // form.setScript('customscript_ssu');
                //form.setScript('customscript_cs_utils');
                form.addButton("custpage_submit", "提交", "submitSplitOrders();");
                // form.setScript('customscript_cs_comboinv');

                var data = _getOrderInfo(order_id);
                if (data.orderstatus == 'H' || data.orderstatus == 'C') {
                    response.write(data.tranid + ' was closed or cancelled.');
                    return;
                }
                var render = template.compile(nlapiLoadFile('2102204').getValue());
                var html = render(data);

                //var html = JSON.stringify();
                //_log('html22', html);
                form.addField("custpage_uihtml", "inlinehtml")
                    //  .setDefaultValue('<h1>Hello</h1>');
                    .setDefaultValue(html);
                // form.addField('custpage_purchasedetails', 'label', '没有找到相关的结果， 请审视搜索条件'); //.setLayoutType('startrow');

                response.writePage(form);
            } else if (action == 'bufa') {

                var bufaId = bufaSO(order_id);
                nlapiSetRedirectURL('record', 'salesorder', bufaId);
            } else if (action == 'bufaGift') { //EUB 补发小礼物的

                _deleteRelatedRecords(order_id);

                bufaSO(order_id);

                var giftId = request.getParameter('giftId');
                var giftSO = nlapiLoadRecord('salesorder', order_id);

                var giftCount = giftSO.getLineItemCount('item');

                var amount = 0;
                while (giftCount) {
                    var giftItem = giftSO.getLineItemValue('item', 'item', giftCount);
                    if (giftItem == 113345 || giftItem == 102214) { // Feed item
                    } else {
                        amount += parseFloat(giftSO.getLineItemValue('item', 'amount', giftCount));
                        giftSO.removeLineItem('item', giftCount);
                    }
                    giftCount--;
                }

                giftSO.selectNewLineItem("item");
                giftSO.setCurrentLineItemValue("item", "item", giftId);
                giftSO.setCurrentLineItemValue("item", "location", giftSO.getFieldValue('location'));
                giftSO.setCurrentLineItemValue("item", "quantity", 1);
                giftSO.setCurrentLineItemValue("item", "amount", amount);
                ////taxcode
                //giftSO.setCurrentLineItemValue("item", "price", -1);
                giftSO.commitLineItem("item");

                var giftSOId = nlapiSubmitRecord(giftSO, true);
                nlapiSetRedirectURL('record', 'salesorder', giftSOId);


            } else if (action == 'cancelSplit') {
                // 不做了， 太麻烦
            }

        } else { // Post

            if (action == 'splitON') {
                var splits = request.getParameter('splits');
                splits = JSON.parse(splits);

                var statusref = nlapiLookupField('salesorder', order_id, 'statusref');
                if (statusref == 'closed') {
                    response.write('这个订单已经关闭了哦， 不能再分了，同志！');
                    return;
                }

                if (splits.length > 1) {
                    var copies = [];
                    for (var i = 0; i < splits.length; i++) {
                        var split = splits[i];

                        //response.write(JSON.stringify(split, null, 2));
                        //return;

                        var otherrefnum = split.otherrefnum;
                        var items = split.items;
                        var copySO = nlapiCopyRecord('salesorder', order_id);
                        var custbody_marketplace = copySO.getFieldValue('custbody_marketplace');

                        if (custbody_marketplace == MarketplaceShipName.eBay) {
                            if (i != 0) {
                                copySO.setFieldValue('custbody_tracking_number_sync', 'T');
                            }
                        }

                        copySO.setFieldValue('otherrefnum', otherrefnum);
                        copySO.setFieldValue('custbody_order_type', 3);// 3 分单
                        copySO.setFieldValue('custbody_parent_sales_order', order_id);
                        copySO.setFieldValue('custbody_zake_ischildorder', 'T');

                        restCopySO(copySO);
                        copySO.setFieldValue('custbody_tracked', 'F');

                        if (i != 0) {
                            copySO.setFieldValue('shippingcost', '');
                            var carrierId = copySO.getFieldValue('custbody_sz_carrier');
                            if (carrierId == 7) { // 7 = 速卖通线上物流
                                copySO.setFieldValue('custbody_zake_alilogistictype', '');
                            }
                        }

                        var copyCount = copySO.getLineItemCount('item');
                        while (copyCount) {
                            // do something
                            var copyItem = copySO.getLineItemValue('item', 'item', copyCount);
                            var found = items.find(function (item) {
                                return copyItem == item.id;
                            });
                            if (found) {
                                if (found.quantity == 0) {
                                    copySO.removeLineItem('item', copyCount);
                                } else {
                                    copySO.setLineItemValue('item', 'quantity', copyCount, found.quantity);
                                }
                            } else {
                                copySO.removeLineItem('item', copyCount);
                            }

                            copyCount--;
                        }

                        copySO.setFieldValue('custbody_delay_bill', 'F');
                        copySO.setFieldValue('custbody_delay_fulfill', 'F');
                        copies.push(nlapiSubmitRecord(copySO, true));
                    }


                    var soRec = nlapiLoadRecord('salesorder', order_id);
                    for (var a = 1; a <= soRec.getLineItemCount('item'); a++) {
                        soRec.setLineItemValue('item', 'isclosed', a, 'T');
                    }
                    soRec.setFieldValue('custbody_delay_bill', 'T');
                    nlapiSubmitRecord(soRec, true);

                    deleteSORelatedRecords(order_id);

                    //response.write('Created copy SOs, Internal ID is ' + copies.join(', '));

                    nlapiSetRedirectURL("RECORD", 'salesorder', order_id);

                } else {
                    response.write('只有一个Split块，对不起，不能分啊！！');
                }

            }
        }
    } else if (depId == 'customdeploy_sl_ui_order_merge') {
        mergeOrders(request, response);
    }


    //} catch (e) {
    //    e = processException(e);
    //    response.write('有问题，请不要继续操作！ 请联系 IT人员！ - ' + e.getMessage())
    //}
}
function bufaSO(order_id) {

    var bufaSO = nlapiCopyRecord('salesorder', order_id);

    var otherrefnum = bufaSO.getFieldValue('otherrefnum');

    bufaSO.setFieldValue('otherrefnum', otherrefnum + '-BUFA');
    bufaSO.setFieldValue('custbody_order_type', 2); // 2 补发单
    bufaSO.setFieldValue('custbody_parent_sales_order', order_id);
    bufaSO.setFieldValue('custbody_zake_ischildorder', 'T');

    restCopySO(bufaSO);

    bufaSO.setFieldValue('custbody_tracked', 'T');
    bufaSO.setFieldValue('custbody_tracking_number_sync', 'T');      // Ebay 不要清空！需要再次上传

    bufaSO.setFieldValue('shippingcost', '');
    var carrierId = bufaSO.getFieldValue('custbody_sz_carrier');
    if (carrierId == 7) { // 7 = 速卖通线上物流
        bufaSO.setFieldValue('custbody_zake_alilogistictype', '');
    }

    // var feeitem = 113345; // or 102214
    var bufaCount = bufaSO.getLineItemCount('item');
    while (bufaCount) {
        // do something
        var item = bufaSO.getLineItemValue('item', 'item', bufaCount);
        if (item == 113345 || item == 102214) {
            bufaSO.removeLineItem('item', bufaCount);
        } else {
            bufaSO.setLineItemValue('item', 'rate', bufaCount, 0);
        }

        bufaCount--;
    }

    var bufaId = nlapiSubmitRecord(bufaSO, true);
    return bufaId;
}

function _deleteRelatedRecords(soId) {

    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', soId),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);
    if (ffSearch != null) {
        if (ffSearch.length == 1) {
            nlapiDeleteRecord('itemfulfillment', ffSearch[0].getId());
        } else {
            _log_email('找到了多个包裹 SO: ' + id, id);
        }
    }

    // 如果有Payment 删除 Payment
    var filters = new Array();
    filters.push(new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational));
    filters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var columns = new Array();
    columns.push(new nlobjSearchColumn('status'));
    columns.push(new nlobjSearchColumn('tranid'));
    var invList = nlapiSearchRecord('invoice', null, filters, columns);

    if (invList != null) {
        _log('invList', invList.length);
        if (invList.length == 1) {
            for (var i = 0; i < invList.length; i++) {
                var id = invList[i].getId();
                var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                    new nlobjSearchFilter('appliedtotransaction', null, 'anyof', [id])
                ], [
                    new nlobjSearchColumn('total'),
                    new nlobjSearchColumn('total', 'appliedToTransaction')
                ]);
                if (pmtSearch != null) {
                    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId());
                }
                nlapiDeleteRecord('invoice', id);
            }
        } else {
            _log_email('SO for multi invoice', soId);
        }

    }
}

/**
 * 清空SO as new
 * @param copySO
 */
function restCopySO(copySO) {
    copySO.setFieldValue('custbody_script_memo', 'copy sales order');
    copySO.setFieldValue('custbody_out_of_stock', 'F');

    copySO.setFieldValue('custbody_tw_fulfillment_status', null);
    copySO.setFieldValue('custbody_taiwu_fulfill_status_code', null);
    copySO.setFieldValue('custbody_taiwu_bill_status_code', null);

    copySO.setFieldValue('custbody_sz_carrier', null);
    copySO.setFieldValue('custbody_ship_method_sz', null);
    copySO.setFieldValue('custbody_sz_carrier_trackingnumber', '');
    copySO.setFieldValue('custbody_carrier_shipment_number', '');

    copySO.setFieldValue('custbody_automated_processed', 'F');

    //copySO.setFieldValue('custbody_api_data', '');
    copySO.setFieldValue('custbody_carrier_api_request', '');
    copySO.setFieldValue('custbody_carrier_api_response', '');

    copySO.setFieldValue('custbody_shippinglabel_info', '');
    copySO.setFieldValue('custbody_zake_fulfillmentjson', '');
    // copySO.setFieldValue('custbody_zake_haschildorder', 'F');
}

// https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=956&deploy=1&action=split&order_id=21916927
//function splitOrder(id) {
//    var form = nlapiCreateForm("分单", false);
//    form.setScript('customscript_ssu');
//    form.setScript('customscript_cs_utils');
//    var html = JSON.stringify(_getOrderInfo(id));
//    _log('html', html);
//    //form.addField("custpage_ui_html", "inlinehtml")
//    //    .setDefaultValue('<h1>Hello</h1>');
//    // .setDefaultValue("<pre>" + html + "</pre>");
//
//
//    return form;
//}

function _getOrderInfo(orderId) {
    var so = nlapiLoadRecord('salesorder', orderId);
    var items = [];
    var count = so.getLineItemCount('item');
    for (var line = 1; line <= count; line++) {

        var id = so.getLineItemValue('item', 'item', line);
        //var fee = '';
        //if (id == 113345) {
        //    fee = 'fee';
        //}
        items.push({
            id: id,
            location: so.getLineItemText('item', 'location', line),
            name: so.getLineItemText('item', 'item', line),

            custcol_item_weight: so.getLineItemValue('item', 'custcol_item_weight', line),
            custcol_weightunit: so.getLineItemValue('item', 'custcol_weightunit', line),

            quantity: so.getLineItemValue('item', 'quantity', line),
            quantitybackordered: so.getLineItemValue('item', 'quantitybackordered', line)
            // disabled: disabled
        })
    }

    return {
        order_id: orderId,
        orderstatus: so.getFieldValue('orderstatus'),
        otherrefnum: so.getFieldValue('otherrefnum'),
        custbody_total_weight: so.getFieldValue('custbody_total_weight'),
        tranid: so.getFieldValue('tranid'),
        items: items,
        items_stringify: JSON.stringify(items)
    }
}
//console.log(JSON.stringify(_getOrderInfo(22824923)));


//5913be7823c7ef4e74055e41
//5913be7823c7ef4e74055e42
//
//59140c6d7778486f03625f9a
//59140c6d7778486f03625f9b
//
//这两组分别可以合单的，还未发货，合单后不超过2kg，可以一起发；
//
//591398f3bdc7d843906b7191
//591398f3bdc7d843906b7192
//591398f3bdc7d843906b7193
//
//像这种，可以合单，但是合完单会超过2kg
//系统到时要提示一下报错，看选ems这些物流，还是再拆出来发
function mergeOrders(request, response) {

    var action = request.getParameter('action');

    var form = nlapiCreateForm("合单", false);
    form.setScript('customscript_ui_order_merge');
    form.addButton("custpage_search_so", "搜索", "searchSO();");
    form.addButton("custpage_merge_so", "确认合并", "mergeSO();");

    // customer
    var customer = form.addField('custpage_merge_customer', 'select', '客人', 'customer', null);
    customer.setMandatory(true);
    var custpage_merge_customer = request.getParameter('custpage_merge_customer');
    if (custpage_merge_customer) {
        customer.setDefaultValue(custpage_merge_customer);
    } else {
        // customer.setDefaultValue('16822147'); // TODO: for testing.
    }


    if (!action) {
        response.writePage(form);
    } else if (action == 'search') {

        var col = [
            new nlobjSearchColumn('tranid').setSort(),
            new nlobjSearchColumn('trandate'),
            new nlobjSearchColumn('entity'),
            new nlobjSearchColumn('total'),
            new nlobjSearchColumn('otherrefnum'),
            new nlobjSearchColumn('custbody_marketplace'),
            new nlobjSearchColumn('memo'),
            new nlobjSearchColumn('status'),
            new nlobjSearchColumn('custbody_total_weight'),
            new nlobjSearchColumn('statusref'),
            new nlobjSearchColumn('shipaddress'),
            new nlobjSearchColumn('currency')
        ];

        var search = nlapiSearchRecord('salesorder', null, [
            new nlobjSearchFilter('mainline', null, 'is', 'T'),
            new nlobjSearchFilter('status', null, 'anyof', [
                'SalesOrd:A' // Pending Approval
            ]),
            new nlobjSearchFilter('name', null, 'anyof', [custpage_merge_customer])
        ], col);

        if (search != null) {
            form.addField('custpage_total_weight', 'label', '重量:');
            var subList = form.addSubList("custpage_so_list", "list", "订单列表", null);

            // mark button
            subList.addMarkAllButtons();
            // checkbox
            subList.addField("sm_checkbox", "checkbox", "Select", null);

            subList.addField("sm_id", "text", "No", null);
            subList.addField("sm_tranid", "text", "编号", null);
            subList.addField("sm_trandate", "text", "日期", null);
            subList.addField("sm_entity", "text", "客户名", null);
            subList.addField("sm_shipaddress", "text", "客人地址", null);
            subList.addField("sm_total", "text", "金额", null);
            subList.addField("sm_currency", "text", "Currency", null);
            subList.addField("sm_otherrefnum", "text", "PO#", null);
            subList.addField("sm_custbody_marketplace", "text", "Marketplace", null);
            subList.addField("sm_memo", "text", "备注", null);
            subList.addField("sm_status", "text", "状态", null);
            subList.addField("sm_weight", "text", "Weight", null);
            subList.addField("sm_internalid", "text", "ID", null);


            var i = 0, len = search.length;
            var index = 0; //(startPage - 1) * perpage_quantity;
            for (; i < len; i++) {

                var searchResult = search[i];
                var line = i + 1;
                index++;

                subList.setLineItemValue("sm_checkbox", line, 'F');
                subList.setLineItemValue("sm_id", line, index.toString());
                subList.setLineItemValue("sm_tranid", line, searchResult.getValue('tranid'));
                subList.setLineItemValue("sm_trandate", line, searchResult.getValue('trandate'));
                subList.setLineItemValue("sm_entity", line, searchResult.getText('entity'));
                subList.setLineItemValue("sm_shipaddress", line, searchResult.getValue('shipaddress'));
                subList.setLineItemValue("sm_total", line, searchResult.getValue('total'));
                subList.setLineItemValue("sm_currency", line, searchResult.getText('currency'));
                subList.setLineItemValue("sm_otherrefnum", line, searchResult.getValue('otherrefnum'));
                subList.setLineItemValue("sm_custbody_marketplace", line, searchResult.getText('custbody_marketplace'));
                subList.setLineItemValue("sm_memo", line, searchResult.getValue('memo'));
                subList.setLineItemValue("sm_status", line, searchResult.getText('status'));
                subList.setLineItemValue("sm_weight", line, searchResult.getValue('custbody_total_weight') + 'G');
                subList.setLineItemValue("sm_internalid", line, searchResult.getId());
            }
        } else {
            form.addField("custpage_message", "label", "木有搜索结果！");
        }


        response.writePage(form);
    } else if (action == 'doMerge') {

        var mergeList = request.getParameter('list');
        _log('mergeList', mergeList);
        mergeList = mergeList.split(',');

        var copySO = nlapiCopyRecord('salesorder', mergeList[0]);

        // 先清空items
        var itemCount = copySO.getLineItemCount('item');
        while (itemCount) {
            //console.log(itemCount);
            // Do delete
            copySO.removeLineItem('item', itemCount);
            itemCount--;
        }

        copySO.setFieldValue('shippingcost', '');

        var copyItems = [];
        var otherrefnum = [];
        var ebayOrderIDList = [];
        var tranid = [];
        var shippingcost = [];
        var custbody_paypal_transaction_id = [];
        for (var k = 0; k < mergeList.length; k++) {
            var subSOId = mergeList[k];
            var subSORec = nlapiLoadRecord('salesorder', subSOId);
            var subSOItemCount = subSORec.getLineItemCount('item');
            tranid.push(subSORec.getFieldValue('tranid'));
            otherrefnum.push(subSORec.getFieldValue('otherrefnum'));
            custbody_paypal_transaction_id.push(subSORec.getFieldValue('custbody_paypal_transaction_id'));
            ebayOrderIDList.push(subSORec.getFieldValue('custbody_ebay_order_id'));
            shippingcost.push(subSORec.getFieldValue('shippingcost'));
            for (var a = 1; a <= subSOItemCount; a++) {
                copyItems.push({
                    item: subSORec.getLineItemValue('item', 'item', a),
                    location: subSORec.getLineItemValue('item', 'location', a),
                    rate: subSORec.getLineItemValue('item', 'rate', a),
                    quantity: subSORec.getLineItemValue('item', 'quantity', a),
                    custcol_wish_itemid: subSORec.getLineItemValue('item', 'custcol_wish_itemid', a),

                    custcol_ebay_item_id: subSORec.getLineItemValue('item', 'custcol_ebay_item_id', a),
                    custcol_ebay_transaction_id: subSORec.getLineItemValue('item', 'custcol_ebay_transaction_id', a),
                    custcol_ebay_transaction_site_id: subSORec.getLineItemValue('item', 'custcol_ebay_transaction_site_id', a)
                });
            }
        }

        var totalcost = 0;
        for (var tindex = 0; tindex < shippingcost.length; tindex++) {
            totalcost += parseFloat(shippingcost[tindex]);
        }
        copySO.setFieldValue('shippingcost', totalcost);

        // 45 个限制
        var tid = tranid.join('|');
        if (tid.length > 45) {
            tid = tid.substring(0, 45);
        }
        copySO.setFieldValue('otherrefnum', tid); // The field otherrefnum contained more than the maximum number ( 45 ) of characters allowed.

        copySO.setFieldValue('custbody_storefront_order', otherrefnum.join('|'));
        copySO.setFieldValue('custbody_ebay_order_id', ebayOrderIDList.join('|'));
        copySO.setFieldValue('custbody_paypal_transaction_id', custbody_paypal_transaction_id.join(','));
        copySO.setFieldValue('orderstatus', 'B');
        copySO.setFieldValue('custbody_zake_ischildorder', 'F'); // 不在乎Caicong的标记
        copySO.setFieldValue('custbody_tracked', 'F');
        restCopySO(copySO);

        copyItems.forEach(function (item) {
            copySO.selectNewLineItem('item');
            copySO.setCurrentLineItemValue('item', 'item', item.item);
            copySO.setCurrentLineItemValue('item', 'location', item.location);
            copySO.setCurrentLineItemValue('item', 'rate', item.rate);
            copySO.setCurrentLineItemValue('item', 'quantity', item.quantity);

            // Wish
            copySO.setCurrentLineItemValue('item', 'custcol_wish_itemid', item.custcol_wish_itemid);

            // Ebay
            copySO.setCurrentLineItemValue('item', 'custcol_ebay_item_id', item.custcol_ebay_item_id);
            copySO.setCurrentLineItemValue('item', 'custcol_ebay_transaction_id', item.custcol_ebay_transaction_id);
            copySO.setCurrentLineItemValue('item', 'custcol_ebay_transaction_site_id', item.custcol_ebay_transaction_site_id);

            copySO.commitLineItem('item');
        });

        copySO.setFieldValue('custbody_order_type', 4); // 4 is 合单
        var parentId = nlapiSubmitRecord(copySO, true);

        for (var b = 0; b < mergeList.length; b++) {

            var soId = mergeList[b];
            var soRec = nlapiLoadRecord('salesorder', soId);
            var count = soRec.getLineItemCount('item');
            for (var c = 1; c <= count; c++) {
                soRec.setLineItemValue('item', 'isclosed', c, 'T');
            }
            soRec.setFieldValue('custbody_parent_sales_order', parentId);
            soRec.setFieldValue('custbody_order_type', 4); // 4 is 合单
            soRec.setFieldValue('custbody_delay_fulfill', 'T');
            soRec.setFieldValue('custbody_delay_bill', 'T');

            nlapiSubmitRecord(soRec, true);

            var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
                new nlobjSearchFilter('createdfrom', null, 'is', soId),
                new nlobjSearchFilter('mainline', null, 'is', 'T')
            ]);
            if (ffSearch != null) {
                if (ffSearch.length == 1) {
                    nlapiDeleteRecord('itemfulfillment', ffSearch[0].getId());
                } else {
                    _log_email('合并SO 关闭订单的时候 删除包裹的时候，，找到了多个包裹 SO: ' + soId, soId);
                }
            }

        }

        _audit('merge for ' + mergeList.length + ' for ' + parentId, nlapiGetContext().getRemainingUsage());

        nlapiSetRedirectURL("RECORD", 'salesorder', parentId);
        // response.write('合了一个新单， ID: ' + parentId)
    } else if (action == 'cancelMerge') {
        var parentSOId = request.getParameter('soId');
        var suborders = nlapiSearchRecord('salesorder', null, [
            new nlobjSearchFilter('mainline', null, 'is', 'T'),
            new nlobjSearchFilter('custbody_order_type', null, 'is', 4),
            new nlobjSearchFilter('custbody_parent_sales_order', null, 'is', parentSOId)
        ]);

        if (suborders != null) {

            for (var x = 0; x < suborders.length; x++) {

                var soId = suborders[x].getId();
                var soRec = nlapiLoadRecord('salesorder', soId);
                var count = soRec.getLineItemCount('item');
                for (var c = 1; c <= count; c++) {
                    soRec.setLineItemValue('item', 'isclosed', c, 'F');
                }
                soRec.setFieldValue('custbody_parent_sales_order', '');
                soRec.setFieldValue('custbody_order_type', 1);
                soRec.setFieldValue('orderstatus', 'A');
                soRec.setFieldValue('custbody_delay_fulfill', 'F');
                soRec.setFieldValue('custbody_delay_bill', 'F');

                nlapiSubmitRecord(soRec, true);
            }


            var parentSORec = nlapiLoadRecord('salesorder', parentSOId);
            var count = parentSORec.getLineItemCount('item');
            for (var c = 1; c <= count; c++) {
                parentSORec.setLineItemValue('item', 'isclosed', c, 'T');
            }
            parentSORec.setFieldValue('custbody_delay_bill', 'T');
            parentSORec.setFieldValue('custbody_delay_fulfill', 'T');
            nlapiSubmitRecord(parentSORec, true);
        }


        nlapiSetRedirectURL("RECORD", 'salesorder', parentSOId);
    }


}

function deleteSORelatedRecords(soId) {

    // 删除包裹
    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', soId),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);
    if (ffSearch != null) {
        if (ffSearch.length == 1) {
            nlapiDeleteRecord('itemfulfillment', ffSearch[0].getId());
        } else {
            _log_email('找到了多个包裹 SO: ' + soId, soId);
        }
    }

    // 删除Invoice
    var invoiceFilters = new Array();
    invoiceFilters.push(new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational));
    invoiceFilters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
    invoiceFilters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var columns = new Array();
    columns.push(new nlobjSearchColumn('status'));
    columns.push(new nlobjSearchColumn('tranid'));
    var invList = nlapiSearchRecord('invoice', null, invoiceFilters, columns);
    if (invList != null) {
        if (invList.length == 1) {
            var id = invList[0].getId();
            var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                new nlobjSearchFilter('appliedtotransaction', null, 'anyof', [id])
            ], [
                new nlobjSearchColumn('total'),
                new nlobjSearchColumn('total', 'appliedToTransaction')
            ]);
            if (pmtSearch != null) {
                nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId());
            }
            nlapiDeleteRecord('invoice', id);
        } else {
            _log_email('SO for multi invoice', soId);
        }

    }
}