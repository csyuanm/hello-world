function run() {
    _updateTrandate();

}

function _updateTrandate() {

    var search = nlapiLoadSearch(null, 2129);
    search = search.runSearch();
    search = search.getResults(0, 1000);


    if (search.length) {

        var yes = [], no = [];
        for (var i = 0, len = search.length; i < len; i++) {

            try {
                //if (i == 10) break;
                var inv = search[i];
                var invId = inv.getId();
                _log('Invoice', invId);
                var apiData = inv.getValue('custbody_api_data', 'createdFrom');
                if (apiData) {
                    apiData = JSON.parse(apiData);
                    var invRec = nlapiLoadRecord('invoice', inv.getId());

                    var paidTime = new Date(apiData.PaidTime);
                    invRec.setFieldValue('custbody_paidtime', nlapiDateToString(paidTime, 'datetimetz'));
                    invRec.setFieldValue('trandate', nlapiDateToString(paidTime, 'date'));

                    nlapiSubmitRecord(invRec, true);

                    var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
                        new nlobjSearchFilter('appliedtotransaction', null, 'is', inv.getId())
                    ]);
                    if (pmtSearch != null) {
                        nlapiSubmitField('customerpayment', pmtSearch[0].getId(), 'trandate', nlapiDateToString(paidTime, 'date'), true);
                    }

                    yes.push(invId);
                } else {
                   // _log_email('No api data from SO', inv.getId());
                }
            } catch (e) {
                processException(e);
            }

            checkGovernance();

        }

        _log_email('Bill update report', JSON.stringify({
            yes: yes,
            no: no
        }, null, 2));

        if (search.length == 1000) {
            var context = nlapiGetContext();
            var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
            _audit('nlapiScheduleScript', status);

        }
    }


}

function _invoiceCheck() {
    var file = nlapiLoadFile(1807297);
    var str = file.getValue(); // mapping.csv

    var papacsv = Papa.parse(str, {header: true});

    if (papacsv.errors.length) {
        throw nlapiCreateError('CSV_ERROR', 'csv errors ' + JSON.stringify(papacsv.errors));
    }
    var csv = papacsv.data;

    _log('csv', csv);

    var resultCSV = [];
    for (var i = 0, len = csv.length; i < len; i++) {

        // if (i == 1) break;
        var obj = {};
        var poNumber = csv[i]['PO/Check Number'];
        obj['PO/Check Number'] = poNumber;

        try {

            _audit('i', poNumber);

            var soSearch = nlapiSearchRecord('salesorder', null, [
                new nlobjSearchFilter('mainline', null, 'is', 'T'),
                new nlobjSearchFilter('otherrefnum', null, 'equalto', poNumber)
            ], [
                new nlobjSearchColumn('status')
            ]);

            if (soSearch != null && soSearch.length == 1) {
                var soId = soSearch[0].getId();
                var status = soSearch[0].getValue('status');
                if (status == 'closed') {

                    var existingInvoiceSearch = nlapiSearchRecord('invoice', null, [
                        new nlobjSearchFilter('createdfrom', null, 'is', soId),
                        new nlobjSearchFilter('mainline', null, 'is', 'T')
                    ]);

                    if (existingInvoiceSearch == null) {
                        _openSORec(soId);

                        var invoice = nlapiTransformRecord('salesorder', soId, 'invoice', {
                            recordmode: 'dynamic',
                            customform: 409
                        });

                        // 收款OK用 Invoice原生的状态来标识
                        invoice.setFieldValue('custbody_taiwu_bill_status_code', '13'); // Bill OK
                        invoice.setFieldValue('custbody_script_memo', 'Billed by script. 太武国际');
                        nlapiSubmitRecord(invoice, true);

                        _closeSORec(soId);

                        obj.Billed = 'To invocie is OK';
                    } else {
                        obj.Billed = 'has invocie already';
                    }

                }

                else if (status == 'partiallyFulfilled' || status == 'pendingBilling' || status == 'pendingFulfillment') {
                    partiallyFulfilled_bill(soId, obj);
                }

                else {
                    obj.Billed = 'no bill for ' + status;
                }

            } else {
                obj.Billed = 'some issues';
            }


        } catch (e) {
            e = processException(e);
            obj.Billed = e.getUserMessage();
        }
        resultCSV.push(obj);
        checkGovernance();
    }

    var csvContent = Papa.unparse(resultCSV, {
        quotes: true
    });

    var resultFile = nlapiCreateFile('PendingBilling_B.csv', 'CSV', csvContent);
    resultFile.setFolder(9741);
    nlapiSubmitFile(resultFile);
}
function partiallyFulfilled_bill(soId, obj) {

    var existingInvoiceSearch = nlapiSearchRecord('invoice', null, [
        new nlobjSearchFilter('createdfrom', null, 'is', soId),
        new nlobjSearchFilter('mainline', null, 'is', 'T')
    ]);

    if (existingInvoiceSearch == null) {

        var invoice = nlapiTransformRecord('salesorder', soId, 'invoice', {
            recordmode: 'dynamic',
            customform: 409
        });

        // 收款OK用 Invoice原生的状态来标识
        invoice.setFieldValue('custbody_taiwu_bill_status_code', '13'); // Bill OK
        invoice.setFieldValue('custbody_script_memo', 'Billed by script. 太武国际');
        nlapiSubmitRecord(invoice, true);

        obj.Billed = 'To invocie is OK';
    } else {
        obj.Billed = 'has invocie already';
    }
}
function _closeSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'T');
    }
    nlapiSubmitRecord(soRec, true);
}


function _openSORec(soId) {
    var soRec = nlapiLoadRecord('salesorder', soId);
    for (var i = 1; i <= soRec.getLineItemCount('item'); i++) {
        soRec.setLineItemValue('item', 'isclosed', i, 'F');
    }
    nlapiSubmitRecord(soRec, true);
}


//function _backup(){
//    var size = 1000;
//    var start = 0;
//
//    do {
//
//        var search = nlapiLoadSearch(null, '2080');
//        search = search.runSearch();
//        search = search.getResults(start * size, (start + 1) * size);
//        _audit('paging', start * size + ' - ' + (start + 1) * size);
//        if (search.length) {
//            for (var i = 0, len = search.length; i < len; i++) {
//
//                var pmt = search[i];
//                //if (i == 1) break;
//                _log('pmt', pmt.getId());
//
//                var pmtRec = nlapiLoadRecord('customerpayment', pmt.getId());
//                var applyItems = [];
//                var count = pmtRec.getLineItemCount('apply');
//                for (var line = 1; line <= count; line++) {
//                    applyItems.push({
//                        internalid: pmtRec.getLineItemValue('apply', 'internalid', line),
//                        trantype: pmtRec.getLineItemValue('apply', 'trantype', line)
//                    });
//                }
//                _log('applyItems', applyItems);
//                if (applyItems.length == 1) {
//                    if (applyItems[0].trantype == 'CustInvc') {
//                        var fieldObject = nlapiLookupField('invoice', applyItems[0].internalid, [
//                            'custbody_ebay_order_id',
//                            'custbody_storefront_order',
//                            'custbody_marketplace',
//                            'custbody_linked_ebay_account',
//                            'otherrefnum',
//                            'custbody_paypal_transaction_id',
//                            'custbody_bank_account'
//                        ]);
//                        _log('fieldObject', fieldObject);
//                        for (var name in fieldObject) {
//                            if (name == 'otherrefnum') {
//                                pmtRec.setFieldValue('custbody_ref_number', fieldObject['otherrefnum']);
//                            } else {
//                                pmtRec.setFieldValue(name, fieldObject[name]);
//                            }
//                        }
//                        nlapiSubmitRecord(pmtRec, true);
//                    }
//                }
//                _auditUsage();
//                checkGovernance();
//            }
//        }
//
//        start++;
//    } while (search.length);
//}
