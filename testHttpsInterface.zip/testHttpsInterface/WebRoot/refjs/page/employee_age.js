function employeeInit(type,from) {
	var idNumber = nlapiGetFieldValue('custentity_identification_number');
    nlapiLogExecution('debug', 'info', 'type:'+type);
   if('view' == type){
	 	if(idNumber == '' || idNumber == null){
			nlapiSetFieldValue('custentity_age', 0);
			return ;
		}
		var today = new Date();
		var month = today.getMonth();
		var day = today.getDate();
		var age = today.getFullYear() - idNumber.substring(6, 10) - 1;
		if (idNumber.substring(10, 12) < month
				|| idNumber.substring(10, 12) == month
				&& idNumber.substring(12, 14) <= day) {
			age++;
		}
		nlapiSetFieldValue('custentity_age', age);
	   nlapiLogExecution('debug', 'info', '>>>>>>>>>'+idNumber);
   }
 

}

