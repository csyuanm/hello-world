//值改变的调整
function fieldChanged(type, name, linenum){
	 console.log('type: ' + type + ' name: ' + name + ' linenum: ' + linenum);
	 //1所有商城2有赞商城3京东商城
	 var eshoptype = nlapiGetFieldValue('custitem_e_shop'); //商城类型
	 console.log("eshoptype:" + eshoptype + "====name:" + name);
}