// file : yanwen_ship_trigger.js
// date : 03/06/2015
// dev : Bill Jin

function replacer(key, value){
    if (typeof value == "number" && !isFinite(value)){
        return String(value);
    }
    return value;
}

function padStr(i) {
    return (i < 10) ? "0" + i : "" + i;
}

function printDate(now) {
   var now = new Date();
   var dateStr = padStr(now.getFullYear()) + "-" +
                  padStr(1 + now.getMonth()) + "-" +
                  padStr(now.getDate()) + "T" +
                  padStr(now.getHours()) + ":" +
                  padStr(now.getMinutes()) + ":" +
                  padStr(now.getSeconds());
   return dateStr;
}

function clone(obj) {
    if (null == obj || "object" != typeof obj) return obj;
    var copy = obj.constructor();
    for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
    }
    return copy;
}

function getKitInfo(id, record, data, pricelevel, count)
{
	var item1 = nlapiLoadRecord('kititem', id, {recordmode: 'dynamic'});

	for (var sub = 1; sub <= item1.getLineItemCount("member"); sub ++)
	{
		var temp = clone(record);

		//item1.selectLineItem('member', sub);
		var item_names = item1.getLineItemText("member", "item", sub).split(':');
		if (item_names.length > 1)
		{
			var item_names1 = item_names[item_names.length - 1].trim().replace(/,/g, " ").split(' ');
			temp.Item_Code = item_names1[0].trim().replace(/,/g, " ");
		}
		else
		{
			var item_names1 = item_names[0].trim().replace(/,/g, " ").split(' ');
			temp.Item_Code = item_names1[0].trim().replace(/,/g, " ");
		}
		temp.ItemDescription = item1.getLineItemValue("member", "memberdescr", sub);
		temp.Quantity = item1.getLineItemValue("member", "quantity", sub) * count;

		temp.SalesPrice = "";//item1.getLineItemMatrixValue('price1', 'price', 1, 1);

		var subtype = nlapiLookupField('item', item1.getLineItemValue("member", "item", sub), 'type');

		if (subtype == "Kit")
		{
			getKitInfo(item1.getLineItemValue("member", "item", sub), temp, data, pricelevel, item1.getLineItemValue("member", "quantity", sub) * count);
		}
		else if (subtype == "InvtPart")
		{
			var inv = nlapiLoadRecord('inventoryitem', item1.getLineItemValue("member", "item", sub), {recordmode: 'dynamic'});
			var priceLevels = inv.getLineItemCount("price1");

			for (var lvl = 1; lvl <= priceLevels; lvl ++)
			{
				if (pricelevel == inv.getLineItemValue("price1", "pricelevel", lvl))
				{
					temp.SalesPrice = inv.getLineItemMatrixValue('price1', 'price', lvl, 1);
					break;
				}
			}
			if (temp.SalesPrice == "")
			{
				temp.SalesPrice = inv.getLineItemMatrixValue('price1', 'price', 1, 1);
			}
		}

		
		data.data.push(temp);
	}
}

function processItemShipmentToYanwen( type )
{
	try{
		//if ( type != 'userevent' && type != 'skipped' && type != 'userinterface' ) return;
        if ( type != 'edit' && type != 'pack' && type != 'userinterface' ) return;
        
        var user_id = '100000';//'302229';
        var service_type = 'service_sandbox';//'service';
        var user_token = 'MTAwMDAwOjEwMDAwMQ==';//'MzAyMjI5OnRhaXd1Z3Vvamk=';
        var yanwen_url = 'http://online.yw56.com.cn/@service_type/Users/@user_id/Expresses';
        
        yanwen_url = yanwen_url.replace("@user_id", user_id);
        yanwen_url = yanwen_url.replace("@service_type", service_type);
        
        var js_type = nlapiGetRecordType();
        var js_id = nlapiGetRecordId();
        
        if (js_type != "itemfulfillment") return;  

        var tranid = nlapiGetFieldValue('tranid');
        var shipping_address1 = nlapiGetFieldValue('shipaddr1');
        var shipping_address2 = nlapiGetFieldValue('shipaddr2');
        var shipping_city = nlapiGetFieldValue('shipcity');
        var shipping_state = nlapiGetFieldValue('shipstate');
        var shipping_zip = nlapiGetFieldValue('shipzip');
        var shipping_company = nlapiGetFieldValue('shipcompany');
        var shipping_phone = nlapiGetFieldValue('shipphone');
        var shipping_country = nlapiGetFieldText('shipcountry');

        var ship_address = nlapiGetFieldValue('shipaddress');
        var n = ship_address.indexOf(shipping_address1);
        var shipping_name = ship_address.substring(0, n).replace(/\r/g," ").replace(/\n/g," ").replace(/,/g, " ");
        
        // Getting Customer
        var customer_filters = new Array();
        customer_filters[0] = new nlobjSearchFilter('internalid', null, 'is', nlapiGetFieldValue('entity'));

        var customer_columns = new Array();
        customer_columns.push( new nlobjSearchColumn('companyname'));
        customer_columns.push( new nlobjSearchColumn('phone'));
        customer_columns.push( new nlobjSearchColumn('homephone'));
        customer_columns.push( new nlobjSearchColumn('mobilephone'));
        customer_columns.push( new nlobjSearchColumn('email'));
        
        var customer = nlapiSearchRecord( 'customer', null, customer_filters, customer_columns );

        var shipping_email = "";
        
        if (customer)
        {
            shipping_email = customer[0].getValue('email');
        }

        // Getting Shipping fee
        var fee_filters = new Array();
        fee_filters[0] = new nlobjSearchFilter('name', null, 'is', shipping_country);

        var fee_columns = new Array();
        fee_columns.push( new nlobjSearchColumn('name'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yanwen_loc_name_cn'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yanwen_loc_code'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yanwen_bj_china_post_zone'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yw_bj_china_post_rate'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yanwen_dutch_post_base'));
        fee_columns.push( new nlobjSearchColumn('custrecord_yw_dutch_post_rate'));

        var fee = nlapiSearchRecord( 'customrecord_shipping_location_rate_code', null, fee_filters, fee_columns );

        nlapiLogExecution('debug', 'Shipping Info', tranid + ":" + shipping_address1 + ":" + shipping_address2 + ":" + shipping_city + ":" + shipping_state + ":" + shipping_country + ":" + shipping_zip + ":" + shipping_company + ":" + shipping_phone + ":" + shipping_email + ":" + shipping_name);
                    
        // Getting Item
        var item_name = "";
        var weight = 0;
        var weight_unit = 1;
        var quantity = 0;
        var price = 0;
        var item_shipping_cost = 0;
        var shipping_cost = 0;
        var currency = "CNY";
        var memo = "";
        var channel = "";
        var item_count = nlapiGetLineItemCount("item");

        for (var i = 1; i <= item_count; i ++)
        {
            item_name = nlapiGetLineItemValue('item', 'itemname', i);
            quantity = parseFloat(nlapiGetLineItemValue('item', 'quantity', i));
            item_shipping_cost = 0;
            
            nlapiLogExecution('debug', 'Item Info', item_name + ":" + nlapiGetLineItemValue('item', 'itemtype', i) + ":" + quantity + ":" + nlapiGetLineItemValue('item', 'item', i) + ":" + channel);
            
            var record_name = "inventoryitem";
            switch (nlapiGetLineItemValue('item', 'itemtype', i))
            {
                case "InvtPart":
                    record_name = "inventoryitem";
                    break;                
                case "NonInvtPart":
                    record_name = "noninventoryitem";
                    break;                
                case "Kit":
                    record_name = "kititem";
                    break;                
                case "OthCharge":
                    record_name = "otherchargeitem";
                    break;                
                case "Service":
                    record_name = "serviceitem";
                    break;                
            }
            
            
            var item = nlapiLoadRecord(record_name, nlapiGetLineItemValue('item', 'item', i));
            if (item)
            {
                weight_unit = 1;
                switch (item.getFieldValue("weightunit"))
                {
                    case "1":
                        weight_unit = 453.592;
                        break;
                    case "2":
                        weight_unit = 28.3495;
                        break;
                    case "3":
                        weight_unit = 1000;
                        break;
                    case "4":
                        weight_unit = 1;
                        break;
                }
                weight = parseFloat(item.getFieldValue("weight")) * weight_unit;
                price = parseFloat(item.getFieldValue("custitem_cost_rmb"));
                memo = item.getFieldValue("salesdescription");
                channel = item.getFieldValue("custitem_china_shipping_method");
                
                // Yanwen Shipping
                var data = "<ExpressType><Epcode></Epcode><Userid>";
                var url = 'http://209.190.75.64/Bill/SubmitInvoiceToFTP.php';
                var headers = {"Content-Type": "text/xml; charset=utf-8", "Authorization": "basic " + user_token};
                
                data = data + user_id + "</Userid><Channel>";

                if (channel == "China Post")
                {
                    if (fee)
                        item_shipping_cost = weight * quantity * parseFloat(fee[0].getValue('custrecord_yw_bj_china_post_rate'));
                    data = data + "北京EMS";
                }
                else if (channel == "Dutch Post")
                {
                    if (fee)
                        item_shipping_cost = weight * quantity * parseFloat(fee[0].getValue('custrecord_yw_dutch_post_rate')) + parseFloat(fee[0].getValue('custrecord_yanwen_dutch_post_base'));
                    data = data + "荷兰邮政挂号小包(含电)";
                }
                else
                {
                    //continue;
                    if (fee)
                        item_shipping_cost = weight * quantity * parseFloat(fee[0].getValue('custrecord_yw_bj_china_post_rate'));
                    data = data + "北京EMS";
                }
                shipping_cost = shipping_cost + item_shipping_cost;    

                data = data + "</Channel><Package>无</Package><UserOrderNumber>";
                data = data + "IF" + tranid + "</UserOrderNumber><SendDate>" + printDate() + "</SendDate><Receiver><Userid>" + user_id + "</Userid>";
                data = data + "<Name>" + shipping_name + "</Name><Phone>" + shipping_phone + "</Phone><Mobile>" + shipping_phone + "</Mobile><Email>" + shipping_email + "</Email><Company>" + shipping_company + "</Company><Country>" + shipping_country + "</Country>";
                data = data + "<Postcode>" + shipping_zip + "</Postcode><State>" + shipping_state + "</State><City>" + shipping_city + "</City><Address1>" + shipping_address1 + "</Address1><Address2>" + shipping_address2 + "</Address2></Receiver>";
                
                if (memo == null || memo == "null")
                    data = data + "<Memo></Memo>";
                else
                    data = data + "<Memo>" + memo + "</Memo>";
                    
                data = data + "<Quantity>" + quantity + "</Quantity><GoodsName><Userid>" + user_id + "</Userid><NameCh>" + item_name + "</NameCh><NameEn>" + item_name + "</NameEn><Weight>" + weight + "</Weight>";
                data = data + "<DeclaredValue>" + price + "</DeclaredValue><DeclaredCurrency>" + currency + "</DeclaredCurrency></GoodsName></ExpressType>";                
                    
                var response = nlapiRequestURL(yanwen_url, data, headers, null, 'POST');
                var res_xml = nlapiStringToXML(response.getBody());
                nlapiLogExecution('debug', 'Yanwen Response', response.getBody());
                var root_node = nlapiSelectNode( res_xml, "/CreateExpressResponseType" );
                
                if (nlapiSelectValue(root_node, "CallSuccess") == "true")
                {
                    var created_express = nlapiSelectNode( res_xml, "//CreatedExpress" );
                    var epcode = nlapiSelectValue(created_express, "Epcode");
                
                    // Save Yanwen shipping status
                    var state_record = nlapiCreateRecord( 'customrecord_yanwen_shipstatus');
                    
                    state_record.setFieldValue( 'name', "YanwenShipping_" + tranid);
                    state_record.setFieldValue( 'custrecord_tracking_no', epcode);
                    state_record.setFieldValue( 'custrecord_customer_id', nlapiGetFieldValue('entity'));
                    state_record.setFieldValue( 'custrecord_customer_name', shipping_name);
                    state_record.setFieldValue( 'custrecord_item_name', item_name);
                    state_record.setFieldValue( 'custrecord_item_weight', weight);
                    state_record.setFieldValue( 'custrecord_item_quantity', quantity);
                    state_record.setFieldValue( 'custrecord_shipping_cost_cny', item_shipping_cost);
                    state_record.setFieldValue( 'custrecord_shipping_channel', channel);

                    var id = nlapiSubmitRecord(state_record, true);    
                }
                else
                {
                    var response_node = nlapiSelectNode( res_xml, "//Response" );
                    var message = nlapiSelectValue(response_node, "ReasonMessage");
                    var reason = nlapiSelectValue(response_node, "Reason");
                    
                    nlapiLogExecution('debug', 'Yanwen Error Message', reason + ":" + message);
                    alert(reason + ":" + message);
                }
            }
        }
        
        nlapiSetFieldValue('custbody_total_shipping_cost_cny', shipping_cost);
        
	}catch(e){
		nlapiLogExecution('error', 'Yanwen api error', e);
	}
}
