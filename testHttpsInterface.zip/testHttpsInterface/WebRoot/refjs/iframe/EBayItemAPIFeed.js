var EBayItemFeed = {
    __type: "customrecord_ebay_item_api_feed",
    uploadFeedMapping: {
        custrecord_ebay_feed_item: "itemRecordId",
        custrecord_ebay_feed_language: "eBayItemLanguageSetRecordId",
        custrecord_ebay_feed_site: "eBayItemSiteSettingRecordId",
        custrecord_ebay_feed_account: "eBayGlobalAccountSettingRecordId",
        custrecord_ebay_feed_seq: "itemTitlePictureSequenceId",
        custrecord_ebay_feed_push_qty: "custrecord_ei_qty",
        custrecord_ebay_feed_category_id: "site_category_id",
        custrecord_ebay_feed_specifics: "specificList",
        custrecord_ebay_feed_gallery: "gallery",
        custrecord_ebay_feed_body_picture: "bodyPicture",
        custrecord_ebay_feed_api_site: "country",
        custrecord_ebay_feed_api_sku: "sku",
        custrecord_ebay_feed_api_title: "title",
        custrecord_ebay_feed_api_baseprice: "baseprice",
        custrecord_ebay_feed_api_price: "price",
        custrecord_ebay_feed_currency: "currency",
        custrecord_ebay_feed_description: "description",
        custrecord_ebay_feed_language_code: "language_code",
        custrecord_ebay_feed_shippingdetails: "shippingDetails",
        custrecord_ebay_feed_returnpolicy: "returnPolicy",
        custrecord_ebay_feed_paypalaccount: "paypalAccount",
        custrecord_ebay_feed_seller_id: "sellerId",
        custrecord_ebay_feed_ship_ocation: "defaultShipFromLocation",
        custrecord_ebay_feed_token: "token"
    },
    create: function(feed) {
        var record = nlapiCreateRecord(this.__type);
        this.process(record, feed, "create");
        return nlapiSubmitRecord(record, true);
    },
    update: function(id, feed) {
        var record = nlapiLoadRecord(this.__type, id);
        var processResult = this.process(record, feed, "update");
        if (processResult.recordFieldChangedCount) {
            return nlapiSubmitRecord(record, true);
        } else {
            return id;
        }
    },
    search: function(id) {
        var fieldMapping = this.uploadFeedMapping;
        var columns = [];
        for (var i in fieldMapping) {
            columns.push(new nlobjSearchColumn(i));
        }
        [ "internalid", "custrecord_ebay_feed_category_title" ].forEach(function(name) {
            columns.push(new nlobjSearchColumn(name));
        });
        var searchResult = __nlapiSearchRecord(this.__type, null, [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ id ]) ], columns);
        searchResult.list.forEach(function(item, index) {
            index++;
            item.__no = index;
            item.__link = nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", item.internalid.value);
        });
        return searchResult;
    },
    process: function(record, feed, action) {
        var newFeedFieldMapping = this.uploadFeedMapping;
        var recordFieldChangedCount = 0;
        for (var field in newFeedFieldMapping) {
            var feedFieldValue;
            if (feed.hasOwnProperty(newFeedFieldMapping[field])) {
                feedFieldValue = feed[newFeedFieldMapping[field]];
            }
            if (!feedFieldValue) feedFieldValue = null;
            var setFlag = false;
            if (action == "create") {
                setFlag = true;
                recordFieldChangedCount++;
            } else {
                var recordFieldValue = record.getFieldValue(field) || record.getFieldText(field);
                if (Array.isArray(feedFieldValue)) {
                    feedFieldValue = JSON.stringify(feedFieldValue);
                }
                if (recordFieldValue != feedFieldValue) {
                    setFlag = true;
                    recordFieldChangedCount++;
                }
            }
            if (setFlag) {
                record.setFieldValue(field, feedFieldValue);
            }
        }
        _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
        return {
            recordFieldChangedCount: recordFieldChangedCount
        };
    }
};

function run(request, response) {
    runPage(request, response, "Ebay Item Feed List", EBayItemAPIFeed);
}

function EBayItemAPIFeed(request, response) {
    this.filePath = "SuiteScripts/FramePage/iframe/EBayItemAPIFeed.html";
    this.name = "EBayItemAPIFeed";
    var item__internalid = request.getParameter("item__internalid");
    if (item__internalid) {
        this.__InitPageParams = {
            item__internalid: item__internalid
        };
    }
    __FramePage.call(this, request, response);
}

inherit(__FramePage, EBayItemAPIFeed);

EBayItemAPIFeed.prototype.extend({
    __InitPage: function() {
        var item__internalid = this.request.getParameter("item__internalid");
        if (item__internalid) {
            var list = EBayItemFeed.search(item__internalid).list;
            this.renderPage({
                list: [ list[0] ]
            });
        } else {
            this.renderPage();
        }
    },
    __ProcessGetRequest: function(action) {
        if (action == "search") {}
    },
    __ProcessPostRequest: function(action) {}
});

function parseSearchResult(searchResult, columns) {
    var record = {};
    for (var j = 0; j < columns.length; j++) {
        var column = columns[j];
        var name = column.getName();
        var join = column.getJoin();
        if (join) {
            name += "---" + join.toLowerCase();
        }
        record[name] = {
            value: searchResult.getValue(column),
            text: searchResult.getText(column)
        };
    }
    return record;
}