/*! iFrame Resizer (iframeSizer.contentWindow.min.js) - v2.7.1 - 2014-12-12
 *  Desc: Include this file in any page being loaded into an iframe
 *        to force the iframe to resize to the content size.
 *  Requires: iframeResizer.min.js on host page.
 *  Copyright: (c) 2014 David J. Bradshaw - dave@bradshaw.net
 *  License: MIT
 */
!function() {
    "use strict";
    function a(a, b, c) {
        "addEventListener" in window ? a.addEventListener(b, c, !1) : "attachEvent" in window && a.attachEvent("on" + b, c);
    }
    function b(a) {
        return $ + "[" + ab + "] " + a;
    }
    function c(a) {
        Z && "object" == typeof window.console && console.log(b(a));
    }
    function d(a) {
        "object" == typeof window.console && console.warn(b(a));
    }
    function e() {
        c("Initialising iFrame"), f(), i(), h("background", L), h("padding", O), o(), m(), 
        j(), p(), n(), D("init", "Init message from host page");
    }
    function f() {
        function a(a) {
            return "true" === a ? !0 : !1;
        }
        var b = X.substr(_).split(":");
        ab = b[0], M = void 0 !== b[1] ? Number(b[1]) : M, P = void 0 !== b[2] ? a(b[2]) : P, 
        Z = void 0 !== b[3] ? a(b[3]) : Z, Y = void 0 !== b[4] ? Number(b[4]) : Y, bb = void 0 !== b[5] ? a(b[5]) : bb, 
        J = void 0 !== b[6] ? a(b[6]) : J, N = b[7], V = void 0 !== b[8] ? b[8] : V, L = b[9], 
        O = b[10], fb = void 0 !== b[11] ? Number(b[11]) : fb;
    }
    function g(a, b) {
        return -1 !== b.indexOf("-") && (d("Negative CSS value ignored for " + a), b = ""), 
        b;
    }
    function h(a, b) {
        void 0 !== b && "" !== b && "null" !== b && (document.body.style[a] = b, c("Body " + a + ' set to "' + b + '"'));
    }
    function i() {
        void 0 === N && (N = M + "px"), g("margin", N), h("margin", N);
    }
    function j() {
        document.documentElement.style.height = "", document.body.style.height = "", c('HTML & body height set to "auto"');
    }
    function k() {
        a(window, "resize", function() {
            D("resize", "Window resized");
        });
    }
    function l() {
        a(window, "click", function() {
            D("click", "Window clicked");
        });
    }
    function m() {
        U !== V && (V in jb || (d(V + " is not a valid option for heightCalculationMethod."), 
        V = "bodyScroll"), c('Height calculation method set to "' + V + '"'));
    }
    function n() {
        !0 === J ? (k(), l(), s()) : c("Auto Resize disabled");
    }
    function o() {
        var a = document.createElement("div");
        a.style.clear = "both", a.style.display = "block", document.body.appendChild(a);
    }
    function p() {
        bb && (c("Enable public methods"), window.parentIFrame = {
            close: function() {
                D("close", "parentIFrame.close()", 0, 0);
            },
            getId: function() {
                return ab;
            },
            reset: function() {
                G("parentIFrame.size");
            },
            scrollTo: function(a, b) {
                H(b, a, "scrollTo");
            },
            scrollToOffset: function(a, b) {
                H(b, a, "scrollToOffset");
            },
            sendMessage: function(a, b) {
                H(0, 0, "message", JSON.stringify(a), b);
            },
            setHeightCalculationMethod: function(a) {
                V = a, m();
            },
            setTargetOrigin: function(a) {
                c("Set targetOrigin: " + a), db = a;
            },
            size: function(a, b) {
                var c = "" + (a ? a : "") + (b ? "," + b : "");
                E(), D("size", "parentIFrame.size(" + c + ")", a, b);
            }
        });
    }
    function q() {
        0 !== Y && (c("setInterval: " + Y + "ms"), setInterval(function() {
            D("interval", "setInterval: " + Y);
        }, Math.abs(Y)));
    }
    function r(b) {
        function d(b) {
            (void 0 === b.height || void 0 === b.width || 0 === b.height || 0 === b.width) && (c("Attach listerner to " + b.src), 
            a(b, "load", function() {
                D("imageLoad", "Image loaded");
            }));
        }
        b.forEach(function(a) {
            if ("attributes" === a.type && "src" === a.attributeName) d(a.target); else if ("childList" === a.type) {
                var b = a.target.querySelectorAll("img");
                Array.prototype.forEach.call(b, function(a) {
                    d(a);
                });
            }
        });
    }
    function s() {
        function a() {
            var a = document.querySelector("body"), d = {
                attributes: !0,
                attributeOldValue: !1,
                characterData: !0,
                characterDataOldValue: !1,
                childList: !0,
                subtree: !0
            }, e = new b(function(a) {
                D("mutationObserver", "mutationObserver: " + a[0].target + " " + a[0].type), r(a);
            });
            c("Enable MutationObserver"), e.observe(a, d);
        }
        var b = window.MutationObserver || window.WebKitMutationObserver;
        b ? 0 > Y ? q() : a() : (d("MutationObserver not supported in this browser!"), q());
    }
    function t() {
        function a(a) {
            function b(a) {
                var b = /^\d+(px)?$/i;
                if (b.test(a)) return parseInt(a, K);
                var d = c.style.left, e = c.runtimeStyle.left;
                return c.runtimeStyle.left = c.currentStyle.left, c.style.left = a || 0, a = c.style.pixelLeft, 
                c.style.left = d, c.runtimeStyle.left = e, a;
            }
            var c = document.body, d = 0;
            return "defaultView" in document && "getComputedStyle" in document.defaultView ? (d = document.defaultView.getComputedStyle(c, null), 
            d = null !== d ? d[a] : 0) : d = b(c.currentStyle[a]), parseInt(d, K);
        }
        return document.body.offsetHeight + a("marginTop") + a("marginBottom");
    }
    function u() {
        return document.body.scrollHeight;
    }
    function v() {
        return document.documentElement.offsetHeight;
    }
    function w() {
        return document.documentElement.scrollHeight;
    }
    function x() {
        for (var a = document.querySelectorAll("body *"), b = a.length, d = 0, e = new Date().getTime(), f = 0; b > f; f++) a[f].getBoundingClientRect().bottom > d && (d = a[f].getBoundingClientRect().bottom);
        return e = new Date().getTime() - e, c("Parsed " + b + " HTML elements"), c("LowestElement bottom position calculated in " + e + "ms"), 
        d;
    }
    function y() {
        return [ t(), u(), v(), w() ];
    }
    function z() {
        return Math.max.apply(null, y());
    }
    function A() {
        return Math.min.apply(null, y());
    }
    function B() {
        return Math.max(t(), x());
    }
    function C() {
        return Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
    }
    function D(a, b, d, e) {
        function f() {
            a in {
                reset: 1,
                resetPage: 1,
                init: 1
            } || c("Trigger event: " + b);
        }
        function g() {
            S = n, ib = o, H(S, ib, a);
        }
        function h() {
            return gb && a in Q;
        }
        function i() {
            function a(a, b) {
                var c = Math.abs(a - b) <= fb;
                return !c;
            }
            return n = void 0 !== d ? d : jb[V](), o = void 0 !== e ? e : C(), a(S, n) || P && a(ib, o);
        }
        function j() {
            return !(a in {
                init: 1,
                interval: 1,
                size: 1
            });
        }
        function k() {
            return V in cb;
        }
        function l() {
            c("No change in size detected");
        }
        function m() {
            j() && k() ? G(b) : a in {
                interval: 1
            } || (f(), l());
        }
        var n, o;
        h() ? c("Trigger event cancelled: " + a) : i() ? (f(), E(), g()) : m();
    }
    function E() {
        gb || (gb = !0, c("Trigger event lock on")), clearTimeout(hb), hb = setTimeout(function() {
            gb = !1, c("Trigger event lock off"), c("--");
        }, R);
    }
    function F(a) {
        S = jb[V](), ib = C(), H(S, ib, a);
    }
    function G(a) {
        var b = V;
        V = U, c("Reset trigger event: " + a), E(), F("reset"), V = b;
    }
    function H(a, b, d, e, f) {
        function g() {
            void 0 === f ? f = db : c("Message targetOrigin: " + f);
        }
        function h() {
            var g = a + ":" + b, h = ab + ":" + g + ":" + d + (void 0 !== e ? ":" + e : "");
            c("Sending message to host page (" + h + ")"), eb.postMessage($ + h, f);
        }
        g(), h();
    }
    function I(a) {
        function b() {
            return $ === ("" + a.data).substr(0, _);
        }
        function f() {
            X = a.data, eb = a.source, e(), T = !1, setTimeout(function() {
                W = !1;
            }, R);
        }
        function g() {
            W ? c("FramePage reset ignored by init") : (c("FramePage size reset by host page"), 
            F("resetPage"));
        }
        function h() {
            return a.data.split("]")[1];
        }
        function i() {
            return "iFrameResize" in window;
        }
        function j() {
            return a.data.split(":")[2] in {
                "true": 1,
                "false": 1
            };
        }
        b() && (T && j() ? f() : "reset" === h() ? g() : a.data === X || i() || d("Unexpected message (" + a.data + ")"));
    }
    var J = !0, K = 10, L = "", M = 0, N = "", O = "", P = !1, Q = {
        resize: 1,
        click: 1
    }, R = 128, S = 1, T = !0, U = "offset", V = U, W = !0, X = "", Y = 32, Z = !1, $ = "[iFrameSizer]", _ = $.length, ab = "", bb = !1, cb = {
        max: 1,
        scroll: 1,
        bodyScroll: 1,
        documentElementScroll: 1
    }, db = "*", eb = window.parent, fb = 0, gb = !1, hb = null, ib = 1, jb = {
        offset: t,
        bodyOffset: t,
        bodyScroll: u,
        documentElementOffset: v,
        scroll: w,
        documentElementScroll: w,
        max: z,
        min: A,
        grow: z,
        lowestElement: B
    };
    a(window, "message", I);
}();

if (typeof this.alert == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function processException(e) {
    var code, message;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = "nlobjError";
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + e.getStackTrace().join(", ");
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (this.alert) alert("Something is wrong! Please concat IT team for help. " + code + ": " + message);
    nlapiSendEmail(-5, "59532543@qq.com", code, message);
    return {
        code: code,
        message: message
    };
}

var LOGGING = {
    maxLength: 100,
    logList: [],
    add: function(message) {
        if (typeof message == "object") {
            message = JSON.stringify(message);
        }
        var list = LOGGING.logList;
        list.push(message);
        var maxLength = LOGGING.maxLength;
        if (list.length >= maxLength) {
            var outLength = list.length - maxLength;
            list.splice(0, outLength);
        }
    },
    clear: function() {
        LOGGING.logList = [];
    },
    getDetail: function() {
        return LOGGING.logList.join("\r\n");
    }
};

function _log(title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 2);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
        } else {
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            console.log(message);
        }
    }
}

function _log_email(title, detail) {
    nlapiSendEmail(-5, "59532543@qq.com", title, detail);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function extendFn(Fn) {
    Fn.extend = Fn.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function emailMergeObj(obj, tplId) {
    var emailResult = nlapiLoadFile(tplId).getValue();
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            emailResult = emailResult.replace(new RegExp(k, "g"), obj[o]);
        }
    }
    return emailResult;
}

function createHTML(html, obj) {
    for (var i in obj) {
        var k = "{{" + i + "}}";
        html = html.replace(new RegExp(k, "g"), obj[i]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                record[column.getName()] = {
                    value: search_record.getValue(column),
                    text: search_record.getText(column)
                };
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function getSearchResult(search) {
    var columns = search.getColumns();
    var searchList = [];
    var resultSet = search.runSearch();
    resultSet.forEachResult(function(searchResult) {
        var record = {};
        for (var i = 0; i < columns.length; i++) {
            var column = columns[i];
            record[column.getName()] = {
                value: searchResult.getValue(column),
                text: searchResult.getText(column)
            };
        }
        searchList.push(record);
        return true;
    });
    _log("getSearchResult", searchList);
    return searchList;
}

function groupSearchResult(keys, array, toArray) {
    var group = {};
    array.forEach(function(item) {
        var key = "";
        if (typeof keys == "string") {
            key = item[keys].value;
        } else if (Array.isArray(keys)) {
            key = keys.map(function(key_name) {
                return key += item[key_name].value;
            }).join("___");
        } else {
            key = item["internalid"].value;
        }
        if (group.hasOwnProperty(key)) {
            group[key].push(item);
        } else {
            group[key] = [ item ];
        }
    });
    _log("groupSearchResult", group);
    if (toArray) {
        return obj_to_array(group);
    } else {
        return group;
    }
}

function obj_to_array(obj) {
    var list = [];
    for (var i in obj) {
        list.push(obj[i]);
    }
    return list;
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function parseDataToJSON(data) {
    try {
        if (typeof data == "string") {
            data = data.replace(/(<!--(?:(?!-->).)*-->)/g, "").replace(/\r\n|\n/g, "").trim();
            data = JSON.parse(data);
        }
    } catch (e) {
        alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

function post_to_url(path, params, method) {
    method = method || "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    form.setAttribute("target", "_blank");
    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }
    }
    document.body.appendChild(form);
    form.submit();
}

function openNewTab(url) {
    window.open(url, "_blank");
    window.focus();
}

function bindSelectFn($element, config) {
    var defaultConfig = {
        highlightClass: "warning"
    };
    config = config || {};
    config = $.extend(defaultConfig, config);
    var highlightClass = "warning";
    if (config.hasOwnProperty("highlightClass")) {
        highlightClass = config.highlightClass;
    }
    var $selectAll = $element.find(".selectAll");
    if ($selectAll.length) {
        $selectAll.on("click", function(e) {
            if ($(this).prop("checked") == true) {
                $element.find(".select").each(function() {
                    $(this).prop("checked", true);
                    $(this).closest("tr").addClass(highlightClass);
                });
            } else {
                $element.find(".select").each(function() {
                    $(this).prop("checked", false);
                    $(this).closest("tr").removeClass(highlightClass);
                });
            }
        });
    }
    var $select = $element.find(".select");
    var select_length = $select.length;
    if ($select.length) {
        $select.on("click", function() {
            var $checkbox = $(this);
            var $tr = $(this).closest("tr");
            var selectList = [];
            $select.each(function() {
                selectList.push($(this).prop("checked"));
            });
            if ($checkbox.prop("checked") == true) {
                $tr.addClass(highlightClass);
                var allSelected = selectList.filter(function(item) {
                    return item == true;
                });
                if (allSelected.length == select_length) {
                    $selectAll.length && $selectAll.prop("checked", true);
                }
            } else {
                $tr.removeClass(highlightClass);
                var allCancelled = selectList.filter(function(item) {
                    return item == false;
                });
                if (allCancelled.length == select_length) {
                    $selectAll.length && $selectAll.prop("checked", false);
                }
            }
        });
    }
    if (config.hasOwnProperty("allSelected")) {
        if (config.allSelected == true) {
            window.setTimeout(function() {
                $selectAll.trigger("click");
            }, 300);
        }
    }
}