function getEbayItemFeedList(item__internalid) {
    var itemSiteList = getEbayItemSiteList(item__internalid);
    var uploadList = [];
    for (var i = 0; i < itemSiteList.length; i++) {
        var siteItem = itemSiteList[i];
        var eBayGlobalAccountMapping = siteItem.eBayItemSiteSettingRecord.eBayGlobalAccountMapping;
        for (var j = 0; j < eBayGlobalAccountMapping.length; j++) {
            var eBayGlobalAccountRecord = eBayGlobalAccountMapping[j];
            var sequenceList = [];
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence1 == "T") sequenceList.push("custrecord_title_pic_seq1");
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence2 == "T") sequenceList.push("custrecord_title_pic_seq2");
            for (var k = 0; k < sequenceList.length; k++) {
                var itemTitlePictureSequence = eBayGlobalAccountRecord[sequenceList[k]];
                itemTitlePictureSequence = itemTitlePictureSequence.text;
                var eBayFeedItem = {};
                eBayFeedItem.itemRecordId = siteItem.itemRecordId;
                eBayFeedItem.eBayItemSiteSettingRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemSiteSettingRecordId;
                eBayFeedItem.eBayItemLanguageSetRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.eBayItemLanguageSetRecordId;
                eBayFeedItem.eBayGlobalAccountSettingRecordId = eBayGlobalAccountRecord.eBayGlobalAccountSettingRecordId;
                eBayFeedItem.itemTitlePictureSequenceId = eBayGlobalAccountRecord[sequenceList[k]].value;
                if (!eBayFeedItem.itemTitlePictureSequenceId) continue;
                eBayFeedItem.itemTitlePictureSequence = itemTitlePictureSequence;
                eBayFeedItem.sku = siteItem.itemSKU;
                eBayFeedItem.baseprice = siteItem.baseprice;
                eBayFeedItem.site_category_id = siteItem.eBayItemSiteSettingRecord.custrecord_ei_site_category_id;
                eBayFeedItem.custrecord_ei_qty = siteItem.eBayItemSiteSettingRecord.custrecord_ei_qty;
                eBayFeedItem.specificList = siteItem.eBayItemSiteSettingRecord.specificList;
                eBayFeedItem.country = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_territory_id;
                eBayFeedItem.currency = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_default_currency;
                eBayFeedItem.language_code = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_language_code;
                eBayFeedItem.paypalAccount = eBayGlobalAccountRecord.custrecord_paypal_account_linked;
                eBayFeedItem.sellerId = eBayGlobalAccountRecord.sellerId;
                eBayFeedItem.defaultShipFromLocation = eBayGlobalAccountRecord.custrecord_default_ship_from_location;
                eBayFeedItem.token = eBayGlobalAccountRecord.api_token;
                var seq = itemTitlePictureSequence.split("-");
                if (Array.isArray(seq)) {
                    var titleNo = seq[0].replace("T", "");
                    eBayFeedItem.title = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord["title" + titleNo] || "";
                    eBayFeedItem.description = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_sale_description || "";
                    var gallerySeq = seq[1];
                    eBayFeedItem.gallery = getItemGallery(gallerySeq, siteItem.custitem_ebay_gallery_picture_columns);
                    var bodyPicSeq = seq[2];
                    eBayFeedItem.bodyPicture = getBodyPicture(bodyPicSeq, siteItem.custitem_ebay_body_picture_columns);
                } else {
                    eBayFeedItem.title = null;
                    eBayFeedItem.description = null;
                    eBayFeedItem.gallery = null;
                    eBayFeedItem.bodyPicture = null;
                }
                uploadList.push(eBayFeedItem);
            }
        }
    }
    return uploadList;
}

function getItemGallery(seq, custitem_ebay_gallery_picture_columns) {
    if (!seq) return null;
    var list = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = seq.charAt(i);
        if (no == "0") no = "10";
        if (custitem_ebay_gallery_picture_columns.hasOwnProperty("custitem_ebay_gallery_picture_" + no)) {
            if (custitem_ebay_gallery_picture_columns["custitem_ebay_gallery_picture_" + no]) {
                list.push(custitem_ebay_gallery_picture_columns["custitem_ebay_gallery_picture_" + no]);
            }
        }
    }
    return list;
}

function getBodyPicture(seq, custitem_ebay_body_picture_columns) {
    if (!seq) return null;
    var list = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = null;
        var name = seq.charAt(i);
        switch (name) {
          case "A":
            no = 1;
            break;

          case "B":
            no = 2;
            break;

          case "C":
            no = 3;
            break;

          case "D":
            no = 4;
            break;

          case "E":
            no = 5;
            break;

          case "F":
            no = 6;
            break;

          case "G":
            no = 7;
            break;

          case "H":
            no = 8;
            break;

          case "I":
            no = 9;
            break;

          case "J":
            no = 10;
            break;

          default:
            no = 0;
        }
        no = "custitem_ebay_body_picture_" + no;
        if (custitem_ebay_body_picture_columns.hasOwnProperty(no) && custitem_ebay_body_picture_columns[no]) {
            list.push(custitem_ebay_body_picture_columns[no]);
        }
    }
    return list;
}

function getEbayItemSiteList(item__internalid) {
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]) ];
    var columns = [ new nlobjSearchColumn("internalid"), new nlobjSearchColumn("itemid"), new nlobjSearchColumn("baseprice") ];
    columns.push(new nlobjSearchColumn("internalid", "custrecord_ei_item_link"));
    var custitem_ebay_gallery_picture_columns = [], custitem_ebay_body_picture_columns = [];
    for (var j = 1; j <= 10; j++) {
        custitem_ebay_gallery_picture_columns.push(new nlobjSearchColumn("custitem_ebay_gallery_picture_" + j));
        custitem_ebay_body_picture_columns.push(new nlobjSearchColumn("custitem_ebay_body_picture_" + j));
    }
    columns = columns.concat(custitem_ebay_gallery_picture_columns, custitem_ebay_body_picture_columns);
    var searchResults = nlapiSearchRecord("item", null, filter, columns);
    var itemSiteList = [];
    if (searchResults != null) {
        for (var i = 0; i < searchResults.length; i++) {
            var searchResult = searchResults[i];
            var itemRecord = {
                itemRecordId: searchResult.getValue("internalid"),
                itemSKU: searchResult.getValue("itemid"),
                baseprice: searchResult.getValue("baseprice"),
                custrecord_ei_site_internalid: searchResult.getValue("internalid", "custrecord_ei_item_link")
            };
            itemRecord.eBayItemSiteSettingRecord = itemRecord.custrecord_ei_site_internalid ? loadEbayItemSiteSettingRecord(itemRecord.custrecord_ei_site_internalid) : null;
            itemRecord.custitem_ebay_gallery_picture_columns = setPicture(searchResult, custitem_ebay_gallery_picture_columns);
            itemRecord.custitem_ebay_body_picture_columns = setPicture(searchResult, custitem_ebay_body_picture_columns);
            itemSiteList.push(itemRecord);
        }
    }
    return itemSiteList;
}

function setPicture(searchResult, picture_columns) {
    var picture = {};
    picture_columns.forEach(function(colmun) {
        picture[colmun.getName()] = searchResult.getText(colmun);
    });
    return picture;
}

function loadEbayItemSiteSettingRecord(id) {
    var siteRecord = nlapiLoadRecord("customrecord_ebay_item_site_setting", id);
    var eBayItemSiteSettingRecord = {
        eBayItemSiteSettingRecordId: siteRecord.getId(),
        custrecord_ei_item_link: siteRecord.getFieldValue("custrecord_ei_item_link"),
        custrecord_ei_language_set: siteRecord.getFieldValue("custrecord_ei_language_set"),
        custrecord_ei_use_sequence1: siteRecord.getFieldValue("custrecord_ei_use_sequence1"),
        custrecord_ei_use_sequence2: siteRecord.getFieldValue("custrecord_ei_use_sequence2"),
        custrecord_ei_site_category_id: siteRecord.getFieldValue("custrecord_ei_site_category_id"),
        custrecord_ei_qty: siteRecord.getFieldValue("custrecord_ei_qty"),
        custrecord_ei_ebay_accounts: siteRecord.getFieldValue("custrecord_ei_ebay_accounts"),
        custrecord_ei_site: siteRecord.getFieldValue("custrecord_ei_site")
    };
    var specificList = [];
    for (var i = 0; i < 15; i++) {
        var line = i + 1;
        if (siteRecord.getFieldValue("custrecord_ei_specific" + line) && siteRecord.getFieldValue("custrecord_ei_specific_value" + line)) {
            specificList.push({
                specificName: siteRecord.getFieldValue("custrecord_ei_specific" + line),
                specificValue: siteRecord.getFieldValue("custrecord_ei_specific_value" + line)
            });
        }
    }
    eBayItemSiteSettingRecord.specificList = specificList;
    eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord = loadEbayGlobalSiteSettingRecord(eBayItemSiteSettingRecord.custrecord_ei_site);
    eBayItemSiteSettingRecord.eBayItemLanguageSetRecord = loadEbayItemLanguageSetRecord(eBayItemSiteSettingRecord.custrecord_ei_language_set);
    var eBayAccounts = eBayItemSiteSettingRecord.custrecord_ei_ebay_accounts;
    eBayAccounts = eBayAccounts.split("");
    eBayItemSiteSettingRecord.eBayGlobalAccountMapping = eBayAccounts.map(function(eBayAccountId) {
        return loadEbayGlobalAccountSettingRecord(eBayAccountId);
    });
    return eBayItemSiteSettingRecord;
}

function loadEbayItemLanguageSetRecord(id) {
    var languageRecord = nlapiLoadRecord("customrecord_ebay_item_language", id);
    return {
        eBayItemLanguageSetRecordId: languageRecord.getId(),
        name: languageRecord.getFieldValue("name"),
        custrecord_eil_item_link: languageRecord.getFieldValue("custrecord_eil_item_link"),
        custrecord_eil_sale_description: languageRecord.getFieldValue("custrecord_eil_sale_description"),
        custrecordcustrecord_eil_package_include: languageRecord.getFieldValue("custrecordcustrecord_eil_package_include"),
        custrecord_eil_package_excludes: languageRecord.getFieldValue("custrecord_eil_package_excludes"),
        custrecord_eil_additional_information: languageRecord.getFieldValue("custrecord_eil_additional_information")
    };
}

function loadEbayGlobalAccountSettingRecord(eBayAccountId) {
    _log("Is need cached ?? eBayAccountId", eBayAccountId);
    var eBayAccountRecord = nlapiLoadRecord("customrecord_ebay_accounts", eBayAccountId);
    return {
        eBayGlobalAccountSettingRecordId: eBayAccountRecord.getId(),
        sellerId: eBayAccountRecord.getFieldValue("name"),
        api_token: eBayAccountRecord.getFieldValue("custrecord_ebay_api_token"),
        custrecord_paypal_account_linked: eBayAccountRecord.getFieldText("custrecord_paypal_account_linked"),
        custrecord_title_pic_seq1: {
            value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq1"),
            text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq1")
        },
        custrecord_title_pic_seq2: {
            value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq2"),
            text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq2")
        },
        custrecord_default_ship_from_location: eBayAccountRecord.getFieldText("custrecord_default_ship_from_location")
    };
}

function loadEbayGlobalSiteSettingRecord(ebayGlobalSiteSettingRecordId) {
    _log("ebayGlobalSiteSettingRecordId", ebayGlobalSiteSettingRecordId);
    var customrecord_ebay_global_record = nlapiLoadRecord("customrecord_ebay_global", ebayGlobalSiteSettingRecordId);
    return {
        custrecord_ebay_language_code: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_language_code"),
        custrecord_ebay_territory_id: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_territory_id"),
        custrecord_default_currency: customrecord_ebay_global_record.getFieldText("custrecord_default_currency")
    };
}

function run(request, response) {
    runPage(request, response, "Ebay Item Search", EBayItemSearch);
}

function EBayItemSearch(request, response) {
    this.filePath = "SuiteScripts/FramePage/iframe/EBayItemSearch.html";
    this.name = "EBayItemSearch";
    __FramePage.call(this, request, response);
}

inherit(__FramePage, EBayItemSearch);

EBayItemSearch.prototype.extend({
    __InitPage: function() {
        this.renderPage({
            item__internalid: 303
        });
    },
    __ProcessGetRequest: function(action) {
        if (action == "search") {
            var item__internalid = this.request.getParameter("item__internalid");
            _log("item__internalid", item__internalid);
            var uploadList = getEbayItemFeedList(item__internalid);
            var uploadListLabel = uploadList[0];
            var labels = [];
            for (var name in uploadListLabel) {
                labels.push(name);
            }
            uploadList = uploadList.map(function(item, index) {
                var html = "<tr>";
                index++;
                html += "<td>" + index + "</td>";
                for (var key in item) {
                    if (Array.isArray(item[key])) {
                        if (key == "gallery" || key == "bodyPicture") {
                            var picList = item[key];
                            html += '<td><div style="width: 260px;">';
                            html += picList.map(function(pic) {
                                return '<img width="50px" height="50px" src="' + pic + '" alt=""/>';
                            }).join("");
                            html += "</div></td>";
                        } else {
                            html += "<td>" + item[key].join("<br/>") + "</td>";
                        }
                    } else {
                        if (key == "token") {
                            html += '<td><div style="width: 100px; height: 50px; overflow: hidden">' + item[key] + "</div></td>";
                        } else if (key == "sku") {
                            html += '<td class="text-nowrap">' + item[key] + "</td>";
                        } else {
                            html += "<td>" + item[key] + "</td>";
                        }
                    }
                }
                html += "</tr>";
                return html;
            });
            return extend({
                success: true,
                item__internalid: item__internalid
            }, {
                labels: labels,
                uploadList: uploadList
            });
        }
    },
    __ProcessPostRequest: function() {}
});

function parseSearchResult(searchResult, columns) {
    var record = {};
    for (var j = 0; j < columns.length; j++) {
        var column = columns[j];
        var name = column.getName();
        var join = column.getJoin();
        if (join) {
            name += "---" + join.toLowerCase();
        }
        record[name] = {
            value: searchResult.getValue(column),
            text: searchResult.getText(column)
        };
    }
    return record;
}

function trHTMLBuild(record) {
    var tr_html = "<tr>";
    for (var name in record) {
        var value = record[name].value;
        var text = record[name].text;
        if (value.indexOf(",") != -1) {
            value += " | " + text;
        } else {
            if (text && value != text) {
                value += ": " + text;
            }
        }
        tr_html += '<td class="text-nowrap">' + value + "</td>";
    }
    tr_html += "</tr>";
    return tr_html;
}

function splitJournal(journalObj, itemList) {
    if (journalObj.hasOwnProperty("_index")) {
        journalObj["_index"]++;
    } else {
        journalObj["_index"] = 0;
        journalObj["_size"] = Math.ceil(journalObj.body.items.length / 5);
    }
    journalObj._last = false;
    if (journalObj.body.items.length > 5) {
        var removedItems = journalObj.body.items.splice(0, 5);
        var journalCloneObj = JSON.parse(JSON.stringify(journalObj));
        journalCloneObj.body.items = removedItems;
        itemList.push(journalCloneObj);
        splitJournal(journalObj, itemList);
    } else {
        journalObj._last = true;
        itemList.push(journalObj);
    }
}