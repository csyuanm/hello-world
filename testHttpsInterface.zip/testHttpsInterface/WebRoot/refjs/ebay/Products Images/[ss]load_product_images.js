/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       25 Feb 2015     Sansom L
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Operation types: create, edit, view, copy, print, email
 * @param {nlobjForm} form Current form
 * @param {nlobjRequest} request Request object
 * @returns {Void}
 */
function userEventBeforeLoad(type, form, request){
	try{
		if ( type == 'create' || type == 'edit' ){
			var recId = nlapiGetRecordId();
			form.setScript('customscript_inv_image_load_cl');
			form.addButton('custpage_loadimages', 'Load Images', 'loadProductImagesSet(' + recId + ')');
		}
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on userEventBeforeLoad()', e);
	}
}
