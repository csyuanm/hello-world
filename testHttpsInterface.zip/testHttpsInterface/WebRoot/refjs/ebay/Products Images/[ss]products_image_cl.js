/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       24 Feb 2015     Sansom L
 *
 */

function loadProductImagesSet(id){
	try{
		var itemid = nlapiGetFieldValue('itemid');
		if ( itemid == '' || itemid == null ){
			itemid = jQuery('input#itemid').val();
			if ( itemid == '' || itemid == null ){
				alert('There is no Item Name/Number.');
				return false;
			}			
		}
		
		// search image files in file cabinets
		var filters = [];
		filters[0] = new nlobjSearchFilter('name', null, 'startswith', itemid);
		
		var columns = [];
		columns[0] = new nlobjSearchColumn('name');
		columns[1] = new nlobjSearchColumn('url');
		
		var result = nlapiSearchRecord('file', null, filters, columns);
		
		if ( result ){
			var str1 = '', str2 = '', str3 = '', str4 = '', str5 = '';
			for ( var i = 0; i < result.length; i++ ){
				if ( result[i].getValue('name').indexOf(itemid + '_1') > -1 ){
					str1 += '<img width="100" alt="' + result[i].getValue('name') + '" src="' + result[i].getValue('url') + '" />';
				}
				if ( result[i].getValue('name').indexOf(itemid + '_2') > -1 ){
					str2 += '<img width="100" alt="' + result[i].getValue('name') + '" src="' + result[i].getValue('url') + '" />';
				}
				if ( result[i].getValue('name').indexOf(itemid + '_3') > -1 ){
					str3 += '<img width="100" alt="' + result[i].getValue('name') + '" src="' + result[i].getValue('url') + '" />';
				}
				if ( result[i].getValue('name').indexOf(itemid + '_4') > -1 ){
					str4 += '<img width="100" alt="' + result[i].getValue('name') + '" src="' + result[i].getValue('url') + '" />';
				}
				if ( result[i].getValue('name').indexOf(itemid + '_5') > -1 ){
					str5 += '<img width="100" alt="' + result[i].getValue('name') + '" src="' + result[i].getValue('url') + '" />';
				}
			}
			nlapiSetFieldValue('custitem_picture_set1', str1);
			nlapiSetFieldValue('custitem_picture_set2', str2);
			nlapiSetFieldValue('custitem_picture_set3', str3);
			nlapiSetFieldValue('custitem_picture_set4', str4);
			nlapiSetFieldValue('custitem_picture_set5', str5);
		}

	}catch(e){
		nlapiLogExecution('error', 'unexpected error on loadProductImagesSet()', e);
		alert(e);
	}
}
