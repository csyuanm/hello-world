/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       29 Apr 2015     sansom-pc
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function clientPageInit(type){
	try{
		nlapiSetFieldDisplay('custpage_field_subcategory1', false);
		nlapiSetFieldDisplay('custpage_field_subcategory2', false);
		nlapiSetFieldDisplay('custpage_field_subcategory3', false);
		nlapiSetFieldDisplay('custpage_field_subcategory4', false);
		nlapiSetFieldDisplay('custpage_field_subcategory5', false);
		nlapiSetFieldDisplay('custpage_field_subcategory6', false);
		
		jQuery('span#custrecord_ei_site_category_id_fs').parent().parent().append(cust_button_html);
				
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on page init func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @returns {Boolean} True to continue save, false to abort save
 */
function clientSaveRecord(){
	for (var i = 1; i <= MAX_SPECIFICS; i++) {
		if (jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').css('display') != 'none') {
			//console.log(i + ':' + jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
			nlapiSetFieldValue('custrecord_ei_specific' + i, jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
		} else if (jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').css('display') != 'none') {
			nlapiSetFieldValue('custrecord_ei_specific' + i, jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html());
		} else {
			//console.log(i + ': none');
			//nlapiSetFieldValue('custitem_item_specific_' + i, '');
		}
		var dropdown_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_value');
		if (dropdown_val != null && dropdown_val != '') {
			//console.log(i + '-drop:' + dropdown_val);
			nlapiSetFieldValue('custrecord_ei_specific_value' + i, dropdown_val);
		} else {
			var text_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_text_val');
			//console.log(i + '-text_val:' + text_val);
			if (text_val != null && text_val != '') {
				nlapiSetFieldValue('custrecord_ei_specific_value' + i, text_val);
			} else {
				//nlapiSetFieldValue('custitem_item_specific_' + i + '_value', '');
			}
		}
	}
	return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Boolean} True to continue changing field value, false to abort value change
 */
function clientValidateField(type, name, linenum){
   
    return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){
	try {
		  
		if (name == 'custrecord_ei_site' || name.indexOf('custpage_field_subcategory') > -1) {
			var ebay_site = nlapiGetFieldValue('custrecord_ei_site');
			var site_id = nlapiLookupField('customrecord_ebay_global', ebay_site, 'custrecord_ebay_site_id');
			console.log(site_id);

			if (name == 'custrecord_ei_site') {
				result = ebayCategoryBrowseStep(site_id, 'custrecord_ei_site', 'custpage_field_subcategory1', '0');

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', false);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory1') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory1', 'custpage_field_subcategory2', '1');
				nlapiSetFieldValue('custrecord_ei_site_category_id', nlapiGetFieldValue('custpage_field_subcategory1'));
				nlapiSetFieldValue('custrecord_ei_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory2') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory2', 'custpage_field_subcategory3', '2');
				nlapiSetFieldValue('custrecord_ei_site_category_id', nlapiGetFieldValue('custpage_field_subcategory2'));
				nlapiSetFieldValue('custrecord_ei_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {

					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory3') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory3', 'custpage_field_subcategory4', '3');
				nlapiSetFieldValue('custrecord_ei_site_category_id', nlapiGetFieldValue('custpage_field_subcategory3'));
				nlapiSetFieldValue('custrecord_ei_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {

					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory4') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory4', 'custpage_field_subcategory5', '4');
				nlapiSetFieldValue('custrecord_ei_site_category_id', nlapiGetFieldValue('custpage_field_subcategory4'));
				nlapiSetFieldValue('custrecord_ei_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4'));


				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory5') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory5', 'custpage_field_subcategory6', '5');
				nlapiSetFieldValue('custrecord_ei_site_category_id', nlapiGetFieldValue('custpage_field_subcategory5'));
				nlapiSetFieldValue('custrecord_ei_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4') + ' > ' + nlapiGetFieldText('custpage_field_subcategory5'));


				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
				}

			}


		}

	} catch (e) {
		nlapiLogExecution('error', 'unexpected error on field change func', e);
	}
}
