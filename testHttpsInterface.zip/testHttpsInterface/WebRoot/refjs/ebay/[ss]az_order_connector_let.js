/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       30 Apr 2015     sansom-pc
 *
 */

/**
 * @param {nlobjRequest} request Request object
 * @param {nlobjResponse} response Response object
 * @returns {Void} Any output is written via response object
 */
function order_connection_let(request, response){
	try{
		/*
		 *  @@ Get parameters for mws keys
		**/

		var acc_key = nlapiGetContext().getSetting('script', 'custscript_az_acc_key');
		var keys_obj = get_mws_keys(acc_key);
		var orders = get_az_orders(keys_obj);


	}catch(e){
		nlapiLogExecution('error', 'Unexpected Error', e);
	}
}

function get_az_orders(keys_obj){
	try{

		// get current date obj
		var currentDates = new Date();

		// get before 3mins date obj
		var beforeDates = new Date(currentDates.getTime() - 3 * 60000);

		// get before 1hr date obj
		var afterDates = new Date(currentDates.getTime() - 60 * 60000);


		query = [];
		query.push("Action=ListOrders");
		query.push("SellerId=" + keys_obj.seller_id);
		query.push("MarketplaceId.Id.1=" + keys_obj.market_id);
		query.push("CreatedBefore=" + encodeURIComponent(beforeDates.toISODateTimeString()));
		query.push("CreatedAfter=" + encodeURIComponent(afterDates.toISODateTimeString()));
		query.push("AWSAccessKeyId=" + keys_obj.aws_key);
		query.push("Timestamp=" + encodeURIComponent(currentDates.toISODateTimeString()));
		query.push("Version=2011-01-01");
		query.push("SignatureVersion=2");
		query.push("SignatureMethod=HmacSHA256");
		query.push("OrderStatus.Status.1=Unshipped");
		query.push("OrderStatus.Status.2=PartiallyShipped");
	
		query.sort();

		var signature = "POST\n" + keys_obj.endpoint.replace('https://', '') + "\n/Orders/2011-01-01\n" + query.join('&');

		nlapiLogExecution('debug', 'signature', signature);

		var hash = CryptoJS.HmacSHA256(signature, keys_obj.security_key);
		var hashInBase64 = CryptoJS.enc.Base64.stringify(hash);	
	
		query.push("Signature=" + encodeURIComponent(hashInBase64));

		nlapiLogExecution('debug', 'hash', encodeURIComponent(hashInBase64));

		var url = keys_obj.endpoint + '/Orders/2011-01-01';

		nlapiLogExecution('debug', 'url', url);

		var response = nlapiRequestURL(url, query.join('&'));

		nlapiLogExecution('debug', 'response', response.getBody());


	}catch(e){
		nlapiLogExecution('error', 'Unexpected Error on get_az_orders()', e);
		return false;
	}
}