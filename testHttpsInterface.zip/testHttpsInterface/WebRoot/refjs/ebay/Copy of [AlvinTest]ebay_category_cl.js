/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Feb 2015     Sansom Li
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
	var shortNameofEbay ='';
	var itemNum = '';
	var macroAccountLinked = '';
	var regularAccountLinked= '';

function clientPageInit(type){

	try{
		nlapiSetFieldDisplay('custpage_field_subcategory1', false);
		nlapiSetFieldDisplay('custpage_field_subcategory2', false);
		nlapiSetFieldDisplay('custpage_field_subcategory3', false);
		nlapiSetFieldDisplay('custpage_field_subcategory4', false);
		nlapiSetFieldDisplay('custpage_field_subcategory5', false);
		nlapiSetFieldDisplay('custpage_field_subcategory6', false);
		//load the currency rate 
		if(nlapiGetFieldValue('custitem_current_currency_rate') == ''){
			nlapiSetFieldValue('custitem_current_currency_rate', formatNum(nlapiExchangeRate('USD','CNY')));
		//console.long(nlapiExchangeRate('USD','CNY'));	

		}
		
		console.log(cust_button_html);

		jQuery('span#custitem_ebay_categoryid_fs').parent().parent().append(cust_button_html);
		  nlapiSetFieldDisplay('custpage_ebay_china_shipping_method', false);
		  nlapiSetFieldDisplay('custpage_text_china_shipping_method', false);
		if (type == 'edit'|| type == 'create'){
			if(nlapiGetFieldValue('custitem_ebay_shipping_service') !='' ){
				nlapiSetFieldDisplay('custpage_text_china_shipping_method',true);
				nlapiSetFieldValue('custpage_text_china_shipping_method', nlapiGetFieldValue('custitem_ebay_shipping_service'));
				
			}else {
				nlapiSetFieldValue('custpage_text_china_shipping_method', '');
			}
		}else{
			nlapiSetFieldDisplay('custitem_ebay_shipping_service',true);
			
		}
		
	if (type == 'edit'){
		var item_FirstCoulmn = nlapiGetLineItemText('member', 'item', 1);
		if(item_FirstCoulmn !=''){
			
			var split = item_FirstCoulmn.split(' ');
			var itemNum = split[0];
			 ItemDropdown(itemNum);
		}


	}
		
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on page init func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){

	try{
		
		if(name == 'custitem_ebay_listing_key_item'){
			alert('I am in this function');
			var itemInternalID = nlapiGetFieldValue('custitem_ebay_listing_key_item');
			nlapiSelectLineItem('member', 1);
			nlapiSetCurrentLineItemValue('member', 'item', itemInternalID, true,true);
			//nlapiSetLineItemValue('member', 'item', 0, itemInternalID);
			 nlapiCommitLineItem('member');
		}
		
		
		if ( name == 'custitem_listing_account' || name.indexOf('custpage_field_subcategory') > -1 ){
			var ebay_account = nlapiGetFieldValue('custitem_listing_account');
			var site_id = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid');
			console.log(site_id);
			
			site_id = getEbayGlobalSiteID(site_id);
			
			//short name for Ebay
			shortNameofEbay = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_shortname');
			if (itemNum != ''){
				nlapiSetFieldValue('itemid',  shortNameofEbay +'-'+ itemNum);
			}
			
 var defaultcurr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_default_currency',true);
 	 console.log(defaultcurr);
var sitecountr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid',true);
			console.log(sitecountr);
	var split = sitecountr.split('-');
			var countrycode = nlapiSetFieldValue('custitem_ebay_countrycode',split[1]);
	
			var currencycode = nlapiSetFieldValue('custitem_ebay_currencycode', defaultcurr);
			var context = nlapiGetContext();
			var username = context.getName();
	

 //alert("Hello" + defaultcurr + sitecountr + split[1] );
			
			if ( name == 'custitem_listing_account' )
			{
				result = ebayCategoryBrowseStep(site_id, 'custitem_listing_account', 'custpage_field_subcategory1', '0');
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', false);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}
				
			}
			
			if ( name == 'custpage_field_subcategory1' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory1', 'custpage_field_subcategory2', '1');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory1'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory1'));
					//console.log(JSON.stringify(specifics));
				}		
				
			}
			
			if ( name == 'custpage_field_subcategory2' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory2', 'custpage_field_subcategory3', '2');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory2'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory2'));
					//console.log(JSON.stringify(specifics));
				}			
				
			}
			
			if ( name == 'custpage_field_subcategory3' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory3', 'custpage_field_subcategory4', '3');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory3'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3'));
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory3'));
					//console.log(JSON.stringify(specifics));
				}
				
			}
			
			if ( name == 'custpage_field_subcategory4' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory4', 'custpage_field_subcategory5', '4');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory4'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4'));
					
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory4'));
					//console.log(JSON.stringify(specifics));
				}
				
			}
			
			if ( name == 'custpage_field_subcategory5' ){
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory5', 'custpage_field_subcategory6', '5');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory5'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4') + ' > ' + nlapiGetFieldText('custpage_field_subcategory5'));
				
				
				if( result ){
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
				}else{
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory5'));
					//console.log(JSON.stringify(specifics));
				}
				
			}	
			
			
		}
		

		
		//if ( name == 'custitem_ebay_categoryid' ){
		//	nlapiSetFieldValue('custitem_ebay_category_title', '');
		//}

		
	}catch(e){
		nlapiLogExecution('error', 'unexpected error on field change func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
function clientValidateLine(type){
/*	if ( type == 'member' ){
		jQuery('body').css('overflow', 'hidden');
		popup_select_pictures = popup_select_pictures.replace('_itemid_', nlapiGetCurrentLineItemValue('member', 'item'));
		jQuery('body').append(popup_select_pictures);
	}*/
	
    return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @returns {Boolean} True to continue save, false to abort save
 */
function clientSaveRecord(){
	for ( var i = 1; i <= MAX_SPECIFICS; i++ ){
		if ( jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').css('display') != 'none' )
		{
			//console.log(i + ':' + jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
		}else if ( jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').css('display') != 'none' )
		{
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html());
		}else{
			//console.log(i + ': none');
			//nlapiSetFieldValue('custitem_item_specific_' + i, '');
		}
		var dropdown_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_value');
		if ( dropdown_val != null && dropdown_val != '' )
		{
			//console.log(i + '-drop:' + dropdown_val);
			nlapiSetFieldValue('custitem_item_specific_' + i + '_value', dropdown_val);
		}else{
			var text_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_text_val');
			//console.log(i + '-text_val:' + text_val);
			if ( text_val != null && text_val != '' )
			{
				nlapiSetFieldValue('custitem_item_specific_' + i + '_value', text_val);
			}else{
				//nlapiSetFieldValue('custitem_item_specific_' + i + '_value', '');
			}
		}
	}
	
	
    return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 *   
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Boolean} True to continue changing field value, false to abort value change
 */
function clientValidateField(type, name, linenum){


	if ( name == 'custitem_listing_account' || name.indexOf('custpage_field_subcategory') > -1 ){
		
	}

	
	
if(name == 'item'){

	var column1 = nlapiGetCurrentLineItemText('member', 'item'); 
	var dropdown ='';
	if(column1 != ''){
		var split = column1.split(' ');
		itemNum = split[0];
		alert(itemNum);
		if(shortNameofEbay != ''){
			nlapiSetFieldValue('itemid',  shortNameofEbay +'-'+ itemNum);
		}
		 ItemDropdown(itemNum);
	}


	}

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//this is for the "ITEM NAME/NUMBER"
		if (name=='custitem_ebay_listing_price' || name == 'custitem_listing_account'){
				var ebayListingPrice = nlapiGetFieldValue('custitem_ebay_listing_price');
				if(nlapiGetFieldValue('custitem_listing_account') != ''){
					var ebay_account = nlapiGetFieldValue('custitem_listing_account');
					//alert(ebay_account);
					macroAccountLinked = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_micro_paypal_account_linked',true);
					regularAccountLinked = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_paypal_account_linked',true);
					}
				if (ebayListingPrice >12){
					nlapiSetFieldValue('custitem_ebay_paypal_account_to_use', regularAccountLinked);
			}else{
				nlapiSetFieldValue('custitem_ebay_paypal_account_to_use', macroAccountLinked);
			}
		}


		
    return true;
}


function formatNum(num){
	  var numMatch = String(num).match(/\d*(\.\d{0,5})?/);
	 
	  return (numMatch[0] += numMatch[1] ? '00000'.substr(0, 6 - numMatch[1].length) : '.00000');
	}

function assignItmeNumber(){
	
}


function ItemDropdown(itemNum){
	//nlapiSelectLineItem('item', 1);
	//alert(name);
	jQuery('#sub').remove();
	jQuery('#ebayShipping').remove();
	nlapiSetFieldValue('custitem_ebay_listing_title','');
	//jQuery('#custpage_ebay_title_text').remove();

	var columns = new Array();
	var filter = new nlobjSearchFilter("itemid",null,"is",itemNum);
	
	columns[0] = new nlobjSearchColumn('custitem_product_title_1_en');
	columns[1] = new nlobjSearchColumn('custitem_product_title_2_en');
	columns[2] = new nlobjSearchColumn('custitem_product_title_3_en');
	columns[3] = new nlobjSearchColumn('custitem_porduct_title_1_de');
	columns[4] = new nlobjSearchColumn('custitem_product_title_1_es');
	columns[5] = new nlobjSearchColumn('custitem_product_title_1_fr');
	columns[6] = new nlobjSearchColumn('custitem_item_parcel_classification');
	//columns[0].setSort(true);
	
	var results = nlapiSearchRecord('inventoryitem', null,filter, columns);
	//alert("Done search");
	//alert(results[0].getValue(columns[1] ));
	if(results[0].getValue(columns[1] ) != ''){
		//nlapiSetFieldValue('custitem_ebay_shipping_service', regularAccountLinked);
		
	dropdown = '<div id="sub" > <ul style= "width: 450px;background-color: white;border: solid 1px black;float: left;overflow: hidden;text-overflow: ellipsis;">';
	dropdown +='<li> English 1 ->'+results[0].getValue(columns[0] ) +'</li>';
	dropdown +='<li> English 2 ->'+results[0].getValue(columns[1] ) +'</li>';
	dropdown +='<li> English 3 ->'+results[0].getValue(columns[2] ) +'</li>';
	dropdown +='<li> German	->'+results[0].getValue(columns[3] ) +'</li>';
	dropdown +='<li> Spanish  ->'+results[0].getValue(columns[4] ) +'</li>';
	dropdown +='<li> French   ->'+results[0].getValue(columns[5] ) +'</li>';
	dropdown +='</ul></div>';
	jQuery('#sub').css('background-color', 'grey');
	jQuery('#sub').css('float', 'left');
	jQuery('#sub').css('border', '1px');


	jQuery('#custitem_ebay_listing_title').after(dropdown);
	jQuery('#sub').hide();
	jQuery('#custitem_ebay_listing_title').click(function () {
		
		jQuery('#custitem_ebay_listing_title').next('#sub').show();
		jQuery('#sub li').mouseover(function(){jQuery(this).css('background-color','#B9C6C9') });
		jQuery('#sub li').mouseout(function(){jQuery(this).css('background-color','white') });
		jQuery('#sub li').click(function () {
			var title = jQuery(this).text().split('->');
			nlapiSetFieldValue('custitem_ebay_listing_title',title[1]);
			jQuery('#sub').hide();
			//jQuery('#sub').empty();
            });
        });
				
	}
	var shippingMap = {};
	shippingMap['Economy(China Post)'] = 'EconomyShippingFromOutsideUS';
	shippingMap['Standard(Dutch Post)'] = 'StandardShippingFromOutsideUS';
	shippingMap['ePacket(ePacket)'] = 'ePacketChina';
		//var shippingMap = {'China Post':'Economy Shipping From Outside US', 'Dutch':'Stardard', 'ePacket':'ePacket China' };
		//var ebayShippingMap = {'China Post':'Economy(China Post)', 'Dutch':'Standard(Dutch Post)', 'ePacket':'ePacket(ePacket)' };
		//alert(results[0].getText(columns[6]));
		var shipping = results[0].getText(columns[6]);
		var ebayShippingDropdown = '<div id="ebayShipping" > <ul style= "width: 280px;background-color: white;border: solid 1px black;float: left;overflow: hidden;text-overflow: ellipsis;">';
			if (shipping === "Standard"){
				ebayShippingDropdown +='<li>Economy(China Post) </li>';
				ebayShippingDropdown +='<li>Standard(Dutch Post)</li>';
				ebayShippingDropdown +='<li>ePacket(ePacket)</li>';
				
			}else if (shipping === "Contains Battery/Magnetics"){
				ebayShippingDropdown +='<li>Standard(Dutch Post)</li>';
				ebayShippingDropdown +='<li>ePacket(ePacket)</li>';
			}else if (shipping === "Is Battery"){
				ebayShippingDropdown +='<li>ePacket(ePacket)</li>';
			}
			ebayShippingDropdown+='</ul></div>';
			jQuery('#custitem_ebay_shipping_service').after(ebayShippingDropdown);
			jQuery('#ebayShipping').hide();
			jQuery('#custitem_ebay_shipping_service').click(function () {
				
				jQuery('#ebayShipping').show();
				jQuery('#ebayShipping li').mouseover(function(){jQuery(this).css('background-color','#B9C6C9') });
				jQuery('#ebayShipping li').mouseout(function(){jQuery(this).css('background-color','white') });
				jQuery('#ebayShipping li').click(function () {
					//var title = jQuery(this).text().split('->');
					nlapiSetFieldValue('custitem_ebay_shipping_service',shippingMap[jQuery(this).text()]);
					
					jQuery('#ebayShipping').hide();
					//jQuery('#sub').empty();
		            });
		        });
}
