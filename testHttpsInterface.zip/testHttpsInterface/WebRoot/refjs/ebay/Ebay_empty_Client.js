/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       10 Apr 2015     station
 *
 */

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType 
 * 
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
function clientPageInit(type){
   
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment. 
 * @appliedtorecord recordType
 * 
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */
function clientFieldChanged(type, name, linenum){
	  if (name == 'custitem_listing_account') {

          switch (nlapiGetFieldValue('custitem_listing_account')) {
              case '2':
                  nlapiSetFieldValue('customform', 60, null, true);
                  break;
              case '3':
                  nlapiSetFieldValue('customform', 62, null, true);
                  break;
              case '4':
                  nlapiSetFieldValue('customform', 57, null, true);
                  break;
              case '5':
                  nlapiSetFieldValue('customform', 67, null, true);
                  break;
              case '6':
                  nlapiSetFieldValue('customform', 63, null, true);
                  break;
              case '7':
                  nlapiSetFieldValue('customform', 64, null, true);
                  break;
              case '8':
                  nlapiSetFieldValue('customform', 65, null, true);
                  break;
              case '9':
                  nlapiSetFieldValue('customform', 55, null, true);
                  break;
              case '10':
                  nlapiSetFieldValue('customform', 59, null, true);
                  break;
              case '11':
                  nlapiSetFieldValue('customform', 61, null, true);
                  break;
              case '12':
                  nlapiSetFieldValue('customform', 68, null, true);
                  break;
              case '13':
                  nlapiSetFieldValue('customform', 58, null, true);
                  break;
              case '14':
                  nlapiSetFieldValue('customform', 66, null, true);
                  break;
              case '15':
                  nlapiSetFieldValue('customform', 56, null, true);
                  break;
          }


      }
}

function SetEbayListingKeyItem(itemID){
	alert(itemID);
	return '293';
}
