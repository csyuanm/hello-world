/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       12 Feb 2015     Sansom Li
 *
 */
/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Access mode: create, copy, edit
 * @returns {Void}
 */
var shortNameofEbay = '';
var itemNum = '';
var macroAccountLinked = '';
var regularAccountLinked = '';
var shippingtab = '',
	faqtab = '',
	feedbacktab = '',
	paymenttab = '',
	contacttab = '',
	returntab = '';

function clientPageInit(type) {
	 
	if (type == 'edit') {
		var item_FirstCoulmn = nlapiGetLineItemText('member', 'item', 1);

		if (item_FirstCoulmn != '') {

			var split = item_FirstCoulmn.split(' ');
			var itemNum = split[0];
			// ItemDropdown(itemNum);
			var columns = new Array();
			var filter = new nlobjSearchFilter("itemid", null, "is", itemNum);

			columns[0] = new nlobjSearchColumn('custitem_ebay_categoryid');
			var searchresults = nlapiSearchRecord('inventoryitem', null, filter, columns);
			for (var i = 0; searchresults != null && i < searchresults.length; i++) {
				var searchresult = searchresults[i];
				var invid = searchresult.getId();

			}
			}
	   
		}
	   
			if (type == 'create') {
				AssignAccount();
				var listingAccount = nlapiGetFieldValue('custitem_listing_account');
				if ( listingAccount != null && listingAccount != '' ){
					var EbayAccount = nlapiLoadRecord('customrecord_ebay_accounts', listingAccount);
					shippingtab = EbayAccount.getFieldValue('custrecord_shipping_tab');
					faqtab = EbayAccount.getFieldValue('custrecord_faq_tab');
					feedbacktab = EbayAccount.getFieldValue('custrecord_feedback_tab');
					paymenttab = EbayAccount.getFieldValue('custrecord_payment_tab');
					contacttab = EbayAccount.getFieldValue('custrecord_contact_us_tab');
					returntab = EbayAccount.getFieldValue('custrecord_return_tab');
				}				
				

				var itemInternalID = nlapiGetFieldValue('custitem_ebay_listing_key_item');
			  
				if(itemInternalID != ''){
					  //alert(itemInternalID);
					nlapiSelectLineItem('member', 1);
					nlapiSetCurrentLineItemValue('member', 'item', itemInternalID, true, true);
					//nlapiSetLineItemValue('member', 'item', 0, itemInternalID);
					nlapiCommitLineItem('member');
				}
			}
			nlapiSetFieldValue('taxschedule', 1, false, true);

			//var itemid1 = jQuery("#member_row_1 td:first").text();
		
	

	try {
		nlapiSetFieldDisplay('custpage_field_subcategory1', false);
		nlapiSetFieldDisplay('custpage_field_subcategory2', false);
		nlapiSetFieldDisplay('custpage_field_subcategory3', false);
		nlapiSetFieldDisplay('custpage_field_subcategory4', false);
		nlapiSetFieldDisplay('custpage_field_subcategory5', false);
		nlapiSetFieldDisplay('custpage_field_subcategory6', false);

		//load the currency rate 
		if (nlapiGetFieldValue('custitem_current_currency_rate') == '') {
			nlapiSetFieldValue('custitem_current_currency_rate', formatNum(nlapiExchangeRate('USD', 'CNY')));
			//console.long(nlapiExchangeRate('USD','CNY'));	

		}

		console.log(cust_button_html);

		jQuery('span#custitem_ebay_categoryid_fs').parent().parent().append(cust_button_html);


	} catch (e) {
		nlapiLogExecution('error', 'unexpected error on page init func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Void}
 */

function setTab() {
	alert('hi');
	for (i = 1; i <= n; i++) {
		var con = document.getElementById(name + "body" + i);
		var bar = document.getElementById(name + '' + i);
		bar.className = i == cursel ? "on" : "off";
		con.style.display = i == cursel ? "block" : "none";
	}
}



function clientFieldChanged(type, name, linenum) {

	try {
	  
		if (name == 'custitem_ebay_listing_key_item') {
			var itemInternalID = nlapiGetFieldValue('custitem_ebay_listing_key_item');
			nlapiSelectLineItem('member', 1);
			nlapiSetCurrentLineItemValue('member', 'item', itemInternalID, true, true);
			//nlapiSetLineItemValue('member', 'item', 0, itemInternalID);
			nlapiCommitLineItem('member');
		}




		if (name == 'custitem_listing_account' || name.indexOf('custpage_field_subcategory') > -1) {
			var ebay_account = nlapiGetFieldValue('custitem_listing_account');
			var site_id = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid');
			console.log(site_id);

			site_id = getEbayGlobalSiteID(site_id);

			//short name for Ebay
			shortNameofEbay = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_shortname');

			if (itemNum != '') {
				nlapiSetFieldValue('itemid', shortNameofEbay + '-' + itemNum);
			}

/*	            var defaultcurr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_default_currency', true);
			console.log(defaultcurr);
			var sitecountr = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_ebay_selling_siteid', true);
			console.log(sitecountr);
			var split = sitecountr.split('-');
			var countrycode = nlapiSetFieldValue('custitem_ebay_countrycode', split[1]);

			var currencycode = nlapiSetFieldValue('custitem_ebay_currencycode', defaultcurr);
			var context = nlapiGetContext();
			var username = context.getName();*/


			//alert("Hello" + defaultcurr + sitecountr + split[1] );

			if (name == 'custitem_listing_account') {
				result = ebayCategoryBrowseStep(site_id, 'custitem_listing_account', 'custpage_field_subcategory1', '0');

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', false);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				}

			}

			if (name == 'custpage_field_subcategory1') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory1', 'custpage_field_subcategory2', '1');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory1'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', false);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory1'));
					//console.log(JSON.stringify(specifics));
				}

			}

			if (name == 'custpage_field_subcategory2') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory2', 'custpage_field_subcategory3', '2');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory2'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {

					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', false);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory2'));
					//console.log(JSON.stringify(specifics));
				}

			}

			if (name == 'custpage_field_subcategory3') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory3', 'custpage_field_subcategory4', '3');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory3'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3'));

				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {

					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', false);
					nlapiSetFieldDisplay('custpage_field_subcategory5', false);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory3'));
					//console.log(JSON.stringify(specifics));
				}

			}

			if (name == 'custpage_field_subcategory4') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory4', 'custpage_field_subcategory5', '4');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory4'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4'));


				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', false);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory4'));
					//console.log(JSON.stringify(specifics));
				}

			}

			if (name == 'custpage_field_subcategory5') {
				result = ebayCategoryBrowseStep(site_id, 'custpage_field_subcategory5', 'custpage_field_subcategory6', '5');
				nlapiSetFieldValue('custitem_ebay_categoryid', nlapiGetFieldValue('custpage_field_subcategory5'));
				nlapiSetFieldValue('custitem_ebay_category_title', nlapiGetFieldText('custpage_field_subcategory1') + ' > ' + nlapiGetFieldText('custpage_field_subcategory2') + ' > ' + nlapiGetFieldText('custpage_field_subcategory3') + ' > ' + nlapiGetFieldText('custpage_field_subcategory4') + ' > ' + nlapiGetFieldText('custpage_field_subcategory5'));


				if (result) {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
				} else {
					nlapiSetFieldDisplay('custpage_field_subcategory1', true);
					nlapiSetFieldDisplay('custpage_field_subcategory2', true);
					nlapiSetFieldDisplay('custpage_field_subcategory3', true);
					nlapiSetFieldDisplay('custpage_field_subcategory4', true);
					nlapiSetFieldDisplay('custpage_field_subcategory5', true);
					nlapiSetFieldDisplay('custpage_field_subcategory6', true);
					//var specifics = getEbayCategorySpecifics(site_id, nlapiGetFieldValue('custpage_field_subcategory5'));
					//console.log(JSON.stringify(specifics));
				}

			}


		}


		//if ( name == 'custitem_ebay_categoryid' ){
		//	nlapiSetFieldValue('custitem_ebay_category_title', '');
		//}


	} catch (e) {
		nlapiLogExecution('error', 'unexpected error on field change func', e);
	}
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Sublist internal id
 * @returns {Boolean} True to save line item, false to abort save
 */
function clientValidateLine(type) {
	if (type == 'member') {
		jQuery('body').css('overflow', 'hidden');
		popup_select_pictures = popup_select_pictures.replace('_itemid_', nlapiGetCurrentLineItemValue('member', 'item'));
		jQuery('body').append(popup_select_pictures);
	}
	return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @returns {Boolean} True to continue save, false to abort save
 */
function clientSaveRecord() {
	for (var i = 1; i <= MAX_SPECIFICS; i++) {
		if (jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').css('display') != 'none') {
			//console.log(i + ':' + jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html());
		} else if (jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').css('display') != 'none') {
			nlapiSetFieldValue('custitem_item_specific_' + i, jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html());
		} else {
			//console.log(i + ': none');
			//nlapiSetFieldValue('custitem_item_specific_' + i, '');
		}
		var dropdown_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_value');
		if (dropdown_val != null && dropdown_val != '') {
			//console.log(i + '-drop:' + dropdown_val);
			nlapiSetFieldValue('custitem_item_specific_' + i + '_value', dropdown_val);
		} else {
			var text_val = nlapiGetFieldValue('custpage_field_specific_' + i + '_text_val');
			//console.log(i + '-text_val:' + text_val);
			if (text_val != null && text_val != '') {
				nlapiSetFieldValue('custitem_item_specific_' + i + '_value', text_val);
			} else {
				//nlapiSetFieldValue('custitem_item_specific_' + i + '_value', '');
			}
		}
	}


	return true;
}

/**
 * The recordType (internal id) corresponds to the "Applied To" record in your script deployment.
 * @appliedtorecord recordType
 *
 * @param {String} type Sublist internal id
 * @param {String} name Field internal id
 * @param {Number} linenum Optional line item number, starts from 1
 * @returns {Boolean} True to continue changing field value, false to abort value change
 */
function clientValidateField(type, name, linenum) {


	if (name == 'custitem_listing_account' || name.indexOf('custpage_field_subcategory') > -1) {

	}

	if (name == 'item') {
		//nlapiSelectLineItem('item', 1);
		//alert(name);
		jQuery('#sub').remove();
		nlapiSetFieldValue('custitem_ebay_listing_title', '');
		//jQuery('#custpage_ebay_title_text').remove();
		var column1 = nlapiGetCurrentLineItemText('member', 'item');
		var dropdown = '';
		if (column1 != '') {
			var split = column1.split(' ');
			itemNum = split[0];
			if (shortNameofEbay != '') {
				nlapiSetFieldValue('itemid', shortNameofEbay + '-' + itemNum);
			} else {
				nlapiSetFieldValue('itemid', itemNum);

			}
		}
		//assign value to template
		//SetEbayTemplate(itemNum);
		var columns = new Array();
		var filter = new nlobjSearchFilter("itemid", null, "is", itemNum);

		columns[0] = new nlobjSearchColumn('custitem_product_title_1_en');
		columns[1] = new nlobjSearchColumn('custitem_product_title_2_en');
		columns[2] = new nlobjSearchColumn('custitem_product_title_3_en');
		columns[3] = new nlobjSearchColumn('custitem_porduct_title_1_de');
		columns[4] = new nlobjSearchColumn('custitem_product_title_1_es');
		columns[5] = new nlobjSearchColumn('custitem_product_title_1_fr');
		columns[6] = new nlobjSearchColumn('custitem_item_parcel_classification');
		//	columns[7] = new nlobjSearchColumn('internalid');
		//columns[0].setSort(true);

		var results = nlapiSearchRecord('inventoryitem', null, filter, columns);
		//alert("Done search");
		//alert(results[0].getValue(columns[1] ));
		if (results[0] != null) {
			//nlapiSetFieldValue('custitem_ebay_shipping_service', regularAccountLinked);
			//		nlapiSetFieldValue('custitem_ebay_listing_key_item',results[0].getValue(columns[7]), null, true);
			dropdown = '<div id="sub" > <ul style= "width: 450px;background-color: white;border: solid 1px black;float: left;overflow: hidden;text-overflow: ellipsis;">';
			dropdown += '<li> English 1 ->' + results[0].getValue(columns[0]) + '</li>';
			dropdown += '<li> English 2 ->' + results[0].getValue(columns[1]) + '</li>';
			dropdown += '<li> English 3 ->' + results[0].getValue(columns[2]) + '</li>';
			dropdown += '<li> German	->' + results[0].getValue(columns[3]) + '</li>';
			dropdown += '<li> Spanish  ->' + results[0].getValue(columns[4]) + '</li>';
			dropdown += '<li> French   ->' + results[0].getValue(columns[5]) + '</li>';
			dropdown += '</ul></div>'
			jQuery('#sub').css('background-color', 'grey');
			jQuery('#sub').css('float', 'left');
			jQuery('#sub').css('border', '1px');


			jQuery('#custitem_ebay_listing_title').after(dropdown);
			jQuery('#sub').hide();
			jQuery('#custitem_ebay_listing_title').click(function() {

				jQuery('#custitem_ebay_listing_title').next('#sub').show();
				jQuery('#sub li').mouseover(function() {
					jQuery(this).css('background-color', '#B9C6C9')
				});
				jQuery('#sub li').mouseout(function() {
					jQuery(this).css('background-color', 'white')
				});
				jQuery('#sub li').click(function() {
					var title = jQuery(this).text().split('->');
					nlapiSetFieldValue('custitem_ebay_listing_title', title[1]);
					jQuery('#sub').hide();
					//jQuery('#sub').empty();
				});
			});
		}

	}
	//this is for the "ITEM NAME/NUMBER"
	if (name == 'custitem_ebay_listing_price' || name == 'custitem_listing_account') {
		var ebayListingPrice = nlapiGetFieldValue('custitem_ebay_listing_price');
		if (nlapiGetFieldValue('custitem_listing_account') != '') {
			var ebay_account = nlapiGetFieldValue('custitem_listing_account');
			//alert(ebay_account);
			macroAccountLinked = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_micro_paypal_account_linked', true);
			regularAccountLinked = nlapiLookupField('customrecord_ebay_accounts', ebay_account, 'custrecord_paypal_account_linked', true);
		}
		if (ebayListingPrice > 12) {
			nlapiSetFieldValue('custitem_ebay_paypal_account_to_use', regularAccountLinked);
		} else {
			nlapiSetFieldValue('custitem_ebay_paypal_account_to_use', macroAccountLinked);
		}
	}
	return true;
}

function formatNum(num) {
	var numMatch = String(num).match(/\d*(\.\d{0,5})?/);

	return (numMatch[0] += numMatch[1] ? '00000'.substr(0, 6 - numMatch[1].length) : '.00000');
}

function SetEbayTemplate(invid) {

	var Current = nlapiLoadRecord('inventoryitem', invid);

	var displayname = Current.getFieldValue('displayname');
	var description = Current.getFieldValue('salesdescription');
	var features = Current.getFieldValue('custitem_item_features');
	var width = Current.getFieldValue('custitem_item_width');
	var widthunit = Current.getFieldValue('custitem_width_unit');
	var height = Current.getFieldValue('custitem_item_height');
	var heightunit = Current.getFieldValue('custitem_height_unit');
	var length = Current.getFieldValue('custitem_item_length');
	var lengthunit = Current.getFieldValue('custitem_length_unit');
	var weight = Current.getFieldValue('weight');
	var weightunit = Current.getFieldValue('weightunit');
	var totalweight = weight + weightunit;
	var dimension = '(' + length + 'x' + width + 'x' + height + ')' + '(L x W x H)';
	var packageval1 = Current.getFieldValue('custitem_package_includes');
	var packageval2 = Current.getFieldValue('custitem_package_excludes');
	var packagetotal = packageval1 + packageval2;
	var picture1 = Current.getFieldValue('custitem_picture_set1');

	var picture2 = Current.getFieldValue('custitem_picture_set2');
	var picture3 = Current.getFieldValue('custitem_picture_set3');
	var picture4 = Current.getFieldValue('custitem_picture_set4');
	var picture5 = Current.getFieldValue('custitem_picture_set5');

	var abc = "'mainright'";

	var contentmain = '<script>function setTab(name,cursel,n){for(i=1;i<=n;i++){var con=document.getElementById(name+"body"+i);var bar=document.getElementById(name+""+i);bar.className=i==cursel?"on":"off";con.style.display=i==cursel?"block":"none";}}</script><style> #pro .showsamll img {border: 1px solid #c5c5c5;float: left;height: 88px;margin: 0 15px 15px 0;overflow: hidden;width: 88px;} #pro .showsamll {float: left;height: auto;overflow: hidden;width: 210px;} #undermenu .info02 {float:left; width:874px; height:auto; border:2px solid #d65c33; border-top:0 none; padding:20px; margin-bottom:20px; background:#fff; color:#333333; font:normal 14px Arial; line-height:25px; overflow:hidden;} #mainright6.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) center -170px no-repeat; color:#fff; } #mainright6.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) center -170px no-repeat; color:#000;} #mainright6.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) center -170px no-repeat; color:#000; } #mainright6.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg ) center -170px no-repeat; color:#fff;} #mainright5.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) center -136px no-repeat; color:#fff; }#mainright5.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) center -136px no-repeat; color:#000;}#mainright5.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) center -136px no-repeat; color:#000; }#mainright5.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg ) center -136px no-repeat; color:#fff;} #mainright4.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) center -102px no-repeat; color:#fff; }#mainright4.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) center -102px no-repeat; color:#000;}#mainright4.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) center -102px no-repeat; color:#000; }#mainright4.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg ) center -102px no-repeat; color:#fff;} #mainright3.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) center -68px no-repeat; color:#fff; }#mainright3.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) center -68px no-repeat; color:#000;}#mainright3.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) center -68px no-repeat; color:#000; }#mainright3.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg ) center -68px no-repeat; color:#fff;} #mainright2.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) center -34px no-repeat; color:#fff; }#mainright2.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) center -34px no-repeat; color:#000;}#mainright2.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) center -34px no-repeat; color:#000; }#mainright2.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg ) center -34px no-repeat; color:#fff;} #mainright1.on{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) no-repeat; color:#fff; margin:0px 0px 0px -40px;} #mainright1{margin:0px 0px 0px -40px;} #mainright1.off{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg ) no-repeat; color:#000;  }#mainright1.on:hover{background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_bg.jpg) no-repeat; color:#000;  }#mainright1.off:hover{ background:url(http://www.yalldata.com/downloads/upzone/image/yallstore/NewTemp/menu_hover.jpg) no-repeat; color:#fff;  } #mainright1 ,#mainright2 ,#mainright3 ,#mainright4 ,#mainright5 ,#mainright6{width:83px; height:34px; text-align:left; color:#000; font-size:14px; line-height:34px; padding-left:40px; } .line_navbar li{ width:123px; height:34px; cursor:pointer; border-bottom:3px solid #d25400; float:left; margin-right:2px; } #undermenu {float:left; width:918px; padding-left:6px; margin-bottom:20px; overflow:hidden;}.line_navbar{ width:918px;}</style><div id="rightcol" style="float: left;height: auto;margin-top: 10px;overflow: hidden;width: 924px;"><div id="showproall" style="background: none repeat scroll 0 0 #fff;border: 1px solid #cbcbcb;float: left;height: auto;margin-bottom: 20px;overflow: hidden;padding: 20px 30px 30px;width: 862px;"><div class="title02" style="border-bottom: 5px solid #ff6600;color: #2a2a2a;float: left;font: bold 20px Arial;margin-bottom: 25px;overflow: hidden;padding: 10px 0;text-align: center;width: 862px;">' + displayname + '</div><div id="pro" style="float: left;height: auto;margin-bottom: 30px;overflow: hidden;width: 862px;"><div class="showbig" style="border: 1px solid #c5c5c5;float: left;height: 500px;margin: 0 70px 0 30px;overflow: hidden; width: 500px;">' + picture1 + '</div><div class="showsamll">' + picture2 + picture3 + picture4 + picture5 + '</div></div></div><div class="banner04" style="background:#f4f4f4;border: 1px solid #f2f2f2;box-shadow: 2px 2px 2px #cccccc;float: left;height: auto;margin-bottom: 20px;overflow: hidden;width: 920px;"><div style="background:#ff6633;color:#fff; font-size:20px;font-weight:bold;width:200px;padding:10px 10px 10px 10px">Description</div><div id="info01" style="float: left;overflow: hidden;padding: 60px 20px 20px;width: 880px;"><div id="publishDescription"><strong>Introductions:<br></strong>' + description + '<br><p><strong></strong>&nbsp;</p><p><strong>Features:<br></strong>' + features + '<p><br><strong>Specifications:<br></strong>' + dimension + '<br>Weight:' + totalweight + '<br><br><strong>Package Includes:<br></strong>' + packagetotal + '</div></div></div><div id="undermenu" style="color: #333333;font: 14px/25px Arial;"><div class="line_navbar" style="width: 918px;"><ul><li class="on" id="mainright1" onclick="setTab(' + abc + ',1,6);return false;">Shipping</li><li class="off" id="mainright2" onclick="setTab(' + abc + ',2,6);return false;">Payment</li><li class="off" id="mainright3" onclick="setTab(' + abc + ',3,6);return false;">Return</li><li  class="off" id="mainright4" onclick="setTab(' + abc + ',4,6);return false;">Feedback </li><li  class="off" id="mainright5" onclick="setTab(' + abc + ',5,6);return false;">Contact Us</li><li style="margin-right:0px;"  class="off" id="mainright6" onclick="setTab(' + abc + ',6,6);return false;">FAQ</li><li style=" width:172px; margin-right:0px; "></li></ul></div><div class="info02"><div id="mainrightbody1"><h1 class="color01" style="color: #03a2f6;">Shipping:</h1> <div class="pad01">' + shippingtab + '</div></div><div style="display:none;" id="mainrightbody2"><h1 class="color01" style="color: #03a2f6;">Payment:</h1><div class="pad01">' + paymenttab + '</div></div><div style="display:none;" id="mainrightbody3"><h1 class="color01" style="color: #03a2f6;">Returns:</h1><div class="pad01">' + returntab + '</div></div><div style="display:none;" id="mainrightbody4"><h1 class="color01" style="color: #03a2f6;">Feedback:</h1><div class="pad01"><span class="color02">' + feedbacktab + '</div></div><div style="display:none;" id="mainrightbody5"><h1 class="color01" style="color: #03a2f6;">Contact us:</h1><div class="pad01">' + contacttab + '</div></div><div style="display:none;" id="mainrightbody6"><h1 class="color01" style="color: #03a2f6;">FAQ:</h1> <div class="pad01">' + faqtab + '</div></div> </div></div></div>';
	nlapiSetFieldValue('custitemtemplateebay', contentmain);

}

function AssignAccount(){
	  switch (nlapiGetFieldValue('customform')) {
	 
	  case '60':
		  alert('I am here!!');
		  nlapiSetFieldValue('custitem_listing_account', 2, null, true);
		  break;
	  case '62':
		  nlapiSetFieldValue('custitem_listing_account', 3, null, true);
		  break;
	  case '57':
		  nlapiSetFieldValue('custitem_listing_account', 4, null, true);
		  break;
	  case '67':
		  nlapiSetFieldValue('custitem_listing_account', 5, null, true);
		  break;
	  case '63':
		  nlapiSetFieldValue('custitem_listing_account', 6, null, true);
		  break;
	  case '64':
		  nlapiSetFieldValue('custitem_listing_account', 7, null, true);
		  break;
	  case '65':
		  nlapiSetFieldValue('custitem_listing_account', 8, null, true);
		  break;
	  case '55':
		  nlapiSetFieldValue('custitem_listing_account', 9, null, true);
		  break;
	  case '59':
		  nlapiSetFieldValue('custitem_listing_account', 10, null, true);
		  break;
	  case '61':
		  nlapiSetFieldValue('custitem_listing_account', 11, null, true);
		  break;
	  case '68':
		  nlapiSetFieldValue('custitem_listing_account', 12, null, true);
		  break;
	  case '58':
		  nlapiSetFieldValue('custitem_listing_account', 13, null, true);
		  break;
	  case '66':
		  nlapiSetFieldValue('custitem_listing_account', 14, null, true);
		  break;
	  case '56':
		  nlapiSetFieldValue('custitem_listing_account', 15, null, true);
		  break;
  }			
}




