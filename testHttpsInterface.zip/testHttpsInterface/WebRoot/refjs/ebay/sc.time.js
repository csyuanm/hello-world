function run() {

    //  var utcDatetime = this.moment().utc();

    //var date = new Date();
    //nlapiLogExecution('debug', 'new Date()', date);
    //nlapiLogExecution('debug', 'nlapiDateToString', nlapiDateToString(new Date(), 'datetimetz'));
    nlapiLogExecution('debug', '_Date.getUTCDate()', getUTCDateTime());
    nlapiLogExecution('debug', '---', new Date("2015-12-27T20:32:25.000Z"));
}

function getUTCDateTime() {
    var now = new Date();
    var offset = now.getTimezoneOffset();
    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
    nlapiLogExecution('debug', 'getUTCDateTime', utcDate);
    return utcDate;
}

//function getUTCTime() {
//    var now = new Date();
//    var offset = now.getTimezoneOffset();
//    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
//    nlapiLogExecution('debug', 'utcDate', utcDate);
//    return Date.UTC(utcDate.getFullYear(),
//            utcDate.getMonth(),
//            utcDate.getDate(),
//            utcDate.getHours(),
//            utcDate.getMinutes(),
//            utcDate.getSeconds(),
//            utcDate.getMilliseconds());
//
//}

//// -------- 标准化 on Production Scheduled -----
//var _Date = {
//
////View	Debug	_Date.getChicagoTime()	1/25/2016	10:41 pm	-System-	Mon Jan 25 2016 22:41:05 GMT-0800 (PST)	Remove
////View	Debug	_Date.getUTCDate()	1/25/2016	10:41 pm	-System-	Tue Jan 26 2016 03:41:05 GMT-0800 (PST)	Remove
////View	Debug	nlapiDateToString	1/25/2016	10:41 pm	-System-	1/25/2016 7:41:05 pm	Remove
////View	Debug	new Date()	1/25/2016	10:41 pm	-System-	Mon Jan 25 2016 19:41:05 GMT-0800 (PST)	Remove
//
//    getUTCDate: function () {
//        var now = new Date();
//        var offset = now.getTimezoneOffset();
//        var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
//        return utcDate;
//    },
//
//    getChicagoTime: function () {
//        //// 夏时制 (UTC-5): From 2016年03月13
//        return new Date(this.getUTCDate().getTime() + (-5) * 60 * 60 * 1000);
//    }
//};