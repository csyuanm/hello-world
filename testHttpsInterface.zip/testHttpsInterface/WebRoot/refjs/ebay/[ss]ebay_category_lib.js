/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       12 Feb 2015     Sansom Li
 *
 */

/*
 * @global variables
 */

var EBAY_ACCOUNT_LIST_FIELD = 'custitem_listing_account',
EBAY_API_ENDPOINT = 'https://api.ebay.com/wsapi',
EBAY_OPEN_API_ENDPOINT = 'http://open.api.ebay.com/Shopping?',
EBAY_SITE_ID = '0',
EBAY_LOOT_CATEGORY_ID = '-1',
EBAY_API_VERSION = '897',
EBAY_DEV_ID = 'bb0adac2-2404-4f42-a70f-3412a33e51fc',
EBAY_APP_ID = 'zakeusaf2-c89a-477d-a620-8c8d46f6bdd',
EBAY_CERT_ID = 'c2017a04-a780-456a-86db-a4f994d4e44a',
MAX_SPECIFICS = 15,
MAX_SUB_CATEGORY = 6;

var cust_button_html = '<span style="margin-left: 10px;" class="uir-field"><div id="tbl_custom_is_button" class="uir-button"><div id="tr_custom_is_button" class="pgBntG">';
cust_button_html += '<div id="tdbody_custom_is_button" class="bntBgB"><input type="button" _mousedown="F" style="" class="rndbuttoninpt bntBgT" value="Populate Item Specifics" id="cust_is_button" name="cust_is_button" onclick="populate_item_specifics(); return false;" onmousedown="this.setAttribute(\'_mousedown\',\'T\'); setButtonDown(true, false, this);" onmouseup="this.setAttribute(\'_mousedown\',\'F\'); setButtonDown(false, false, this);" onmouseout="if(this.getAttribute(\'_mousedown\')==\'T\') setButtonDown(false, false, this);" onmouseover="if(this.getAttribute(\'_mousedown\')==\'T\') setButtonDown(true, false, this);">';
cust_button_html += '</div></div></div></span>';

var popup_select_pictures = '<div class="ppp-wrapper" style="background: none repeat scroll 0 0 #000; bottom: 0; display: block; left: 0; opacity: 0.5; overflow: hidden; position: fixed; right: 0; top: 0; z-index: 9000;"></div>';
popup_select_pictures += '<div id="popup_wrapper" style="position:fixed; top:30%; left: 40%; background: none repeat scroll 0 0 #fff; border: 1px solid #696969; border-radius: 2px; font-family: arial; font-size: 14px; width: 320px; line-height:22px; z-index: 9999;">';
popup_select_pictures += '<div style="padding: 20px;  width: 318px;">';
popup_select_pictures += '<div class="description" style="text-align:center; height:30px; line-height:30px; margin-bottom: 10px;">Select Pictures Set for this item.</div>';
popup_select_pictures += '<div id="product_img_set_select" style="text-align:center;">';
popup_select_pictures += '<select rel="_itemid_" id="product_imgs_set"><option value="1">Picture Set1</option><option value="2">Picture Set2</option><option value="3">Picture Set3</option><option value="4">Picture Set4</option><option value="5">Picture Set5</option></select></div>';
popup_select_pictures += '</div><div style="text-align:center; padding-bottom: 20px;"><a style="color:#fff; background: linear-gradient(to bottom, #4c9dff 2%, #187bf2 100%) repeat scroll 0 0 rgba(0, 0, 0, 0) !important; border-color: #125ab2 !important;  border-radius: 3px; border: 1px solid transparent; cursor: pointer; text-align: center; padding:3px 12px;" onclick="chooseImageSet();">Save</a></div></div>';

function get_ebay_category_service_url(siteId, parent_category){
	
	// optional parameters
	siteId = typeof siteId !== 'undefined' ? siteId : EBAY_SITE_ID;
	parent_category = typeof parent_category !== 'undefined' ? parent_category : EBAY_LOOT_CATEGORY_ID;

	// build service endpoints
	var service_url = EBAY_OPEN_API_ENDPOINT;
	service_url += 'callname=GetCategoryInfo&appid=' + EBAY_APP_ID;
	service_url += '&siteid=' + siteId;
	service_url += '&CategoryID=' + parent_category;
	service_url += '&version=' + EBAY_API_VERSION;
	service_url += '&IncludeSelector=ChildCategories';

	nlapiLogExecution('debug', 'service_url', service_url);

	return service_url;
}

function chooseImageSet(){	
	var image_set = jQuery('#product_imgs_set').val();
	
	var image_set_val = nlapiLookupField('item', jQuery('#product_imgs_set').attr('rel'), 'custitem_picture_set' + image_set);
	console.log(image_set_val);
	if ( image_set_val != null && image_set_val != '' ){
		
		var img_html = '<div onclick="saveImageSet();" id="popup_wrapper" style="position:fixed; top:30%; left: 30%; background: none repeat scroll 0 0 #fff; border: 1px solid #696969; border-radius: 2px; font-family: arial; font-size: 14px; width: 480px; line-height:22px; z-index: 9999;">';
		img_html += image_set_val;
		img_html += '</div>';
		
		nlapiSetFieldValue('custitem_picture_set1', image_set_val);
		jQuery('#popup_wrapper').remove();
		jQuery('.ppp-wrapper').attr('onclick', 'saveImageSet();');
		jQuery('body').append(img_html);
	}else{
		alert('No images data!');
		jQuery('#popup_wrapper').remove();
		jQuery('.ppp-wrapper').remove();
		jQuery('body').css('overflow', 'visible');
		nlapiSetFieldValue('custitem_ebay_picture_url', '');
		nlapiSetFieldValue('custitem_picture_set1', '');
	}
	
	var item_id_val = nlapiGetFieldValue('itemid');
	
	if ( item_id_val.indexOf('_') > 0 ){
		item_id_val = item_id_val.substring(0, item_id_val.indexOf('_'));
	}
	
	nlapiSetFieldValue('itemid', item_id_val + '_' + image_set);
	
}

function saveImageSet(){
	var img_arr = [];
	jQuery('#popup_wrapper img').each(function(){
		img_arr.push('https://system.na1.netsuite.com' + jQuery(this).attr('src'));
	});
	nlapiSetFieldValue('custitem_ebay_picture_url', img_arr.join());
	jQuery('#popup_wrapper').remove();
	jQuery('.ppp-wrapper').remove();
	jQuery('body').css('overflow', 'visible');
}

function getEbayGlobalSiteID(siteId){
	siteId = typeof siteId !== 'undefined' ? siteId : '1';
	var index;
	switch ( siteId ){
		case '1':
			index = '0';
			break;
		case '2':
			index = '2';
			break;
		case '3':
			index = '0';
			break;
		case '4':
			index = '0';
			break;
		case '5':
			index = '0';
			break;
		default:
			index = '0';
			break;			
	}
	return index;
}

function ebayCategoryBrowseStep(site_id, prev_fldname, next_fldname, level){
	var response_data;
	
	if ( prev_fldname != 'custitem_listing_account' ){
		if ( !nlapiGetFieldValue(prev_fldname) ){
			alert('This Field Couldn\'t be empty.');
			return false;
		}		
		response_data = nlapiRequestURL(get_ebay_category_service_url(site_id, nlapiGetFieldValue(prev_fldname)));
	}else{
		response_data = nlapiRequestURL(get_ebay_category_service_url(site_id));
	}	
	
	var json_data = xml2json.parser(response_data.getBody());
	
	last_category = false;

	console.log(json_data);
	
	if ( json_data.getcategoryinforesponse.categoryarray.category ){
		
		var category_len = json_data.getcategoryinforesponse.categoryarray.category.length;		
		nlapiRemoveSelectOption(next_fldname, null);		
		
		for ( var i = 0; i < category_len; i++ ){
			var cat_obj = json_data.getcategoryinforesponse.categoryarray.category[i];
			if ( cat_obj.categorylevel != level ){
				if ( !last_category ){
					nlapiInsertSelectOption(next_fldname, '', '', true);
				}
				nlapiInsertSelectOption(next_fldname, cat_obj.categoryid, cat_obj.categoryname, false);
				last_category = true;
			}				
		}
	}
	
	console.log('event:' + last_category);

	//for ( var i = 0; i < specifics_len; i++ ){
	//	nlapiRemoveSelectOption('custpage_field_specific_' + i + '_value', null);
	//	nlapiSetFieldDisplay('custpage_field_specific_' + i + '_value', false);
	//}
	
	return last_category;
}

function getEbayCategorySpecifics(site_id, category_id){
	
	var request_body = '<?xml version="1.0" encoding="utf-8"?>';
	request_body += '<GetCategorySpecificsRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
	request_body += '<RequesterCredentials>';
	request_body += '<eBayAuthToken>AgAAAA**AQAAAA**aAAAAA**fTveVA**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wGkYqiD5WCpQmdj6x9nY+seQ**ArECAA**AAMAAA**sSIYUxrt+lndLgpBTfQTkjfqsH3dLa7FYQo/hZPcG5FVIYz1T9zm5PLV+PapUI76XUYoiarR4JLJkOKhb/XFCqC/OFy8WPCIQCMzVxCZX7B4q6qVnckuv5LrUpO7EUoCM1O6XNLw0w8/ZeZGOO7qY69J9dYDhVjVP3uIzJ0So899yg44UzS8nB75QY6Oe5z/3ZznKGHC8dMOgdgmqiDePSfD44YsD92vW0pam9rokRs7D9w0GSv9UxfxrV+Om1S3lk8C3WdCaOtb5eBb2CzgDMdtSp49f8YIwjZul+FO4q+NUiiKdhmbdRyAHOB+itk4A1Y6pe58iummIbcYROfAbgC94dMCgwhRjp17EFYjrdNanlLpZHKG+i5pq89Pmxnq3gf1g18HW487lBEZLCWEpQKPdrwmEJM3PXPSEOdsS4TRoHqluV7vAxqb2RCW8YgQICQ9SdhRTKwuK2mhpv8evaAowhBGbSQ5zU3FECh6ojWieiHALULnXAH3czAZACpJdfQgCirlVW5WocpWfdsoqKrZGG+smKu3tJ5nAVlVPoQnQTviTxzQCttMooooUP37SLe7XMqxIa2X+/TpmcjAvgmPeTUIxPS/s6xMU389OL2TUzYruIth0oCczMPs8RKl3/IPYcawi9EV0wnt+f7VweXZ6DjaT9ZVahdANNUonHsS0E2DMr2IrstlyntmyfRfuGh/QucBnRNQOsuauY8yOsemHmK4C4c/tj0r1c/UVtJucyfAEtqzly7H2me2rlla</eBayAuthToken>';
	request_body += '</RequesterCredentials>';
	request_body += '<CategoryID>' + category_id + '</CategoryID>';
	request_body += '</GetCategorySpecificsRequest>';
	
	var header = new Array();
	header['X-EBAY-API-SESSION-CERTIFICATE'] = EBAY_DEV_ID + ';' + EBAY_APP_ID + ';' + EBAY_CERT_ID;
	header['X-EBAY-API-COMPATIBILITY-LEVEL'] = EBAY_API_VERSION;
	header['X-EBAY-API-DEV-NAME'] = EBAY_DEV_ID;
	header['X-EBAY-API-APP-NAME'] = EBAY_APP_ID;
	header['X-EBAY-API-CERT-NAME'] = EBAY_CERT_ID;
	header['X-EBAY-API-CALL-NAME'] = 'GetCategorySpecifics';
	header['X-EBAY-API-SITEID'] = site_id;
	header['Content-Type'] = 'text/xml';
	header['Content-Length'] = request_body.length;
	
	var return_val = nlapiRequestURL('https://api.ebay.com/ws/api.dll', request_body, header);
	
	var json_data = xml2json.parser(return_val.getBody());

	try{
		clearItemSpecifics();
		if ( json_data.getcategoryspecificsresponse.ack == 'Success' )
		{
			console.log(json_data.getcategoryspecificsresponse);
			if ( json_data.getcategoryspecificsresponse.recommendations.namerecommendation ){
				var specifics_len = json_data.getcategoryspecificsresponse.recommendations.namerecommendation.length;				

				if ( typeof specifics_len != 'undefined' )
				{
					if ( specifics_len > 15 )
					{
						alert('This category have 15 more item specifics.');
					}
					for ( var i = 1; i <= specifics_len; i++ ){
						var specifics_obj = json_data.getcategoryspecificsresponse.recommendations.namerecommendation[i];
						if ( typeof specifics_obj.valuerecommendation != 'undefined' ){
							var specifics_recommend_len = specifics_obj.valuerecommendation.length;
							nlapiRemoveSelectOption('custpage_field_specific_' + i + '_value', null);
							
							//nlapiSetFieldValue('custpage_field_specific_' + i, specifics_obj.name);
							//var field = nlapiGetField('custpage_field_specific_' + i + '_value');
							//field.setLabel(specifics_obj.name);

							console.log(specifics_obj.name +' : ' + specifics_recommend_len);
							if ( typeof specifics_recommend_len != 'undefined' )
							{
								jQuery('#custpage_field_specific_' + i + '_value_fs_lbl').html(specifics_obj.name);
								jQuery('#custpage_field_specific_' + i + '_value_fs_lbl_uir_label').removeClass('uir-label-empty');
								for ( var j = 0; j < specifics_recommend_len; j++ ){
									if ( specifics_recommend_len > 0 )
									{
										if ( j == 0 )
										{
											nlapiInsertSelectOption('custpage_field_specific_' + i + '_value', '', '', false);
										}
										nlapiInsertSelectOption('custpage_field_specific_' + i + '_value', specifics_obj.valuerecommendation[j].value, specifics_obj.valuerecommendation[j].value, false);
									}
								}
								nlapiSetFieldDisplay('custpage_field_specific_' + i + '_value', true);
							}else{
								jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html(specifics_obj.name);
								jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl_uir_label').removeClass('uir-label-empty');
								nlapiSetFieldDisplay('custpage_field_specific_' + i + '_text_val', true);
							}
						}else{
							jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl').html(specifics_obj.name);
							jQuery('#custpage_field_specific_' + i + '_text_val_fs_lbl_uir_label').removeClass('uir-label-empty');
							nlapiSetFieldDisplay('custpage_field_specific_' + i + '_text_val', true);
						}
					}
				}else{
					var specifics_name = json_data.getcategoryspecificsresponse.recommendations.namerecommendation.name;
					if ( typeof specifics_name != 'undefined' )
					{
						var specifics_obj = json_data.getcategoryspecificsresponse.recommendations.namerecommendation;

						if ( typeof specifics_obj.valuerecommendation != 'undefined' )
						{
							var specifics_recommend_len = specifics_obj.valuerecommendation.length;
							if ( typeof specifics_recommend_len != 'undefined' )
							{
								jQuery('#custpage_field_specific_1_value_fs_lbl').html(specifics_obj.name);
								jQuery('#custpage_field_specific_1_value_fs_lbl_uir_label').removeClass('uir-label-empty');
								for ( var j = 0; j < specifics_recommend_len; j++ ){
									if ( specifics_recommend_len > 0 )
									{
										if ( j == 0 )
										{
											nlapiInsertSelectOption('custpage_field_specific_1_value', '', '', false);
										}
										nlapiInsertSelectOption('custpage_field_specific_1_value', specifics_obj.valuerecommendation[j].value, specifics_obj.valuerecommendation[j].value, false);
									}
								}
								nlapiSetFieldDisplay('custpage_field_specific_1_value', true);
							}else{
								jQuery('#custpage_field_specific_1_text_val_fs_lbl').html(specifics_obj.name);
								jQuery('#custpage_field_specific_1_text_val_fs_lbl_uir_label').removeClass('uir-label-empty');
								nlapiSetFieldDisplay('custpage_field_specific_1_text_val', true);
							}
						}else{
							jQuery('#custpage_field_specific_1_text_val_fs_lbl').html(specifics_obj.name);
							jQuery('#custpage_field_specific_1_text_val_fs_lbl_uir_label').removeClass('uir-label-empty');
							nlapiSetFieldDisplay('custpage_field_specific_1_text_val', true);
						}						
					}
				}			
			}
		}

		return json_data;
	}catch(e){
		nlapiLogExecution('error', 'ebay api return values parse', e);
		return false;
	}
	
	/*if ( json_data.getcategoryspecificsresponse.recommendations.namerecommendation ){
		var specifics_len = json_data.getcategoryspecificsresponse.recommendations.namerecommendation.length;		
		
		for ( var i = 0; i < specifics_len; i++ ){
			var specifics_obj = json_data.getcategoryspecificsresponse.recommendations.namerecommendation[i];
			if ( specifics_obj.valuerecommendation ){
				var specifics_recommend_len = specifics_obj.valuerecommendation.length;
				for ( var j = 0; j < specifics_recommend_len; j++ ){
					specifics_obj.valuerecommendation[j].value;
				}
			}			
		}
	}*/
	
}

function populate_item_specifics(){
	if ( nlapiGetFieldValue('custitem_listing_account') )
	{
		var site_id = nlapiLookupField('customrecord_ebay_accounts', nlapiGetFieldValue('custitem_listing_account'), 'custrecord_ebay_selling_siteid');
		site_id = getEbayGlobalSiteID(site_id);
	}else{
		site_id = 0;
	}
	if ( nlapiGetFieldValue('custitem_ebay_categoryid') != '' && nlapiGetFieldValue('custitem_ebay_categoryid') != null )
	{
		ebayDirectCategoryBrowseStep(site_id, nlapiGetFieldValue('custitem_ebay_categoryid'));
	}else{
		alert('pls input category id.');
	}
}

function ebayDirectCategoryBrowseStep(site_id, category){
	var response_data = nlapiRequestURL(get_ebay_category_service_url(site_id, category));
	
	var json_data = xml2json.parser(response_data.getBody());
	
	last_category = false;

	console.log(json_data);

	if ( json_data.getcategoryinforesponse.ack == 'Failure' )
	{
		alert(json_data.getcategoryinforesponse.errors.longmessage);
	}else{
		getEbayCategorySpecifics(site_id, category);		

		var catname_path;

		if ( json_data.getcategoryinforesponse.categorycount > 1 ){
			catname_path = json_data.getcategoryinforesponse.categoryarray.category[0].categorynamepath.split(':');
		}else{
			catname_path = json_data.getcategoryinforesponse.categoryarray.category.categorynamepath.split(':');
		}

		

		var category_title = catname_path[0];
		
		for ( var i = 1; i < catname_path.length; i++ )
		{
			category_title += ' > ' + catname_path[i];
		}
		
		//nlapiSetFieldValue('custitem_ebay_categoryid', json_data.getcategoryinforesponse.categoryarray.category.categoryid);
		nlapiSetFieldValue('custitem_ebay_category_title', category_title);
	}
	
	//if ( json_data.getcategoryinforesponse.categorycount > 1 ){

	//	alert('This category is not leaf, there more child categories, pls input only leaf categories.');
		
	//}else{

		
					
	//}
}

function clearItemSpecifics(){
	for ( var i = 1; i <= MAX_SPECIFICS; i++ ){
		nlapiRemoveSelectOption('custpage_field_specific_' + i + '_value', null);
		nlapiSetFieldValue('custpage_field_specific_' + i + '_text_val', '');
		nlapiSetFieldValue('custitem_item_specific_' + i, '');
		nlapiSetFieldValue('custitem_item_specific_' + i + '_value', '');
		nlapiSetFieldDisplay('custpage_field_specific_' + i + '_text_val', false);
		nlapiSetFieldDisplay('custpage_field_specific_' + i + '_value', false);
	}
}