function create(dataIn){
	nlapiLogExecution('DEBUG', 'dataIn', JSON.stringify(dataIn));
	return 'ok';
}