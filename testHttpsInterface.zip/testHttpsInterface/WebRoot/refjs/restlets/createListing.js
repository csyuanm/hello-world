
var listings = {
	newegg: {
		internalID: 1,
		id: 'customrecord_newegg_listings'
	}
};

function import(dataIn) {
	var id = listings[dataIn.market].id;
	var internalID = listings[dataIn.market].internalID;
	var exists = checkExists(dataIn.sku, id);
	if(exists){
		return 'exsists';
	}
	var rec = nlapiCreateRecord(id);
	rec.setFieldValue('custrecord36', internalID);  // newegg account
	rec.setFieldValue('custrecord_is', 'T');  // is_active
	var itemID = getItemID(dataIn.sku);
	if(itemID == null){
		return 'Item not Found: '+dataIn.sku;
	}
	rec.setFieldValue('custrecord25', itemID); // inventory item
	rec.setFieldValue('custrecord26', dataIn.sku);
	//rec.setFieldValue('custrecord27', dataIn.con);
	rec.setFieldValue('custrecord_qty', dataIn.qty);
	rec.setFieldValue('custrecord_price', dataIn.price);
	rec.setFieldValue('custrecord_msrp', dataIn.msrp);
	rec.setFieldValue('custrecord_newegg_id', dataIn.neweggID);
	var submit = nlapiSubmitRecord(rec);
	return {record: id, id: submit};
}

function checkExists(sku, rec){
	var item;
	var filter;
	filter = new Array();
	filter[0] = new nlobjSearchFilter('custrecord26', null,'is', sku);
	item = nlapiSearchRecord(rec, null, filter);
	if(item == null){
		return false;
	}else{
		return true;
	}
}

function getItemID(sku){
	var item;
	var filter;
	filter = new Array();
	filter[0] = new nlobjSearchFilter('itemid', null,'is', sku);
	item = nlapiSearchRecord('inventoryitem', null, filter);
	if(item == null){
		filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null,'is', sku);
		item = nlapiSearchRecord('inventoryitem', null, filter);
	}
	if(item == null){
		filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku_2', null,'is', sku);
		item = nlapiSearchRecord('inventoryitem', null, filter);
		if(item == null){
			//logger('Item not found: '+sku+'\r\n', '')
			nlapiLogExecution('DEBUG', 'Item not found', sku);
			return null;
		}
	}
	return item[0].id;
}

function logger(msg, sub){
	var auth = 152613;
	var targ = 'johnny@zake.com,ryan@zake.com,jake@zake.com';
	nlapiLogExecution('DEBUG', 'msg', msg);
	nlapiLogExecution('DEBUG', 'sub', sub);
	nlapiSendEmail(auth, targ, sub, msg);
}