function post(dataIn){
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('casenumber', null, 'is', dataIn.id);
	var search = nlapiSearchRecord('supportcase', null, filter);
	var rec = nlapiLoadRecord('supportcase', search[0].id);
	return rec;
}