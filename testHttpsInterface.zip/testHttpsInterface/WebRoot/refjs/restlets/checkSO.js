function check(dataIn){
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', dataIn.id);
	filter[1] = new nlobjSearchFilter('mainline', null, 'is', 'T');
	var cols = new Array();
	cols[0] = new nlobjSearchColumn('otherrefnum');
	cols[0] = new nlobjSearchColumn('status');
	var search = nlapiSearchRecord('salesorder', null, filter, cols);
	nlapiLogExecution('DEBUG', 'search', JSON.stringify(search));
	if(search == null){
	   return {id: 'not found'};
	}
	return JSON.stringify(search[0]);
}