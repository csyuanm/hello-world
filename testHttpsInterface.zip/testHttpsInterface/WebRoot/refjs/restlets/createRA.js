function post(dataIn){
	var rec = nlapiCreateRecord('returnauthorization');
	rec.setFieldValue('customform', dataIn.form);
	rec.setFieldValue('otherrefnum');
	rec.setFieldValue('entity');
	rec.setFieldValue('memo');
	rec.setFieldValue('custbody_zake_action');
	rec.setFieldValue('custbody_storefront_list');
	rec.setFieldValue('custbody_marketplace');
}

function getItem(sku){
	//item
	//tax code
	//price
	// from sku
}