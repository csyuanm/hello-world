function start(){
	var listings = nlapiSearchRecord('customrecord_woo_listing');
	var hold = {};
	listings.forEach(function(list, i){
		var rec = nlapiLoadRecord('customrecord_woo_listing', list.id);
		var legacy = rec.getFieldValue('custrecord40');
		var itemID = rec.getFieldValue('custrecord39');
		var item = nlapiLoadRecord('inventoryitem', itemID);
		var loc = item.findLineItemValue('locations','location_display','USA : South Bend : South Bend-Primary');
		var qty = item.getLineItemValue('locations','quantityavailable', loc);
		rec.setFieldValue('custrecord41', qty);
		nlapiSubmitRecord(rec);
		hold[legacy] = qty;
	});
	return hold;
}