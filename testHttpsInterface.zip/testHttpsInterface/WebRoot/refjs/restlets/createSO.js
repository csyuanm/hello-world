var TBD = 6;
var Standard = 1;
var ThreeDay = 2;
var TwoDay = 3;
var NextDay = 4;
var International = 5;
var Pickup = 7;

function import(dataIn) {
    nlapiLogExecution('DEBUG', 'dataIn', JSON.stringify(dataIn));
    var t = typeof(dataIn);
    nlapiLogExecution('DEBUG', 'type', t);
	var po = dataIn.orderNumber.toString();
	var exists = checkExists(po);
	if (exists != null) {
		var obj = {
			id : exists,
			type : 'salesOrder',
			status : 'exists'
		};
		return obj;
	}
	var shipping = 37625; // internal id of shipping item
	var assembly = 40258; // internal id of assembly item
	var id = getID(dataIn);
	var address = getAddress(id, dataIn);
	var items = dataIn.items;
	var rec = nlapiCreateRecord('salesorder');
	if(dataIn.createdfrom != undefined){
		if(dataIn.createdfrom != null){
			rec.setFieldValue('custbody_return_auth_number', dataIn.createdfrom);
		}
	}
	rec.setFieldValue('entity', id);
	rec.setFieldValue('location', 2); // 2 = South Bend-Primary
	rec.setFieldValue('custbody_storefront_list', dataIn.storefront);
	rec.setFieldValue('custbody_marketplace', dataIn.market);
	rec.setFieldValue('subsidiary', 1); // 1 = zake usa holding
	rec.setFieldValue('memo', 'Import from Pitchfork');
	rec.setFieldValue('customform', 150);
	rec.setFieldValue('otherrefnum', dataIn.orderNumber.toString());
	rec.setFieldValue('custbody_customer_email', dataIn.email);
	if(dataIn.account != undefined){
		rec.setFieldValue('account', dataIn.account);
	}
	if (dataIn.shippingAmount != undefined) {
		rec.setFieldValue('shippingcost', dataIn.shippingAmount);
	} else {
		rec.setFieldValue('shippingcost', 0);
	}
	if (dataIn.ship_via == "Ground") {
		rec.setFieldValue('shippingcost', 0);
		rec.setFieldValue('custbody_market_ship_serv_lvl', Standard);
		rec.setFieldValue("orderstatus", "A");
	} else if (dataIn.ship_via == "2 Days") {
		rec.setFieldValue('custbody_market_ship_serv_lvl', TwoDay);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', '2 day');
	} else if (dataIn.ship_via == "3 Days") {
		rec.setFieldValue('custbody_market_ship_serv_lvl', ThreeDay);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', '3 day');
	} else if (dataIn.ship_via == "International") {
		rec.setFieldValue('custbody_market_ship_serv_lvl', International);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', 'international');
	} else if (dataIn.ship_via == "Next Day") {
		rec.setFieldValue('custbody_market_ship_serv_lvl', NextDay);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', 'next day');
	}else if(dataIn.ship_via == "Expedited"){
		rec.setFieldValue('custbody_market_ship_serv_lvl', Standard);
		rec.setFieldValue("orderstatus", "A");
	}else if(dataIn.ship_via == "" || dataIn.ship_via == "Pickup"){
		rec.setFieldValue('custbody_market_ship_serv_lvl', Pickup);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', 'Pickup');
	} else {
		rec.setFieldValue('custbody_market_ship_serv_lvl', TBD);
		rec.setFieldValue("orderstatus", "A");
		nlapiLogExecution('DEBUG', 'ship_via', 'TBD');
	}
	var tax = isTaxable(items);
	if(tax){
		rec.setFieldValue('istaxable', 'T');
		rec.setFieldValue('taxrate', 7);
	}
	for (var i = 0; i < items.length; i++) {
		var single = items[i];
		if (single.description == "Sales Tax") {
			//rec.setFieldValue('istaxable', 'T');
			rec.setFieldValue('taxitem', 10);
			rec.setFieldValue('taxtotal', single.price);
			continue;
		} else if (single.description == "Freight Charges") {
			nlapiLogExecution('DEBUG', 'Freight Charges', JSON.stringify(single));
			rec.setFieldValue('shippingcost', single.price);
			continue;
		} else if (single.description == "assembly") {
			rec.selectNewLineItem('item');
			rec.setCurrentLineItemValue('item', 'item', assembly);
			rec.setCurrentLineItemValue('item', 'quantity', 1);
			rec.setCurrentLineItemValue('item', 'price', '-1');
			rec.setCurrentLineItemValue('item', 'rate', single.price);
			if(tax){
				rec.setCurrentLineItemValue('item', 'istaxable', 'T');
			}
			rec.commitLineItem('item');
			continue;
		} else if (single.description == "Storefront Discount"){
			nlapiLogExecution('DEBUG', 'Storefront Discount', JSON.stringify(single));
			rec.setFieldValue('custbody_has_issues', 'T');
			rec.setFieldValue('memo', 'Storefront Discount Error');
			continue;
		} else {
			var s = single.item_id.split('#');
			var sku = s[0];
			var item = getItem(sku);
			rec.selectNewLineItem('item');
			rec.setCurrentLineItemValue('item', 'item', item.id);
			rec.setCurrentLineItemValue('item', 'quantity', single.qty);
			rec.setCurrentLineItemValue('item', 'price', '-1');
			rec.setCurrentLineItemValue('item', 'rate', single.price);
			if(tax){
				rec.setCurrentLineItemValue('item', 'istaxable', 'T');
			}
			rec.commitLineItem('item');
		}
	}
	var submited = '';
	var obj = {};
	try {
		submited = nlapiSubmitRecord(rec, true);
		obj.id = submited;
		obj.type = 'salesOrder';
		obj.status = 'created';
	} catch(e){
		obj.id = po;
		obj.type = 'salesOrder';
		obj.status = 'error';
		nlapiLogExecution('DEBUG', 'error', JSON.stringify(e));
		nlapiLogExecution('DEBUG', 'order', po);
	}
	return obj;
}

function getItem(sku){
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', sku);
	var item = nlapiSearchRecord('inventoryitem', null, filter);
	if(item == null){
		filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'contains', sku);
		item = nlapiSearchRecord('inventoryitem', null, filter);
	}
	return item[0];
}

function isTaxable(items){
	var done = false;
	items.forEach(function(item, i){
		if (item.description == "Sales Tax") {
			done = true;
		}
	});
	return done;
}

function checkExists(po) {
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', po);
	var cols = new Array();
	cols[0] = new nlobjSearchColumn('otherrefnum');
	var x = nlapiSearchRecord('salesorder', null, filter, cols);
	if (x == null) {
		return null;
	} else {
		return x[0].id;
	}
}

function getID(dataIn) {
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.email);
	var x = nlapiSearchRecord('customer', null, filter);
	if (x == null) {
		var id = createCustomer(dataIn);
		return id;
	} else {
		var id = x[0].id;
		return id;
	}
}

function getAddress(id, data) {
	var address = null;
	var cust = nlapiLoadRecord('customer', id);
	var count = cust.getLineItemCount('addressbook');
	for (var i = 0; i < count; i++) {
		var addr = cust.getLineItemValue('addressbook', 'addr1', i + 1);
		if (addr == data.shipping.addr1) {
			address = i + 1;
		}
	}
	if (address == null) {
		cust.selectNewLineItem('addressbook');
		cust.setCurrentLineItemValue('addressbook', 'addressee', data.firstName+' '+data.lastName);
		cust.setCurrentLineItemValue('addressbook', 'addr1', data.shipping.addr1);
		cust.setCurrentLineItemValue('addressbook', 'addr2', data.shipping.addr2);
		cust.setCurrentLineItemValue('addressbook', 'city', data.shipping.city);
		cust.setCurrentLineItemValue('addressbook', 'state', data.shipping.state);
		cust.setCurrentLineItemValue('addressbook', 'zip', data.shipping.zip);
		cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
		cust.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
		cust.commitLineItem('addressbook');
		nlapiSubmitRecord(cust, true);
		address = count + 1;
	}
	return address;
}

function createCustomer(customer) {
	var cust = nlapiCreateRecord('customer');
	var billing = customer.billing;
	var shipping = customer.shipping;
	cust.setFieldValue('isperson', 'T');
	cust.setFieldValue('subsidiary', 1); // 1 = zake usa holding
if(customer.firstName.length > 32){
  customer.firstName = customer.firstName.slice(0,30);
}
	cust.setFieldValue('firstname', customer.firstName);
	cust.setFieldValue('lastname', customer.lastName);
	cust.setFieldValue('email', customer.email);
	cust.setFieldValue('phone', customer.phone);
	cust.selectNewLineItem('addressbook');
	cust.setCurrentLineItemValue('addressbook', 'addr1', customer.shipping.addr1);
	cust.setCurrentLineItemValue('addressbook', 'addr2', customer.shipping.addr2);
	cust.setCurrentLineItemValue('addressbook', 'city', customer.shipping.city);
	cust.setCurrentLineItemValue('addressbook', 'state', customer.shipping.state);
	cust.setCurrentLineItemValue('addressbook', 'zip', customer.shipping.zip);
	cust.commitLineItem('addressbook');
	if (customer.billing.addr1 != customer.shipping.addr1) {
		cust.selectNewLineItem('addressbook');
		cust.setCurrentLineItemValue('addressbook', 'addr1', customer.billing.addr1);
		cust.setCurrentLineItemValue('addressbook', 'addr2', customer.billing.addr2);
		cust.setCurrentLineItemValue('addressbook', 'city', customer.billing.city);
		cust.setCurrentLineItemValue('addressbook', 'state',customer.billing.state);
		cust.setCurrentLineItemValue('addressbook', 'zip', customer.billing.zip);
		cust.commitLineItem('addressbook');
	}
	var id = nlapiSubmitRecord(cust);
	return id;
}