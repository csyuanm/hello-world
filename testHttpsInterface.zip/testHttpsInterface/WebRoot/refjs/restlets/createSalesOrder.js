
// createSalesOrder.js
//
// Author: Jacob Van Vleet
// Email: jake@zake.com, jacob.vanvleet@gmail.com
// Skype: jake3bt
// Created: 8/4/2016
// Netsuite Attachment: Restlet - url: https://rest.na1.netsuite.com/app/site/hosting/restlet.nl?script=703&deploy=1
// Purpose: Rest api to create a sales order
//--------------------------------------------------------------------------------------------------------------------------------------------
// Example dataIn object
//  {
//      firstName: string,
//      lastName: string,
//      email: string,
//      phone: string,
//      orderNumber: string,
//      ship_via: string,
//      status: string,
//      market: number,
//      storefront: number,
//      shippingAmount: number,
//      account: number,
//      location: number,
//      form: number,
//      shipping: {
//          addr1: string,
//          addr2: string,
//          city: string,
//          state: string,
//          zip: string,
//          country:string
//      },
//      billing: {
//          addr1: string,
//          addr2: string,
//          city: string,
//          state: string,
//          zip: string,
//          country:string
//      },
//      items: [
//          {
//              item_id: string,
//              description: string,
//              price: number,
//              qty: number
//          }
//      ]
//  }



// misc item ids
var shipping = 37625; // internal id of shipping item
var assembly = 40258; // internal id of assembly item
var arr={};
arr['Afghanistan']='AF' 
	arr['Aland Islands']='AX' 
	arr['Albania']='AL' 
	arr['Algeria']='DZ' 
	arr['American Samoa']='AS' 
	arr['Andorra']='AD' 
	arr['Angola']='AO' 
	arr['Anguilla']='AI' 
	arr['Antarctica']='AQ' 
	arr['Antigua And Barbuda']='AG' 
	arr['Argentina']='AR' 
	arr['Armenia']='AM' 
	arr['Aruba']='AW' 
	arr['Australia']='AU' 
	arr['Austria']='AT' 
	arr['Azerbaijan']='AZ' 
	arr['Bahamas']='BS' 
	arr['Bahrain']='BH' 
	arr['Bangladesh']='BD' 
	arr['Barbados']='BB' 
	arr['Belarus']='BY' 
	arr['Belgium']='BE' 
	arr['Belize']='BZ' 
	arr['Benin']='BJ' 
	arr['Bermuda']='BM' 
	arr['Bhutan']='BT' 
	arr['Bolivia']='BO' 
	arr['Bosnia And Herzegovina']='BA' 
	arr['Botswana']='BW' 
	arr['Bouvet Island']='BV' 
	arr['Brazil']='BR' 
	arr['British Indian Ocean Territory']='IO' 
	arr['Brunei Darussalam']='BN' 
	arr['Bulgaria']='BG' 
	arr['Burkina Faso']='BF' 
	arr['Burundi']='BI' 
	arr['Cambodia']='KH' 
	arr['Cameroon']='CM' 
	arr['Canada']='CA' 
	arr['Cape Verde']='CV' 
	arr['Cayman Islands']='KY' 
	arr['Central African Republic']='CF' 
	arr['Chad']='TD' 
	arr['Chile']='CL' 
	arr['China']='CN' 
	arr['Christmas Island']='CX' 
	arr['Cocos (Keeling) Islands']='CC' 
	arr['Colombia']='CO' 
	arr['Comoros']='KM' 
	arr['Congo']='CG' 
	arr['Congo Democratic Republic']='CD' 
	arr['Cook Islands']='CK' 
	arr['Costa Rica']='CR' 
	arr['Cote D\'Ivoire']='CI' 
	arr['Croatia']='HR' 
	arr['Cuba']='CU' 
	arr['Cyprus']='CY' 
	arr['Czech Republic']='CZ' 
	arr['Denmark']='DK' 
	arr['Djibouti']='DJ' 
	arr['Dominica']='DM' 
	arr['Dominican Republic']='DO' 
	arr['Ecuador']='EC' 
	arr['Egypt']='EG' 
	arr['El Salvador']='SV' 
	arr['Equatorial Guinea']='GQ' 
	arr['Eritrea']='ER' 
	arr['Estonia']='EE' 
	arr['Ethiopia']='ET' 
	arr['Falkland Islands (Malvinas)']='FK' 
	arr['Faroe Islands']='FO' 
	arr['Fiji']='FJ' 
	arr['Finland']='FI' 
	arr['France']='FR' 
	arr['French Guiana']='GF' 
	arr['French Polynesia']='PF' 
	arr['French Southern Territories']='TF' 
	arr['Gabon']='GA' 
	arr['Gambia']='GM' 
	arr['Georgia']='GE' 
	arr['Germany']='DE' 
	arr['Ghana']='GH' 
	arr['Gibraltar']='GI' 
	arr['Greece']='GR' 
	arr['Greenland']='GL' 
	arr['Grenada']='GD' 
	arr['Guadeloupe']='GP' 
	arr['Guam']='GU' 
	arr['Guatemala']='GT' 
	arr['Guernsey']='GG' 
	arr['Guinea']='GN' 
	arr['Guinea-Bissau']='GW' 
	arr['Guyana']='GY' 
	arr['Haiti']='HT' 
	arr['Heard Island & Mcdonald Islands']='HM' 
	arr['Holy See (Vatican City State)']='VA' 
	arr['Honduras']='HN' 
	arr['Hong Kong']='HK' 
	arr['Hungary']='HU' 
	arr['Iceland']='IS' 
	arr['India']='IN' 
	arr['Indonesia']='ID' 
	arr['Iran Islamic Republic Of']='IR' 
	arr['Iraq']='IQ' 
	arr['Ireland']='IE' 
	arr['Isle Of Man']='IM' 
	arr['Israel']='IL' 
	arr['Italy']='IT' 
	arr['Jamaica']='JM' 
	arr['Japan']='JP' 
	arr['Jersey']='JE' 
	arr['Jordan']='JO' 
	arr['Kazakhstan']='KZ' 
	arr['Kenya']='KE' 
	arr['Kiribati']='KI' 
	arr['Korea']='KR' 
	arr['Kuwait']='KW' 
	arr['Kyrgyzstan']='KG' 
	arr['Lao People\'s Democratic Republic']='LA' 
	arr['Latvia']='LV' 
	arr['Lebanon']='LB' 
	arr['Lesotho']='LS' 
	arr['Liberia']='LR' 
	arr['Libyan Arab Jamahiriya']='LY' 
	arr['Liechtenstein']='LI' 
	arr['Lithuania']='LT' 
	arr['Luxembourg']='LU' 
	arr['Macao']='MO' 
	arr['Macedonia']='MK' 
	arr['Madagascar']='MG' 
	arr['Malawi']='MW' 
	arr['Malaysia']='MY' 
	arr['Maldives']='MV' 
	arr['Mali']='ML' 
	arr['Malta']='MT' 
	arr['Marshall Islands']='MH' 
	arr['Martinique']='MQ' 
	arr['Mauritania']='MR' 
	arr['Mauritius']='MU' 
	arr['Mayotte']='YT' 
	arr['Mexico']='MX' 
	arr['Micronesia Federated States Of']='FM' 
	arr['Moldova']='MD' 
	arr['Monaco']='MC' 
	arr['Mongolia']='MN' 
	arr['Montenegro']='ME' 
	arr['Montserrat']='MS' 
	arr['Morocco']='MA' 
	arr['Mozambique']='MZ' 
	arr['Myanmar']='MM' 
	arr['Namibia']='NA' 
	arr['Nauru']='NR' 
	arr['Nepal']='NP' 
	arr['Netherlands']='NL' 
	arr['Netherlands Antilles']='AN' 
	arr['New Caledonia']='NC' 
	arr['New Zealand']='NZ' 
	arr['Nicaragua']='NI' 
	arr['Niger']='NE' 
	arr['Nigeria']='NG' 
	arr['Niue']='NU' 
	arr['Norfolk Island']='NF' 
	arr['Northern Mariana Islands']='MP' 
	arr['Norway']='NO' 
	arr['Oman']='OM' 
	arr['Pakistan']='PK' 
	arr['Palau']='PW' 
	arr['Palestinian Territory Occupied']='PS' 
	arr['Panama']='PA' 
	arr['Papua New Guinea']='PG' 
	arr['Paraguay']='PY' 
	arr['Peru']='PE' 
	arr['Philippines']='PH' 
	arr['Pitcairn']='PN' 
	arr['Poland']='PL' 
	arr['Portugal']='PT' 
	arr['Puerto Rico']='PR' 
	arr['Qatar']='QA' 
	arr['Reunion']='RE' 
	arr['Romania']='RO' 
	arr['Russian Federation']='RU' 
	arr['Rwanda']='RW' 
	arr['Saint Barthelemy']='BL' 
	arr['Saint Helena']='SH' 
	arr['Saint Kitts And Nevis']='KN' 
	arr['Saint Lucia']='LC' 
	arr['Saint Martin']='MF' 
	arr['Saint Pierre And Miquelon']='PM' 
	arr['Saint Vincent And Grenadines']='VC' 
	arr['Samoa']='WS' 
	arr['San Marino']='SM' 
	arr['Sao Tome And Principe']='ST' 
	arr['Saudi Arabia']='SA' 
	arr['Senegal']='SN' 
	arr['Serbia']='RS' 
	arr['Seychelles']='SC' 
	arr['Sierra Leone']='SL' 
	arr['Singapore']='SG' 
	arr['Slovakia']='SK' 
	arr['Slovenia']='SI' 
	arr['Solomon Islands']='SB' 
	arr['Somalia']='SO' 
	arr['South Africa']='ZA' 
	arr['South Georgia And Sandwich Isl.']='GS' 
	arr['Spain']='ES' 
	arr['Sri Lanka']='LK' 
	arr['Sudan']='SD' 
	arr['Suriname']='SR' 
	arr['Svalbard And Jan Mayen']='SJ' 
	arr['Swaziland']='SZ' 
	arr['Sweden']='SE' 
	arr['Switzerland']='CH' 
	arr['Syrian Arab Republic']='SY' 
	arr['Taiwan']='TW' 
	arr['Tajikistan']='TJ' 
	arr['Tanzania']='TZ' 
	arr['Thailand']='TH' 
	arr['Timor-Leste']='TL' 
	arr['Togo']='TG' 
	arr['Tokelau']='TK' 
	arr['Tonga']='TO' 
	arr['Trinidad And Tobago']='TT' 
	arr['Tunisia']='TN' 
	arr['Turkey']='TR' 
	arr['Turkmenistan']='TM' 
	arr['Turks And Caicos Islands']='TC' 
	arr['Tuvalu']='TV' 
	arr['Uganda']='UG' 
	arr['Ukraine']='UA' 
	arr['United Arab Emirates']='AE' 
	arr['United Kingdom']='GB' 
	arr['United States']='US' 
	arr['United States Outlying Islands']='UM' 
	arr['Uruguay']='UY' 
	arr['Uzbekistan']='UZ' 
	arr['Vanuatu']='VU' 
	arr['Venezuela']='VE' 
	arr['Viet Nam']='VN' 
	arr['Virgin Islands British']='VG' 
	arr['Virgin Islands U.S.']='VI' 
	arr['Wallis And Futuna']='WF' 
	arr['Western Sahara']='EH' 
	arr['Yemen']='YE' 
	arr['Zambia']='ZM' 
	arr['Zimbabwe']='ZW'

function start(dataIn){
	try{
  nlapiLogExecution('DEBUG', 'Code start',dataIn.ship_via);
  nlapiLogExecution('DEBUG', 'shipping.country',dataIn.shipping.country);
  nlapiLogExecution('DEBUG', 'billing.country',dataIn.billing.country);
  nlapiLogExecution('DEBUG', 'orderNumber',dataIn.orderNumber);
  

    var po = dataIn.orderNumber.toString();
    var exists = checkExists(po);
	if (exists != null) {
		var obj = {
			id : exists,
			type : 'salesOrder',
			status : 'exists',
			storefront: dataIn.storfront,
			market: dataIn.market
		};
		return obj;
	}else{
        var custID = getCustID(dataIn);
        //var address = getAddress(custID, dataIn);
        var items = dataIn.items;
        var rec = nlapiCreateRecord('salesorder');
        rec.setFieldValue('entity', custID);  // set customer
        rec.setFieldValue('custbody_storefront_list', dataIn.storefront); // set storefront
        rec.setFieldValue('custbody_marketplace', dataIn.market); // set marketplace
        rec.setFieldValue('subsidiary', 1); // 1 = zake international
        rec.setFieldValue('memo', 'Import from Pitchfork'); // mark as order that came from pitchfork
        rec.setFieldValue('otherrefnum', dataIn.orderNumber.toString()); // set po #
        rec.setFieldValue('custbody_customer_email', dataIn.email); // set email
        rec.setFieldValue('shipaddressee', dataIn.firstName+' '+dataIn.lastName);
        rec.setFieldValue('shipaddr1', dataIn.shipping.addr1);
        rec.setFieldValue('shipaddr2', dataIn.shipping.addr2);
        rec.setFieldValue('shipcity', dataIn.shipping.city);
        rec.setFieldValue('shipstate', dataIn.shipping.state);
        rec.setFieldValue('shipzip', dataIn.shipping.zip);
        if (dataIn.billing.addr1 != dataIn.shipping.addr1 && dataIn.billing.addr1 != null && dataIn.billing.addr1 != undefined) {  
            // if billing and shipping address diffrent, add second address
            rec.setFieldValue('billaddressee', dataIn.firstName+' '+dataIn.lastName);
            rec.setFieldValue('billaddr1', dataIn.billing.addr1);
            rec.setFieldValue('billaddr2', dataIn.billing.addr2);
            rec.setFieldValue('billcity', dataIn.billing.city);
            rec.setFieldValue('billstate',dataIn.billing.state);
            rec.setFieldValue('billzip', dataIn.billing.zip);
        }
        if(dataIn.createdfrom != undefined){  // set if created from somthing, like an ra
            if(dataIn.createdfrom != null){
                rec.setFieldValue('custbody_return_auth_number', dataIn.createdfrom);
            }
        }

        if(dataIn.location == undefined){ // set location
            rec.setFieldValue('location', 2); // 2 = South Bend-Primary
        }else{
            rec.setFieldValue('location', dataIn.location);
        }
        if(dataIn.form == undefined){ // set custom from
            rec.setFieldValue('customform', 150); // default form id
        }else{
            rec.setFieldValue('customform', dataIn.form);
        }
        if(dataIn.status == undefined || ship(dataIn.ship_via)==6 || ship(dataIn.ship_via)==7){  // set order status // added  || ship(dataIn.ship_via)==6 and 7 modified by AJ for Premier orders
            rec.setFieldValue("orderstatus", "A"); // pending approval
        }else{
            rec.setFieldValue("orderstatus", dataIn.status);
        }
        if(dataIn.account != undefined){  // set account
            rec.setFieldValue('account', dataIn.account);
        } // default is auto assigned
        if (dataIn.shippingAmount != undefined) {  // set shipping charge
            if(dataIn.ship_via == 'Ground'){
                rec.setFieldValue('shippingcost', 0);
            }else{
                rec.setFieldValue('shippingcost', dataIn.shippingAmount);
            }
        } else {
            rec.setFieldValue('shippingcost', 0);
        }
        rec.setFieldValue('custbody_market_ship_serv_lvl', ship(dataIn.ship_via));
        var tax = isTaxable(items);
        if(tax){
            rec.setFieldValue('istaxable', 'T');
            rec.setFieldValue('taxrate', 7); // indiana tax
        }

        for (var i = 0; i < items.length; i++) {
            var single = items[i];
            if (single.description == "Sales Tax") {
                rec.setFieldValue('taxitem', 10);
                rec.setFieldValue('taxtotal', single.price);
                continue;
            } else if (single.description == "Freight Charges") {
                rec.setFieldValue('shippingcost', single.price);
                continue;
            } else if (single.description == "assembly") {
                rec.selectNewLineItem('item');
                rec.setCurrentLineItemValue('item', 'item', assembly);
                rec.setCurrentLineItemValue('item', 'quantity', 1);
                rec.setCurrentLineItemValue('item', 'price', '-1');
                rec.setCurrentLineItemValue('item', 'rate', single.price);
                if(tax){
                    rec.setCurrentLineItemValue('item', 'istaxable', 'T');
                }
                rec.commitLineItem('item');
                continue;
            } else if (single.description == "Storefront Discount"){
                nlapiLogExecution('DEBUG', 'Storefront Discount', JSON.stringify(single));
                rec.setFieldValue('custbody_has_issues', 'T');
                rec.setFieldValue('memo', 'Storefront Discount Error');
                continue;
            } else {
                var s = single.item_id.split('#');
                var sku = s[0];
                var item = getItem(sku);
                rec.selectNewLineItem('item');
                rec.setCurrentLineItemValue('item', 'item', item.id);
                rec.setCurrentLineItemValue('item', 'quantity', single.qty);
                rec.setCurrentLineItemValue('item', 'price', '-1');
                rec.setCurrentLineItemValue('item', 'rate', single.price);
                rec.setCurrentLineItemValue('item', 'custcol_newegg_sku', sku);
                if(tax){
                    rec.setCurrentLineItemValue('item', 'istaxable', 'T');
                }
                rec.commitLineItem('item');
                continue;
            }
        }
        var exists2 = checkExists(po);
        if(exists2 != null){
        	var obj = {
    			id : exists,
    			type : 'salesOrder',
    			status : 'exists',
    			storefront: dataIn.storfront,
    			market: dataIn.market
    		};
    		return obj;
        }else{
        	var submited = nlapiSubmitRecord(rec, true);
            var d = new Date();
            var obj = {};
            obj.id = submited;
            obj.type = 'salesOrder';
            obj.status = 'created';
            obj.createdAt = d.toString();
            obj.storefront = dataIn.storfront;
    		obj.market = dataIn.market;
            return obj;
        }
    }
}
	catch(e){
		var file=nlapiCreateFile('NeweggOrder'+dataIn.orderNumber.toString(), 'PLAINTEXT', JSON.stringify(dataIn));
		nlapiSendEmail(29799,'aj@webbeeglobal.com','Err:Newegg Order Import', e,'govind@webbee.biz',null,null,file);
	}}

function handelError(e, obj){
    var auth = 29799;
    var sub = JSON.stringify(obj);
    var msg = JSON.stringify(e);
	var col = new Array();
	col[0] = new nlobjSearchColumn('name');
	var search = nlapiSearchRecord('customlist_script_error', null, null, col);
	search.forEach(function(s){
		var email = s.getValue('name');
		nlapiSendEmail(auth, email, sub, msg);
	});
}

function ship(ship_via){
    // shipping codes
    var TBD = 6;
    var Standard = 1;
    var ThreeDay = 2;
    var TwoDay = 3;
    var NextDay = 4;
    var International = 5;
    var Pickup = 7;
    var obj = {};
    if (ship_via == "Ground") {
        return Standard;
	} else if (ship_via == "2 Days") {
        return TwoDay;
	} else if (ship_via == "3 Days") {
        return ThreeDay;
	} else if (ship_via == "International") {
        return International;
	} else if (ship_via == "Next Day") {
        return NextDay;
	}else if(ship_via == "Expedited"){
		return Standard;
	}else if(ship_via == "" || ship_via == "Pickup"){
		return Pickup;
	} else {
		return TBD;
	}
}

function checkExists(po){  // checks to see if a sales order with that po# exists in NS.
    var filter = new Array();
	filter[0] = new nlobjSearchFilter('otherrefnum', null, 'equalto', po);
	var x = nlapiSearchRecord('salesorder', null, filter);
	if (x == null) {
		return null;
	} else {
		return x[0].id;  // if it does exists returns internal id of existing order for logging
	}
}

function isTaxable(items){  // checks sales tax
	var done = false;
	items.forEach(function(item, i){
		if (item.description == "Sales Tax") {
			done = true;
		}
	});
	return done;
}

function getCustID(dataIn) {  // checks if customer exists.  If it doesn't creates the customer
	var phone=dataIn.phone;
	var filter = new Array();
	filter[0] = new nlobjSearchFilter('email', null, 'is', dataIn.email);
	var x = nlapiSearchRecord('customer', null, filter);
	if (x == null) {
		var id = createCustomer(dataIn);
		return id;
	} 
	else {
		var id = x[0].id;

		
		nlapiLogExecution('DEBUG', 'Existing Customer',id);
		var obj=nlapiLoadRecord('customer',id,{recordmode : 'dynamic'});
		var flag=0;
		var flag1=0;
		var lines = obj.getLineItemCount('addressbook');
		nlapiLogExecution('DEBUG', 'lines',lines);		
		for(var z=1;z<=lines;z++){
			var cust_zipcode=obj.getLineItemValue('addressbook', 'zip', z);
			var cust_addr1=obj.getLineItemValue('addressbook','addr1', z);

			nlapiLogExecution('DEBUG', 'cust_zipcode',cust_zipcode);
			nlapiLogExecution('DEBUG', 'cust_addr1',cust_addr1);

			if(cust_zipcode==dataIn.shipping.zip&&cust_addr1==dataIn.shipping.addr1){
				flag++;
			}
           if(cust_zipcode==dataIn.billing.zip&&cust_addr1==dataIn.billing.addr1){
				flag1++;
			}

		}
		if(flag==0){
		nlapiLogExecution('DEBUG','cust_zipcode',cust_zipcode );
		nlapiLogExecution('DEBUG','cust_addressee',cust_addr1 );

		
		obj.selectNewLineItem('addressbook');
		obj.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping.addr1);
		var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
		if(!dataIn.shipping.country)
			subrecord.setFieldValue('country', 'US');
		else
		subrecord.setFieldValue('country', arr[dataIn.shipping.country]);
		subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
		if (phone.match(/[^0]/) && (phone.length >= 8)) {
			subrecord.setFieldValue('addrphone', phone);
		}
		if(dataIn.shipping.addr1)
		{
	    subrecord.setFieldValue('addr1', dataIn.shipping.addr1);
		subrecord.setFieldValue('addr2', dataIn.shipping.addr2);
		}
		else{
		    subrecord.setFieldValue('addr1', dataIn.shipping.addr2);
		}
		subrecord.setFieldValue('city', dataIn.shipping.city);
		subrecord.setFieldValue('state', dataIn.shipping.state);
		subrecord.setFieldValue('zip', dataIn.shipping.zip);
		subrecord.commit();
		obj.commitLineItem('addressbook');
			
		}
		if(flag1==0){
			obj.selectNewLineItem('addressbook');
			obj.setCurrentLineItemValue('addressbook', 'label', dataIn.billing.addr1);
			var subrecord = obj.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
			if(!dataIn.billing.country)
				subrecord.setFieldValue('country', 'US');
			else
			subrecord.setFieldValue('country', arr[dataIn.billing.country]);
			subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
			if (phone.match(/[^0]/) && (phone.length >= 8)) {
				subrecord.setFieldValue('addrphone', phone);
			}
			if(dataIn.shipping.addr1)
			{
		    subrecord.setFieldValue('addr1', dataIn.billing.addr1);
			subrecord.setFieldValue('addr2', dataIn.billing.addr2);
			}
			else{
			    subrecord.setFieldValue('addr1', dataIn.billing.addr2);
			}
			subrecord.setFieldValue('city', dataIn.billing.city);
			subrecord.setFieldValue('state', dataIn.billing.state);
			subrecord.setFieldValue('zip', dataIn.billing.zip);
			subrecord.commit();
			obj.commitLineItem('addressbook');
		}
	 nlapiSubmitRecord(obj, null,true);
	
		return id;
	}
}

function createCustomer(dataIn) {
	var phone=dataIn.phone;
	var cust = nlapiCreateRecord('customer');
	var billing = dataIn.billing;
	var shipping = dataIn.shipping;
	cust.setFieldValue('isperson', 'T');
	cust.setFieldValue('subsidiary', 1); // 1 = zake international
    if(dataIn.firstName.length > 32){
        dataIn.firstName = dataIn.firstName.slice(0,30);
    }
	cust.setFieldValue('firstname', dataIn.firstName);
	cust.setFieldValue('lastname', dataIn.lastName);
	cust.setFieldValue('email', dataIn.email);
	cust.setFieldValue('phone', phone.slice(0,22));

	cust.selectNewLineItem('addressbook');
	//cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.shipping.addr1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.shipping.country)
		subrecord.setFieldValue('country', 'US');
	else
	subrecord.setFieldValue('country', arr[dataIn.shipping.country]);
	subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping.addr1)
	{
    subrecord.setFieldValue('addr1', dataIn.shipping.addr1);
	subrecord.setFieldValue('addr2', dataIn.shipping.addr2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.shipping.addr2);
	}
	subrecord.setFieldValue('city', dataIn.shipping.city);
	subrecord.setFieldValue('state', dataIn.shipping.state);
	subrecord.setFieldValue('zip', dataIn.shipping.zip);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	
	cust.selectNewLineItem('addressbook');
	cust.setCurrentLineItemValue('addressbook', 'label', dataIn.billing.addr1);
	var subrecord = cust.createCurrentLineItemSubrecord('addressbook','addressbookaddress');
	if(!dataIn.billing.country)
		subrecord.setFieldValue('country', 'US');	
	else
	subrecord.setFieldValue('country', arr[dataIn.billing.country]);
	subrecord.setFieldValue('addressee', dataIn.firstName+' '+dataIn.lastName);
	if (phone.match(/[^0]/) && (phone.length >= 8)) {
		subrecord.setFieldValue('addrphone', phone.slice(0,22));
	}
	if(dataIn.shipping.addr1)
	{
    subrecord.setFieldValue('addr1', dataIn.billing.addr1);
	subrecord.setFieldValue('addr2', dataIn.billing.addr2);
	}
	else{
	    subrecord.setFieldValue('addr1', dataIn.billing.addr2);
	}
	subrecord.setFieldValue('city', dataIn.billing.city);
	subrecord.setFieldValue('state', dataIn.billing.state);
	subrecord.setFieldValue('zip', dataIn.billing.zip);
	subrecord.commit();
	cust.commitLineItem('addressbook');
	var id = nlapiSubmitRecord(cust);
	nlapiLogExecution('DEBUG', 'new customer', id)
	return id;
}

/*function getAddress(id, data) {
	var address = null;
	var cust = nlapiLoadRecord('customer', id);
	var count = cust.getLineItemCount('addressbook');
	for (var i = 0; i < count; i++) {
		var addr = cust.getLineItemValue('addressbook', 'addr1', i + 1);
		if (addr == data.shipping.addr1) {
			address = i + 1;
            cust.setLineItemValue('addressbook', 'defaultshipping', i, 'T');
		    cust.setLineItemValue('addressbook', 'defaultbilling', i, 'T');
            cust.commitLineItem('addressbook');
            nlapiSubmitRecord(cust, true);
		}
	}
	if (address == null) {
		cust.selectNewLineItem('addressbook');
		cust.setCurrentLineItemValue('addressbook', 'addressee', data.firstName+' '+data.lastName);
		cust.setCurrentLineItemValue('addressbook', 'addr1', data.shipping.addr1);
		cust.setCurrentLineItemValue('addressbook', 'addr2', data.shipping.addr2);
		cust.setCurrentLineItemValue('addressbook', 'city', data.shipping.city);
		cust.setCurrentLineItemValue('addressbook', 'state', data.shipping.state);
		cust.setCurrentLineItemValue('addressbook', 'zip', data.shipping.zip);
		cust.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
		cust.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
		cust.commitLineItem('addressbook');
		nlapiSubmitRecord(cust, true);
		address = count + 1;
	}
	return address;
}*/

function getItem(sku){
var filter = new Array();
filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'is', sku);
var item = nlapiSearchRecord('inventoryitem', null, filter);
if(item == null){
	filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku', null, 'contains', sku);
	item = nlapiSearchRecord('inventoryitem', null, filter);
	if(item == null){
		filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku_2', null, 'contains', sku);
		item = nlapiSearchRecord('inventoryitem', null, filter);
		if(item == null){
			filter[0] = new nlobjSearchFilter('custitem_legacy_3b_sku_2', null, 'is', sku);
			item = nlapiSearchRecord('inventoryitem', null, filter);
		}
	}
}
return item[0];
}
