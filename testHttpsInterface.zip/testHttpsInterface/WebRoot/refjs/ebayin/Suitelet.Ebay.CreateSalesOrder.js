function runMSO(request, response) {

    //try {
    var mso_id = request.getParameter('mso_id');
    _pullOne(mso_id);
    nlapiSetRedirectURL('RECORD', 'customrecord_missing_sales_order', mso_id);
    //} catch (e) {
    //    var info = ' --- ';
    //    if (ebayAccountSearch) {
    //        info = 'ebayAccountSearch-' + ebayAccountSearch[0].getId();
    //    }
    //    processException(e, info);
    //} finally {
    //    nlapiSetRedirectURL('RECORD', 'customrecord_missing_sales_order', mso_id);
    //}


}

function schRun() {

    var search = nlapiSearchRecord('customrecord_missing_sales_order', null, [
        new nlobjSearchFilter('custrecord_mso_pull_in', null, 'is', 'F')
    ]);

    if (search != null) {
        for (var i = 0; i < search.length; i++) {
            _pullOne(search[i].getId());
        }
    }
}

function _pullOne(mso_id) {
    var msoRecord = nlapiLoadRecord('customrecord_missing_sales_order', mso_id);

    var custrecord_mso_ebay_account = msoRecord.getFieldValue('custrecord_mso_ebay_account');
    var ebayOrderId = msoRecord.getFieldValue('custrecord_mso_id');
    var custrecord_mso_from_json = msoRecord.getFieldValue('custrecord_mso_from_json');
    // --- 断章取义法！

    var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [
        new nlobjSearchFilter('internalid', null, 'is', custrecord_mso_ebay_account)
    ], [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_ebay_api_token'),
        new nlobjSearchColumn('custrecord_ebay_global_site_access'),
        new nlobjSearchColumn('custrecord_ea_subsidiary'),
        new nlobjSearchColumn('custrecord_ebay_shortname'),
        new nlobjSearchColumn('custrecord_ebay_account_storefront'),

        new nlobjSearchColumn('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
        new nlobjSearchColumn('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
        new nlobjSearchColumn('custrecord_ed_cert_name', 'custrecord_ebay_dev_account')
    ]);

    if (ebayAccountSearch != null) {


        _log('ebayAccountSearch.length', ebayAccountSearch.length);
        if (ebayAccountSearch.length == 1) {

            var soId = null;
            try {

                RUNNING_ACCOUNT.EBAY_ACCOUNT_ID = ebayAccountSearch[0].getId();
                RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN = ebayAccountSearch[0].getValue('custrecord_ebay_api_token');
                //RUNNING_ACCOUNT.SAVED_FILE_NAME = 'EBAY_GETORDERS_Shenzhen_TIME_' + ebayAccountSearch[0].getId() + '.txt';
                RUNNING_ACCOUNT.SUBSIDIARY = ebayAccountSearch[0].getValue('custrecord_ea_subsidiary');
                //RUNNING_ACCOUNT.STOREFRONT = ebayAccountSearch[0].getValue('custrecord_ebay_account_storefront');
                _audit('RUNNING_ACCOUNT', RUNNING_ACCOUNT);

                if (custrecord_mso_from_json == 'T') {

                    var Order = JSON.parse(msoRecord.getFieldValue('custrecord_mso_info'));

                    //if (msoRecord.getFieldValue('custrecord_mso_reason') &&
                    //    msoRecord.getFieldValue('custrecord_mso_reason').indexOf('for the following field: phone') != -1) {
                    //    Order.ShippingAddress.Phone = '';
                    //}

                    // var result = createEbaySalesOrder(Order, ebayAccountSearch[0]);

                    var result = _createSO(Order, ebayAccountSearch[0]);

                    _log('result', result);
                    if (result.success) {
                        soId = result.id;
                        msoRecord.setFieldValue('custrecord_mso_pull_in', 'T');
                        msoRecord.setFieldValue('custrecord_mso_reason', '进入到了NS， 放心！');
                    } else {
                        msoRecord.setFieldValue('custrecord_mso_reason', _cutText(JSON.stringify(result)));

                    }

                } else {

                    var token = ebayAccountSearch[0].getValue('custrecord_ebay_api_token');
                    var ebayAccountId = ebayAccountSearch[0].getId();

                    //_log(searchResult.getValue('name') + ' -- ' + ebayAccountId);

                    var devHeader = {
                        'X-EBAY-API-APP-NAME': ebayAccountSearch[0].getValue('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
                        'X-EBAY-API-DEV-NAME': ebayAccountSearch[0].getValue('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
                        'X-EBAY-API-CERT-NAME': ebayAccountSearch[0].getValue('custrecord_ed_cert_name', 'custrecord_ebay_dev_account'),
                        'Content-Type': 'application/xml'
                    };

                    var xml = buildOrderXML(token, ebayOrderId);


                    var header = extend(devHeader, {
                        'X-EBAY-API-SITEID': '0', // 0 for US 抓单时候不区分 site 的
                        'X-EBAY-API-CALL-NAME': 'GetOrders',
                        'X-EBAY-API-COMPATIBILITY-LEVEL': '911'
                    });

                    var orderResponse = nlapiRequestURL('https://api.ebay.com/ws/api.dll', xml, header);
                    _log('orderResponse', orderResponse.getBody());
                    orderResponse = new X2JS().xml_str2json(orderResponse.getBody());

                    //_log('orderResponse', orderResponse);

                    soId = _processRes(msoRecord, orderResponse, ebayAccountSearch)
                }


            } catch (e) {
                e = processException(e);
                msoRecord.setFieldValue('custrecord_mso_pull_in', 'F');
                msoRecord.setFieldValue('custrecord_mso_reason', e.getUserMessage());
            }

            if (soId) msoRecord.setFieldValue('custrecord_mso_linked_so', soId);


            nlapiSubmitRecord(msoRecord);
            //// for next account
            //RUNNING_ACCOUNT = {
            //    EBAY_ACCOUNT_ID: null,
            //    EBAY_ACCOUNT_TOKEN: null,
            //    //SAVED_FILE_NAME: '',
            //    SUBSIDIARY: null
            //};
        } else {
            _log_email('Ebay account more than 2');
        }
    }
}

// Same as refactoryOrdersResponse
function _refactoryOrdersResponse(GetOrdersResponse) {

    // if (GetOrdersResponse.ReturnedOrderCountActual == '0') return; // GetOrdersResponse;

    if (GetOrdersResponse.hasOwnProperty('OrderArray') && GetOrdersResponse.OrderArray.Order) {
        if (!Array.isArray(GetOrdersResponse.OrderArray.Order)) {
            GetOrdersResponse.OrderArray.Order = [GetOrdersResponse.OrderArray.Order];
        }
        GetOrdersResponse.OrderArray.Order.forEach(function (Order) {
            if (!Array.isArray(Order.TransactionArray.Transaction)) {
                Order.TransactionArray.Transaction = [Order.TransactionArray.Transaction];
            }
            if (Order.MonetaryDetails) {
                if (!Array.isArray(Order.MonetaryDetails.Payments.Payment)) {
                    Order.MonetaryDetails.Payments.Payment = [Order.MonetaryDetails.Payments.Payment];
                }
            }
            Order.ExternalTransaction = _toarray(Order.ExternalTransaction);
        });
    }

    //return GetOrdersResponse;
}
function _processRes(msoRecord, GetOrdersResponse, ebayAccountSearch) {

    _log('_processRes');

    var id = null;
    // var GetOrdersResponse = datain.__response;
    _refactoryOrdersResponse(GetOrdersResponse.GetOrdersResponse);

    GetOrdersResponse = GetOrdersResponse.GetOrdersResponse;

    if (GetOrdersResponse.Ack == 'Success' || GetOrdersResponse.Ack == 'Warning') {

        if (GetOrdersResponse.Ack == 'Warning') {
            _log_email('Ebay get order 有点问题', JSON.stringify(GetOrdersResponse.Errors))
        }

        if (GetOrdersResponse.ReturnedOrderCountActual != '0') {
            var OrderArray = GetOrdersResponse.OrderArray;
            if (OrderArray) {
                var Order = GetOrdersResponse.OrderArray.Order[0];

                try {
                    var result = _createSO(Order, ebayAccountSearch[0]);
                    _log('result', result);
                    if (result.success) {
                        id = result.id;
                        msoRecord.setFieldValue('custrecord_mso_pull_in', 'T');
                        msoRecord.setFieldValue('custrecord_mso_reason', '进入到了NS， 放心！');
                    } else {
                        // {"success":false,"code":"EXISTING_SALES_ORDER__NS有这个单了","id":"11600806"}
                        if (result.code == "EXISTING_SALES_ORDER__NS有这个单了") {
                            msoRecord.setFieldValue('custrecord_mso_pull_in', 'T');
                        }
                        msoRecord.setFieldValue('custrecord_mso_info', JSON.stringify(Order));
                        msoRecord.setFieldValue('custrecord_mso_reason', _cutText(JSON.stringify(result)));
                    }

                } catch (e) {
                    msoRecord.setFieldValue('custrecord_mso_info', JSON.stringify(Order));
                }


                //for (var i = 0; i < Order.length; i++) {
                //
                //    var _Order = Order[i];
                //
                //
                //}
            }

        } else {
            _audit('ORDER SIZE: 0');
            // _log_email('GetOrders--- 0: responseJSON', JSON.stringify(GetOrdersResponse, null, 2) + '\r\n' + xml);
        }

    } else {
        _log_email('Ebay Ack Error', GetOrdersResponse.Ack + '\r\n' + JSON.stringify(GetOrdersResponse.Errors));
    }

    return id;

}

function buildOrderXML(token, SPECIFIC_ORDER_ID) {

    var xml = '';

    _log('SPECIFIC_ORDER_ID', SPECIFIC_ORDER_ID);
    //var utcDatetime = this.moment().utc();
    xml += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<GetOrdersRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">";
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + token + "<\/eBayAuthToken>";
    xml += "  <\/RequesterCredentials>";

    xml += '  <OrderIDArray><OrderID>' + SPECIFIC_ORDER_ID + '</OrderID></OrderIDArray>';

    // DetailLevel
    xml += "  <DetailLevel>ReturnAll<\/DetailLevel>";
    xml += "  <OrderRole>Seller<\/OrderRole>";
    // xml += "  <OrderStatus>Active<\/OrderStatus>";
    xml += "<\/GetOrdersRequest>";

    return xml;
}