function X2JS(config) {
    "use strict";
    var VERSION = "1.1.5";
    config = config || {};
    initConfigDefaults();
    initRequiredPolyfills();
    function initConfigDefaults() {
        if (config.escapeMode === undefined) {
            config.escapeMode = true;
        }
        config.attributePrefix = config.attributePrefix || "_";
        config.arrayAccessForm = config.arrayAccessForm || "none";
        config.emptyNodeForm = config.emptyNodeForm || "text";
        if (config.enableToStringFunc === undefined) {
            config.enableToStringFunc = true;
        }
        config.arrayAccessFormPaths = config.arrayAccessFormPaths || [];
        if (config.skipEmptyTextNodesForObj === undefined) {
            config.skipEmptyTextNodesForObj = true;
        }
        if (config.stripWhitespaces === undefined) {
            config.stripWhitespaces = true;
        }
        config.datetimeAccessFormPaths = config.datetimeAccessFormPaths || [];
    }
    var DOMNodeTypes = {
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        CDATA_SECTION_NODE: 4,
        COMMENT_NODE: 8,
        DOCUMENT_NODE: 9
    };
    function initRequiredPolyfills() {
        function pad(number) {
            var r = String(number);
            if (r.length === 1) {
                r = "0" + r;
            }
            return r;
        }
        if (typeof String.prototype.trim !== "function") {
            String.prototype.trim = function() {
                return this.replace(/^\s+|^\n+|(\s|\n)+$/g, "");
            };
        }
        if (typeof Date.prototype.toISOString !== "function") {
            Date.prototype.toISOString = function() {
                return this.getUTCFullYear() + "-" + pad(this.getUTCMonth() + 1) + "-" + pad(this.getUTCDate()) + "T" + pad(this.getUTCHours()) + ":" + pad(this.getUTCMinutes()) + ":" + pad(this.getUTCSeconds()) + "." + String((this.getUTCMilliseconds() / 1e3).toFixed(3)).slice(2, 5) + "Z";
            };
        }
    }
    function getNodeLocalName(node) {
        var nodeLocalName = node.localName;
        if (nodeLocalName == null) nodeLocalName = node.baseName;
        if (nodeLocalName == null || nodeLocalName == "") nodeLocalName = node.nodeName;
        return nodeLocalName;
    }
    function getNodePrefix(node) {
        return node.prefix;
    }
    function escapeXmlChars(str) {
        if (typeof str == "string") return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"); else return str;
    }
    function unescapeXmlChars(str) {
        return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/");
    }
    function toArrayAccessForm(obj, childName, path) {
        switch (config.arrayAccessForm) {
          case "property":
            if (!(obj[childName] instanceof Array)) obj[childName + "_asArray"] = [ obj[childName] ]; else obj[childName + "_asArray"] = obj[childName];
            break;
        }
        if (!(obj[childName] instanceof Array) && config.arrayAccessFormPaths.length > 0) {
            var idx = 0;
            for (;idx < config.arrayAccessFormPaths.length; idx++) {
                var arrayPath = config.arrayAccessFormPaths[idx];
                if (typeof arrayPath === "string") {
                    if (arrayPath == path) break;
                } else if (arrayPath instanceof RegExp) {
                    if (arrayPath.test(path)) break;
                } else if (typeof arrayPath === "function") {
                    if (arrayPath(obj, childName, path)) break;
                }
            }
            if (idx != config.arrayAccessFormPaths.length) {
                obj[childName] = [ obj[childName] ];
            }
        }
    }
    function fromXmlDateTime(prop) {
        var bits = prop.split(/[-T:+Z]/g);
        var d = new Date(bits[0], bits[1] - 1, bits[2]);
        var secondBits = bits[5].split(".");
        d.setHours(bits[3], bits[4], secondBits[0]);
        if (secondBits.length > 1) d.setMilliseconds(secondBits[1]);
        if (bits[6] && bits[7]) {
            var offsetMinutes = bits[6] * 60 + Number(bits[7]);
            var sign = /\d\d-\d\d:\d\d$/.test(prop) ? "-" : "+";
            offsetMinutes = 0 + (sign == "-" ? -1 * offsetMinutes : offsetMinutes);
            d.setMinutes(d.getMinutes() - offsetMinutes - d.getTimezoneOffset());
        } else if (prop.indexOf("Z", prop.length - 1) !== -1) {
            d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()));
        }
        return d;
    }
    function checkFromXmlDateTimePaths(value, childName, fullPath) {
        if (config.datetimeAccessFormPaths.length > 0) {
            var path = fullPath.split(".#")[0];
            var idx = 0;
            for (;idx < config.datetimeAccessFormPaths.length; idx++) {
                var dtPath = config.datetimeAccessFormPaths[idx];
                if (typeof dtPath === "string") {
                    if (dtPath == path) break;
                } else if (dtPath instanceof RegExp) {
                    if (dtPath.test(path)) break;
                } else if (typeof dtPath === "function") {
                    if (dtPath(obj, childName, path)) break;
                }
            }
            if (idx != config.datetimeAccessFormPaths.length) {
                return fromXmlDateTime(value);
            } else return value;
        } else return value;
    }
    function parseDOMChildren(node, path) {
        if (node.nodeType == DOMNodeTypes.DOCUMENT_NODE) {
            var result = new Object();
            var nodeChildren = node.childNodes;
            for (var cidx = 0; cidx < nodeChildren.length; cidx++) {
                var child = nodeChildren.item(cidx);
                if (child.nodeType == DOMNodeTypes.ELEMENT_NODE) {
                    var childName = getNodeLocalName(child);
                    result[childName] = parseDOMChildren(child, childName);
                }
            }
            return result;
        } else if (node.nodeType == DOMNodeTypes.ELEMENT_NODE) {
            var result = new Object();
            result.__cnt = 0;
            var nodeChildren = node.childNodes;
            for (var cidx = 0; cidx < nodeChildren.length; cidx++) {
                var child = nodeChildren.item(cidx);
                var childName = getNodeLocalName(child);
                if (child.nodeType != DOMNodeTypes.COMMENT_NODE) {
                    result.__cnt++;
                    if (result[childName] == null) {
                        result[childName] = parseDOMChildren(child, path + "." + childName);
                        toArrayAccessForm(result, childName, path + "." + childName);
                    } else {
                        if (result[childName] != null) {
                            if (!(result[childName] instanceof Array)) {
                                result[childName] = [ result[childName] ];
                                toArrayAccessForm(result, childName, path + "." + childName);
                            }
                        }
                        result[childName][result[childName].length] = parseDOMChildren(child, path + "." + childName);
                    }
                }
            }
            for (var aidx = 0; aidx < node.attributes.length; aidx++) {
                var attr = node.attributes.item(aidx);
                result.__cnt++;
                result[config.attributePrefix + attr.name] = attr.value;
            }
            var nodePrefix = getNodePrefix(node);
            if (nodePrefix != null && nodePrefix != "") {
                result.__cnt++;
                result.__prefix = nodePrefix;
            }
            if (result["#text"] != null) {
                result.__text = result["#text"];
                if (result.__text instanceof Array) {
                    result.__text = result.__text.join("\n");
                }
                if (config.escapeMode) result.__text = unescapeXmlChars(result.__text);
                if (config.stripWhitespaces) result.__text = result.__text.trim();
                delete result["#text"];
                if (config.arrayAccessForm == "property") delete result["#text_asArray"];
                result.__text = checkFromXmlDateTimePaths(result.__text, childName, path + "." + childName);
            }
            if (result["#cdata-section"] != null) {
                result.__cdata = result["#cdata-section"];
                delete result["#cdata-section"];
                if (config.arrayAccessForm == "property") delete result["#cdata-section_asArray"];
            }
            if (result.__cnt == 1 && result.__text != null) {
                result = result.__text;
            } else if (result.__cnt == 0 && config.emptyNodeForm == "text") {
                result = "";
            } else if (result.__cnt > 1 && result.__text != null && config.skipEmptyTextNodesForObj) {
                if (config.stripWhitespaces && result.__text == "" || result.__text.trim() == "") {
                    delete result.__text;
                }
            }
            delete result.__cnt;
            if (config.enableToStringFunc && (result.__text != null || result.__cdata != null)) {
                result.toString = function() {
                    return (this.__text != null ? this.__text : "") + (this.__cdata != null ? this.__cdata : "");
                };
            }
            return result;
        } else if (node.nodeType == DOMNodeTypes.TEXT_NODE || node.nodeType == DOMNodeTypes.CDATA_SECTION_NODE) {
            return node.nodeValue;
        }
    }
    function startTag(jsonObj, element, attrList, closed) {
        var resultStr = "<" + (jsonObj != null && jsonObj.__prefix != null ? jsonObj.__prefix + ":" : "") + element;
        if (attrList != null) {
            for (var aidx = 0; aidx < attrList.length; aidx++) {
                var attrName = attrList[aidx];
                var attrVal = jsonObj[attrName];
                if (config.escapeMode) attrVal = escapeXmlChars(attrVal);
                resultStr += " " + attrName.substr(config.attributePrefix.length) + "='" + attrVal + "'";
            }
        }
        if (!closed) resultStr += ">"; else resultStr += "/>";
        return resultStr;
    }
    function endTag(jsonObj, elementName) {
        return "</" + (jsonObj.__prefix != null ? jsonObj.__prefix + ":" : "") + elementName + ">";
    }
    function endsWith(str, suffix) {
        return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }
    function jsonXmlSpecialElem(jsonObj, jsonObjField) {
        if (config.arrayAccessForm == "property" && endsWith(jsonObjField.toString(), "_asArray") || jsonObjField.toString().indexOf(config.attributePrefix) == 0 || jsonObjField.toString().indexOf("__") == 0 || jsonObj[jsonObjField] instanceof Function) return true; else return false;
    }
    function jsonXmlElemCount(jsonObj) {
        var elementsCnt = 0;
        if (jsonObj instanceof Object) {
            for (var it in jsonObj) {
                if (jsonXmlSpecialElem(jsonObj, it)) continue;
                elementsCnt++;
            }
        }
        return elementsCnt;
    }
    function parseJSONAttributes(jsonObj) {
        var attrList = [];
        if (jsonObj instanceof Object) {
            for (var ait in jsonObj) {
                if (ait.toString().indexOf("__") == -1 && ait.toString().indexOf(config.attributePrefix) == 0) {
                    attrList.push(ait);
                }
            }
        }
        return attrList;
    }
    function parseJSONTextAttrs(jsonTxtObj) {
        var result = "";
        if (jsonTxtObj.__cdata != null) {
            result += "<![CDATA[" + jsonTxtObj.__cdata + "]]>";
        }
        if (jsonTxtObj.__text != null) {
            if (config.escapeMode) result += escapeXmlChars(jsonTxtObj.__text); else result += jsonTxtObj.__text;
        }
        return result;
    }
    function parseJSONTextObject(jsonTxtObj) {
        var result = "";
        if (jsonTxtObj instanceof Object) {
            result += parseJSONTextAttrs(jsonTxtObj);
        } else if (jsonTxtObj != null) {
            if (config.escapeMode) result += escapeXmlChars(jsonTxtObj); else result += jsonTxtObj;
        }
        return result;
    }
    function parseJSONArray(jsonArrRoot, jsonArrObj, attrList) {
        var result = "";
        if (jsonArrRoot.length == 0) {
            result += startTag(jsonArrRoot, jsonArrObj, attrList, true);
        } else {
            for (var arIdx = 0; arIdx < jsonArrRoot.length; arIdx++) {
                result += startTag(jsonArrRoot[arIdx], jsonArrObj, parseJSONAttributes(jsonArrRoot[arIdx]), false);
                result += parseJSONObject(jsonArrRoot[arIdx]);
                result += endTag(jsonArrRoot[arIdx], jsonArrObj);
            }
        }
        return result;
    }
    function parseJSONObject(jsonObj) {
        var result = "";
        var elementsCnt = jsonXmlElemCount(jsonObj);
        if (elementsCnt > 0) {
            for (var it in jsonObj) {
                if (jsonXmlSpecialElem(jsonObj, it)) continue;
                var subObj = jsonObj[it];
                var attrList = parseJSONAttributes(subObj);
                if (subObj == null || subObj == undefined) {
                    result += startTag(subObj, it, attrList, true);
                } else if (subObj instanceof Object) {
                    if (subObj instanceof Array) {
                        result += parseJSONArray(subObj, it, attrList);
                    } else if (subObj instanceof Date) {
                        result += startTag(subObj, it, attrList, false);
                        result += subObj.toISOString();
                        result += endTag(subObj, it);
                    } else {
                        var subObjElementsCnt = jsonXmlElemCount(subObj);
                        if (subObjElementsCnt > 0 || subObj.__text != null || subObj.__cdata != null) {
                            result += startTag(subObj, it, attrList, false);
                            result += parseJSONObject(subObj);
                            result += endTag(subObj, it);
                        } else {
                            result += startTag(subObj, it, attrList, true);
                        }
                    }
                } else {
                    result += startTag(subObj, it, attrList, false);
                    result += parseJSONTextObject(subObj);
                    result += endTag(subObj, it);
                }
            }
        }
        result += parseJSONTextObject(jsonObj);
        return result;
    }
    this.parseXmlString = function(xmlDocStr) {
        return nlapiStringToXML(xmlDocStr);
    };
    this.asArray = function(prop) {
        if (prop instanceof Array) return prop; else return [ prop ];
    };
    this.toXmlDateTime = function(dt) {
        if (dt instanceof Date) return dt.toISOString(); else if (typeof dt === "number") return new Date(dt).toISOString(); else return null;
    };
    this.asDateTime = function(prop) {
        if (typeof prop == "string") {
            return fromXmlDateTime(prop);
        } else return prop;
    };
    this.xml2json = function(xmlDoc) {
        return parseDOMChildren(xmlDoc);
    };
    this.xml_str2json = function(xmlDocStr) {
        var xmlDoc = this.parseXmlString(xmlDocStr);
        if (xmlDoc != null) return this.xml2json(xmlDoc); else return null;
    };
    this.json2xml_str = function(jsonObj) {
        return parseJSONObject(jsonObj);
    };
    this.json2xml = function(jsonObj) {
        var xmlDocStr = this.json2xml_str(jsonObj);
        return this.parseXmlString(xmlDocStr);
    };
    this.getVersion = function() {
        return VERSION;
    };
}

if (typeof this.alert == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function parseException(e) {
    var code, message;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = "nlobjError";
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + e.getStackTrace().join(", ");
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    return {
        code: code,
        message: message
    };
}

function processException(e, info) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "\r\n" + info;
    }
    nlapiSendEmail(-5, "allan@zakeusa.com", code, message);
    _log(code, message);
    return {
        code: code,
        message: message
    };
}

var __RecordLogFlag = false;

function _log(title, detail) {
    var logSwitch = true, format = false;
    if (__RecordLogFlag) format = true;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 2);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
            if (__RecordLogFlag) {
                LogFile.writeLog(title, detail);
            }
        } else {
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            console.log(message);
        }
    }
}

function _log_email(title, detail) {
    nlapiSendEmail(-5, "59532543@qq.com", title, detail);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function extendFn(Fn) {
    Fn.extend = Fn.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function emailMergeObj(obj, tplId) {
    var emailResult = nlapiLoadFile(tplId).getValue();
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            emailResult = emailResult.replace(new RegExp(k, "g"), obj[o]);
        }
    }
    return emailResult;
}

function templateMerge(tpl, obj) {
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            var content = obj[o];
            content = content.replace(/\r\n/g, "<br/>");
            tpl = tpl.replace(new RegExp(k, "g"), content);
        }
    }
    return tpl;
}

function createHTML(html, obj) {
    for (var i in obj) {
        var k = "{{" + i + "}}";
        html = html.replace(new RegExp(k, "g"), obj[i]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiLoadRecord(type, id) {
    var record = nlapiLoadRecord(type, id);
    return {
        getFieldText: function(name) {
            return record.getFieldText(name);
        },
        getFieldValue: function(name) {
            return record.getFieldValue(name);
        },
        getField: function(name) {
            return {
                name: name,
                value: record.getFieldValue(name),
                text: record.getFieldText(name)
            };
        },
        getId: function() {
            return record.getId();
        },
        getRecord: function() {
            return record;
        }
    };
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    var joinname = join + "." + name;
                    record[joinname] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function __nlapiSearchRecord2(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            record["__id"] = search_record.getId();
            record["__type"] = search_record.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var value = search_record.getValue(column);
                var text = search_record.getText(column);
                if (value && text) {
                    record[name] = {
                        value: value,
                        text: text
                    };
                } else {
                    record[name] = value;
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecord2 LIST", list);
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getSearchResult(search) {
    var columns = search.getColumns();
    var searchList = [];
    var resultSet = search.runSearch();
    resultSet.forEachResult(function(searchResult) {
        var record = {};
        for (var i = 0; i < columns.length; i++) {
            var column = columns[i];
            record[column.getName()] = {
                value: searchResult.getValue(column),
                text: searchResult.getText(column)
            };
        }
        searchList.push(record);
        return true;
    });
    _log("getSearchResult", searchList);
    return searchList;
}

function groupSearchResult(keys, array, toArray) {
    var group = {};
    array.forEach(function(item) {
        var key = "";
        if (typeof keys == "string") {
            key = item[keys].value;
        } else if (Array.isArray(keys)) {
            key = keys.map(function(key_name) {
                return key += item[key_name].value;
            }).join("___");
        } else {
            key = item["internalid"].value;
        }
        if (group.hasOwnProperty(key)) {
            group[key].push(item);
        } else {
            group[key] = [ item ];
        }
    });
    _log("groupSearchResult", group);
    if (toArray) {
        return obj_to_array(group);
    } else {
        return group;
    }
}

function obj_to_array(obj) {
    var list = [];
    for (var i in obj) {
        list.push(obj[i]);
    }
    return list;
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        _log("debug - [Profiling]", Math.round((new Date().getTime() - this.startTime) / 1e3) + "s");
    }
};

var EBayRecordType = {
    customrecord_ebay_item_site_setting: "customrecord_ebay_item_site_setting",
    customrecord_ebay_item_language: "customrecord_ebay_item_language",
    customrecord_ebay_global: "customrecord_ebay_global"
};

function deepmerge(target, src) {
    var array = Array.isArray(src);
    var dst = array && [] || {};
    if (array) {
        target = target || [];
        dst = dst.concat(target);
        src.forEach(function(e, i) {
            if (typeof dst[i] === "undefined") {
                dst[i] = e;
            } else if (typeof e === "object") {
                dst[i] = deepmerge(target[i], e);
            } else {
                if (target.indexOf(e) === -1) {
                    dst.push(e);
                }
            }
        });
    } else {
        if (target && typeof target === "object") {
            Object.keys(target).forEach(function(key) {
                dst[key] = target[key];
            });
        }
        Object.keys(src).forEach(function(key) {
            if (typeof src[key] !== "object" || !src[key]) {
                dst[key] = src[key];
            } else {
                if (!target[key]) {
                    dst[key] = src[key];
                } else {
                    dst[key] = deepmerge(target[key], src[key]);
                }
            }
        });
    }
    return dst;
}

function autoSetEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = item.label;
        }
        item.options.forEach(function(opt) {
            opt.translation = opt.value;
        });
    });
}

function autoRemoveEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = "";
        }
    });
    item.options.forEach(function(opt) {
        opt.translation = "";
    });
}

Array.prototype.unique = function() {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j]) a.splice(j--, 1);
        }
    }
    return a;
};

function convertToEbayVariationXML(variation, mainSKU) {
    var xml = "";
    xml += "<Variations>";
    var hasPictures = variation.childRecordList.some(function(item) {
        return item.custitem_ebay_variation_picture;
    });
    if (hasPictures) {
        xml += "    <Pictures>";
        variation.availOptions.forEach(function(item) {
            xml += "        <VariationSpecificName>" + item.translation + "</VariationSpecificName>";
            var specificGroup = {};
            variation.childRecordList.forEach(function(childRecord) {
                var _translation = childRecord[item.name].translation;
                if (specificGroup.hasOwnProperty(_translation)) {
                    if (childRecord.custitem_ebay_variation_picture) {
                        specificGroup[_translation].push([ childRecord.custitem_ebay_variation_picture ]);
                    }
                } else {
                    if (childRecord.custitem_ebay_variation_picture) specificGroup[_translation] = [ childRecord.custitem_ebay_variation_picture ];
                }
            });
            for (var label in specificGroup) {
                xml += "        <VariationSpecificPictureSet>";
                xml += "            <VariationSpecificValue>" + label + "</VariationSpecificValue>";
                specificGroup[label].forEach(function(pictureURL) {
                    if (pictureURL) {
                        xml += "            <PictureURL>";
                        xml += "                " + pictureURL;
                        xml += "            </PictureURL>";
                    }
                });
                xml += "        </VariationSpecificPictureSet>";
            }
        });
        xml += "    </Pictures>";
    }
    variation.childRecordList.forEach(function(vari) {
        xml += "    <Variation>";
        xml += "        <StartPrice>" + vari.baseprice + "</StartPrice>";
        var matrixItemSKU = vari.itemid;
        matrixItemSKU = matrixItemSKU.substring(matrixItemSKU.indexOf(" : ") + 3);
        xml += "        <SKU>" + mainSKU + "/" + matrixItemSKU + "</SKU>";
        xml += "        <Quantity>" + vari.locationquantityavailable + "</Quantity>";
        xml += "        <VariationSpecifics>";
        variation.availOptions.forEach(function(item) {
            xml += "            <NameValueList>";
            xml += "                <Name>" + item.translation + "</Name>";
            xml += "                <Value>" + vari[item.name].translation + "</Value>";
            xml += "            </NameValueList>";
        });
        xml += "        </VariationSpecifics>";
        xml += "    </Variation>";
    });
    xml += "    <VariationSpecificsSet>";
    variation.availOptions.forEach(function(item) {
        xml += "        <NameValueList>";
        xml += "            <Name>" + item.translation + "</Name>";
        var values = variation.childRecordList.map(function(vari) {
            var vari_translation = vari[item.name].translation;
            return "            <Value>" + vari_translation + "</Value>";
        });
        xml += values.unique().join("");
        xml += "        </NameValueList>";
    });
    xml += "    </VariationSpecificsSet>";
    xml += "</Variations>";
    return xml;
}

function createProxyImageURL(netsuiteImageURL) {
    netsuiteImageURL = netsuiteImageURL.substring(netsuiteImageURL.indexOf("?") + 1);
    netsuiteImageURL = netsuiteImageURL.split("&");
    var urlParams = {};
    netsuiteImageURL.forEach(function(item) {
        item = item.split("=");
        urlParams[item[0]] = item[1];
    });
    var h = urlParams["h"];
    var id = urlParams["id"];
    var position = {};
    for (var j = 0; j < id.length; j++) {
        var p = j + 1;
        position[p] = id.charAt(j);
    }
    var str = [];
    for (var i = 0; i < h.length; i++) {
        str.push(h.charAt(i));
    }
    var name = [];
    str.forEach(function(char, index) {
        if (position.hasOwnProperty(index)) {
            name.push(position[index]);
        }
        name.push(char);
    });
    return name.join("");
}

function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name) || "";
    },
    val: function(name) {
        return this.rec.getFieldValue(name) || "";
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
        _log("~~~~~~~~~~~~~~~~~~~~~~~~~~ Refresh!!! and rec is new and this.refreshFlag = true; ~~~~~~~~~~~~~~~~~~~~~~");
    }
});

extendFn(Record);

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    _log(group, list);
    return list;
};

var EBayFeedStatus = {
    online: 1,
    offline: 2
};

var EBayFeedAction = {
    PleaseSelectAction: 7,
    NewOrUpdate: 2,
    ReNew: 5,
    OfflineItem: 6
};

var EbayItemFeed = {
    __type: "customrecord_ebay_item_api_feed",
    FieldMapping: {
        custrecord_ebay_feed_item: "itemRecordId",
        custrecord_ebay_feed_language_id: "languageId",
        custrecord_ebay_feed_global_site: "eBayGlobalSiteRecordId",
        custrecord_ebay_feed_account: "eBayGlobalAccountSettingRecordId",
        custrecord_ebay_feed_seq: "itemTitlePictureSequenceId",
        custrecord_ebay_feed_language: "eBayItemLanguageSetRecordId",
        custrecord_ebay_feed_site: "eBayItemSiteSettingRecordId",
        custrecord_ebay_feed_push_qty: "custrecord_ei_qty",
        custrecord_ebay_feed_category_id: "site_category_id",
        custrecord_ebay_feed_specifics: "specificList",
        custrecord_ebay_feed_gallery: "gallery",
        custrecord_ebay_feed_body_picture: "bodyPicture",
        custrecord_ebay_feed_api_site: "country",
        custrecord_ebay_feed_location_country: "locationCountry",
        custrecord_ebay_feed_api_sku: "sku",
        custrecord_ebay_feed_api_title: "title",
        custrecord_ebay_feed_api_baseprice: "baseprice",
        custrecord_ebay_feed_api_price: "price",
        custrecord_ebay_feed_currency: "currency",
        custrecord_ebay_feed_description: "description",
        custrecord_ebay_feed_language_code: "language_code",
        custrecord_ebay_feed_shippingdetails: "shippingDetails",
        custrecord_ebay_feed_returnpolicy: "returnPolicy",
        custrecord_ebay_feed_paypalaccount: "paypalAccount",
        custrecord_ebay_feed_seller_id: "sellerId",
        custrecord_ebay_feed_location: "defaultShipFromLocation",
        custrecord_ebay_feed_token: "token",
        custrecord_ebay_feed_errorlanguage: "errorLanguage",
        custrecord_ebay_feed_site_id: "apiSiteId",
        custrecord_ebay_feed_matrix_item: "ismatrix",
        custrecord_ebay_feed_variations: "variation",
        custrecord_ebay_feed_item_type: "itemType",
        custrecord_ebay_feed_is_var: "isVar",
        custrecord_ebay_feed_status: "_status",
        custrecord_ebay_feed_action: "_action"
    },
    getRecordFieldList: function() {
        var f = this.FieldMapping;
        var list = [];
        for (var i in f) {
            list.push(i);
        }
        return list;
    },
    create: function(feed) {
        var record = nlapiCreateRecord(this.__type);
        this.processRecord(record, feed, "create");
        return nlapiSubmitRecord(record, true);
    },
    update: function(id, feed) {
        var record = nlapiLoadRecord(this.__type, id);
        var processResult = this.processRecord(record, feed, "update");
        if (processResult.recordFieldChangedCount) {
            return {
                recordFieldChangedCount: processResult.recordFieldChangedCount,
                id: nlapiSubmitRecord(record, true)
            };
        } else {
            return {
                recordFieldChangedCount: 0,
                id: id
            };
        }
    },
    search: function(id, addFilter) {
        var fieldMapping = this.FieldMapping;
        var columns = [];
        for (var i in fieldMapping) {
            columns.push(new nlobjSearchColumn(i));
        }
        [ "internalid", "custrecord_ebay_feed_category_title", "lastmodified", "lastmodifiedby" ].forEach(function(name) {
            columns.push(new nlobjSearchColumn(name));
        });
        var filter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ id ]), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_language_id", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_seq", null, "noneof", "@NONE@") ];
        if (addFilter && Array.isArray(addFilter)) {
            filter = filter.concat(addFilter);
        }
        var searchResult = __nlapiSearchRecord(this.__type, null, filter, columns);
        searchResult.list.forEach(function(item, index) {
            index++;
            item.__no = index;
            item.__link = nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", item.internalid.value);
        });
        return searchResult;
    },
    processRecord: function(record, feed, action) {
        var newFeedFieldMapping = this.FieldMapping;
        var recordFieldChangedCount = 0;
        for (var ebay_feed_record_field in newFeedFieldMapping) {
            var feedFieldValue;
            if (feed.hasOwnProperty(newFeedFieldMapping[ebay_feed_record_field])) {
                feedFieldValue = feed[newFeedFieldMapping[ebay_feed_record_field]];
            }
            if (!feedFieldValue) feedFieldValue = null;
            if (Array.isArray(feedFieldValue)) {
                feedFieldValue = JSON.stringify(feedFieldValue);
            }
            if (typeof feedFieldValue == "object") {
                feedFieldValue = JSON.stringify(feedFieldValue);
            }
            var setFlag = false;
            if (action == "create") {
                setFlag = true;
                recordFieldChangedCount++;
            } else {
                var recordFieldValue = record.getFieldValue(ebay_feed_record_field) || record.getFieldText(ebay_feed_record_field);
                if (ebay_feed_record_field == "custrecord_ebay_feed_status") {
                    if (recordFieldValue == EBayFeedStatus.online) {} else {
                        if (recordFieldValue != feedFieldValue) {
                            setFlag = true;
                            recordFieldChangedCount++;
                        }
                    }
                } else if (ebay_feed_record_field == "custrecord_ebay_feed_action") {
                    if (!recordFieldValue) {
                        setFlag = true;
                        recordFieldChangedCount++;
                    }
                } else {
                    if (recordFieldValue != feedFieldValue) {
                        setFlag = true;
                        recordFieldChangedCount++;
                    }
                }
            }
            if (setFlag) {
                record.setFieldValue(ebay_feed_record_field, feedFieldValue);
            }
        }
        _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
        return {
            recordFieldChangedCount: recordFieldChangedCount
        };
    }
};

function __EbayItemFeed(id) {
    Record.call(this, EbayItemFeed.__type, id);
}

inherit(Record, __EbayItemFeed);

__EbayItemFeed.prototype.getVariation = function() {
    var v = this.val("custrecord_ebay_feed_variations");
    if (v && typeof v == "string") {
        return JSON.parse(v);
    }
    return v;
};

var EBayRequest = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll",
    headers: {
        "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
        "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
        "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
        "Content-Type": "application/xml"
    }
};

__EbayItemFeed.prototype.callAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<AddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + that.val("custrecord_ebay_feed_token") + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <ErrorLanguage>en_US</ErrorLanguage>";
    xml += "  <WarningLevel>High</WarningLevel>";
    xml += "  <Item>";
    xml += "    <Site>" + that.val("custrecord_ebay_feed_api_site") + "</Site>";
    var mainSKU = that.val("custrecord_ebay_feed_api_sku");
    xml += "    <SKU>" + mainSKU + "</SKU>";
    xml += "    <Title>" + that.val("custrecord_ebay_feed_api_title") + "</Title>";
    xml += "    <Currency>" + that.val("custrecord_ebay_feed_currency") + "</Currency>";
    xml += "    <ConditionID>1000</ConditionID>";
    xml += "    <Country>" + that.val("custrecord_ebay_feed_location_country") + "</Country>";
    xml += "    <StartPrice>" + that.val("custrecord_ebay_feed_api_price") + "</StartPrice>";
    xml += "    <DispatchTimeMax>2</DispatchTimeMax>";
    xml += "    <HitCounter>BasicStyle</HitCounter>";
    xml += "    <ListingDuration>GTC</ListingDuration>";
    xml += "    <ListingType>FixedPriceItem</ListingType>";
    xml += "    <Location>" + that.val("custrecord_ebay_feed_location") + "</Location>";
    xml += "    <PaymentMethods>PayPal</PaymentMethods>";
    xml += "    <PayPalEmailAddress>" + that.val("custrecord_ebay_feed_paypalaccount") + "</PayPalEmailAddress>";
    xml += "    <PrivateListing>false</PrivateListing>";
    xml += "    <Quantity>" + that.val("custrecord_ebay_feed_push_qty") + "</Quantity>";
    xml += "    <OutOfStockControl>true</OutOfStockControl>";
    xml += "    <PrimaryCategory>";
    xml += "      <CategoryID>" + that.val("custrecord_ebay_feed_category_id") + "</CategoryID>";
    xml += "    </PrimaryCategory>";
    xml += "    <Description><![CDATA[" + that.val("custrecord_ebay_feed_description") + "]]></Description>";
    var specifics = that.val("custrecord_ebay_feed_specifics");
    if (specifics) {
        specifics = JSON.parse(specifics);
        if (Array.isArray(specifics) && specifics.length) {
            xml += "    <ItemSpecifics>";
            xml += specifics.map(function(item) {
                var nameValueList = "";
                nameValueList += "<NameValueList>";
                nameValueList += "    <Name>" + nlapiEscapeXML(item.specificName) + "</Name>";
                nameValueList += "    <Value>" + nlapiEscapeXML(item.specificValue) + "</Value>";
                nameValueList += "</NameValueList>";
                return nameValueList;
            }).join("");
            xml += "    </ItemSpecifics>";
        }
    }
    var gallery = that.val("custrecord_ebay_feed_gallery");
    if (gallery) {
        gallery = JSON.parse(gallery);
        if (Array.isArray(gallery) && gallery.length) {
            xml += "    <PictureDetails>";
            gallery.forEach(function(link) {
                if (link.indexOf("/core/media/media.nl") == 0) {
                    link = "https://system.na1.netsuite.com" + link;
                }
                xml += "      <PictureURL>" + nlapiEscapeXML(link) + "</PictureURL>";
            });
            xml += "    </PictureDetails>";
        }
    }
    var custrecord_ebay_feed_is_var = that.val("custrecord_ebay_feed_is_var");
    if (custrecord_ebay_feed_is_var == "T") {
        var variations = that.val("custrecord_ebay_feed_variations");
        variations = JSON.parse(variations);
        xml += convertToEbayVariationXML(variations, mainSKU);
    }
    xml += _.unescape(that.val("custrecord_ebay_feed_returnpolicy"));
    xml += _.unescape(that.val("custrecord_ebay_feed_shippingdetails"));
    _log("shipping....", _.unescape(that.val("custrecord_ebay_feed_shippingdetails")));
    xml += "  </Item>";
    xml += "</AddFixedPriceItemRequest>";
    var header = EBayRequest.headers;
    header["X-EBAY-API-SITEID"] = that.val("custrecord_ebay_feed_site_id");
    extend(header, {
        "X-EBAY-API-CALL-NAME": "AddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    });
    _log("header", header);
    _log_email("Feed ID: " + that.getId() + " XML: " + mainSKU, xml);
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
    var x2js = new X2JS();
    var responseJSON = x2js.xml_str2json(response.getBody());
    this.rec.setFieldValue("custrecord_ebay_feed_last_api_request", xml);
    this.rec.setFieldValue("custrecord_ebay_feed_last_api_response", response.getBody());
    nlapiSubmitRecord(this.rec, true);
    _log("lastmodifiedby", that.val("lastmodifiedby"));
    var lastmodifiedby = that.val("lastmodifiedby");
    lastmodifiedby = parseInt(lastmodifiedby);
    if (lastmodifiedby > 0) {
        nlapiSendEmail(-5, that.val("lastmodifiedby"), "Feed ID: " + that.getId() + " Ebay API Response", JSON.stringify(responseJSON));
    } else {
        nlapiSendEmail(-5, "allan@zakeusa.com", "Feed ID: " + that.getId() + " Ebay API Response", JSON.stringify(responseJSON));
    }
};

function run() {
    var context = nlapiGetContext();
    var ebaySiteId = context.getSetting("SCRIPT", "custscript_ebay_site");
    var site = nlapiLookupField("customrecord_ebay_global", ebaySiteId, "custrecord_ebay_territory_id");
    var feedSearchResults = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_api_site", null, "is", site), new nlobjSearchFilter("custrecord_ebay_feed_action", null, "anyof", [ EBayFeedAction.NewOrUpdate ]), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_language_id", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_seq", null, "noneof", "@NONE@") ], null);
    _log("feedSearchResults", feedSearchResults);
    for (var i = 0; i < feedSearchResults.length; i++) {
        var feedSearchResult = feedSearchResults[i];
        _log("__EbayItemFeed", "------------------------------ START: " + nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", feedSearchResult.getId()) + " --------------------------------");
        try {
            var feed = new __EbayItemFeed(feedSearchResult.getId());
            feed.callAddFixedPriceItem();
        } catch (e) {
            e = parseException(e);
            _log_email("Feed ID: " + feed.getId() + " has error", e.code + ": " + e.message + "<br/><br/>" + JSON.stringify(feed));
        }
        _log("__EbayItemFeed", "------------------------------ END --------------------------------");
    }
}