function beforeLoad(type, form, request) {
    try {
        if (nlapiGetContext().getExecutionContext() == "userinterface") {
            var shipping_options_flag = false;
            var shipping_options = nlapiGetFieldValue("custrecord_eso_shippingdetails");
            if (shipping_options) {
                shipping_options = JSON.parse(shipping_options);
                shipping_options_flag = true;
            }
            var GlobalShipping = form.addField("custpage_globalshipping", "checkbox", "Global Shipping");
            var ShipToLocations = form.addField("custpage_shiptolocations", "multiselect", "ShipTo Locations", "customlist_ebay_country_code_type");
            var ShippingType = form.addField("custpage_shippingdetails_shippingtype", "select", "Shipping Type", "customlist_ebay_shipping_type_code");
            var ExcludeShipToLocation = form.addField("custpage_exclocation", "multiselect", "Exclude ShipTo Locations", "customlist_ebay_country_code_type");
            if (shipping_options_flag) {
                ShipToLocations.setDefaultValue(shipping_options.ShipToLocations.map(function(location) {
                    return location.value;
                }));
                GlobalShipping.setDefaultValue(shipping_options.GlobalShipping.value);
                ExcludeShipToLocation.setDefaultValue(shipping_options.ShippingDetails.ExcludeShipToLocation.map(function(location) {
                    return location.value;
                }));
                ShippingType.setDefaultValue(shipping_options.ShippingDetails.ShippingType.value);
            }
            var DomesticShippingTab = form.addTab("custpage_tab_domestic_shipping", "Domestic Shipping");
            for (var i = 1; i <= 4; i++) {
                var domestic_shipping_subtab = "custpage_subtab_domestic_shipping" + i;
                var DomesticShippingSubTab = form.addSubTab(domestic_shipping_subtab, "Domestic Shipping " + i, "custpage_tab_domestic_shipping");
                if (i == 1) {
                    var FreeShipping = form.addField("custpage_shipping_service_freeshipping", "checkbox", "Free Shipping", null, domestic_shipping_subtab);
                }
                var ShippingService = form.addField("custpage_shipping_service" + i, "select", "Shipping Service", "customrecord_ebay_shipping_service_code", domestic_shipping_subtab);
                var ShippingServiceCost = form.addField("custpage_shipping_service_cost" + i, "currency", "Shipping Service Cost", null, domestic_shipping_subtab);
                var ShippingServiceAdditionalCost = form.addField("custpage_shipping_service_additional_cost" + i, "currency", "Shipping Service Additional Cost", null, domestic_shipping_subtab);
                var ShippingSurcharge = form.addField("custpage_shipping_surcharge" + i, "currency", "Shipping Surcharge", null, domestic_shipping_subtab);
                if (shipping_options_flag) {
                    var shipping_option = shipping_options.ShippingDetails.ShippingServiceOptions.find(function(item) {
                        return item.ShippingServicePriority == i;
                    });
                    if (shipping_option) {
                        if (i == 1) {
                            FreeShipping.setDefaultValue(shipping_option.FreeShipping.value);
                        }
                        ShippingService.setDefaultValue(shipping_option.ShippingService.value);
                        ShippingServiceCost.setDefaultValue(shipping_option.ShippingServiceCost);
                        ShippingServiceAdditionalCost.setDefaultValue(shipping_option.ShippingServiceAdditionalCost);
                        ShippingSurcharge.setDefaultValue(shipping_option.ShippingSurcharge);
                    }
                }
            }
            var InternationalShippingServiceTab = form.addTab("custpage_tab_international_shipping", "International Shipping");
            for (var j = 1; j <= 5; j++) {
                var international_shipping_subtab = "custpage_subtab_international_shipping" + j;
                var InternationalShippingSubTab = form.addSubTab(international_shipping_subtab, "International Shipping " + j, "custpage_tab_international_shipping");
                var ShippingService = form.addField("custpage_int_shipping_service" + j, "select", "Shipping Service", "customrecord_ebay_shipping_service_code", international_shipping_subtab);
                var ShippingServiceCost = form.addField("custpage_int_shipping_service_cost" + j, "currency", "Shipping Service Cost", null, international_shipping_subtab);
                var ShippingServiceAdditionalCost = form.addField("custpage_int_shipping_service_additional_cost" + j, "currency", "Shipping Service Additional Cost", null, international_shipping_subtab);
                var ShipToLocation = form.addField("custpage_int_shipto_location" + j, "multiselect", "ShipTo Location", "customlist_ebay_country_code_type", international_shipping_subtab);
                if (shipping_options_flag) {
                    var shipping_option = shipping_options.ShippingDetails.InternationalShippingServiceOption.find(function(item) {
                        return item.ShippingServicePriority == j;
                    });
                    if (shipping_option) {
                        ShippingService.setDefaultValue(shipping_option.ShippingService.value);
                        ShippingServiceCost.setDefaultValue(shipping_option.ShippingServiceCost);
                        ShippingServiceAdditionalCost.setDefaultValue(shipping_option.ShippingServiceAdditionalCost);
                        ShipToLocation.setDefaultValue(shipping_option.ShipToLocation.map(function(location) {
                            return location.value;
                        }));
                    }
                }
            }
        }
    } catch (e) {
        processException(e);
    }
}

function beforeSubmit(type) {}