function getItem(datain) {
    var productSKU = datain.productSKU;
    return searchNetSuiteItem(productSKU);
}


function searchNetSuiteItem(sku, onlyInventoryItemTag) {

    // : http://stackoverflow.com/questions/5915096/get-random-item-from-javascript-array
    // :: for test
    //var item = SZ_TEST_ITEMS[Math.floor(Math.random() * SZ_TEST_ITEMS.length)];
    //return {
    //    id: item,
    //    location: 34 // 34 Shenzhen YMW 深圳杨美仓库
    //};

    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');
    columns[1] = new nlobjSearchColumn('itemid');
    columns[2] = new nlobjSearchColumn('description');
    columns[3] = new nlobjSearchColumn('preferredlocation');

    // location
    columns[4] = new nlobjSearchColumn('location');

    var search = nlapiSearchRecord('item', null, [
        ['subsidiary', 'is', Subsidiaries.TaiwuInternational],
        'AND',
        [
            ['name', 'is', sku],
            'OR',
            ['custitem_legacy_tong_sku', 'is', sku]
        ]
    ], columns);

    if (search != null) {

        if (search.length == 1) {
            return {
                id: search[0].getId(),
                location: search[0].getValue('location')
            }
        } else {
            throw createEbayError('Item search result size wrong! SKU: ' + sku + ' and search size: ' + search.length);
        }

    } else {  // custitem_sku_alias

        var search = nlapiSearchRecord('item', null, [
            new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
            new nlobjSearchFilter('custitem_sku_alias', null, 'contains', sku)
        ], columns);

        if (search != null) {

            if (search.length == 1) {
                return {
                    id: search[0].getId(),
                    location: search[0].getValue('location')
                }
            } else {
                throw createEbayError('Item search result size wrong! SKU: ' + sku + ' and search size: ' + search.length);
            }

        } else {

            if (!onlyInventoryItemTag) {
                return searchKitItem(sku);
            }


        }

    }

}

function searchKitItem(kitSku) {

    var kitSearch = nlapiSearchRecord('customrecord_kit', null, [
        ['custrecord_kit_sku', 'is', kitSku],
        'OR',
        ['custrecord_sku_alias', 'contains', kitSku]
    ], [
        new nlobjSearchColumn('custrecord_kit_mapping')
    ]);

    //00328=3
    //00816=1;00819=1

    if (kitSearch != null) {
        if (kitSearch.length == 1) {
            var kitMapping = kitSearch[0].getValue('custrecord_kit_mapping');
            kitMapping = kitMapping.split(';');

            var itemResult = [];
            for (var i = 0; i < kitMapping.length; i++) {
                var mapping = kitMapping[i];
                var subSKU = mapping.substring(0, mapping.indexOf('='));
                var qty = parseInt(mapping.substring(mapping.indexOf('=') + 1));

                var item = searchNetSuiteItem(subSKU, true);
                item.qty = qty;

                itemResult.push(item);

            }

            return itemResult;

        } else {
            throw createEbayError('kitSearch: search result size wrong! SKU: ' + kitSku + ' and search size: ' + kitSearch.length);
        }
    } else {

        throw createEbayError('kitSearch: No ' + kitSku + ' SKU on NetSuite for Shezhen subsidiary.');
    }

}