var ITEM_OPTIONS = [ [ "custitem_var_color", "Colors" ], [ "custitem_var_size", "Sizes" ], [ "custitem_womens_size", "Womens Size" ], [ "custitem_watch_deisgn", "Watch Design" ], [ "custitem_var_assortment", "Assortment" ], [ "custitem_var_bag_pattern", "Bag Pattern" ], [ "custitem_child_size", "Child Size" ], [ "custitem_var_color_temp", "Color Temp" ], [ "custitem_var_compatible_with", "Compatible With" ], [ "custitem_var_legging_design", "Legging Design" ], [ "custitem_var_mens_size", "Mens Size" ], [ "custitem_var_print_design", "Print Design" ], [ "custitem_var_shape", "Shape" ], [ "custitem_var_style", "Style" ], [ "custitem_var_womens_shoe_size", "Shoe Size" ], [ "custitem_var_mens_pant_size", "Mens Pant Size" ], [ "custitem_var_bra_size", "Bra Size" ], [ "custitem_var_child_shoe_size", "Child Shoe Size" ], [ "custitem_var_mens_shoe_size", "Mens Shoe Size" ], [ "custitem_var_amps", "AMPS" ], [ "custitem_zake_option2", "Number" ], [ "custitem_zake_other", "Letter" ] ];

function isMatrixItem(item__internalid) {
    var ismatrix = false;
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
    if (testSearch != null) ismatrix = true;
    return ismatrix;
}

function getItemType(id) {
    return nlapiLookupField("item", id, "type");
}

function isKitItem(id) {
    return getItemType(id) == "Kit";
}

function EbayItem(type, id) {
    this.id = id;
    this.pictureSearch = null;
    Record.call(this, type, id);
}

EbayItem.TYPE = {
    INVENTORY_ITEM: "inventoryitem",
    KIT_ITEM: "kititem"
};

inherit(Record, EbayItem);

EbayItem.prototype.extend({
    getPictureSearch: function() {
        if (this.pictureSearch == null) {
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", [ this.id ]) ], [ new nlobjSearchColumn("custitem_ebay_gallery_pictures"), new nlobjSearchColumn("custitem_ebay_body_pictures") ]);
            var pictureSearch = {
                gallery: [],
                bodyPicture: []
            };
            if (search != null) {
                if (search[0].getValue("custitem_ebay_gallery_pictures")) {
                    pictureSearch.gallery = JSON.parse(search[0].getValue("custitem_ebay_gallery_pictures"));
                } else {
                    pictureSearch.gallery = [];
                }
                if (search[0].getValue("custitem_ebay_body_pictures")) {
                    pictureSearch.bodyPicture = JSON.parse(search[0].getValue("custitem_ebay_body_pictures"));
                } else {
                    pictureSearch.bodyPicture = [];
                }
            }
            this.pictureSearch = pictureSearch;
            return pictureSearch;
        } else {
            return this.pictureSearch;
        }
    },
    getGalleryPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.gallery;
    },
    getBodyPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.bodyPicture;
    }
});

function EbayInventoryItem(id, ismatrix) {
    EbayItem.call(this, "inventoryitem", id);
}

inherit(EbayItem, EbayInventoryItem);

EbayInventoryItem.prototype.getField = function(name) {
    var record = this.rec;
    return {
        name: name,
        value: record.getFieldValue(name),
        text: record.getFieldText(name)
    };
};

EbayInventoryItem.prototype._ismatrix = function() {
    return this.ismatrix == "T";
};

EbayInventoryItem.prototype.getLocationQuantity = function() {
    return this.getSubList("locations", [ "location", "location_display", "quantityavailable" ]);
};

EbayInventoryItem.prototype.getAvailableOptions = function(langCode) {
    var parentRecord = this;
    var availOptions = ITEM_OPTIONS.map(function(o) {
        if (langCode && langCode == "EN") {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: o[1]
            });
        } else {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: ""
            });
        }
    }).filter(function(item) {
        return item.value;
    });
    availOptions.forEach(function(item) {
        item.value = item.value.split("");
        item.text = item.text.split("");
        item.options = item.value.map(function(v, i) {
            if (langCode && langCode == "EN") {
                return {
                    id: v,
                    value: item.text[i],
                    translation: item.text[i]
                };
            } else {
                return {
                    id: v,
                    value: item.text[i],
                    translation: ""
                };
            }
        });
        delete item.value;
        delete item.text;
    });
    return availOptions;
};

EbayInventoryItem.prototype.getChildRecord = function() {
    var parentRecord = this;
    var availOptions = this.getAvailableOptions();
    var matrixOptionsColumns = availOptions.map(function(option) {
        return new nlobjSearchColumn(option.name).setLabel(option.label);
    });
    var columns = [ new nlobjSearchColumn("itemid"), new nlobjSearchColumn("upccode"), new nlobjSearchColumn("custitem_item_picture"), new nlobjSearchColumn("custitem_item_var_picture") ];
    columns = columns.concat(matrixOptionsColumns);
    var itemChildRecordSearchResults = nlapiSearchRecord("inventoryitem", null, [ new nlobjSearchFilter("parent", null, "is", parentRecord.getId()), new nlobjSearchFilter("isinactive", null, "is", "F") ], columns);
    var searchList = [];
    if (itemChildRecordSearchResults != null) {
        for (var i = 0, len = itemChildRecordSearchResults.length; i < len; i++) {
            var childRecord = itemChildRecordSearchResults[i];
            var record = {};
            record["__id"] = childRecord.getId();
            record["__type"] = childRecord.getRecordType();
            var options = [];
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var label = column.getLabel();
                var value = childRecord.getValue(column);
                var text = childRecord.getText(column);
                if (value && text) {
                    var optionName = availOptions.filter(function(item) {
                        return item.name == name;
                    });
                    if (optionName.length && optionName.length == 1) {
                        optionName = optionName[0];
                        options.push({
                            label: {
                                name: optionName.name,
                                label: optionName.label,
                                translation: optionName.translation
                            },
                            option: {
                                name: name,
                                value: value,
                                text: text,
                                translation: ""
                            }
                        });
                    } else {
                        record[name] = {
                            value: value,
                            text: text
                        };
                    }
                } else {
                    if (name == "itemid") {
                        if (value.indexOf(" : ") != -1) value = value.substring(value.indexOf(" : ") + 3);
                    }
                    record[name] = value;
                }
            }
            record.options = options;
            searchList.push(record);
        }
    }
    return searchList;
};

EbayInventoryItem.getAvailableOptions = function(parentId, langCode) {
    return new EbayInventoryItem(parentId).getAvailableOptions(langCode);
};

function EbayKitItem(id) {
    EbayItem.call(this, "kititem", id);
}

inherit(EbayItem, EbayKitItem);

EbayKitItem.prototype.getOption = function() {
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var name = "custitem_var_kit";
    var value = [];
    var text = [];
    var options = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        var var_name = line[3].trim();
        index++;
        value.push(id + "_" + index);
        text.push(var_name);
        return {
            id: id + "_" + index,
            value: var_name,
            translation: ""
        };
    });
    return {
        availOptions: [ {
            name: name,
            value: value,
            text: text,
            label: "Kit Variation",
            translation: "",
            options: options
        } ]
    };
};

function getVariationQuantity(id_expression, mainLocation) {
    id_expression = id_expression.map(function(id) {
        var qtyIndex = id.indexOf("*");
        if (qtyIndex != -1) {
            return {
                _id: id.substring(0, qtyIndex),
                _qty: id.substring(qtyIndex + 1)
            };
        } else {
            return {
                _id: id,
                _qty: "1"
            };
        }
    });
    var columns = [];
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", id_expression.map(function(item) {
        return item._id;
    })), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ mainLocation ]) ], columns);
    var list = [];
    if (search != null) {
        search.forEach(function(searchResult, index) {
            var total = searchResult.getValue("formulanumeric");
            _log("total" + index, total);
            if (total) {
                _log("searchResult.getId()", searchResult.getId());
                _log("id_expression", id_expression);
                var qty = id_expression.filter(function(item) {
                    return item._id == searchResult.getId();
                })[0]._qty;
                list.push(Math.floor(parseInt(total) / parseInt(qty)));
            }
        });
    } else {
        return 0;
    }
    _log("getVariationQuantity: " + JSON.stringify(id_expression), list);
    if (list.length) {
        var qty = _.min(list);
        if (!qty) qty = 0;
        _log(typeof qty, qty);
        return qty;
    } else {
        return 0;
    }
}

EbayKitItem.prototype.getChildRecord = function() {
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var childRecordList = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        index++;
        var line_id = line[0].trim();
        var line_sku = line[1].trim();
        var kit_var_id = line_id.replace(/\,/g, "^").replace(/\s/g, "");
        return {
            __id: kit_var_id,
            __type: "KIT_INV",
            itemid: kit_var_id,
            baseprice: line[2].trim(),
            custitem_ebay_variation_picture: "",
            custitem_var_kit: {
                value: id + "_" + index,
                text: line[3].trim(),
                translation: ""
            },
            locationquantityavailable: getVariationQuantity(line_id.split(",").map(function(id) {
                return id.trim();
            }), mainLocation)
        };
    });
    _log("EbayKitItem.prototype.getChildRecord", childRecordList);
    return {
        childRecordList: childRecordList
    };
};

function run(request, response) {
    try {
        var action = request.getParameter("action");
        if (request.getMethod() == "GET") {
            var item__internalid = request.getParameter("item__internalid");
            if (!item__internalid) {
                response.write("Not specific Item ID!");
                return;
            }
            if (action == "submit") {
                response.writeLine(JSON.stringify(_submitFeeds(item__internalid)));
            } else if (action == "print_label") {
                renderInlineLabelPDF(request, response);
            }
        } else {
            if (action == "previewListingDescription") {
                var previewHTML = nlapiLoadFile(678690).getValue();
                var render = template.compile(previewHTML);
                var renderObject = {
                    title: request.getParameter("title"),
                    featureddescription: request.getParameter("featureddescription"),
                    storedetaileddescription: request.getParameter("storedetaileddescription")
                };
                var custitem_ebay_body_pictures = [];
                var pics = request.getParameter("custitem_ebay_body_pictures");
                if (pics && isJsonString(pics)) {
                    custitem_ebay_body_pictures = JSON.parse(pics);
                    if (custitem_ebay_body_pictures.length) {
                        custitem_ebay_body_pictures = custitem_ebay_body_pictures.map(function(pic) {
                            return '<img style="max-width: 660px;" src="' + pic + '" /></br>';
                        });
                    }
                }
                renderObject.custitem_ebay_body_pictures = custitem_ebay_body_pictures.join("");
                var html = render(renderObject);
                response.write(html);
            }
        }
    } catch (e) {
        processException(e, {
            item__internalid: item__internalid
        });
    }
}

function renderInlineLabelPDF(request, response) {
    var item__internalid = request.getParameter("item__internalid");
    var item = nlapiLoadRecord("inventoryitem", item__internalid);
    var renderer = nlapiCreateTemplateRenderer();
    renderer.setTemplate(nlapiLoadFile("SuiteScripts/PDF/ItemLabel.html").getValue());
    renderer.addRecord("record", item);
    var xml = renderer.renderToString();
    var file = nlapiXMLToPDF(xml);
    response.setContentType("PDF", item.getFieldValue("itemid") + ".pdf", "inline");
    response.write(file);
}

var SYNC_REPORT = {
    issues: [],
    updated: [],
    created: [],
    ignore: []
};

function _submitFeeds(item__internalid) {
    var p = new Profiling();
    try {
        var feeds = null;
        try {
            feeds = buildFeeds(item__internalid);
            _log("Size: " + feeds.length, feeds);
            if (!feeds.length) return {
                name: "BUILD_FEEDS_ERROR",
                message: "No feed found."
            };
        } catch (e) {
            e = processException(e, {
                item__internalid: item__internalid,
                stage: "buildFeeds"
            });
            return {
                name: "BUILD_FEEDS_ERROR",
                message: e.getUserMessage(),
                spendTime: p.end()
            };
        }
        for (var i = 0, len = feeds.length; i < len; i++) {
            var feed = feeds[i];
            try {
                createOrUpdateEbayItemFeed(feed);
            } catch (e) {
                e = processException(e, {
                    feed: feed,
                    stage: "createOrUpdateEbayItemFeed"
                });
                SYNC_REPORT.issues.push(e.getUserMessage());
            }
        }
        return {
            name: "SUBMIT_FEED",
            SYNC_REPORT: SYNC_REPORT,
            spendTime: p.end()
        };
    } catch (e) {
        e = processException(e);
        return {
            name: "SUBMIT_FEED_ERROR",
            message: e.getUserMessage(),
            spendTime: p.end()
        };
    }
}

function createOrUpdateEbayItemFeed(scriptBuildFeed) {
    var is_matrix_inventory = false;
    var filter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "is", [ scriptBuildFeed.custrecord_ebay_feed_item ]), new nlobjSearchFilter("custrecord_ef_language", null, "is", [ scriptBuildFeed.custrecord_ef_language ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_global_site", "is", [ scriptBuildFeed.custrecord_ebay_feed_global_site ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_account", "is", [ scriptBuildFeed.custrecord_ebay_feed_account ]), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", "@NONE@") ];
    if (scriptBuildFeed.hasOwnProperty("eBayFeedChildList")) {
        filter.push(new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "T"));
        is_matrix_inventory = true;
    } else {
        filter.push(new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"));
    }
    var masterFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter, [ new nlobjSearchColumn("custrecord_ebay_feed_online_ref"), new nlobjSearchColumn("custrecord_ef_ns_created"), new nlobjSearchColumn("custrecord_ebay_feed_gallery"), new nlobjSearchColumn("custrecord_ebay_feed_body_picture") ]);
    if (masterFeedSearch == null) {
        scriptBuildFeed.custrecord_ebay_feed_status = EbayFeedStatus.New;
        var record = nlapiCreateRecord("customrecord_ebay_item_api_feed");
        scriptBuildFeed._suffix = _uniqid();
        scriptBuildFeed.custrecord_ebay_feed_sku = [ scriptBuildFeed._itemid, scriptBuildFeed._suffix ].join("|");
        submitMasterEbayItemFeedRecord(record, scriptBuildFeed, "create");
        var newRecordId = nlapiSubmitRecord(record, true);
        SYNC_REPORT.created.push("Created Feed record. " + newRecordId);
        if (is_matrix_inventory) {
            if (newRecordId) {
                submitVariationChildFeedRecord(scriptBuildFeed, newRecordId);
            } else {
                throw createEbayError("parentId: Could not created.");
            }
        }
    } else {
        _audit("masterFeedSearch.length", masterFeedSearch.length);
        var existingFeedPictures = {
            gallery: masterFeedSearch.map(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_gallery");
            }),
            bodyPicture: masterFeedSearch.map(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_body_picture");
            })
        };
        masterFeedSearch = masterFeedSearch.filter(function(searchResult) {
            return searchResult.getValue("custrecord_ef_ns_created") == "T";
        });
        if (masterFeedSearch.length == 1) {
            if (masterFeedSearch[0].getValue("custrecord_ebay_feed_online_ref") == "F") {
                var id = masterFeedSearch[0].getId();
                var record = nlapiLoadRecord("customrecord_ebay_item_api_feed", id);
                var custrecord_ebay_feed_sku = record.getFieldValue("custrecord_ebay_feed_sku");
                custrecord_ebay_feed_sku = custrecord_ebay_feed_sku.split("|");
                if (custrecord_ebay_feed_sku.length == 2) {
                    scriptBuildFeed._suffix = custrecord_ebay_feed_sku[1];
                } else {
                    scriptBuildFeed._suffix = _uniqid();
                }
                var submitResult = submitMasterEbayItemFeedRecord(record, scriptBuildFeed, "update");
                var msg = "";
                if (submitResult.recordFieldChangedCount) {
                    id = nlapiSubmitRecord(record, true);
                    msg += "Updated Feed record. " + id + " Changed(" + submitResult.recordFieldChangedCount + ")" + " [ " + submitResult.recordFieldChangedList.join(", ") + " ]";
                }
                if (is_matrix_inventory) {
                    submitVariationChildFeedRecord(scriptBuildFeed, id);
                    msg += "\r\nUpdated Feed record. " + id + " child feeds";
                }
                if (msg) {
                    SYNC_REPORT.updated.push(msg);
                }
            } else {
                SYNC_REPORT.ignore.push("Ignore Feed " + masterFeedSearch[0].getId() + " because that feed record have been ref for eBay site already.");
            }
        } else {
            if (masterFeedSearch.length) {
                if (masterFeedSearch.length > 1) {
                    SYNC_REPORT.issues.push("NS craeted feed: found more than 1 records. " + masterFeedSearch.map(function(sr) {
                        return sr.getId();
                    }).join(", ") + " for " + scriptBuildFeed.custrecord_ebay_feed_account);
                }
            } else {}
        }
    }
}

function submitMasterEbayItemFeedRecord(record, submittedFeed, action) {
    _log("action", action);
    _log("submittedFeed", submittedFeed);
    var recordFieldChangedCount = 0;
    var recordFieldChangedList = [];
    for (var field in submittedFeed) {
        _audit(">>>>>>>>>>>>>>>>>>>>>>>>>> " + field, submittedFeed[field]);
        if (field.indexOf("_") == 0) {
            continue;
        }
        if (field == "eBayFeedChildList" || field == "_exclude") {
            continue;
        }
        var feedFieldValue = submittedFeed[field];
        if (Array.isArray(feedFieldValue)) {
            feedFieldValue = JSON.stringify(feedFieldValue);
        } else if (typeof feedFieldValue == "object") {
            if (feedFieldValue != null) {
                feedFieldValue = JSON.stringify(feedFieldValue);
            }
        }
        if (!feedFieldValue) feedFieldValue = null;
        if (action == "create") {
            recordFieldChangedCount++;
            recordFieldChangedList.push("--allfields--");
            record.setFieldValue(field, feedFieldValue);
        } else {
            var recordFieldValue = record.getFieldValue(field) || record.getFieldText(field);
            if (!recordFieldValue) {
                recordFieldValue = null;
            }
            if (field == "custrecord_ebay_feed_api_title" && record.getFieldValue("custrecord_ebay_feed_api_title")) {} else {
                if (recordFieldValue != feedFieldValue) {
                    _log("field", field);
                    _log("recordFieldValue: feedFieldValue for Type", typeof recordFieldValue + ": " + typeof feedFieldValue);
                    _log("recordFieldValue: feedFieldValue", recordFieldValue + ": " + feedFieldValue);
                    recordFieldChangedCount++;
                    recordFieldChangedList.push(field);
                    record.setFieldValue(field, feedFieldValue);
                }
            }
        }
    }
    _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
    return {
        recordFieldChangedCount: recordFieldChangedCount,
        recordFieldChangedList: recordFieldChangedList
    };
}

function submitVariationChildFeedRecord(submittedFeed, parentId) {
    var updateFlag = false;
    _log("submitVariationChildFeedRecord submittedFeed", submittedFeed);
    var variations = submittedFeed.eBayFeedChildList;
    variations.forEach(function(vari) {
        vari.custrecord_ebay_feed_parent = parentId;
        vari.custrecord_ebay_feed_sku = vari._itemid + "|" + submittedFeed._suffix;
    });
    var submittedSKU = variations.map(function(item) {
        return item._itemid;
    });
    _log("submittedSKU", submittedSKU);
    for (var i = 0; i < variations.length; i++) {
        var variation = variations[i];
        var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_api_sku", null, "is", [ variation._itemid ]), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", parentId) ], [ new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_api_sku") ]);
        if (subFeedSearch == null) {
            _log("new subfeed search");
            var subFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
            submitVariationSubFeedRecord(subFeedRecord, variation);
            var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
            updateFlag = true;
        } else {
            var subFeed = null;
            if (subFeedSearch.length == 1) {
                subFeed = subFeedSearch[0];
            } else {
                subFeed = subFeedSearch.shift();
                subFeedSearch.forEach(function(item) {
                    nlapiDeleteRecord("customrecord_ebay_item_api_feed", item.getId());
                });
            }
            var subFeedSKU = subFeed.getValue("custrecord_ebay_feed_api_sku");
            if (submittedSKU.contains(subFeedSKU)) {
                submittedSKU.remove(subFeedSKU);
                var subFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", subFeed.getId());
                submitVariationSubFeedRecord(subFeedRecord, variation);
                var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
            } else {
                nlapiDeleteRecord("customrecord_ebay_item_api_feed", subFeed.getId());
            }
        }
    }
}

function submitVariationSubFeedRecord(subFeedRecord, variation) {
    variation.customform = "173";
    _audit("============submitVariationSubFeedRecord", variation);
    for (var field in variation) {
        if (field.indexOf("_") == 0) continue;
        var v = variation[field];
        if (typeof v == "object" && v != null) v = JSON.stringify(v);
        subFeedRecord.setFieldValue(field, v);
    }
}

function buildFeeds(item__internalid) {
    var context = nlapiGetContext();
    _log("buildFeeds", item__internalid);
    var submitList = [];
    var item = LOAD_EBAY_ITEM_RECORD(item__internalid);
    var INDEX = 0;
    var langSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_item_language, null, [ new nlobjSearchFilter("internalid", "custrecord_eil_item_link", "is", item__internalid) ], [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_eil_language"), new nlobjSearchColumn("custrecord_eil_title_permutations"), new nlobjSearchColumn("custrecord_eil_variations"), new nlobjSearchColumn("custrecord_eil_details_description") ]);
    if (langSearch != null) {
        for (var j = 0; j < langSearch.length; j++) {
            var langRec = langSearch[j];
            var titleList = langRec.getValue("custrecord_eil_title_permutations");
            if (titleList) {
                titleList = JSON.parse(titleList);
            }
            var siteColumns = [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_ei_ebay_accounts"), new nlobjSearchColumn("custrecord_ei_item_link"), new nlobjSearchColumn("custrecord_ei_language_set"), new nlobjSearchColumn("custrecord_ei_site"), new nlobjSearchColumn("custrecord_ei_ebay_accounts"), new nlobjSearchColumn("custrecord_ei_location"), new nlobjSearchColumn("custrecord_ei_shipping_options"), new nlobjSearchColumn("custrecord_ei_listing_duration"), new nlobjSearchColumn("custrecord_ei_site_price"), new nlobjSearchColumn("custrecord_ei_site_category_id"), new nlobjSearchColumn("custrecord_ei_max_push_quantity"), new nlobjSearchColumn("custrecord_ei_push_quantity"), new nlobjSearchColumn("custrecord_ei_condition") ];
            for (var a = 0; a < 15; a++) {
                var line = a + 1;
                siteColumns.push(new nlobjSearchColumn("custrecord_ei_specific" + line));
                siteColumns.push(new nlobjSearchColumn("custrecord_ei_specific_value" + line));
            }
            var siteSettingSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_item_site_setting, null, [ new nlobjSearchFilter("internalid", "custrecord_ei_item_link", "is", item__internalid), new nlobjSearchFilter("internalid", "custrecord_ei_language_set", "is", langRec.getId()) ], siteColumns);
            if (siteSettingSearch != null) {
                for (var i = 0; i < siteSettingSearch.length; i++) {
                    var siteSetting = siteSettingSearch[i];
                    var specificList = [];
                    for (var aa = 0; aa < 15; aa++) {
                        var lineaa = aa + 1;
                        if (siteSetting.getValue("custrecord_ei_specific" + lineaa) && siteSetting.getValue("custrecord_ei_specific_value" + lineaa)) {
                            specificList.push({
                                specificName: siteSetting.getValue("custrecord_ei_specific" + lineaa),
                                specificValue: siteSetting.getValue("custrecord_ei_specific_value" + lineaa)
                            });
                        }
                    }
                    var accounts = siteSetting.getValue("custrecord_ei_ebay_accounts");
                    accounts = accounts.split(",");
                    if (accounts.length) {
                        var EBAY_ITEM_PRICE_INCREMENT_VARIANT = .01;
                        for (var k = 0; k < accounts.length; k++) {
                            var accountId = accounts[k];
                            var eBayFeedItem = {};
                            if (item.custitem_internal_marketing_position == "2") {
                                eBayFeedItem.custrecord_ef_cease_when_sold_out = "T";
                            } else {
                                eBayFeedItem.custrecord_ef_cease_when_sold_out = "F";
                            }
                            eBayFeedItem.custrecord_ef_upc = item.upccode || "Does not apply";
                            eBayFeedItem.custrecord_ef_ean = "Does not apply";
                            eBayFeedItem.custrecord_ef_isbn = "Does not apply";
                            eBayFeedItem.custrecord_ebay_feed_item = item__internalid;
                            eBayFeedItem.custrecord_ef_language = langRec.getValue("custrecord_eil_language");
                            eBayFeedItem.custrecord_ebay_feed_global_site = siteSetting.getValue("custrecord_ei_site");
                            eBayFeedItem.custrecord_ebay_feed_account = accountId;
                            eBayFeedItem.custrecord_ebay_feed_language = langRec.getId();
                            eBayFeedItem.custrecord_ef_item_site_setting = siteSetting.getId();
                            eBayFeedItem.custrecord_ebay_feed_submitted_by = context.getUser();
                            eBayFeedItem.custrecord_ebay_feed_gallery = item.gallery;
                            eBayFeedItem.custrecord_ebay_feed_body_picture = item.bodyPicture;
                            eBayFeedItem.custrecord_ebay_feed_picture = item.custitem_item_picture;
                            eBayFeedItem.custrecord_ebay_feed_location = siteSetting.getValue("custrecord_ei_location");
                            eBayFeedItem.custrecord_ef_shipping_options = siteSetting.getValue("custrecord_ei_shipping_options");
                            eBayFeedItem.custrecord_ebay_feed_category_id = siteSetting.getValue("custrecord_ei_site_category_id");
                            eBayFeedItem.custrecord_ef_listing_duration = siteSetting.getValue("custrecord_ei_listing_duration");
                            eBayFeedItem.custrecord_ebay_feed_condition = siteSetting.getValue("custrecord_ei_condition") || 1;
                            eBayFeedItem._itemid = item.itemid;
                            var refId = [ item.id, eBayFeedItem.custrecord_ebay_feed_item, eBayFeedItem.custrecord_ef_language, eBayFeedItem.custrecord_ebay_feed_global_site, eBayFeedItem.custrecord_ebay_feed_account ].join("");
                            var _title = "";
                            if (typeof titleList == "object" && titleList != null) {
                                var existingTitle = titleList.filter(function(title) {
                                    return title.referId == refId;
                                });
                                if (existingTitle.length) {
                                    if (existingTitle.length == 1) {
                                        _title = existingTitle[0].title;
                                    } else {
                                        throw createEbayError("Found more than 1 title existing.");
                                    }
                                } else {
                                    var availReferIdTitle = titleList.filter(function(title) {
                                        return title.referId == null;
                                    });
                                    if (availReferIdTitle.length) {
                                        var aTitle = availReferIdTitle[0];
                                        _title = aTitle.title;
                                        aTitle.referId = refId;
                                    } else {
                                        _title = "TODO: Title " + new Date().getTime();
                                    }
                                }
                                _log("titleList", titleList);
                            } else {
                                _title = "TODO: at" + k;
                            }
                            eBayFeedItem.custrecord_ebay_feed_api_title = _title.trim();
                            eBayFeedItem.custrecord_ebay_feed_api_price = _mathround(parseFloat(siteSetting.getValue("custrecord_ei_site_price")) + EBAY_ITEM_PRICE_INCREMENT_VARIANT * k);
                            eBayFeedItem.custrecord_ef_max_push_qty = siteSetting.getValue("custrecord_ei_max_push_quantity");
                            eBayFeedItem.custrecord_ebay_feed_push_qty = siteSetting.getValue("custrecord_ei_push_quantity");
                            eBayFeedItem.custrecord_ebay_feed_ns_ref_id = item.id;
                            if (item.type == "kititem") {
                                eBayFeedItem.custrecord_ebay_feed_matrix_item = "F";
                                eBayFeedItem.custrecord_ebay_feed_matrix_child_item = "F";
                                eBayFeedItem.custrecord_ebay_feed_combo = "T";
                            } else if (item.type == "inventoryitem") {
                                if (item.ismatrix == "T") {
                                    eBayFeedItem.custrecord_ebay_feed_matrix_item = "T";
                                    eBayFeedItem.custrecord_ebay_feed_matrix_child_item = "F";
                                    eBayFeedItem.custrecord_ebay_feed_ns_ref_id = item.id;
                                    var custrecord_eil_variations = langRec.getValue("custrecord_eil_variations");
                                    custrecord_eil_variations = JSON.parse(custrecord_eil_variations);
                                    var availOptions = custrecord_eil_variations;
                                    var childRecordList = cloneObj(item.childRecordList);
                                    _log("childRecordList", childRecordList);
                                    childRecordList.forEach(function(matrixRecord) {
                                        matrixRecord.options.forEach(function(__option) {
                                            _log("__option", __option);
                                            __option.label.translation = availOptions.filter(function(av) {
                                                return av.name == __option.label.name;
                                            })[0].translation;
                                            __option.option.translation = availOptions.filter(function(av) {
                                                return av.name == __option.label.name;
                                            })[0].options.filter(function(op) {
                                                return op.id == __option.option.value;
                                            })[0].translation;
                                        });
                                    });
                                    var eBayFeedChildList = [];
                                    childRecordList.forEach(function(childItem) {
                                        var eBayFeedChildItem = {};
                                        eBayFeedChildItem.custrecord_ef_upc = childItem.upccode || "Does not apply";
                                        eBayFeedChildItem.custrecord_ef_ean = "Does not apply";
                                        eBayFeedChildItem.custrecord_ef_isbn = "Does not apply";
                                        eBayFeedChildItem.custrecord_ebay_feed_item = childItem.__id;
                                        eBayFeedChildItem.custrecord_ef_language = eBayFeedItem.custrecord_ef_language;
                                        eBayFeedChildItem.custrecord_ebay_feed_global_site = eBayFeedItem.custrecord_ebay_feed_global_site;
                                        eBayFeedChildItem.custrecord_ebay_feed_account = eBayFeedItem.custrecord_ebay_feed_account;
                                        eBayFeedChildItem.custrecord_ebay_feed_language = eBayFeedItem.custrecord_ebay_feed_language;
                                        eBayFeedChildItem.custrecord_ef_item_site_setting = eBayFeedItem.custrecord_ef_item_site_setting;
                                        eBayFeedChildItem.custrecord_ebay_feed_submitted_by = eBayFeedItem.custrecord_ebay_feed_submitted_by;
                                        eBayFeedChildItem.custrecord_ebay_feed_picture = childItem.custitem_item_picture.value || eBayFeedItem.custrecord_ebay_feed_picture;
                                        eBayFeedChildItem.custrecord_ef_picture2 = childItem.custitem_item_var_picture;
                                        eBayFeedChildItem.custrecord_ebay_feed_location = eBayFeedItem.custrecord_ebay_feed_location;
                                        eBayFeedChildItem._itemid = childItem.itemid;
                                        eBayFeedChildItem.custrecord_ebay_feed_api_price = eBayFeedItem.custrecord_ebay_feed_api_price;
                                        eBayFeedChildItem.custrecord_ef_max_push_qty = eBayFeedItem.custrecord_ef_max_push_qty;
                                        eBayFeedChildItem.custrecord_ebay_feed_push_qty = eBayFeedItem.custrecord_ebay_feed_push_qty;
                                        eBayFeedChildItem.custrecord_ebay_feed_ns_ref_id = childItem.__id;
                                        eBayFeedChildItem.custrecord_ebay_feed_matrix_item = "F";
                                        eBayFeedChildItem.custrecord_ebay_feed_matrix_child_item = "T";
                                        eBayFeedChildItem.custrecord_ebay_feed_combo = "F";
                                        eBayFeedChildItem.custrecord_ebay_feed_parent = null;
                                        eBayFeedChildItem.custrecord_ebay_feed_variations = childItem;
                                        eBayFeedChildList.push(eBayFeedChildItem);
                                    });
                                    eBayFeedItem.eBayFeedChildList = eBayFeedChildList;
                                    eBayFeedItem.custrecord_ebay_feed_variations = {
                                        availOptions: availOptions,
                                        childRecordList: childRecordList
                                    };
                                } else {
                                    eBayFeedItem.custrecord_ebay_feed_matrix_item = "F";
                                    eBayFeedItem.custrecord_ebay_feed_matrix_child_item = "F";
                                }
                                eBayFeedItem.custrecord_ebay_feed_combo = "F";
                            }
                            eBayFeedItem.custrecord_ebay_feed_specifics = specificList;
                            eBayFeedItem.custrecord_ef_template = findFeedTemplate(langRec.getValue("custrecord_eil_language"), accountId);
                            eBayFeedItem.custrecord_ebay_feed_description = langRec.getValue("custrecord_eil_details_description");
                            eBayFeedItem.custrecord_ef_ns_created = "T";
                            submitList.push(eBayFeedItem);
                            INDEX++;
                        }
                    }
                }
            }
            nlapiSubmitField("customrecord_ebay_item_language", langRec.getId(), "custrecord_eil_title_permutations", JSON.stringify(titleList), true);
        }
    }
    if (nlapiGetUser() == 530) {
        _auditEbayFile("submitList.txt", submitList);
    }
    return submitList;
}

function _isShenzhenSubsidiaryFeed() {}

function _isZakeInternationalSubsidiaryFeed() {}

function findFeedTemplate(langId, accId) {
    _log("findFeedTemplate", arguments);
    var search = nlapiSearchRecord("customrecord_ebay_template", null, [ new nlobjSearchFilter("custrecord_eat_language", null, "is", langId), new nlobjSearchFilter("internalid", "custrecord_eat_ebay_account", "is", accId), new nlobjSearchFilter("isinactive", null, "is", "F") ], [ new nlobjSearchColumn("custrecord_eat_tpl") ]);
    if (search != null) {
        if (search.length) {
            return search[0].getId();
        }
    }
    return 2;
}

function LOAD_EBAY_ITEM_RECORD(item__internalid) {
    var ITEM_RECORD = {};
    var ismatrix = "F";
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    if (getItemType(item__internalid) == "Kit") {
        ITEM_RECORD.type = "kititem";
    } else {
        ITEM_RECORD.type = "inventoryitem";
        var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
        if (testSearch != null) ismatrix = "T";
    }
    _log("ismatrix", ismatrix);
    ITEM_RECORD.ismatrix = ismatrix;
    var __item = null;
    if (ITEM_RECORD.type == "kititem") {
        __item = new EbayKitItem(item__internalid);
    } else {
        __item = new EbayInventoryItem(item__internalid, ismatrix);
    }
    ITEM_RECORD.id = __item.getId();
    if (!__item.getFieldValue("class")) throw createEbayError("The item record have no Class!");
    if (ITEM_RECORD.type == "inventoryitem" && ismatrix == "T") {
        ITEM_RECORD.childRecordList = __item.getChildRecord();
    } else if (ITEM_RECORD.type == "kititem") {
        ITEM_RECORD.childRecordList = __item.getChildRecord();
    }
    ITEM_RECORD.internalid = __item.val("internalid");
    ITEM_RECORD.itemid = __item.val("itemid");
    ITEM_RECORD.class = __item.val("class");
    ITEM_RECORD.custitem_item_picture = __item.val("custitem_item_picture");
    ITEM_RECORD.custitem_item_picture_url = __item.text("custitem_item_picture");
    ITEM_RECORD.gallery = __item.getGalleryPicture();
    ITEM_RECORD.bodyPicture = __item.getBodyPicture();
    ITEM_RECORD.custitem_internal_marketing_position = __item.val("custitem_internal_marketing_position");
    ITEM_RECORD.upccode = __item.val("upccode");
    return ITEM_RECORD;
}