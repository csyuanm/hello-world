function renderChildRecordOptionsUI(type, form, variations, languageId) {
    form.addTab("custpage_var_tab", "Variation Tab");
    form.addField("custpage_style", "inlinehtml", null, null, null).setDefaultValue('<style type="text/css">.uir-machine-headerrow > td{padding-left: 5px !important;}</style>');
    var variationsList = form.addSubList("custpage_variations", "list", "Variations", "custpage_var_tab");
    variations.forEach(function(item) {
        var linename = "var_" + item.name;
        var linename_translation = linename + "_translation";
        variationsList.addField(linename, "text", item.label, null);
        if (type == "create" || type == "edit") {
            variationsList.addField(linename_translation, "text", '<input type="text" class="variations_translation_title" value="' + item.translation + '" name="' + item.name + '"/>', null);
        } else {
            variationsList.addField(linename_translation, "text", item.translation, null);
        }
        var options = item.options;
        options.forEach(function(opt, index) {
            var line = index + 1;
            variationsList.setLineItemValue(linename, line, opt.value);
            if (type == "create") {
                variationsList.setLineItemValue(linename_translation, line, '<input type="text" ' + 'value="" ' + 'name="' + opt.id + "#" + item.name + "#translation" + '" ' + 'class="variations_translation" ' + 'id="' + opt.id + "_translation" + index + '" />');
            } else {
                if (type == "edit") {
                    variationsList.setLineItemValue(linename_translation, line, '<input type="text" ' + 'value="' + opt.translation + '" ' + 'name="' + opt.id + "#" + item.name + "#translation" + '" ' + 'class="variations_translation" ' + 'id="' + opt.id + "_translation" + index + '" />');
                } else if (type == "view") {
                    variationsList.setLineItemValue(linename_translation, line, opt.translation);
                }
            }
        });
    });
}

(function($, window, document, undefined) {
    var $custpage_variations_splits = $("#custpage_variations_splits");
    var variations = nlapiGetFieldValue("custrecord_eil_variations");
    variations = JSON.parse(variations);
    $custpage_variations_splits.find(".variations_translation").on("input change", function() {
        var $this = $(this);
        var name = $this.attr("name");
        console.log(name);
        name = name.split("#");
        var availOption = variations.filter(function(item) {
            return item.name == name[1];
        });
        if (availOption.length && availOption.length == 1) {
            availOption = availOption[0];
            var opt = availOption.options.filter(function(o) {
                return o.id == name[0];
            });
            if (opt.length && opt.length == 1) {
                opt[0].translation = $this.val();
                console.log($this.val());
            }
            console.log(JSON.stringify(availOption));
            nlapiSetFieldValue("custrecord_eil_variations", JSON.stringify(variations));
        }
    });
    $custpage_variations_splits.find(".variations_translation_title").on("input change", function() {
        var $this = $(this);
        var name = $this.attr("name");
        console.log(name);
        var optionSet = variations.filter(function(item) {
            return item.name == name;
        });
        if (optionSet.length && optionSet.length == 1) {
            optionSet = optionSet[0];
            optionSet.translation = $this.val();
            console.log(JSON.stringify(optionSet));
            nlapiSetFieldValue("custrecord_eil_variations", JSON.stringify(variations));
        }
    });
})(jQuery, window, document);

var ActionType = "";

function pageInit(type) {
    ActionType = type;
    console.log(type);
    if (type == "create") {}
}

function saveRecord() {
    return true;
}

function fieldChanged(type, name, linenum) {
    console.log(arguments);
    if ("custrecord_eil_language" == name) {
        var itemName = nlapiGetFieldText("custrecord_eil_item_link");
        var languageId = nlapiGetFieldValue("custrecord_eil_language");
        var languageName = nlapiGetFieldText("custrecord_eil_language");
        var $variationsUI = jQuery("#custpage_variations_splits");
        var variationsChanged = false;
        var variations = nlapiGetFieldValue("custrecord_eil_variations");
        variations = variations.trim();
        if (!variations) {
            $variationsUI.hide();
            console.log("Inventory or Kit");
        } else {
            variationsChanged = true;
            variations = JSON.parse(variations);
            if (ActionType == "create") {
                if (languageId == "1") {
                    autoSetEnglishTranslation(variations);
                } else {
                    autoRemoveEnglishTranslation(variations);
                }
            }
            $variationsUI.find(".variations_translation").each(function() {
                var $this = jQuery(this);
                var name = $this.attr("name").split("#");
                var availOption = variations.filter(function(item) {
                    return item.name == name[1];
                });
                if (availOption.length) {
                    availOption = availOption[0];
                    var opt = availOption.options.filter(function(o) {
                        return o.id == name[0];
                    });
                    if (opt.length) opt = opt[0];
                    $this.val(opt.translation);
                }
            });
            $variationsUI.find(".variations_translation_title").each(function() {
                var $this = jQuery(this);
                var name = $this.attr("name");
                var opt_title = variations.filter(function(item) {
                    return item.name == name;
                });
                if (opt_title.length) {
                    opt_title = opt_title[0];
                    $this.val(opt_title.translation);
                }
            });
        }
        if (variationsChanged) nlapiSetFieldValue("custrecord_eil_variations", JSON.stringify(variations));
        nlapiSetFieldValue("name", itemName + ": " + languageName);
    }
}