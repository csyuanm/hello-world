var Math2 = {
    parseValue: function(value) {
        if (typeof value == "number") {
            return value;
        } else {
            var stringValue = value.toString();
            stringValue = stringValue.replace(/,/g, "");
            if (stringValue.indexOf(".") != -1) {
                stringValue = parseFloat2(stringValue);
            } else {
                stringValue = parseInt2(stringValue);
            }
            return stringValue;
        }
    },
    makeValue: function(val) {
        return Math.round(this.parseValue(val) * 100) / 100;
    },
    add: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a + b) * 100) / 100;
    },
    sub: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a - b) * 100) / 100;
    },
    multiply: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a * b * 100) / 100;
    },
    division: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a / b * 100) / 100;
    },
    compare: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        a = Math.round(a * 100);
        b = Math.round(b * 100);
        if (a > b) {
            return 1;
        } else if (a < b) {
            return -1;
        } else {
            return 0;
        }
    }
};

function parseInt2(value) {
    value = value || 0;
    value = parseInt(value);
    if (isNaN(value)) value = 0;
    return value;
}

function parseFloat2(value) {
    value = value || 0;
    value = parseFloat(value);
    if (isNaN(value)) value = 0;
    return value;
}

if (typeof this.console == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function parseException(e) {
    var code, message;
    var userMessage = null;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = e.getCode() || "nlobjError";
            var st = e.getStackTrace();
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + st.join(", ");
            userMessage = e.getDetails();
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (userMessage == null) userMessage = message;
    var context = nlapiGetContext();
    var sname = [ context.getDeploymentId(), "@Subsidiary" + context.getSubsidiary(), context.getEmail() ].join(" ");
    return {
        code: "[" + code + "] " + sname,
        ERROR_CODE: code,
        message: message,
        userMessage: userMessage
    };
}

function processException(e, info, sendEmail) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "<br/><br/>" + info;
    }
    if (typeof console == "undefined") {
        if (sendEmail != false) {
            _log("nlapiSendEmail", code);
            nlapiSendEmail(530, "allan@zakeusa.com", code, message);
        }
    } else {
        alert(code + "///" + message);
    }
    _nlapiLogExecution("ERROR", code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

function disabledFields(fields) {
    var defaultFields = [ "customform", "name" ];
    if (typeof fields != "undefined" && Array.is(fields)) {
        fields = fields.concat(defaultFields);
    } else {
        fields = defaultFields;
    }
    _disabledFields(fields);
}

function _disabledFields(fields) {
    if (nlapiGetContext().getUser() != "530") {
        if (fields && Array.isArray(fields) && fields.length) {
            fields.forEach(function(field) {
                nlapiGetField(field).setDisplayType("disabled");
            });
        }
    }
}

function _nlapiLogExecution(logType, title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (typeof console == "undefined") {
            if (detail) {
                if (typeof detail == "object") {
                    if (format) {
                        nlapiLogExecution(logType, title, JSON.stringify(detail, undefined, 4));
                    } else {
                        nlapiLogExecution(logType, title, JSON.stringify(detail));
                    }
                } else {
                    nlapiLogExecution(logType, title, detail);
                }
            } else {
                nlapiLogExecution(logType, title, detail);
            }
        } else {
            if (typeof title == "object") {
                title = JSON.stringify(title, null, 2);
            }
            if (typeof detail == "object") {
                console.log(title + "///" + JSON.stringify(detail, null, 2));
            } else {
                console.log(title + "///" + detail);
            }
        }
    }
}

function _log(title, detail) {
    var logType = "debug";
    _nlapiLogExecution(logType, title, detail);
}

function _audit(title, detail) {
    _nlapiLogExecution("AUDIT", title, detail);
}

function _log_email(title, detail) {
    nlapiSendEmail(530, "allan@zakeusa.com", nlapiGetContext().getDeploymentId() + ": " + title, detail);
}

function _sendEmail(to, title, detail) {
    title = nlapiGetContext().getDeploymentId() + ": " + title;
    _log("[SENTEMAIL] " + to + " " + title, detail);
    nlapiSendEmail(530, to, title, detail);
}

function simpleCreateRecord(type, obj) {
    var rec = nlapiCreateRecord(type);
    for (var field in obj) {
        rec.setFieldValue(field, obj[field]);
    }
    return nlapiSubmitRecord(rec, true);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

Array.prototype.remove = function(value) {
    var a = this;
    var index = a.indexOf(value);
    if (index > -1) {
        a.splice(index, 1);
    }
};

Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) < 0;
    });
};

Array.prototype.same = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) >= 0;
    });
};

function _toarray(obj) {
    if (!Array.isArray(obj)) obj = [ obj ];
    return obj;
}

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
    children.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function createTextFile(name, content, folderId) {
    folderId = folderId || 80473;
    var file = nlapiCreateFile(name + ".txt", "PLAINTEXT", content);
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function _renderPage(html, obj) {
    for (var o in obj) {
        var k = "{{" + o + "}}";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function _renderPage2(html, obj) {
    for (var o in obj) {
        var k = "#" + o + "#";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    var joinname = join + "." + name;
                    record[joinname] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function __nlapiSearchRecordX(type, id, filters, columns) {
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            record["__id"] = search_record.getId();
            record["__type"] = search_record.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var value = search_record.getValue(column);
                var text = search_record.getText(column);
                if (value && text) {
                    record[name] = {
                        value: value,
                        text: text
                    };
                } else {
                    record[name] = value;
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecordX", list);
    return list;
}

function __nlapiSearchRecord2(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    return {
        columnLabels: columnLabels,
        list: __nlapiSearchRecordX(type, id, filters, columns)
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function _auditUsage() {
    _audit("getRemainingUsage USAGE", nlapiGetContext().getRemainingUsage());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        var spendTime = Math.round((new Date().getTime() - this.startTime) / 1e3) + "s";
        _audit("_audit - [Profiling]", spendTime);
        return spendTime;
    }
};

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(url ? url : location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function _mathround(a) {
    return Math.round(a * 100) / 100;
}

var IS_NS_SANDBOX = false;

var NS_DOMAIN = "system.na1.netsuite.com";

if (nlapiGetContext().getEnvironment() == "SANDBOX") {
    IS_NS_SANDBOX = true;
    NS_DOMAIN = "system.sandbox.netsuite.com";
}

var Subsidiaries = {
    ZakeUSAHolding: 2,
    Swagway: 4,
    TaiwuInternational: 3,
    ZakeInternational: 1
};

function logparams(request) {
    _log("request.getMethod()----", request.getMethod());
    _log("---logparams---", getparams(request));
}

function getparams(request) {
    var params = request.getAllParameters();
    var paramlist = [];
    for (var param in params) {
        paramlist.push({
            parameter: param,
            value: params[param]
        });
    }
    return paramlist;
}

function checkGovernance() {
    if (nlapiGetContext().getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < 500) {
        nlapiLogExecution("AUDIT", "checkGovernance---", nlapiGetContext().getRemainingUsage());
        var state = nlapiYieldScript();
        _audit("state.status", state.status);
        if (state.status == "FAILURE") {
            throw nlapiCreateError("YIELD_SCRIPT_ERROR", "Failed to yield script, exiting<br/>Reason = " + state.reason + "<br/>Size = " + state.size + "<br/>Information = " + state.information);
        } else if (state.status == "RESUME") {
            nlapiLogExecution("debug", "checkGovernance-------------", nlapiGetContext().getRemainingUsage());
            nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        }
    } else {
        nlapiGetContext().setPercentComplete((1e4 - nlapiGetContext().getRemainingUsage()) / 100);
    }
}

function rescheduled(params) {
    var context = nlapiGetContext();
    if (context.getExecutionContext() != "scheduled") {
        return false;
    }
    var remainingUsage = nlapiGetContext().getRemainingUsage();
    if (remainingUsage < 500) {
        _audit("remainingUsage", remainingUsage);
        var status = null;
        if (params) {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
        } else {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        }
        _audit("status", status);
        if (status == "QUEUED") {
            _audit("Reschedule for usage reset ...", remainingUsage);
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

var MarketplaceShipService = {
    ToBeDetermined: 6,
    Standard: 1,
    ThirdDaySelect: 2,
    SecondDayAir: 3,
    NextDay: 4,
    InternationalShippingFromUS: 5
};

var MarketplaceShipName = {
    AliExpress: 1,
    Amazon: 2,
    eBay: 3,
    Wish: 4,
    _3BBestbuy: 5,
    _3BNewegg: 6,
    Rakuten: 7,
    PCDirect: 8,
    _3Btech: 9,
    Swagway: 10
};

var MARKETPLACE_LIST = [ {
    marketplaceId: 10,
    ARAccount: "177",
    formid: "151",
    name: "Swagway"
}, {
    marketplaceId: 3,
    ARAccount: "1127",
    formid: "178",
    name: "EbayClaimthis"
}, {
    marketplaceId: 2,
    ARAccount: "176",
    formid: "263",
    name: "SavannahAmazon",
    store: "1"
}, {
    marketplaceId: 2,
    ARAccount: "174",
    formid: "199",
    name: "BetterChoiceAmazon",
    store: "8"
}, {
    marketplaceId: 5,
    ARAccount: "1126",
    formid: "220",
    name: "ThreeBTechBestBuy"
}, {
    marketplaceId: 7,
    ARAccount: "1129",
    formid: "220",
    name: "ThreeBTechRakuten"
}, {
    marketplaceId: 6,
    ARAccount: "1128",
    formid: "150",
    name: "NeweggZake"
}, {
    marketplaceId: 9,
    ARAccount: "1130",
    formid: "150",
    name: "ThreeBTechNet"
}, {
    marketplaceId: 8,
    ARAccount: "1131",
    formid: "150",
    name: "PCDirect"
} ];

var SALES_ORDER_FORM = {
    SWAGWAY: 151,
    EBAY: 178
};

function getUTCDateTime() {
    var now = new Date();
    var offset = now.getTimezoneOffset();
    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
    nlapiLogExecution("debug", "getUTCDateTime", utcDate);
    return utcDate;
}

var DateCompare = {
    convert: function(d) {
        return d.constructor === Date ? d : d.constructor === Array ? new Date(d[0], d[1], d[2]) : d.constructor === Number ? new Date(d) : d.constructor === String ? new Date(d) : typeof d === "object" ? new Date(d.year, d.month, d.date) : NaN;
    },
    compare: function(a, b) {
        return isFinite(a = this.convert(a).valueOf()) && isFinite(b = this.convert(b).valueOf()) ? (a > b) - (a < b) : NaN;
    },
    inRange: function(d, start, end) {
        return isFinite(d = this.convert(d).valueOf()) && isFinite(start = this.convert(start).valueOf()) && isFinite(end = this.convert(end).valueOf()) ? start <= d && d <= end : NaN;
    }
};

function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    val2: function(name) {
        return {
            name: name,
            value: this.rec.getFieldValue(name),
            text: this.rec.getFieldText(name)
        };
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var EbayRecordType = {
    customrecord_ebay_item_site_setting: "customrecord_ebay_item_site_setting",
    customrecord_ebay_item_language: "customrecord_ebay_item_language",
    customrecord_ebay_global: "customrecord_ebay_global",
    customrecord_ebay_item_api_feed: "customrecord_ebay_item_api_feed",
    customrecord_ebay_feed_workflow: "customrecord_ebay_feed_workflow",
    customrecord_ebay_account: "customrecord_ebay_account"
};

var EbayRequest = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll",
    headers: {
        "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
        "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
        "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
        "Content-Type": "application/xml"
    },
    call: function(header, xml) {
        try {
            var message = "OK";
            var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(this.headers, header));
            var x2js = new X2JS();
            var responseJSON = x2js.xml_str2json(response.getBody());
            return {
                success: true,
                message: message,
                response: responseJSON
            };
        } catch (e) {
            e = processException(e);
            return {
                success: false,
                message: e.getMessage()
            };
        }
    }
};

function saveAPICallResult(fileName, pageNumber, arr) {
    if (!Array.isArray(arr)) {
        throw createEbayError("Params is error and not array");
    }
    fileName += ".txt";
    var folderId = 295527;
    var file = null;
    if (pageNumber == 1) {
        var content = {
            startTime: new Date().getTime(),
            arr: arr
        };
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content));
    } else {
        file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
        var content = file.getValue();
        content = JSON.parse(content);
        content.arr = content.arr.concat(arr);
        content.arrLenth = content.arr.length;
        content.endTime = new Date().getTime();
        content.spendTime = Math.round((content.endTime - content.startTime) / 1e3) + "s";
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content, null, 2));
    }
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

function sendAPICallResult(fileName) {
    fileName += ".txt";
    var file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
    var content = file.getValue();
    _log_email(fileName, content);
}

var EBAY_FEED_STATUS = {
    OFFLINE: 1,
    ONLINE: 2,
    NEW: 8,
    IN_QUE_NEW: 21,
    REJECTED: 7,
    SCHEDULED_IN_QUE_NEW: 4,
    SCHEDULED_IN_QUE_NEW_ERROR: 22,
    SCHEDULED_IN_QUE_RE_LIST: 18,
    SCHEDULED_IN_QUE_RE_LIST_ERROR: 23,
    SCHEDULED_NON_ACTION: 20,
    WAITING_FOR_APPROVAL: 6
};

var EBAY_FEED_BUTTON = {
    APPROVE: 1,
    DELIST: 6,
    FORCE_DELIST: 7,
    RE_SUBMIT: 3,
    REJECT: 2,
    RELIST: 5,
    REVISE: 4
};

var EbayFeedStatus = {
    Online: 1,
    Offline: 2,
    ForcedOffline: 3,
    InQue_New: 4,
    InQue_RelistOnline: 9,
    InQue_RelistOffline: 10,
    Error_New: 5,
    Error_RelistOnline: 11,
    Error_RelistOffline: 14,
    Error_Revise: 12,
    Error_Offline: 13,
    WaitingForApproval: 6,
    Rejected: 7,
    New: 8
};

var EbayFeedButtonAction = {
    Submit: 6,
    Relist: 5,
    Delist: 2,
    ForceDelist: 3,
    Approve: 1,
    Reject: 4,
    Revise: 7,
    ReSubmit: 8
};

var ZakeRole = {
    SalesManager: 1021,
    SalesPerson: 1022
};

function createEbayError(details) {
    return nlapiCreateError("EBAY_ERROR", details);
}

function createError(details) {
    return nlapiCreateError("ZAKE_ERROR", details);
}

function getCustomList(customListId, asObject) {
    var col = new Array();
    col[0] = new nlobjSearchColumn("name");
    col[1] = new nlobjSearchColumn("internalId");
    var obj = {};
    var list = [];
    var results = nlapiSearchRecord(customListId, null, null, col);
    for (var i = 0; results != null && i < results.length; i++) {
        var res = results[i];
        var listValue = res.getValue("name");
        var listID = res.getValue("internalId");
        list.push({
            key: listID,
            value: listValue
        });
        obj[listID] = listValue;
    }
    if (asObject == true) {
        return obj;
    } else {
        return list;
    }
}

function deepmerge(target, src) {
    var array = Array.isArray(src);
    var dst = array && [] || {};
    if (array) {
        target = target || [];
        dst = dst.concat(target);
        src.forEach(function(e, i) {
            if (typeof dst[i] === "undefined") {
                dst[i] = e;
            } else if (typeof e === "object") {
                dst[i] = deepmerge(target[i], e);
            } else {
                if (target.indexOf(e) === -1) {
                    dst.push(e);
                }
            }
        });
    } else {
        if (target && typeof target === "object") {
            Object.keys(target).forEach(function(key) {
                dst[key] = target[key];
            });
        }
        Object.keys(src).forEach(function(key) {
            if (typeof src[key] !== "object" || !src[key]) {
                dst[key] = src[key];
            } else {
                if (!target[key]) {
                    dst[key] = src[key];
                } else {
                    dst[key] = deepmerge(target[key], src[key]);
                }
            }
        });
    }
    return dst;
}

function autoSetEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = item.label;
        }
        item.options.forEach(function(opt) {
            opt.translation = opt.value;
        });
    });
}

function autoRemoveEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = "";
        }
        item.options.forEach(function(opt) {
            opt.translation = "";
        });
    });
}

Array.prototype.unique = function() {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j]) a.splice(j--, 1);
        }
    }
    return a;
};

var ITEM_OPTIONS = [ [ "custitem_var_color", "Colors" ], [ "custitem_var_size", "Sizes" ], [ "custitem_womens_size", "Womens Size" ], [ "custitem_watch_deisgn", "Watch Design" ], [ "custitem_var_assortment", "Assortment" ], [ "custitem_var_bag_pattern", "Bag Pattern" ], [ "custitem_child_size", "Child Size" ], [ "custitem_var_color_temp", "Color Temp" ], [ "custitem_var_compatible_with", "Compatible With" ], [ "custitem_var_legging_design", "Legging Design" ], [ "custitem_var_mens_size", "Mens Size" ], [ "custitem_var_print_design", "Print Design" ], [ "custitem_var_shape", "Shape" ], [ "custitem_var_style", "Style" ], [ "custitem_var_womens_shoe_size", "Shoe Size" ], [ "custitem_var_mens_pant_size", "Mens Pant Size" ], [ "custitem_var_bra_size", "Bra Size" ], [ "custitem_var_child_shoe_size", "Child Shoe Size" ], [ "custitem_var_mens_shoe_size", "Mens Shoe Size" ], [ "custitem_var_amps", "AMPS" ] ];

function isMatrixItem(item__internalid) {
    var ismatrix = false;
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
    if (testSearch != null) ismatrix = true;
    return ismatrix;
}

function getItemType(id) {
    return nlapiLookupField("item", id, "type");
}

function isKitItem(id) {
    return getItemType(id) == "Kit";
}

function EbayItem(type, id) {
    this.id = id;
    this.pictureSearch = null;
    Record.call(this, type, id);
}

EbayItem.TYPE = {
    INVENTORY_ITEM: "inventoryitem",
    KIT_ITEM: "kititem"
};

inherit(Record, EbayItem);

EbayItem.prototype.extend({
    getPictureSearch: function() {
        if (this.pictureSearch == null) {
            var c = [];
            var custitem_ebay_gallery_picture_columns = [];
            for (var j = 1; j <= 10; j++) {
                custitem_ebay_gallery_picture_columns.push("custitem_ebay_gallery_picture_" + j);
            }
            var custitem_ebay_body_picture_columns = [];
            for (var x = 1; x <= 15; x++) {
                custitem_ebay_body_picture_columns.push("custitem_ebay_body_picture_" + x);
            }
            c = c.concat(custitem_ebay_gallery_picture_columns, custitem_ebay_body_picture_columns);
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", [ this.id ]) ], c.map(function(name) {
                return new nlobjSearchColumn(name);
            }));
            if (search == null) {
                throw createEbayError("Not pic in item.");
            } else if (search.length && search.length == 1) {
                search = search[0];
                var pictureSearch = {
                    gallery: custitem_ebay_gallery_picture_columns.map(function(name) {
                        return {
                            name: name,
                            value: search.getValue(name),
                            text: search.getText(name)
                        };
                    }).filter(function(item) {
                        return item.value;
                    }),
                    bodyPicture: custitem_ebay_body_picture_columns.map(function(name) {
                        return {
                            name: name,
                            value: search.getValue(name),
                            text: search.getText(name)
                        };
                    }).filter(function(item) {
                        return item.value;
                    })
                };
                this.pictureSearch = pictureSearch;
                return pictureSearch;
            } else {
                throw createEbayError("Ebay pictures search no found or found more than 1!");
            }
        } else {
            return this.pictureSearch;
        }
    },
    getGalleryPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.gallery;
    },
    getBodyPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.bodyPicture;
    }
});

function EbayInventoryItem(id, ismatrix) {
    this.locationId = null;
    EbayItem.call(this, "inventoryitem", id);
}

inherit(EbayItem, EbayInventoryItem);

EbayInventoryItem.prototype.getField = function(name) {
    var record = this.rec;
    return {
        name: name,
        value: record.getFieldValue(name),
        text: record.getFieldText(name)
    };
};

EbayInventoryItem.prototype._ismatrix = function() {
    return this.ismatrix == "T";
};

EbayInventoryItem.prototype.getLocationQuantity = function() {
    return this.getSubList("locations", [ "location", "location_display", "quantityavailable" ]);
};

EbayInventoryItem.prototype.getChildRecord = function() {
    var variations = {};
    var parentRecord = this;
    var availOptions = this.getRecordVariations();
    var availOptionNameList = [];
    var matrixOptionsColumns = availOptions.availOptions.map(function(option) {
        availOptionNameList.push(option.name);
        return new nlobjSearchColumn(option.name).setLabel(option.label);
    });
    var columns = [ new nlobjSearchColumn("itemid"), new nlobjSearchColumn("baseprice"), new nlobjSearchColumn("custitem_ebay_variation_picture") ];
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    columns = columns.concat(matrixOptionsColumns);
    var itemChildRecordSearchResults = nlapiSearchRecord("inventoryitem", null, [ new nlobjSearchFilter("parent", null, "is", parentRecord.getId()), new nlobjSearchFilter("isinactive", null, "is", "F"), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ 7 ]) ], columns);
    var searchList = [];
    if (itemChildRecordSearchResults != null) {
        for (var i = 0, len = itemChildRecordSearchResults.length; i < len; i++) {
            var childRecord = itemChildRecordSearchResults[i];
            var record = {};
            record["__id"] = childRecord.getId();
            record["__type"] = childRecord.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var label = column.getLabel();
                var value = childRecord.getValue(column);
                var text = childRecord.getText(column);
                if (value && text) {
                    if (availOptionNameList.indexOf(name) != -1) {
                        record[name] = {
                            value: value,
                            text: text,
                            translation: ""
                        };
                    } else {
                        record[name] = {
                            value: value,
                            text: text
                        };
                    }
                } else {
                    if (name == "itemid") {
                        if (value.indexOf(" : ") != -1) value = value.substring(value.indexOf(" : ") + 3);
                    }
                    record[name] = value;
                }
            }
            record["locationquantityavailable"] = childRecord.getValue("formulanumeric");
            searchList.push(record);
        }
    }
    variations.childRecordList = searchList;
    _log("childRecordList", variations);
    return variations;
};

EbayInventoryItem.prototype.getRecordVariations = function() {
    var parentRecord = this;
    var variations = {};
    variations.availOptions = ITEM_OPTIONS.map(function(o) {
        return extend(parentRecord.getField(o[0]), {
            label: o[1],
            translation: ""
        });
    }).filter(function(item) {
        return item.value;
    });
    variations.availOptions.forEach(function(item) {
        item.value = item.value.split("");
        item.text = item.text.split("");
        item.options = item.value.map(function(v, i) {
            return {
                id: v,
                value: item.text[i],
                translation: ""
            };
        });
    });
    return variations;
};

EbayInventoryItem.getMatrixItemVariations = function(parentId) {
    return new EbayInventoryItem(parentId).getRecordVariations();
};

function EbayKitItem(id) {
    EbayItem.call(this, "kititem", id);
}

inherit(EbayItem, EbayKitItem);

EbayKitItem.prototype.getOption = function() {
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var name = "custitem_var_kit";
    var value = [];
    var text = [];
    var options = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        var var_name = line[3].trim();
        index++;
        value.push(id + "_" + index);
        text.push(var_name);
        return {
            id: id + "_" + index,
            value: var_name,
            translation: ""
        };
    });
    return {
        availOptions: [ {
            name: name,
            value: value,
            text: text,
            label: "Kit Variation",
            translation: "",
            options: options
        } ]
    };
};

function getVariationQuantity(id_expression, mainLocation) {
    id_expression = id_expression.map(function(id) {
        var qtyIndex = id.indexOf("*");
        if (qtyIndex != -1) {
            return {
                _id: id.substring(0, qtyIndex),
                _qty: id.substring(qtyIndex + 1)
            };
        } else {
            return {
                _id: id,
                _qty: "1"
            };
        }
    });
    var columns = [];
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", id_expression.map(function(item) {
        return item._id;
    })), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ mainLocation ]) ], columns);
    var list = [];
    if (search != null) {
        search.forEach(function(searchResult, index) {
            var total = searchResult.getValue("formulanumeric");
            _log("total" + index, total);
            if (total) {
                _log("searchResult.getId()", searchResult.getId());
                _log("id_expression", id_expression);
                var qty = id_expression.filter(function(item) {
                    return item._id == searchResult.getId();
                })[0]._qty;
                list.push(Math.floor(parseInt(total) / parseInt(qty)));
            }
        });
    } else {
        return 0;
    }
    _log("getVariationQuantity: " + JSON.stringify(id_expression), list);
    if (list.length) {
        var qty = _.min(list);
        if (!qty) qty = 0;
        _log(typeof qty, qty);
        return qty;
    } else {
        return 0;
    }
}

EbayKitItem.prototype.getChildRecord = function() {
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var childRecordList = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        index++;
        var line_id = line[0].trim();
        var line_sku = line[1].trim();
        var kit_var_id = line_id.replace(/\,/g, "^").replace(/\s/g, "");
        return {
            __id: kit_var_id,
            __type: "KIT_INV",
            itemid: kit_var_id,
            baseprice: line[2].trim(),
            custitem_ebay_variation_picture: "",
            custitem_var_kit: {
                value: id + "_" + index,
                text: line[3].trim(),
                translation: ""
            },
            locationquantityavailable: getVariationQuantity(line_id.split(",").map(function(id) {
                return id.trim();
            }), mainLocation)
        };
    });
    _log("EbayKitItem.prototype.getChildRecord", childRecordList);
    return {
        childRecordList: childRecordList
    };
};

var EbayFeed = {
    PENDING_MODIFICATION: "custrecord_ebay_feed_pending_mdf",
    TYPE: "customrecord_ebay_item_api_feed",
    getRecordFieldList: function() {
        var f = this.FIELD_MAPPING;
        var list = [];
        for (var i in f) {
            list.push(i);
        }
        return list;
    },
    search: function(id, addFilter) {
        var fieldMapping = this.FIELD_MAPPING;
        var columns = [];
        for (var i in fieldMapping) {
            columns.push(new nlobjSearchColumn(i));
        }
        [ "internalid", "custrecord_ebay_feed_category_title", "lastmodified", "lastmodifiedby" ].forEach(function(name) {
            columns.push(new nlobjSearchColumn(name));
        });
        var filter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ id ]), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_language_id", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_seq", null, "noneof", "@NONE@") ];
        if (addFilter && Array.isArray(addFilter)) {
            filter = filter.concat(addFilter);
        }
        var searchResult = __nlapiSearchRecord(this.TYPE, null, filter, columns);
        searchResult.list.forEach(function(item, index) {
            index++;
            item.__no = index;
            item.__link = nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", item.internalid.value);
        });
        return searchResult;
    },
    create: function(feed) {
        feed.custrecord_ebay_feed_status = EbayFeedStatus.New;
        var record = nlapiCreateRecord(this.TYPE);
        this.processFeedRecord(record, feed, "create");
        return nlapiSubmitRecord(record, true);
    },
    update: function(id, feed) {
        var record = nlapiLoadRecord(this.TYPE, id);
        var processResult = this.processFeedRecord(record, feed, "update");
        if (processResult.recordFieldChangedCount) {
            return {
                recordFieldChangedCount: processResult.recordFieldChangedCount,
                recordFieldChangedList: processResult.recordFieldChangedList,
                id: nlapiSubmitRecord(record, true)
            };
        } else {
            return {
                recordFieldChangedCount: 0,
                recordFieldChangedList: processResult.recordFieldChangedList,
                id: id
            };
        }
    },
    processFeedRecord: function(record, feed, action) {
        var recordFieldChangedCount = 0;
        var recordFieldChangedList = [];
        for (var field in feed) {
            var feedFieldValue = feed[field];
            if (Array.isArray(feedFieldValue)) {
                feedFieldValue = JSON.stringify(feedFieldValue);
            } else if (typeof feedFieldValue == "object") {
                if (feedFieldValue != null) {
                    feedFieldValue = JSON.stringify(feedFieldValue);
                }
            }
            if (!feedFieldValue) feedFieldValue = null;
            if (action == "create") {
                recordFieldChangedCount++;
                recordFieldChangedList.push("--all_field--");
                record.setFieldValue(field, feedFieldValue);
            } else {
                var changedFlag = false;
                var recordFieldValue = record.getFieldValue(field) || record.getFieldText(field);
                if (!recordFieldValue) recordFieldValue = null;
                if (field == "custrecord_ebay_feed_api_price" && record.getFieldValue("custrecord_ebay_feed_api_price_noo") == "T") {
                    continue;
                } else if (field == "custrecord_ebay_feed_push_qty" && record.getFieldValue("custrecord_ebay_feed_push_qty_noo") == "T") {
                    continue;
                } else {
                    if (recordFieldValue != feedFieldValue) {
                        _log("field", field);
                        _log("recordFieldValue: feedFieldValue for Type", typeof recordFieldValue + ": " + typeof feedFieldValue);
                        _log("recordFieldValue: feedFieldValue", recordFieldValue + ": " + feedFieldValue);
                        changedFlag = true;
                        recordFieldChangedCount++;
                        recordFieldChangedList.push(field);
                    }
                }
                if (changedFlag) {
                    record.setFieldValue(field, feedFieldValue);
                }
            }
        }
        _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
        return {
            recordFieldChangedCount: recordFieldChangedCount,
            recordFieldChangedList: recordFieldChangedList
        };
    }
};

function run(request, response) {
    try {
        var action = request.getParameter("action");
        var item__internalid = request.getParameter("item__internalid");
        if (request.getMethod() == "GET") {
            if (action == "view") {
                response.writePage(viewFeeds2(item__internalid));
            } else if (action == "viewVariation") {
                response.writePage(viewVariation(request.getParameter("feedId")));
            }
        } else {
            if (action) {
                if (action == "submitFeed") {
                    var actionList = request.getParameter("actionList");
                    actionList = JSON.parse(actionList);
                    actionList.forEach(function(item) {
                        nlapiSubmitField("customrecord_ebay_item_api_feed", item.feed_feed_id, "custrecord_ebay_feed_action", item.feed_next_action, true);
                    });
                    response.write(JSON.stringify({
                        success: true
                    }));
                } else if (action == "reviseVariation") {
                    response.writeLine(JSON.stringify(reviseVariation(request.getParameter("feedId"), JSON.parse(request.getParameter("matrixList")))));
                }
            } else {}
        }
    } catch (e) {
        processException(e);
    } finally {}
}

function reviseVariation(feedId, matrixList) {
    _log("reviseVariation", arguments);
    var feedRecord = new __EbayFeed(feedId);
    var variation = feedRecord.getVariation();
    matrixList.forEach(function(item) {
        var matrixitem = variation.childRecordList.filter(function(matrixRecord) {
            return matrixRecord.__id == item.id;
        });
        if (matrixitem.length) {
            matrixitem = matrixitem[0];
            matrixitem.baseprice = item.price;
        }
    });
    feedRecord.setFieldValue("custrecord_ebay_feed_variations", JSON.stringify(variation));
    feedRecord.setFieldValue("custrecord_ebay_feed_var_reviewed", "T");
    feedRecord.submitRecord();
    return {
        success: true
    };
}

function viewVariation(feedId) {
    var form = nlapiCreateForm("Item Variation", true);
    form.addField("custpage_variation_style", "inlinehtml").setDefaultValue(nlapiLoadFile("65970").getValue());
    form.addField("custpage_feed_id", "inlinehtml").setDefaultValue('<input type="hidden" id="feed_id" value="' + feedId + '"/>');
    var feedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", feedId);
    var variation = feedRecord.getFieldValue("custrecord_ebay_feed_variations");
    var variationReviewed = feedRecord.getFieldValue("custrecord_ebay_feed_var_reviewed");
    variation = JSON.parse(variation);
    var childRecordList = variation.childRecordList;
    form.setScript("customscript_ebay_item_var_client");
    form.addButton("custpage_variation_revise_price", "Revise Matrix Item Price", "revisePrice();");
    var variationList = form.addSubList("custpage_variation_list", "list", "Matrix Items", null);
    variationList.addField("variation_id", "text", "Internal ID", null);
    variationList.addField("variation_sku", "text", "SKU", null);
    variationList.addField("variation_type", "text", "Type", null);
    variationList.addField("variation_price", "text", "Price", null);
    variationList.addField("variation_currency", "text", "Currency", null);
    variationList.addField("variation_picture", "text", "Picture", null);
    variationList.addField("variation_qty", "text", "QTY", null);
    var varNameList = [];
    variation.availOptions.forEach(function(item) {
        variationList.addField("variation_" + item.name, "text", item.label, null);
        varNameList.push({
            name: item.name,
            listname: "variation_" + item.name
        });
    });
    for (var i = 0; i < childRecordList.length; i++) {
        var varRecord = childRecordList[i];
        var line = i + 1;
        variationList.setLineItemValue("variation_id", line, varRecord.__id);
        variationList.setLineItemValue("variation_sku", line, varRecord.itemid);
        variationList.setLineItemValue("variation_type", line, varRecord.__type);
        if (variationReviewed == "T") {
            variationList.setLineItemValue("variation_price", line, '<input class="var-price" type="text" value="' + varRecord.baseprice + '" />');
        } else {
            variationList.setLineItemValue("variation_price", line, '<input class="var-price var-new" type="text" value="' + varRecord.baseprice + " " + varRecord.currency + '" />');
        }
        variationList.setLineItemValue("variation_currency", line, varRecord.currency);
        variationList.setLineItemValue("variation_picture", line, varRecord.custitem_ebay_variation_picture);
        variationList.setLineItemValue("variation_qty", line, varRecord.locationquantityavailable);
        varNameList.forEach(function(name) {
            variationList.setLineItemValue(name.listname, line, varRecord[name.name].translation);
        });
    }
    return form;
}

function viewFeeds2(item__internalid) {
    var form = nlapiCreateForm("Ebay Item Feeds Page", false);
    form.addField("custpage_feed_html", "inlinehtml", null, null, null).setDefaultValue("<script type='text/javascript' src='/core/media/media.nl?id=57971&c=277620&h=ccec99df891949783e7f&whence='></script>");
    form.setScript("customscript_ebay_feed_client");
    var searchResults = EbayFeed.search(item__internalid);
    searchResults = searchResults.list;
    searchResults.forEach(function(searchResult) {
        searchResult.dropList = [ {
            k: "0",
            v: "None Action"
        } ].concat(__EbayFeed.searchActionButton(nlapiGetRole(), searchResult.custrecord_ebay_feed_status.value).map(function(item) {
            return {
                k: item.__id,
                v: item.custrecord_efw_action_button.text
            };
        }));
        if (searchResult.custrecord_ebay_feed_is_var.value == "T") {
            var URL = "/app/site/hosting/scriptlet.nl?script=114&deploy=1";
            searchResult.variationLink = '<a href="#v" onclick="viewVariation(\'' + URL + "&action=viewVariation&feedId=" + searchResult.internalid.value + "')\">View Variation</a>";
        } else {
            searchResult.variationLink = "";
        }
    });
    form.addField("custpage_feedpage_html", "inlinehtml", null, null, null).setDefaultValue(renderPage(nlapiLoadFile(65801).getValue(), {
        searchResults: searchResults
    }));
    return form;
}