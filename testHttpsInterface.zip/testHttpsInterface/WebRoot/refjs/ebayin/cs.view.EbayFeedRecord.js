initNProgress();

function _nlapiGetFieldValue(name) {
    var html = jQuery("#" + name + "_fs_lbl_uir_label").next("span").html();
    if (html && typeof html == "string") {
        return html.trim();
    } else {
        return "";
    }
}

function _nlapiSetFieldValue(name, value) {
    jQuery("#" + name + "_fs_lbl_uir_label").next("span").html(value);
}

function doAction(feedId, buttonId) {
    var data = {
        feedId: feedId,
        buttonId: buttonId
    };
    var type = "GET";
    if (buttonId == EBAY_FEED_BUTTON.REJECT) {
        var reason = window.prompt("Please write reject reason");
        if (reason) {
            data.reason = reason;
            type = "POST";
        } else {
            alert("Reason is required");
            return false;
        }
    }
    jQuery.ajax({
        type: type,
        url: "/app/site/hosting/scriptlet.nl?script=120&deploy=1",
        data: data,
        success: function(data) {
            console.log(typeof data + "///" + data);
            PageOverlay.removeOverlay();
            NProgress.done(true);
            data = parseToJSON(data);
            if (buttonId == EBAY_FEED_BUTTON.VerifyAddItem) {
                alert(JSON.stringify(data, null, 2));
            } else if (data.success == false) {
                alert(data.message);
            }
            window.location.reload();
        },
        beforeSend: function() {
            PageOverlay.showOverlay();
            NProgress.start();
        }
    });
}

function getStatus(feedId, ebayItemId) {
    if (!ebayItemId) {
        alert("Not listed on eBay yet!");
        return false;
    }
    jQuery.ajax({
        url: "/app/site/hosting/scriptlet.nl?script=120&deploy=1",
        data: {
            feedId: feedId,
            ebayItemId: ebayItemId
        },
        success: function(data) {
            console.log(typeof data);
            PageOverlay.removeOverlay();
            NProgress.done();
            data = parseToJSON(data);
            var s = data.response.GetItemResponse.Item.SellingStatus.ListingStatus;
            if (s == "Completed") {
                alert("Offline: " + s);
            } else if (s == "Active") {
                alert("Online: " + s);
            } else {
                alert("Status: " + s);
            }
        },
        beforeSend: function() {
            PageOverlay.showOverlay();
            NProgress.start();
        }
    });
}

function displayPicture(pictureField) {
    var picture = _nlapiGetFieldValue(pictureField);
    picture = picture.replace(/&nbsp;/g, "");
    picture = picture.trim();
    _log("picture", picture);
    if (!picture) return;
    var pictureHTML = '<img style="float: left; margin: 0 10px 10px 0;" width="120px" src="' + picture + '"/>';
    _nlapiSetFieldValue(pictureField, pictureHTML);
}

displayPicture("custrecord_ef_picture2");

function previewDescription() {
    post_to_url("https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=120&deploy=2", {
        desc: _nlapiGetFieldValue("custrecord_ebay_feed_description")
    });
}

ossImageDisplay("custrecord_ebay_feed_gallery");

ossImageDisplay("custrecord_ebay_feed_body_picture");

var $ZakeTable = jQuery("#ZakeTable");

$ZakeTable.parents(".uir-outside-fields-table").css("width", "100%");