if (typeof this.console == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function parseException(e) {
    var code, message;
    var userMessage = null;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = e.getCode() || "nlobjError";
            var st = e.getStackTrace();
            if (Array.isArray(st)) {
                st = st.join(", ");
            }
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + st;
            userMessage = e.getDetails();
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (userMessage == null) userMessage = message;
    var context = nlapiGetContext();
    var sname = [ context.getDeploymentId(), "@Subsidiary" + context.getSubsidiary(), context.getEmail() ].join(" ");
    return {
        code: "[" + code + "] " + sname,
        ERROR_CODE: code,
        message: message,
        userMessage: userMessage
    };
}

function processException(e, info, sendEmail) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "<br/><br/>" + info;
    }
    if (typeof console == "undefined") {
        if (sendEmail != false) {
            _log("nlapiSendEmail", code);
            nlapiSendEmail(530, "allan@zakeusa.com", code, message);
        }
    } else {
        alert(code + "///" + message);
    }
    _nlapiLogExecution("ERROR", code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

function disabledFields(fields) {
    var defaultFields = [ "customform", "name" ];
    if (typeof fields != "undefined" && Array.is(fields)) {
        fields = fields.concat(defaultFields);
    } else {
        fields = defaultFields;
    }
    _disabledFields(fields);
}

function _disabledFields(fields) {
    if (fields && Array.isArray(fields) && fields.length) {
        fields.forEach(function(field) {
            nlapiGetField(field).setDisplayType("disabled");
        });
    }
}

function _nlapiLogExecution(logType, title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (typeof console == "undefined") {
            if (detail) {
                if (typeof detail == "object") {
                    if (format) {
                        nlapiLogExecution(logType, title, JSON.stringify(detail, undefined, 4));
                    } else {
                        nlapiLogExecution(logType, title, JSON.stringify(detail));
                    }
                } else {
                    nlapiLogExecution(logType, title, detail);
                }
            } else {
                nlapiLogExecution(logType, title, detail);
            }
        } else {
            if (typeof title == "object") {
                title = JSON.stringify(title, null, 2);
            }
            if (typeof detail == "object") {
                console.log(title + "///" + JSON.stringify(detail, null, 2));
            } else {
                console.log(title + "///" + detail);
            }
        }
    }
}

function _log(title, detail) {
    var logType = "debug";
    _nlapiLogExecution(logType, title, detail);
}

function _audit(title, detail) {
    _nlapiLogExecution("AUDIT", title, detail);
}

function _log_email(title, detail) {
    nlapiSendEmail(530, "allan@zakeusa.com", nlapiGetContext().getDeploymentId() + ": " + title, detail);
}

function _sendEmail(to, title, detail) {
    title = nlapiGetContext().getDeploymentId() + ": " + title;
    _log("[SENTEMAIL] " + to + " " + title, detail);
    nlapiSendEmail(530, to, title, detail);
}

function simpleCreateRecord(type, obj) {
    var rec = nlapiCreateRecord(type);
    for (var field in obj) {
        rec.setFieldValue(field, obj[field]);
    }
    return nlapiSubmitRecord(rec, true);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

Array.prototype.remove = function(value) {
    var a = this;
    var index = a.indexOf(value);
    if (index > -1) {
        a.splice(index, 1);
    }
};

Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) < 0;
    });
};

Array.prototype.same = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) >= 0;
    });
};

function _toarray(obj) {
    if (!Array.isArray(obj)) obj = [ obj ];
    return obj;
}

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
    children.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function createTextFile(name, content, folderId) {
    folderId = folderId || 80473;
    var file = nlapiCreateFile(name + ".txt", "PLAINTEXT", content);
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function _renderPage(html, obj) {
    for (var o in obj) {
        var k = "{{" + o + "}}";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function _renderPage2(html, obj) {
    for (var o in obj) {
        var k = "#" + o + "#";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    var joinname = join + "." + name;
                    record[joinname] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function __nlapiSearchRecordX(type, id, filters, columns) {
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            record["__id"] = search_record.getId();
            record["__type"] = search_record.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var value = search_record.getValue(column);
                var text = search_record.getText(column);
                if (value && text) {
                    record[name] = {
                        value: value,
                        text: text
                    };
                } else {
                    record[name] = value;
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecordX", list);
    return list;
}

function __nlapiSearchRecord2(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    return {
        columnLabels: columnLabels,
        list: __nlapiSearchRecordX(type, id, filters, columns)
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function _auditUsage() {
    _audit("getRemainingUsage USAGE", nlapiGetContext().getRemainingUsage());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        var spendTime = Math.round((new Date().getTime() - this.startTime) / 1e3) + "s";
        _audit("_audit - [Profiling]", spendTime);
        return spendTime;
    }
};

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(url ? url : location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var IS_NS_SANDBOX = false;

var NS_DOMAIN = "system.na1.netsuite.com";

if (nlapiGetContext().getEnvironment() == "SANDBOX") {
    IS_NS_SANDBOX = true;
    NS_DOMAIN = "system.sandbox.netsuite.com";
}

var Subsidiaries = {
    ZakeUSAHolding: 2,
    Swagway: 4,
    TaiwuInternational: 3,
    ZakeInternational: 1
};

function logparams(request) {
    _log("request.getMethod()----", request.getMethod());
    _log("---logparams---", getparams(request));
}

function getparams(request) {
    var params = request.getAllParameters();
    var paramlist = [];
    for (var param in params) {
        paramlist.push({
            parameter: param,
            value: params[param]
        });
    }
    return paramlist;
}

function checkGovernance() {
    if (nlapiGetContext().getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < 500) {
        nlapiLogExecution("AUDIT", "checkGovernance---", nlapiGetContext().getRemainingUsage());
        var state = nlapiYieldScript();
        _audit("state.status", state.status);
        if (state.status == "FAILURE") {
            throw nlapiCreateError("YIELD_SCRIPT_ERROR", "Failed to yield script, exiting<br/>Reason = " + state.reason + "<br/>Size = " + state.size + "<br/>Information = " + state.information);
        } else if (state.status == "RESUME") {
            nlapiLogExecution("debug", "checkGovernance-------------", nlapiGetContext().getRemainingUsage());
            nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        }
    } else {
        nlapiGetContext().setPercentComplete((1e4 - nlapiGetContext().getRemainingUsage()) / 100);
    }
}

function rescheduled(params) {
    var context = nlapiGetContext();
    if (context.getExecutionContext() != "scheduled") {
        return false;
    }
    var remainingUsage = nlapiGetContext().getRemainingUsage();
    if (remainingUsage < 500) {
        _audit("remainingUsage", remainingUsage);
        var status = null;
        if (params) {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
        } else {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        }
        _audit("status", status);
        if (status == "QUEUED") {
            _audit("Reschedule for usage reset ...", remainingUsage);
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

var MarketplaceShipService = {
    ToBeDetermined: 6,
    Standard: 1,
    ThirdDaySelect: 2,
    SecondDayAir: 3,
    NextDay: 4,
    InternationalShippingFromUS: 5
};

var MarketplaceShipName = {
    AliExpress: 1,
    Amazon: 2,
    eBay: 3,
    Wish: 4,
    _3BBestbuy: 5,
    _3BNewegg: 6,
    Rakuten: 7,
    PCDirect: 8,
    _3Btech: 9,
    Swagway: 10
};

var MARKETPLACE_LIST = [ {
    marketplaceId: 10,
    ARAccount: "177",
    formid: "151",
    name: "Swagway"
}, {
    marketplaceId: 3,
    ARAccount: "1127",
    formid: "178",
    name: "EbayClaimthis"
}, {
    marketplaceId: 2,
    ARAccount: "176",
    formid: "263",
    name: "SavannahAmazon",
    store: "1"
}, {
    marketplaceId: 2,
    ARAccount: "174",
    formid: "199",
    name: "BetterChoiceAmazon",
    store: "8"
}, {
    marketplaceId: 5,
    ARAccount: "1126",
    formid: "220",
    name: "ThreeBTechBestBuy"
}, {
    marketplaceId: 7,
    ARAccount: "1129",
    formid: "220",
    name: "ThreeBTechRakuten"
}, {
    marketplaceId: 6,
    ARAccount: "1128",
    formid: "150",
    name: "NeweggZake"
}, {
    marketplaceId: 9,
    ARAccount: "1130",
    formid: "150",
    name: "ThreeBTechNet"
}, {
    marketplaceId: 8,
    ARAccount: "1131",
    formid: "150",
    name: "PCDirect"
} ];

var SALES_ORDER_FORM = {
    SWAGWAY: 151,
    EBAY: 178
};

function getUTCDateTime() {
    var now = new Date();
    var offset = now.getTimezoneOffset();
    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
    nlapiLogExecution("debug", "getUTCDateTime", utcDate);
    return utcDate;
}

var DateCompare = {
    convert: function(d) {
        return d.constructor === Date ? d : d.constructor === Array ? new Date(d[0], d[1], d[2]) : d.constructor === Number ? new Date(d) : d.constructor === String ? new Date(d) : typeof d === "object" ? new Date(d.year, d.month, d.date) : NaN;
    },
    compare: function(a, b) {
        return isFinite(a = this.convert(a).valueOf()) && isFinite(b = this.convert(b).valueOf()) ? (a > b) - (a < b) : NaN;
    },
    inRange: function(d, start, end) {
        return isFinite(d = this.convert(d).valueOf()) && isFinite(start = this.convert(start).valueOf()) && isFinite(end = this.convert(end).valueOf()) ? start <= d && d <= end : NaN;
    }
};

var EbayRecordType = {
    customrecord_ebay_item_site_setting: "customrecord_ebay_item_site_setting",
    customrecord_ebay_item_language: "customrecord_ebay_item_language",
    customrecord_ebay_global: "customrecord_ebay_global",
    customrecord_ebay_item_api_feed: "customrecord_ebay_item_api_feed",
    customrecord_ebay_feed_workflow: "customrecord_ebay_feed_workflow",
    customrecord_ebay_account: "customrecord_ebay_account"
};

var EbayRequest = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll",
    headers: {
        "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
        "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
        "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
        "Content-Type": "application/xml"
    },
    call: function(header, xml) {
        try {
            var message = "OK";
            var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(this.headers, header));
            var x2js = new X2JS();
            var responseJSON = x2js.xml_str2json(response.getBody());
            return {
                success: true,
                message: message,
                response: responseJSON
            };
        } catch (e) {
            e = processException(e);
            return {
                success: false,
                message: e.getMessage()
            };
        }
    }
};

function saveAPICallResult(fileName, pageNumber, arr) {
    if (!Array.isArray(arr)) {
        throw createEbayError("Params is error and not array");
    }
    fileName += ".txt";
    var folderId = 295527;
    var file = null;
    if (pageNumber == 1) {
        var content = {
            startTime: new Date().getTime(),
            arr: arr
        };
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content));
    } else {
        file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
        var content = file.getValue();
        content = JSON.parse(content);
        content.arr = content.arr.concat(arr);
        content.arrLenth = content.arr.length;
        content.endTime = new Date().getTime();
        content.spendTime = Math.round((content.endTime - content.startTime) / 1e3) + "s";
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content, null, 2));
    }
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

function sendAPICallResult(fileName) {
    fileName += ".txt";
    var file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
    var content = file.getValue();
    _log_email(fileName, content);
}

var EbayFeedStatus = {
    Online: 1,
    Offline: 2,
    ForcedOffline: 3,
    InQue_New: 4,
    InQue_RelistOnline: 9,
    InQue_RelistOffline: 10,
    Error_New: 5,
    Error_RelistOnline: 11,
    Error_RelistOffline: 14,
    Error_Revise: 12,
    Error_Offline: 13,
    WaitingForApproval: 6,
    Rejected: 7,
    New: 8
};

var EbayFeedButtonAction = {
    Submit: 6,
    Relist: 5,
    Delist: 2,
    ForceDelist: 3,
    Approve: 1,
    Reject: 4,
    Revise: 7,
    ReSubmit: 8
};

var ZakeRole = {
    SalesManager: 1021,
    SalesPerson: 1022
};

function createEbayError(details) {
    return nlapiCreateError("EBAY_ERROR", details);
}

function createError(details) {
    return nlapiCreateError("ZAKE_ERROR", details);
}

function getCustomList(customListId, asObject) {
    var col = new Array();
    col[0] = new nlobjSearchColumn("name");
    col[1] = new nlobjSearchColumn("internalId");
    var obj = {};
    var list = [];
    var results = nlapiSearchRecord(customListId, null, null, col);
    for (var i = 0; results != null && i < results.length; i++) {
        var res = results[i];
        var listValue = res.getValue("name");
        var listID = res.getValue("internalId");
        list.push({
            key: listID,
            value: listValue
        });
        obj[listID] = listValue;
    }
    if (asObject == true) {
        return obj;
    } else {
        return list;
    }
}

function deepmerge(target, src) {
    var array = Array.isArray(src);
    var dst = array && [] || {};
    if (array) {
        target = target || [];
        dst = dst.concat(target);
        src.forEach(function(e, i) {
            if (typeof dst[i] === "undefined") {
                dst[i] = e;
            } else if (typeof e === "object") {
                dst[i] = deepmerge(target[i], e);
            } else {
                if (target.indexOf(e) === -1) {
                    dst.push(e);
                }
            }
        });
    } else {
        if (target && typeof target === "object") {
            Object.keys(target).forEach(function(key) {
                dst[key] = target[key];
            });
        }
        Object.keys(src).forEach(function(key) {
            if (typeof src[key] !== "object" || !src[key]) {
                dst[key] = src[key];
            } else {
                if (!target[key]) {
                    dst[key] = src[key];
                } else {
                    dst[key] = deepmerge(target[key], src[key]);
                }
            }
        });
    }
    return dst;
}

function autoSetEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = item.label;
        }
        item.options.forEach(function(opt) {
            opt.translation = opt.value;
        });
    });
}

function autoRemoveEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = "";
        }
        item.options.forEach(function(opt) {
            opt.translation = "";
        });
    });
}

Array.prototype.unique = function() {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j]) a.splice(j--, 1);
        }
    }
    return a;
};