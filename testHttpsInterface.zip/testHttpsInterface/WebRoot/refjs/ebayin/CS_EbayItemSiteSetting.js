var STYLE = "<style>" + ".afterOptions{background-color:#fff;position:absolute;width:300px;border:1px solid #00f}.afterOptions li{padding:5px}" + ".afterOptions li:hover{background-color:#ffefd0}" + ".popupOption{border:1px solid blue!important;}" + "</style>";

jQuery("head").append(STYLE);

initNProgress();

(function($, window, document) {
    $.fn.afterOptions = function(options) {
        return this.each(function() {
            var $THE_TEXT_BOX = $(this);
            $THE_TEXT_BOX.parent().addClass("popupOption");
            function getAfterOptions() {
                return $THE_TEXT_BOX.next(".afterOptions");
            }
            var optionsMenu = '<ul class="afterOptions">';
            optionsMenu += options.map(function(o) {
                return "<li>" + o + "</li>";
            }).join("");
            optionsMenu += "</ul>";
            function hideOptions() {
                if ($THE_TEXT_BOX.next(".afterOptions").length) {
                    $THE_TEXT_BOX.next(".afterOptions").hide();
                }
            }
            $THE_TEXT_BOX.on("focusin dblclick", function() {
                var ao = getAfterOptions();
                if (!ao.length) {
                    $THE_TEXT_BOX.after(optionsMenu);
                    ao = getAfterOptions();
                    ao.children("li").on("click", function() {
                        $THE_TEXT_BOX.val($(this).html().trim());
                        $THE_TEXT_BOX.focus();
                        ao.hide();
                    });
                    ao.on({
                        mouseenter: function() {
                            $THE_TEXT_BOX.off("focusout");
                        },
                        mouseleave: function() {
                            $THE_TEXT_BOX.on("focusout", hideOptions);
                        }
                    });
                } else {
                    ao.show();
                }
            }).on("focusout", hideOptions);
        });
    };
    $.fn.afterOptions.format = function(txt) {
        return "<strong>" + txt + "</strong>";
    };
    $.fn.afterOptions.defaults = {};
})(jQuery, window, document, undefined);

function convert_to_array(obj) {
    if (!Array.isArray(obj)) {
        return [ obj ];
    } else {
        return obj;
    }
}

var POPUP_SPECIFIC_BUTTON = '<input style="padding: 3px 6px; margin-left: 5px; cursor: pointer;" onclick="POPUP_SPECIFIC(); return false;" type="button" ' + 'value="Popup Ebay Category Recommendation Specific"' + ' id="popupCategorySpeicfic" name="popupCategorySpeicfic" />';

jQuery("#custrecord_ei_site_category_id").after(POPUP_SPECIFIC_BUTTON);

function POPUP_SPECIFIC() {
    try {
        if (!nlapiGetFieldValue("custrecord_ei_site")) {
            alert("Please chose site at first.");
            return;
        }
        var ebayAccounts = nlapiGetFieldValue("custrecord_ei_ebay_accounts");
        ebayAccounts = ebayAccounts.split("");
        console.log(ebayAccounts);
        if (!ebayAccounts.length) {
            alert("Ebay accounts have not chose.");
            return;
        }
        var cateid = nlapiGetFieldValue("custrecord_ei_site_category_id");
        if (!cateid) {
            alert("Please input the category ID.");
            return;
        }
        NProgress.start();
        var token = nlapiLookupField("customrecord_ebay_account", ebayAccounts[0], "custrecord_ebay_api_token");
        var xml = "";
        xml += '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<GetCategorySpecificsRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
        xml += "  <WarningLevel>High</WarningLevel>";
        xml += "  <CategorySpecific>";
        xml += "    <CategoryID>" + cateid + "</CategoryID>";
        xml += "  </CategorySpecific>";
        xml += "  <RequesterCredentials>";
        xml += "        <eBayAuthToken>" + token + "</eBayAuthToken>";
        xml += "  </RequesterCredentials>";
        xml += "</GetCategorySpecificsRequest>";
        console.log(xml);
        var res = EbayRequest.call({
            "X-EBAY-API-COMPATIBILITY-LEVEL": "933",
            "X-EBAY-API-SITEID": nlapiGetFieldValue("custrecord_ei_ebayapi_siteid"),
            "X-EBAY-API-CALL-NAME": "GetCategorySpecifics"
        }, xml);
        console.log(JSON.stringify(res));
        if (res.success) {
            if (res.response.GetCategorySpecificsResponse.Ack == "Success") {
                if (res.response.GetCategorySpecificsResponse.Recommendations.hasOwnProperty("NameRecommendation")) {
                    res = res.response.GetCategorySpecificsResponse.Recommendations.NameRecommendation;
                    var specificList = res.map(function(NameRecommendation) {
                        var recs = [];
                        if (NameRecommendation.hasOwnProperty("ValueRecommendation")) {
                            recs = convert_to_array(NameRecommendation.ValueRecommendation).map(function(value) {
                                return value.Value;
                            });
                        }
                        return {
                            Name: NameRecommendation.Name,
                            ValueRecommendation: recs
                        };
                    });
                    console.log(JSON.stringify(specificList, null, 2));
                    var lastSpecificNo = 0;
                    for (var i = 1; i <= 15; i++) {
                        lastSpecificNo = i;
                        if (!specificList.length) break;
                        var specific_name = nlapiGetFieldValue("custrecord_ei_specific" + i);
                        if (specific_name) {
                            var recommendation = findRecommendation(specificList, specific_name);
                            if (recommendation) {
                                jQuery("#custrecord_ei_specific_value" + i).afterOptions(recommendation.Recommendation.ValueRecommendation);
                                specificList.splice(recommendation.Index, 1);
                            }
                        } else {
                            var recommendation = specificList[0];
                            nlapiSetFieldValue("custrecord_ei_specific" + i, recommendation.Name);
                            jQuery("#custrecord_ei_specific_value" + i).afterOptions(recommendation.ValueRecommendation);
                            specificList.splice(0, 1);
                        }
                    }
                    console.log(lastSpecificNo);
                }
            } else {
                alert(JSON.stringify(res.response.GetCategorySpecificsResponse.Errors, null, 2));
            }
        } else {
            alert(res.message);
        }
        NProgress.done(true);
    } catch (e) {
        NProgress.done(true);
        processException(e);
    }
}

function findRecommendation(arr, specific_name) {
    for (var i = 0, len = arr.length; i < len; i++) {
        if (arr[i].Name == specific_name) {
            return {
                Recommendation: arr[i],
                Index: i
            };
        }
    }
    return null;
}

function fieldChanged(type, name, linenum) {
    if ("custrecord_ei_site" == name) {
        console.log(JSON.stringify(arguments));
        var itemName = nlapiGetFieldText("custrecord_ei_item_link");
        var siteName = nlapiGetFieldText("custrecord_ei_site");
        var siteId = nlapiGetFieldValue("custrecord_ei_site");
        nlapiSetFieldValue("name", itemName + ": " + siteName);
        console.log(siteId);
        if (siteId) {
            var siteSearch = nlapiSearchRecord("customrecord_ebay_item_site_setting", null, [ new nlobjSearchFilter("custrecord_ei_item_link", null, "is", nlapiGetFieldValue("custrecord_ei_item_link")), new nlobjSearchFilter("custrecord_ei_site", null, "is", siteId) ]);
            if (siteSearch != null) {
                alert("Site " + siteName + " has already existing! -- size: " + siteSearch.length);
                nlapiSetFieldValue("custrecord_ei_site", "");
            }
        }
    } else if (name == "custrecord_ei_location") {}
}

function pageInit(type) {
    var user = nlapiGetContext().getUser();
    nlapiSetFieldValue("custrecord_ei_employee", user);
}

function saveRecord() {
    return true;
}