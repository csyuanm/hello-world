// 深圳抓单脚本

//var P = new Profiling();
var NSCurrencies = [
    {
        "INTERNALID": 1,
        "NAME": "USD",
        "ISOCODE": "USD"
    },
    {
        "INTERNALID": 2,
        "NAME": "GBP",
        "ISOCODE": "GBP"
    },
    {
        "INTERNALID": 3,
        "NAME": "CAD",
        "ISOCODE": "CAD"
    },
    {
        "INTERNALID": 4,
        "NAME": "EUR",
        "ISOCODE": "EUR"
    },
    {
        "INTERNALID": 5,
        "NAME": "CNY",
        "ISOCODE": "CNY"
    },
    {
        "INTERNALID": 6,
        "NAME": "AUD",
        "ISOCODE": "AUD"
    },
    {
        "INTERNALID": 7,
        "NAME": "HKD",
        "ISOCODE": "HKD"
    },
    {
        "INTERNALID": 8,
        "NAME": "INR",
        "ISOCODE": "INR"
    },
    {
        "INTERNALID": 9,
        "NAME": "MYR",
        "ISOCODE": "MYR"
    },
    {
        "INTERNALID": 10,
        "NAME": "PHP",
        "ISOCODE": "PHP"
    },
    {
        "INTERNALID": 11,
        "NAME": "PLN",
        "ISOCODE": "PLN"
    },
    {
        "INTERNALID": 12,
        "NAME": "RUB",
        "ISOCODE": "RUB"
    },
    {
        "INTERNALID": 13,
        "NAME": "SGD",
        "ISOCODE": "SGD"
    },
    {
        "INTERNALID": 14,
        "NAME": "CHF",
        "ISOCODE": "CHF"
    },
    {
        "INTERNALID": 15,
        "NAME": "JPY",
        "ISOCODE": "JPY"
    }
];

var NS_CONTEXT = nlapiGetContext();
var DEPLOYMENT_ID = nlapiGetContext().getDeploymentId();
_audit('DEPLOYMENT_ID', DEPLOYMENT_ID);

// Case:#205626423015 multi line item in one order
// 每个 Ebay Account 调用时候都是刷新这个全局变量
var RUNNING_ACCOUNT = {
    EBAY_ACCOUNT_ID: null,
    EBAY_ACCOUNT_TOKEN: null,
    SAVED_FILE_NAME: '',
    SUBSIDIARY: null
};

function run() {

    // 这个以后改成 Multi Select -------------- 配置 页面上面改不了！ 只能字符串形式
    var accounts = NS_CONTEXT.getSetting("SCRIPT", "custscript_sz_sc_go_ebay_account");
    accounts = accounts.trim();

    if (accounts) {
        accounts = accounts.split(',');
        accounts = accounts.map(function (acc) {
            return acc.trim();
        });

        for (var i = 0; i < accounts.length; i++) {

            try {

                var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [
                    new nlobjSearchFilter('internalid', null, 'is', accounts[i])
                ], [
                    new nlobjSearchColumn('name'),
                    new nlobjSearchColumn('custrecord_ebay_api_token'),
                    new nlobjSearchColumn('custrecord_ebay_global_site_access'),
                    new nlobjSearchColumn('custrecord_ea_subsidiary'),
                    new nlobjSearchColumn('custrecord_ebay_shortname'),
                    new nlobjSearchColumn('custrecord_ebay_account_storefront'),

                    new nlobjSearchColumn('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
                    new nlobjSearchColumn('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
                    new nlobjSearchColumn('custrecord_ed_cert_name', 'custrecord_ebay_dev_account')
                ]);

                if (ebayAccountSearch != null) {

                    _log('ebayAccountSearch.length', ebayAccountSearch.length);

                    RUNNING_ACCOUNT.EBAY_ACCOUNT_ID = ebayAccountSearch[0].getId();
                    RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN = ebayAccountSearch[0].getValue('custrecord_ebay_api_token');
                    RUNNING_ACCOUNT.SAVED_FILE_NAME = 'EBAY_GETORDERS_Shenzhen_TIME_' + ebayAccountSearch[0].getId() + '.txt';
                    RUNNING_ACCOUNT.SUBSIDIARY = ebayAccountSearch[0].getValue('custrecord_ea_subsidiary');
                    //RUNNING_ACCOUNT.STOREFRONT = ebayAccountSearch[0].getValue('custrecord_ebay_account_storefront');
                    _audit('RUNNING_ACCOUNT', RUNNING_ACCOUNT);

                    _preprocess(ebayAccountSearch[0]);

                    // for next account
                    RUNNING_ACCOUNT = {
                        EBAY_ACCOUNT_ID: null,
                        EBAY_ACCOUNT_TOKEN: null,
                        SAVED_FILE_NAME: '',
                        SUBSIDIARY: null
                    };

                }

            } catch (e) {
                var info = ' --- ';
                if (ebayAccountSearch) {
                    info = 'ebayAccountSearch-' + ebayAccountSearch[0].getId();
                }
                processException(e, info);
            }
            //// : Just testing
            //LogFile.saveLog();

        }
    }

}

function saveTimeFromFile(timeto) {
    var f = nlapiCreateFile(RUNNING_ACCOUNT.SAVED_FILE_NAME, 'PLAINTEXT', timeto);
    f.setFolder(460300); // 1285	EbayIntegration
    return nlapiSubmitFile(f);
}

function getTimeFrom() {

    try {
        var path = 'SuiteScripts/EbayIntegration/timefile/' + RUNNING_ACCOUNT.SAVED_FILE_NAME;
        var timefrom = nlapiLoadFile(path).getValue();
        // 延迟 5分钟
        return this.moment(timefrom.replace('Z', '')).subtract(5, 'minutes').format('YYYY-MM-DDTHH:mm:ss') + '.000Z';

    } catch (e) {

        if (e instanceof nlobjError && e.getCode() == 'RCRD_DSNT_EXIST') {

            var d = getUTCDateTime();
            var currentUTCDate = this.moment(d);

            var timefrom = currentUTCDate.subtract(300, 'minutes').format('YYYY-MM-DDTHH:mm:ss') + '.000Z';
            var f = nlapiCreateFile(RUNNING_ACCOUNT.SAVED_FILE_NAME, 'PLAINTEXT', timefrom);
            f.setFolder(460300); // 460300	timefile
            nlapiSubmitFile(f);

            return timefrom;

        } else {
            throw e;
        }
    }
}

function _preprocess(ebay_account) {

    var timefrom = getTimeFrom();

    // 这里是关键， 取的是当前时间。。。。。
    var d = getUTCDateTime();
    var currentUTCDate = this.moment(d);
    var timeto = currentUTCDate.format('YYYY-MM-DDTHH:mm:ss') + '.000Z';

    if (DEPLOYMENT_ID == 'customdeploy_sz_sc_ebaygetorders_fix') {

        // 这里指定的都是UTC 时间 for SB
        //getEbayOrders(ebay_account, '2016-01-27T05:00:00.000Z', '2016-01-28T05:00:00.000Z');

        timefrom = NS_CONTEXT.getSetting("SCRIPT", "custscript_sz_sc_ebayorder_timefrom");
        timeto = NS_CONTEXT.getSetting("SCRIPT", "custscript_sz_sc_ebayorder_timeto");

        getEbayOrders(ebay_account, timefrom, timeto);
    } else {
        getEbayOrders(ebay_account, timefrom, timeto);
    }


}


// 1. 设置定时脚本cron job, 每隔15分钟运行一次(调用GetOrders):
function getEbayOrders(ebay_account, timefrom, timeto, PageNumber, exeReport) {

    var P = new Profiling();
    var token = ebay_account.getValue('custrecord_ebay_api_token');
    var ebayAccountName = ebay_account.getValue('name');


    // Specify a positive value equal to or lower than the number of pages available (which you determine by examining the results of your initial request).
    // Min: 1. Default: 1.
    PageNumber = PageNumber || 1;

    // : Google with eBay GetOrders API best practices!!!!!
    // : https://ebaydts.com/eBayKBDetails?KBid=5024
    // For GetOrders, the maximum value is 100 and the default value is 25 orders per page.
    var EntriesPerPage = 100; // Min: 1. Max: 100. Default: 25.

    _audit(ebayAccountName + ' Page: ' + PageNumber, timefrom + ' ~ ' + timeto);

    var xml = "";
    xml += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<GetOrdersRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">";
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + token + "<\/eBayAuthToken>";
    xml += "  <\/RequesterCredentials>";

    xml += "  <IncludeFinalValueFee>true</IncludeFinalValueFee>";

    //xml += "  <CreateTimeFrom>2013-03-21T05:48:49.834Z<\/CreateTimeFrom>";
    //xml += "  <CreateTimeTo>2013-03-29T05:48:49.834Z<\/CreateTimeTo>";

    // 24 小时制
    // (2) 将 ModTimeFrom 设置为执行脚本当前时间前60分钟(开始时间必须大于执行脚本间隔时间)，将 ModTimeTo 设置为当前时间;
    xml += "  <ModTimeFrom>" + timefrom + "<\/ModTimeFrom>";
    xml += "  <ModTimeTo>" + timeto + "<\/ModTimeTo>";


    // If  HasMoreOrders field in the response is true, increment the PageNumber and make the call and iterate through the orders as above.
    xml += ['<Pagination>',
        '    <EntriesPerPage>' + EntriesPerPage + '</EntriesPerPage>',
        '    <PageNumber>' + PageNumber + '</PageNumber>',
        '</Pagination>'].join("");

    // 注释掉这个， 但是我们去 Completed 和Canclled的
    //xml += '  <OrderStatus>Completed</OrderStatus>';

    xml += "  <DetailLevel>ReturnAll<\/DetailLevel>";
    xml += "  <OrderRole>Seller<\/OrderRole>";
    xml += "<\/GetOrdersRequest>";

    //if (DEPLOYMENT_ID == 'customdeploy_sz_sc_ebaygetorders_fix') {
    // 这里的XML 优先级最高
    var SPECIFIC_ORDER_ID = NS_CONTEXT.getSetting("SCRIPT", "custscript_sz_sc_go_orderid");
    if (SPECIFIC_ORDER_ID) {
        xml = getSpecificOrdersXML(token, SPECIFIC_ORDER_ID);
    }
    //}

    //var header = extend(EbayRequest.headers, {
    //    'X-EBAY-API-SITEID': '0', // 0 for US 抓单时候不区分 site 的
    //    'X-EBAY-API-CALL-NAME': 'GetOrders',
    //    'X-EBAY-API-COMPATIBILITY-LEVEL': '911'
    //});

    var header = {
        'X-EBAY-API-APP-NAME': ebay_account.getValue('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
        'X-EBAY-API-DEV-NAME': ebay_account.getValue('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
        'X-EBAY-API-CERT-NAME': ebay_account.getValue('custrecord_ed_cert_name', 'custrecord_ebay_dev_account'),
        'Content-Type': 'application/xml',

        'X-EBAY-API-SITEID': '0', // 0 for US 抓单时候不区分 site 的
        'X-EBAY-API-CALL-NAME': 'GetOrders',
        'X-EBAY-API-COMPATIBILITY-LEVEL': '911'
    };


    //_log_email('GetOrders: request xml', xml);

    _audit('PageNumber: ' + PageNumber + ' GetOrders XML', xml);

    var response = nlapiRequestURL('https://api.ebay.com/ws/api.dll', xml, header);
    var x2js = new X2JS();
    // _log_email('GetOrders: response.getBody()', response.getBody());
    //createTextFile('EbayOderXML', response.getBody());

    var GetOrdersResponse = x2js.xml_str2json(response.getBody());
    //if (SPECIFIC_ORDER_ID)
    //    _log_email('PageNumber: ' + PageNumber + ' GetOrders: REQUEST XML AND RESPONSE FOR JSON', xml + '\r\n' + JSON.stringify(GetOrdersResponse, null, 2));

    refactoryOrdersResponse(GetOrdersResponse.GetOrdersResponse);


    // createTextFile('EbayOrderJSON', JSON.stringify(GetOrdersResponse, null, 2));
    GetOrdersResponse = GetOrdersResponse.GetOrdersResponse;

    exeReport = exeReport || [];
    exeReport.push('PageNumber: ' + PageNumber);
    exeReport.push('ReturnedOrderCountActual: ' + GetOrdersResponse.ReturnedOrderCountActual);

    if (GetOrdersResponse.Ack == 'Success' || GetOrdersResponse.Ack == 'Warning') {

        if (GetOrdersResponse.Ack == 'Warning') {
            _log_email('Ack is warning', JSON.stringify(GetOrdersResponse.Errors))
        }

        if (GetOrdersResponse.ReturnedOrderCountActual != '0') {
            var Order = GetOrdersResponse.OrderArray.Order;

            for (var i = 0; i < Order.length; i++) {

                var _Order = Order[i];
                _log('SRN: -------------------------', _Order.ShippingDetails.SellingManagerSalesRecordNumber);

                try {
                    // element to array
                    _Order.ExternalTransaction = _toarray(_Order.ExternalTransaction);

                    var OrderResult = createEbaySalesOrder(_Order, ebay_account);
                    exeReport.push(ebayAccountName + ' -- OrderID: ' + _Order.OrderID + ' / SRN: ' + _Order.ShippingDetails.SellingManagerSalesRecordNumber + ' ---> OrderID: ' + OrderResult.id + ' --- ' + JSON.stringify(OrderResult));

                } catch (e) {

                    e = parseException(e);
                    nlapiSendEmail(530, 'allan@zakeusa.com', ebayAccountName + ' / ' + e.code + ' - RANGE: ' + timefrom + '-' + timeto, e.message + JSON.stringify(_Order));
                    _log(e.ERROR_CODE, e.message);
                    exeReport.push('ERROR! ' + ebayAccountName + ' -- OrderID: ' + _Order.OrderID + ' / SRN: ' + _Order.ShippingDetails.SellingManagerSalesRecordNumber + ' ---> ' + e.userMessage);

                    // :测试时候先不用
                    createMissingSalesOrder(_Order, e.message);
                }

                checkGovernance();
            }

            _audit('GetOrdersResponse.HasMoreOrders', GetOrdersResponse.HasMoreOrders);
            if (GetOrdersResponse.HasMoreOrders == 'true') {

                _auditUsage();

                // 这里的 return 是退出了， 不再往下执行 否则 NS 是自动往下执行的， SHit！！
                return getEbayOrders(ebay_account, timefrom, timeto, parseInt(GetOrdersResponse.PageNumber) + 1, exeReport);
            }


            // below for testing
            //_log_email('EBAY ORDER REPORT', NS_ORDER_REPORT.join('<br/>'));
            // This is sent to info@zake.com 这个是不知道是什么Email 地址 注释掉
            // nlapiSendEmail(-5, 'allan@zakeusa.com,' + nlapiGetContext().getEmail(), 'NS_ORDER_REPORT: All report', NS_ORDER_REPORT.join('\r\n'));

        } else {
            _audit('ORDER SIZE: 0');
            // _log_email('GetOrders--- 0: responseJSON', JSON.stringify(GetOrdersResponse, null, 2) + '\r\n' + xml);
        }


    } else {
        _log_email(ebayAccountName + ' Ack Error', GetOrdersResponse.Ack + '\r\n' + JSON.stringify(GetOrdersResponse.Errors));
    }

    _log_email(ebayAccountName + ': EBAY ORDER REPORT(' + (exeReport.length - 2 * parseInt(GetOrdersResponse.PageNumber)) + ') ' + timefrom + ' ~ ' + timeto,
        P.end() + '\r\n' + JSON.stringify(exeReport, null, 2));

    // 注意只有正规的配置(或者更多正规的配置)才保存 to file！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
    // if (DEPLOYMENT_ID != 'customdeploy_sz_sc_ebaygetorders_fix') {
    if (['customdeploy_sz_sc_ebaygetorders_fix', 'customdeploy_sz_sc_ebaygetorders_test'].indexOf(DEPLOYMENT_ID) == -1) {
        saveTimeFromFile(timeto);
    }

}

function createMissingSalesOrder(salesOrder, errorMessage) {
    var mso = nlapiCreateRecord('customrecord_missing_sales_order');
    mso.setFieldValue('custrecord_mso_marketplace', MarketplaceShipName.eBay);
    mso.setFieldValue('custrecord_mso_ebay_account', RUNNING_ACCOUNT.EBAY_ACCOUNT_ID);
    mso.setFieldValue('custrecord_mso_id', salesOrder.OrderID);
    mso.setFieldValue('custrecord_mso_subsidiary', Subsidiaries.TaiwuInternational);
    mso.setFieldValue('custrecord_mso_reason', errorMessage);
    mso.setFieldValue('custrecord_mso_info', JSON.stringify(salesOrder));
    return nlapiSubmitRecord(mso);
}

function getSpecificOrdersXML(token, SPECIFIC_ORDER_ID) {

    var xml = '';

    _log('SPECIFIC_ORDER_ID', SPECIFIC_ORDER_ID);
    //var utcDatetime = this.moment().utc();
    xml += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<GetOrdersRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">";
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + token + "<\/eBayAuthToken>";
    xml += "  <\/RequesterCredentials>";

    xml += "  <IncludeFinalValueFee>true</IncludeFinalValueFee>";
    xml += '  <OrderIDArray><OrderID>' + SPECIFIC_ORDER_ID + '</OrderID></OrderIDArray>';

    // DetailLevel
    xml += "  <DetailLevel>ReturnAll<\/DetailLevel>";
    xml += "  <OrderRole>Seller<\/OrderRole>";
    // xml += "  <OrderStatus>Active<\/OrderStatus>";
    xml += "<\/GetOrdersRequest>";

    return xml;
}

//OrderArray.Order
//    .TransactionArray.Transaction
//    .ShippingDetails
//    .ShipmentTrackingDetails	ShipmentTrackingDetailsType	Conditionally,
//    repeatable: [0..*]

/**
 *  Refactory Orders Response
 *  If Conditionally, repeatable: [0..*]
 *  Then make array for this
 * @param GetOrdersResponse
 */
function refactoryOrdersResponse(GetOrdersResponse) {

    // if (GetOrdersResponse.ReturnedOrderCountActual == '0') return; // GetOrdersResponse;

    if (GetOrdersResponse.hasOwnProperty('OrderArray') && GetOrdersResponse.OrderArray.Order) {
        if (!Array.isArray(GetOrdersResponse.OrderArray.Order)) {
            GetOrdersResponse.OrderArray.Order = [GetOrdersResponse.OrderArray.Order];
        }
        GetOrdersResponse.OrderArray.Order.forEach(function (Order) {
            if (!Array.isArray(Order.TransactionArray.Transaction)) {
                Order.TransactionArray.Transaction = [Order.TransactionArray.Transaction];
            }
            if (Order.MonetaryDetails) {
                if (!Array.isArray(Order.MonetaryDetails.Payments.Payment)) {
                    Order.MonetaryDetails.Payments.Payment = [Order.MonetaryDetails.Payments.Payment];
                }
            }
        });
    }

    //return GetOrdersResponse;
}

//function toArray(obj) {
//    if (Array.isArray(obj)) {
//        return obj
//    } else {
//        return [obj];
//    }
//}

// 区别其他的channel 千万不要修改！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
function makeNSEbayID(id) {
    return 'EBAY' + id;
}

function createEbaySalesOrder(Order, ebay_account) {

    _log('ebay_order_OrderStatus', Order.OrderStatus);

    if (Order.OrderStatus == 'Completed') {


        // 这个Check 先去掉， 可能不适用于中国这边的逻辑 - 2016/8/22
        //var createdTime = Order.CreatedTime;
        //createdTime = new Date(createdTime);
        //createdTime = createdTime.format('yyyy/MM/dd');
        //
        //// : need up startTime to global var
        //var startTime = new Date(new Date().getTime() - 3 * 7 * 24 * 60 * 60 * 1000);
        //startTime = startTime.format('yyyy/MM/dd');
        //
        //_log('time range', createdTime + ' --- start from: ' + startTime);
        //
        //if (DateCompare.compare(createdTime, startTime) == -1) {
        //    return {
        //        success: false,
        //        code: 'ORDER_CREATE_TIME_ON_3_WEEKS_AGO',
        //        id: null
        //    };
        //}

        // ------------------------------------------- Check Condition Start -----------------------------------
        // TODO: 通途 -- 这里先注释掉， 为了好测试
        // check if order has been shipped
        // https://ebaydts.com/eBayKBDetails?KBid=5024
        // http://stackoverflow.com/questions/14844391/ebay-trading-api-getorders-check-if-order-is-marked-as-shipped

        if (Order.hasOwnProperty('ShippedTime')) {
            return {
                success: false,
                code: 'ORDER_HAS_BEEN_SHIPPED已经发运了',
                id: null
            };
        }

        var isSomeTrackingDetails = Order.TransactionArray.Transaction.some(function (item) {
            return item.hasOwnProperty('ShippingDetails') && item.ShippingDetails.hasOwnProperty('ShipmentTrackingDetails');
        });
        if (isSomeTrackingDetails) {
            return {
                success: false,
                code: 'isSomeTrackingDetails有发运信息',
                id: null
            };
        }

        if (!Order.hasOwnProperty('MonetaryDetails')) {
            return {
                success: false,
                code: 'PAYMENT_FALSE付钱有问题',
                id: null
            };
        }

        // ------------------------------------------- Check Condition End -----------------------------------

        if (Order.CancelStatus == 'NotApplicable' || Order.CancelStatus == 'CancelRejected') {

            // Check payments status
            var PaymentStatus = Order.MonetaryDetails.Payments.Payment.every(function (Payment) {
                return Payment.PaymentStatus == 'Succeeded';
            });

            //_log('PaymentStatus', PaymentStatus);

            // A CheckoutStatus.eBayPaymentStatus value of 'NoPaymentFailure'
            // and a CheckoutStatus.Status value of 'Complete' indicates that checkout is complete.

            //"CheckoutStatus": {
            //    "eBayPaymentStatus": "PayPalPaymentInProcess",
            //        "LastModifiedTime": "2015-07-15T08:28:38.000Z",
            //        "PaymentMethod": "PayPal",
            //        "Status": "Complete",
            //        "IntegratedMerchantCreditCardEnabled": "false"
            //},


            // In the ExternalTransaction container, the ExternalTransactionID field is the the PayPal TransactionID.
            // You can use this to sync up with the PayPal IPNs, APIs or reports. You need to ensure that you have set the DetailLevel field to ReturnAll when you make the request.

            // https://ebaydts.com/eBayKBDetails?KBid=1788
            // PaidTime
            if (Order.hasOwnProperty('PaidTime') &&
                PaymentStatus == true &&
                Order.CheckoutStatus.eBayPaymentStatus == 'NoPaymentFailure' &&
                Order.CheckoutStatus.Status == 'Complete') {


                // *************** FIRST OF FIRST FOR CHECK!!!!!!!!!! ************************
                var searchExistingOrder = nlapiSearchRecord('salesorder', null, [
                    new nlobjSearchFilter('externalid', null, 'is', makeNSEbayID(Order.OrderID))
                ]);
                if (searchExistingOrder != null) {
                    return {
                        success: true,
                        code: 'EXISTING_SALES_ORDER__NS有这个单了',
                        id: searchExistingOrder[0].getId()
                    };
                }


                //var TransactionArray = toArray(Order.TransactionArray);
                // 取第一个Transaction 就行。
                var Transaction = Order.TransactionArray.Transaction[0];
                var nsCurrency = getNSCurrency(Order);

                // 1, 先建立Customer and address information
                var customerId = saveOrUpdateCustomer(Order, Transaction);

                var customform_id = '313'; // 太武国际 Sales Order - Invoice

                // 2, 然后Place items in order
                var salesOrder = nlapiCreateRecord('salesorder', {
                    recordmode: 'dynamic',
                    customform: customform_id
                });
                salesOrder.setFieldValue('custbody_script_memo', 'Ebay订单下载成功！');

                // var salesOrder = nlapiCreateRecord('salesorder');


                // salesOrder.setFieldValue('customform', customform_id);
                salesOrder.setFieldValue('entity', customerId.id);
                salesOrder.setFieldValue('orderstatus', 'B');


                var _total = Order.Total.__text;
                _total = parseFloat(_total);

                salesOrder.setFieldValue('currency', nsCurrency.INTERNALID);
                var currencyCode = salesOrder.getFieldText('currency');
                if (currencyCode != "USD") {
                    var exchangerate = salesOrder.getFieldValue('exchangerate');
                    exchangerate = parseFloat(exchangerate);
                    var usdTotal = _mathround((exchangerate * _total) / 6.6986);
                    //salesOrder.setFieldValue('custbody_ebay_so_total', usdTotal);
                    salesOrder.setFieldValue('custbody_us_dollar_total', usdTotal);
                } else {
                    salesOrder.setFieldValue('custbody_us_dollar_total', _total);
                }


                salesOrder.setFieldValue('custbody_ebay_currency', Order.Total._currencyID);
                salesOrder.setFieldValue('custbody_ebay_total', Order.Total.__text);


                // custbody_api_data
                salesOrder.setFieldValue('custbody_api_data', JSON.stringify(Order));
                salesOrder.setFieldValue('custbody_linked_ebay_account', RUNNING_ACCOUNT.EBAY_ACCOUNT_ID);

                salesOrder.setFieldValue('custbody_ebay_seller_id', Order.SellerUserID);
                salesOrder.setFieldValue('custbody_ebay_order_status', Order.OrderStatus);

                salesOrder.setFieldValue('custbody_market_ship_serv_lvl', 6); // To Be Determined

                // TODO: externalid---------- Commented if testing 这个是确保唯一性的 NS 原生字段！
                salesOrder.setFieldValue('externalid', makeNSEbayID(Order.OrderID));
                salesOrder.setFieldValue('custbody_ebay_order_id', Order.OrderID);
                salesOrder.setFieldValue('custbody_ebay_buyer_id', Order.BuyerUserID);

                var salesRecordNumber = Order.ShippingDetails.SellingManagerSalesRecordNumber;
                salesOrder.setFieldValue('custbody_ebay_sales_record_number', salesRecordNumber);
                salesOrder.setFieldValue('otherrefnum', ebay_account.getValue('custrecord_ebay_shortname') + '-' + salesRecordNumber);
                salesOrder.setFieldValue('custbody_storefront_order', salesRecordNumber);
                salesOrder.setFieldValue('custbody_storefront', Order.SellerUserID);
                salesOrder.setFieldValue('custbody_marketplace', '3'); // Which for Ebay

                // 中国用 Linked Ebay Account 就得了 中国这个都是统一的， 具体区分看 Linked Ebay Account
                // salesOrder.setFieldValue('custbody_storefront_list', RUNNING_ACCOUNT.STOREFRONT);
                salesOrder.setFieldValue('custbody_storefront_list', 23);

                var shippingService = Order.ShippingServiceSelected.ShippingService;

                //salesOrder.setFieldValue('shipcarrier', 'nonups');
                //salesOrder.setFieldValue('shipmethod', '35170');
                //salesOrder.setFieldValue('shippingcost', 0);

                if (parseFloat(Order.ShippingServiceSelected.ShippingServiceCost.__text)) {
                    salesOrder.setFieldValue('shippingcost', Order.ShippingServiceSelected.ShippingServiceCost.__text);
                } else {
                    salesOrder.setFieldValue('shippingcost', 0);
                }

                //nlapiGetFieldValue('shipcarrier')
                //"nonups"
                salesOrder.setFieldValue('shipcarrier', 'nonups');
                salesOrder.setFieldValue('shipmethod', '66630'); // China TBD

                salesOrder.setFieldValue('custbody_customer_email', customerId.email);


                var itemLocations = [];
                var ebayFee = 0;
                var ebayFeeCurrencyId = '';
                Order.TransactionArray.Transaction.forEach(function (_Transaction, index) {

                    //"FinalValueFee": {
                    //    "_currencyID": "USD",
                    //        "__text": "0.16"
                    //},
                    ebayFeeCurrencyId = _Transaction.FinalValueFee._currencyID;
                    var FinalValueFee = parseFloat(_Transaction.FinalValueFee.__text);
                    ebayFee += FinalValueFee;
                    commitLineItem(salesOrder, _Transaction, Order, itemLocations, index)
                });

                // Ebay fee 我们是一周结算一次
                salesOrder.setFieldValue('custbody_ebay_fee', ebayFee);

                var currencyInternalId = NSCurrencies.find(function (item) {
                    return item.ISOCODE == ebayFeeCurrencyId;
                });
                if (currencyInternalId) {
                    salesOrder.setFieldValue('custbody_ebay_fee_currency', currencyInternalId.INTERNALID);
                } else {
                    _log_email('Fee 货币没有发现', ebayFeeCurrencyId);
                }


                //"ExternalTransaction": [
                //    {
                //        "ExternalTransactionID": "5JV54800826035456",
                //        "ExternalTransactionTime": "2016-08-26T10:52:50.000Z",
                //        "FeeOrCreditAmount": {
                //            "_currencyID": "USD",
                //            "__text": "0.36"
                //        },
                //        "PaymentOrRefundAmount": {
                //            "_currencyID": "USD",
                //            "__text": "1.59"
                //        },
                //        "ExternalTransactionStatus": "Succeeded"
                //    }
                //],

                // 取支付的记录
                var paymentRecords = Order.ExternalTransaction.filter(function (trans) {
                    return parseFloat(trans.PaymentOrRefundAmount.__text) > 0 && trans.ExternalTransactionStatus == 'Succeeded';
                });

                var ppId = paymentRecords.map(function (rec) {
                    return rec.ExternalTransactionID;
                });
                if (ppId.length > 1) {
                    _log_email('PP ID大于一个', JSON.stringify(ppId));
                }
                salesOrder.setFieldValue('custbody_paypal_transaction_id', ppId.join(', ')); // : 这个地方需要注意看到的是 知否只是一个值

                var paypalFee = 0;
                Order.ExternalTransaction.forEach(function (externalTransaction) {
                    paypalFee += parseFloat(externalTransaction.FeeOrCreditAmount.__text);
                });

                paypalFee = _mathround(paypalFee);

                if (paypalFee > 0) {
                    // Payment Line
                    // 80447	 	 	Paypal Fee Charge	 	For Sale
                    // 98475 this for new one
                    salesOrder.selectNewLineItem('item');
                    salesOrder.setCurrentLineItemValue('item', 'item', 102214); // Service Type Item
                    // 这个默认为1
                    //salesOrder.setCurrentLineItemValue('item', 'quantity', _Transaction.QuantityPurchased);

                    salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
                    salesOrder.setCurrentLineItemValue('item', 'rate', '-' + paypalFee);

                    salesOrder.commitLineItem('item');
                }


                if (allTheSame(itemLocations)) {
                    salesOrder.setFieldValue('location', itemLocations[0]);
                } else {
                    salesOrder.setFieldValue('custbody_script_memo', '商品位于不同的仓库， 请人工处理这个订单， 谢谢！');
                    salesOrder.setFieldValue('custbody_has_issues', 'T');
                }

                // :currency -- default is US
                //if (Order.Total._currencyID == 'USD') {
                //    salesOrder.setFieldValue('currency', 1);
                //}

                //var total = salesOrder.getFieldValue('total');
                //if (parseFloat(total) != parseFloat(Order.Total.__text)) {
                //    _log_email('Ebay order total was different', Order.OrderID + ' /// ' + total + ' - ' + Order.Total.__text);
                //}

                var id = nlapiSubmitRecord(salesOrder, true);
                _log('sales order has been created', id);


                return {
                    success: true,
                    code: 'NEW_SALES_ORDER',
                    id: id
                    //cashsale_id: JSON.stringify(cashsale_id)
                };
            } else {
                return {
                    success: false,
                    code: 'PAYMENT_FALSE付钱有问题',
                    id: null
                };
            }
        } else {
            return {
                success: false,
                code: 'CancelStatus_is_not_NotApplicable取消状态不匹配',
                id: null
            };
        }
    } else if (Order.OrderStatus == 'Cancelled') {
        _log_email('Cancelled Ebay Order JSON --Cancelled', JSON.stringify(Order));

        var cancelledSalesOrderSearch = nlapiSearchRecord('salesorder', null, [
            new nlobjSearchFilter('custbody_ebay_order_id', null, 'is', Order.OrderID)
        ], [
            new nlobjSearchColumn('status')
        ]);

        if (cancelledSalesOrderSearch != null) {
            if (cancelledSalesOrderSearch.length == 1) {

                var cancelledSalesOrder = cancelledSalesOrderSearch[0];
                var status = cancelledSalesOrder.getValue('status');
                if (status == 'pendingFulfillment') {

                    var ffSearch = nlapiSearchRecord('itemfulfillment', null, [
                        new nlobjSearchFilter('createdfrom', null, 'is', cancelledSalesOrder.getId()),
                        new nlobjSearchFilter('mainline', null, 'is', 'T')
                    ]);

                    if (ffSearch != null) {
                        ffSearch.forEach(function (ffRec) {
                            nlapiDeleteRecord('itemfulfillment', ffRec.getId())
                        })
                    }

                    _closeSalesOrder(cancelledSalesOrder.getId());

                    return {
                        success: false,
                        code: 'Cancelled____return订单被关闭而且包裹被删除',
                        id: null,
                        OrderStatus: Order.OrderStatus
                    };
                }

            }
        }

        return {
            success: false,
            code: 'Cancelled____return__是Canclled的订单但是NS没有找到',
            id: null,
            OrderStatus: Order.OrderStatus
        };

    } else {
        if (Order.OrderStatus != 'Active') {
            _log_email('Ebay Order JSON with New Status', JSON.stringify(Order));
            return {
                success: false,
                code: '__Unknow___这是啥状态__不知道',
                id: null,
                OrderStatus: Order.OrderStatus
            };
        } else {

            return {
                success: false,
                code: 'Just_Active订单还没有好',
                id: null,
                OrderStatus: Order.OrderStatus
            };
        }

    }


}

function _closeSalesOrder(id) {

    var so = nlapiLoadRecord('salesorder', id);
    var linecount = so.getLineItemCount('item');
    var i = 1;
    for (; i <= linecount; i++) {
        so.setLineItemValue('item', 'isclosed', i, 'T');
    }
    nlapiSubmitRecord(so, true);
    _log('SO ' + id + ' was successfully closed.');

}

// Combo case #311436744982-634012910021
function commitLineItem(salesOrder, _Transaction, ebay_order, itemLocations, index) {


    var sku = null;
    // var ebayItemId = null;

    if (_Transaction.hasOwnProperty('Variation')) {
        sku = _Transaction.Variation.SKU;
        // ebayItemId = Transaction.Variation.ItemID;
    } else {
        sku = _Transaction.Item.SKU;
        // ebayItemId = Transaction.Item.ItemID;
    }

    sku = sku.trim();
    if (sku.indexOf('|') != -1) {
        sku = sku.substring(0, sku.indexOf('|'));
    }

    var iteminfo = searchNetSuiteItem(sku);
    _log('iteminfo', iteminfo);
    if (Array.isArray(iteminfo)) {
        iteminfo.forEach(function (iteminfo) {
            itemLocations.push(iteminfo.location);
        });
    } else {
        itemLocations.push(iteminfo.location);
    }


    // --------------- start -----------------
    if (Array.isArray(iteminfo)) { // from dictionary
        // 递归！
        iteminfo.forEach(function (_item, comboIndex) {

            salesOrder.selectNewLineItem('item');

            salesOrder.setCurrentLineItemValue('item', 'item', _item.id);
            salesOrder.setCurrentLineItemValue('item', 'location', _item.location);
            salesOrder.setCurrentLineItemValue('item', 'quantity', parseInt(_Transaction.QuantityPurchased) * parseInt(_item.qty));

            salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level

            if (comboIndex === 0) { // TODO: 这个需要加上 每个产品的价格多少！！如果Kit 记录上面有的话
                salesOrder.setCurrentLineItemValue('item', 'rate', parseFloat(_Transaction.TransactionPrice.__text) / (parseInt(_Transaction.QuantityPurchased) * parseInt(_item.qty)));
            } else {
                salesOrder.setCurrentLineItemValue('item', 'rate', 0);
            }


            _commitLineItem(salesOrder, _Transaction, ebay_order);
            salesOrder.commitLineItem('item');
        });

    }

    //else if (iteminfo.hasOwnProperty('qty')) { // from dictionary
    //    salesOrder.selectNewLineItem('item');
    //    salesOrder.setCurrentLineItemValue('item', 'item', iteminfo.id);
    //    salesOrder.setCurrentLineItemValue('item', 'location', iteminfo.location);
    //    salesOrder.setCurrentLineItemValue('item', 'quantity', parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty));
    //    salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
    //    salesOrder.setCurrentLineItemValue('item', 'rate', parseFloat(_Transaction.TransactionPrice.__text) / (parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty)));
    //    _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
    //    salesOrder.commitLineItem('item');
    //
    //}

    else {

        salesOrder.selectNewLineItem('item');

        salesOrder.setCurrentLineItemValue('item', 'item', iteminfo.id);
        salesOrder.setCurrentLineItemValue('item', 'location', iteminfo.location);
        salesOrder.setCurrentLineItemValue('item', 'quantity', _Transaction.QuantityPurchased);

        // 当开启 Dynamic 的时候 这里的 Item 添加 属性的先后顺序也是有讲究的， 太牛了。。
        salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
        salesOrder.setCurrentLineItemValue('item', 'rate', _Transaction.TransactionPrice.__text);

        _commitLineItem(salesOrder, _Transaction, ebay_order);
        salesOrder.commitLineItem('item');

    }
    // --------------- end -------------------


}

function _commitLineItem(salesOrder, _Transaction, ebay_order) {

    // 如果Customer no taxable
    // 这里就不用设置taxcode inline 了


    //"ShippingAddress": {
    //    "Name": "Donald Watkins",
    //        "Street1": "622 Woods Crossing Ln",
    //        "Street2": "",
    //        "CityName": "Indianapolis",
    //        "StateOrProvince": "IN",
    //        "Country": "US",
    //        "CountryName": "United States",
    //        "Phone": "317 701 0541",
    //        "PostalCode": "46239-2162",
    //        "AddressID": "530188146024",
    //        "AddressOwner": "eBay",
    //        "ExternalAddressID": ""
    //},

    //_log('ebay_order.ShippingAddress', ebay_order.ShippingAddress);
    //
    //if (ebay_order.ShippingAddress.Country == 'US' && ebay_order.ShippingAddress.StateOrProvince == 'IN') {
    //    salesOrder.setCurrentLineItemValue('item', 'taxcode', '-8');        // "-8" for -Not Taxable-
    //} else {
    //
    //    // 42569 UNDEF_CN for 0%
    //    salesOrder.setCurrentLineItemValue('item', 'taxcode', 42569);
    //}


    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_item_id', _Transaction.Item.ItemID);

    _log('Order.ShippingDetails.SalesTax.SalesTaxState', ebay_order.ShippingDetails.SalesTax.SalesTaxState);


    //else {
    //    salesOrder.setCurrentLineItemValue('item', 'texcode', -7);
    //}

    // paypal transaction id
    // salesOrder.setCurrentLineItemValue('item', 'custcol_payment_transaction_id', Order.MonetaryDetails.Payments.Payment[index].ReferenceID.__text);
    salesOrder.setCurrentLineItemValue('item', 'custcol_payment_transaction_id', ebay_order.ExternalTransaction.ExternalTransactionID);

    // custcol_ebay_transaction_id
    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_transaction_id', _Transaction.TransactionID);
    // custcol_ebay_transaction_site_id
    salesOrder.setCurrentLineItemValue('item', 'custcol_ebay_transaction_site_id', _Transaction.TransactionSiteID);
    // custcol_ebay_item_sku
    salesOrder.setCurrentLineItemValue('item', 'custcol_sellersku', _Transaction.Item.SKU);

}


//function getNetSuiteItemInfo(sku) {
//
//
//}


function searchNetSuiteItem(sku, onlyInventoryItemTag) {

    // : http://stackoverflow.com/questions/5915096/get-random-item-from-javascript-array
    // :: for test
    //var item = SZ_TEST_ITEMS[Math.floor(Math.random() * SZ_TEST_ITEMS.length)];
    //return {
    //    id: item,
    //    location: 34 // 34 Shenzhen YMW 深圳杨美仓库
    //};

    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');
    columns[1] = new nlobjSearchColumn('itemid');
    columns[2] = new nlobjSearchColumn('description');
    columns[3] = new nlobjSearchColumn('preferredlocation');

    // location
    columns[4] = new nlobjSearchColumn('location');

    var search = nlapiSearchRecord('item', null, [
        ['subsidiary', 'is', Subsidiaries.TaiwuInternational],
        'AND',
        [
            ['name', 'is', sku],
            'OR',
            ['custitem_legacy_tong_sku', 'is', sku]
        ]
    ], columns);

    if (search != null) {

        if (search.length == 1) {
            _log('search1 got result');
            return {
                id: search[0].getId(),
                location: search[0].getValue('location')
            }
        } else {
            throw createEbayError('Item search result size wrong! SKU: ' + sku + ' and search size: ' + search.length);
        }

    } else {  // custitem_sku_alias

        var search = nlapiSearchRecord('item', null, [
            new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
            new nlobjSearchFilter('custitem_sku_alias', null, 'contains', sku),
            new nlobjSearchFilter('matrix', null, 'is', 'F')
        ], columns);

        if (search != null) {

            if (search.length == 1) {

                _log('search2 got result');
                return {
                    id: search[0].getId(),
                    location: search[0].getValue('location')
                }
            } else {
                throw createEbayError('Item search result size wrong! SKU: ' + sku + ' and search size: ' + search.length);
            }

        } else {

            if (!onlyInventoryItemTag) {

                _log('search3 got result');
                return searchKitItem(sku);
            }


        }

    }

}

function searchKitItem(kitSku) {

    var kitSearch = nlapiSearchRecord('customrecord_kit', null, [
        ['externalid', 'is', kitSku],
        'AND',
        [
            ['custrecord_kit_sku', 'is', kitSku],
            'OR',
            ['custrecord_sku_alias', 'contains', kitSku]
        ]
    ], [
        new nlobjSearchColumn('custrecord_kit_mapping')
    ]);

    //00328=3
    //00816=1;00819=1

    if (kitSearch != null) {
        if (kitSearch.length == 1) {
            var kitMapping = kitSearch[0].getValue('custrecord_kit_mapping');
            kitMapping = kitMapping.split(';');

            var itemResult = [];
            for (var i = 0; i < kitMapping.length; i++) {
                var mapping = kitMapping[i];
                var subSKU = mapping.substring(0, mapping.indexOf('='));
                var qty = parseInt(mapping.substring(mapping.indexOf('=') + 1));

                var item = searchNetSuiteItem(subSKU, true);
                item.qty = qty;

                itemResult.push(item);

            }

            return itemResult;

        } else {
            throw createEbayError('kitSearch: search result size wrong! SKU: ' + kitSku + ' and search size: ' + kitSearch.length);
        }
    } else {

        throw createEbayError('kitSearch: No ' + kitSku + ' SKU on NetSuite for Shezhen subsidiary.');
    }

}

function GetSellingManagerSaleRecordRequest(orderId) {
    _audit('GetSellingManagerSaleRecordRequest', orderId);
    var xml = ['<?xml version="1.0" encoding="utf-8"?>',
        '<GetSellingManagerSaleRecordRequest xmlns="urn:ebay:apis:eBLBaseComponents">',
        '  <RequesterCredentials>',
        '        <eBayAuthToken>' + RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN + '</eBayAuthToken>',
        '  </RequesterCredentials>',
        '  <OrderID>' + orderId + '</OrderID>',
        '</GetSellingManagerSaleRecordRequest>'].join("");

    var response = nlapiRequestURL('https://api.ebay.com/ws/api.dll', xml, extend(EbayRequest.headers, {
        'X-EBAY-API-SITEID': '0',
        'X-EBAY-API-CALL-NAME': 'GetSellingManagerSaleRecord',
        'X-EBAY-API-COMPATIBILITY-LEVEL': '945'
    }));

    response = new X2JS().xml_str2json(response.getBody());
    _log_email('GetSellingManagerSaleRecordRequest', JSON.stringify(response));

    return response.GetSellingManagerSaleRecordResponse.SellingManagerSoldOrder.BuyerEmail;
}

function isValidEmailAddress(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}

function getCustomerEmail(Transaction, orderId) {

    // : 都是要归到 主Email中
    var Email = Transaction.Buyer.Email;
    var EbayMemberEmail = Transaction.Buyer.StaticAlias;

    //if (isValidEmailAddress(Email)) {
    //    return Email;
    //}

    //
    //Why do I get "Invalid Request" for the Buyer Email in the GetItemTransactions, GetOrders, GetSellerTransactions, GetOrderTransactions & GetItem response?
    //    Summary
    //
    //    GetItemTransactions, GetOrders, GetOrderTransactions, GetSellerTransactions & GetItem returns
    // the Buyer Email Intermediation address (ie buyername@members.ebay.com) only if all of the following are true:
    //The caller is in a transactional relationship for the item
    //The call is being executed within a certain amount of time after the transaction is created.  Based on Trust and Safety policies, the time is unspecified and can vary by site.
    //
    //    As a best practice, we recommend that you make the transaction calls within a day so that you have all the updated information.  For instance, make a call to GetSellerTransactions every day with the ModTimeFilter set to the last time you made the call to the current time.  If you get information about transactions individually via GetItemTransactions, then make the call as soon as you get the notification about the sale.

    //"Buyer": {
    //    "Email": "Invalid Request",
    //        "StaticAlias": "punkhe_hsib5727tbz@members.ebay.co.uk",
    //        "UserFirstName": "danny",
    //        "UserLastName": "peters"
    //},

    if (Email && Email != 'Invalid Request') {
        return Email;
    }
    // else if (isValidEmailAddress(EbayMemberEmail)) {
    else if (EbayMemberEmail) {
        //_audit('EbayMemberEmail', EbayMemberEmail);
        return EbayMemberEmail;
    }
    else {
        var responseEmail = GetSellingManagerSaleRecordRequest(orderId);
        if (isValidEmailAddress(responseEmail)) {
            return responseEmail;
        } else {
            return '';
            //throw createEbayError('No customer email found and return NULL...');
        }
    }
}


function createCustomerRecord(Order, Transaction, _ShippingAddress, _BillingAddress, _email) {

    _log('New for customer');
    var newCustomerRecord = nlapiCreateRecord('customer');

    // https://system.sandbox.netsuite.com/app/common/entity/custjob.nl?id=1768250&scrollid=1768250&whence=&cmid=1466410720236 for currency

    //if (Transaction.TransactionSiteID == 'US') {
    //
    //    // https://system.na1.netsuite.com/app/common/multicurrency/currencylist.nl?whence=
    //    // NS Currency Internal ID
    //    //1	USD	USD	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
    //    //2	GBP	GBP	No	No	Yes
    //    //3	CAD	CAD	No	No	Yes
    //    //4	EUR	EUR	No	No	Yes
    //    //5	CNY	CNY	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
    //    //6	AUD	AUD	No	No	Yes
    //    //7	HKD	HKD	No	No	Yes
    //    //8	INR	INR	No	No	Yes
    //    //9	MYR	MYR	No	No	Yes
    //    //10	PHP	PHP	No	No	Yes
    //    //11	PLN	PLN	No	No	Yes
    //    //12	RUB	RUB	No	No	Yes
    //    //13	SGD	SGD	No	No	Yes
    //    //14	CHF	CHF	No	No	Yes
    //    //15	JPY	JPY	No	No	Yes
    //
    //    newCustomerRecord.setFieldValue('currency', 1);
    //}

    newCustomerRecord.setFieldValue('currency', 5); // 这里总是人民币

    var nsCurrency = getNSCurrency(Order);
    newCustomerRecord.selectNewLineItem('currency');
    newCustomerRecord.setCurrentLineItemValue('currency', 'currency', nsCurrency.INTERNALID);
    newCustomerRecord.commitLineItem('currency');


    newCustomerRecord.setFieldValue('subsidiary', RUNNING_ACCOUNT.SUBSIDIARY);
    newCustomerRecord.setFieldValue('isperson', 'T');

    if (Transaction.Buyer.UserFirstName) {
        newCustomerRecord.setFieldValue('firstname', Transaction.Buyer.UserFirstName);
    } else {
        newCustomerRecord.setFieldValue('firstname', '*');
    }

    newCustomerRecord.setFieldValue('lastname', Transaction.Buyer.UserLastName);
    newCustomerRecord.setFieldValue('phone', _ShippingAddress.phone);
    // taxable
    newCustomerRecord.setFieldValue('taxable', 'F');
    //if (usedMainEmailFlag) {
    //    customerRecord.setFieldValue('email', Email);
    //} else {
    //    customerRecord.setFieldValue('custentity_ebay_member_email', EbayMemberEmail);
    //}
    if (_email) newCustomerRecord.setFieldValue('email', _email);

    if (_BillingAddress == null) {
        setAddressLine(newCustomerRecord, _ShippingAddress);
    } else {
        // 不用对比了， 发到国外的肯定这2个Address 是不一样的！
        setAddressLine(newCustomerRecord, _ShippingAddress, 'defaultshipping');
        setAddressLine(newCustomerRecord, _BillingAddress, 'defaultbilling');
    }


    return nlapiSubmitRecord(newCustomerRecord, true);

    // customerRecord = nlapiLoadRecord('customer');
    // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
    // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));

}

// http://www.ebay.com/gds/Shipping-to-APO-AE-/10000000013943736/g.html
function _processCountryCode(countryCode) {
    if (countryCode == 'AA') {
        // AA for Armed Forces Americas,
        return 'US';
    }
    return countryCode;
}
//
//"Total": {
//    "_currencyID": "GBP",
//        "__text": "2.65"
//},
function getNSCurrency(Order) {
    var nsCurrency = NSCurrencies.find(function (item) {
        return Order.Total._currencyID == item.ISOCODE;
    });
    if (!nsCurrency) {
        throw createEbayError('No found this country currency ' + Order.TransactionSiteID)
    }

    return nsCurrency;
}

function saveOrUpdateCustomer(Order, Transaction) {

    var SUBSIDIARY = RUNNING_ACCOUNT.SUBSIDIARY;

    var ShippingAddress = Order.ShippingAddress;
    var _ShippingAddress = {
        "country": _processCountryCode(ShippingAddress.Country),
        "state": ShippingAddress.StateOrProvince,
        "city": ShippingAddress.CityName,
        "addr1": ShippingAddress.Street1,
        "addr2": ShippingAddress.Street2,
        "addressee": ShippingAddress.Name,
        "zip": ShippingAddress.PostalCode,
        "phone": ShippingAddress.Phone || Order.ShippingAddress.Phone || ''
    };
    var _BillingAddress = null;

    if (Order.IsMultiLegShipping == 'true') {
        _BillingAddress = _ShippingAddress;
        var logisticAddress = Order.MultiLegShippingDetails.SellerShipmentToLogisticsProvider.ShipToAddress;
        _ShippingAddress = {
            "country": _processCountryCode(logisticAddress.Country),
            "state": logisticAddress.StateOrProvince,
            "city": logisticAddress.CityName,
            "addr1": logisticAddress.Street1,
            "addr2": logisticAddress.Street2 || '',
            "addressee": logisticAddress.ReferenceID,
            "zip": logisticAddress.PostalCode,
            "phone": ShippingAddress.Phone || Order.ShippingAddress.Phone || ''
        };
    }

    var _email = getCustomerEmail(Transaction, Order.OrderID);

    var id = null;

    if (_email) {

        var filter = [
            new nlobjSearchFilter('isinactive', null, 'is', 'F')
        ];
        filter.push(new nlobjSearchFilter('email', null, 'is', _email));
        filter.push(new nlobjSearchFilter('subsidiary', null, 'is', SUBSIDIARY));

        var customerSearch = nlapiSearchRecord('customer', null, filter);

        if (customerSearch == null) { // New

            id = createCustomerRecord(Order, Transaction, _ShippingAddress, _BillingAddress, _email);

        } else { // Update

            _log("Update for the customer", _email);

            var customerId = customerSearch[0].getId();
            var existingCustomerRecord = nlapiLoadRecord('customer', customerId);

            //if (Transaction.TransactionSiteID == 'US') {
            //    // USD
            //
            //    //1	USD	USD	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
            //    //2	GBP	GBP	No	No	Yes
            //    //3	CAD	CAD	No	No	Yes
            //    //4	EUR	EUR	No	No	Yes
            //    //5	CNY	CNY	Yes	No	Yes	(GMT-05:00) Eastern Time (US & Canada)
            //    //6	AUD	AUD	No	No	Yes
            //    //7	HKD	HKD	No	No	Yes
            //    //8	INR	INR	No	No	Yes
            //    //9	MYR	MYR	No	No	Yes
            //    //10	PHP	PHP	No	No	Yes
            //    //11	PLN	PLN	No	No	Yes
            //    //12	RUB	RUB	No	No	Yes
            //    //13	SGD	SGD	No	No	Yes
            //    //14	CHF	CHF	No	No	Yes
            //    //15	JPY	JPY	No	No	Yes
            //
            //    existingCustomerRecord.setFieldValue('currency', 1);
            //}
            existingCustomerRecord.setFieldValue('currency', 5); // 这里总是人民币

            var nsCurrency = getNSCurrency(Order);

            var addFlag = true;
            var currencyLineCount = existingCustomerRecord.getLineItemCount('currency');
            for (var line = 1; line <= currencyLineCount; line++) {
                var cur = existingCustomerRecord.getLineItemValue('currency', 'currency', line);
                if (cur == nsCurrency.INTERNALID) {
                    addFlag = false;
                    break;
                }
            }
            if (addFlag) {
                existingCustomerRecord.selectNewLineItem('currency');
                existingCustomerRecord.setCurrentLineItemValue('currency', 'currency', nsCurrency.INTERNALID);
                existingCustomerRecord.commitLineItem('currency');
            }

            if (_BillingAddress == null) {

                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log('Set new address _ShippingAddress for existing customer');
                    setAddressLine(existingCustomerRecord, _ShippingAddress);
                } else {
                    existingCustomerRecord.setLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber, 'T');
                    existingCustomerRecord.setLineItemValue('addressbook', 'defaultbilling', existingShippingAddress.linenumber, 'T');
                }
            } else {

                // 因为是 发往国外的 ， 这里 bill Address 和ship Address 肯定是不一样， 否则参考 Noure script

                // Billing address
                var existingBillingAddress = lookupExistingAddress(existingCustomerRecord, _BillingAddress);
                if (existingBillingAddress.addressId == null) {
                    _log('Set new address _BillingAddress for existing customer');
                    setAddressLine(existingCustomerRecord, _BillingAddress, 'defaultbilling');
                } else {
                    if (existingCustomerRecord.getLineItemValue('addressbook', 'defaultbilling', existingBillingAddress.linenumber) !== 'T') {
                        existingCustomerRecord.setLineItemValue('addressbook', 'defaultbilling', existingBillingAddress.linenumber, 'T');
                    }
                }

                // Shipping address
                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log('Set new address existingShippingAddress2222 for existing customer');
                    setAddressLine(existingCustomerRecord, _ShippingAddress, 'defaultshipping');
                } else {
                    if (existingCustomerRecord.getLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber) !== 'T') {
                        existingCustomerRecord.setLineItemValue('addressbook', 'defaultshipping', existingShippingAddress.linenumber, 'T');
                    }
                }
            }

            existingCustomerRecord.setFieldValue('isperson', 'T');
            existingCustomerRecord.setFieldValue('firstname', Transaction.Buyer.UserFirstName);
            existingCustomerRecord.setFieldValue('lastname', Transaction.Buyer.UserLastName);

            if (existingCustomerRecord.getFieldValue('phone') && ShippingAddress.Phone != existingCustomerRecord.getFieldValue('phone')) {
                existingCustomerRecord.setFieldValue('altphone', existingCustomerRecord.getFieldValue('phone'));
                existingCustomerRecord.setFieldValue('phone', ShippingAddress.Phone);
            } else {
                existingCustomerRecord.setFieldValue('phone', ShippingAddress.Phone);
            }

            existingCustomerRecord.setFieldValue('taxable', 'F');
            id = nlapiSubmitRecord(existingCustomerRecord, true);

            // customerRecord = nlapiLoadRecord('customer');
            // 其实这里不用硬设置进去， 已经是Default address NS会自动带入
            // var currentOrderAddressId = customerRecord.getLineItemValue('addressbook', 'id', customerRecord.getLineItemCount('addressbook'));
        }
    } else {

        nlapiSendEmail(530, 'allan@zakeusa.com', '[EBAY_ORDER_NOTIES] ID:' + Order.OrderID, 'THE ORDER NO EMAIL.' + JSON.stringify(Order));
        id = createCustomerRecord(Order, Transaction, ShippingAddress, _ShippingAddress, _email);
    }

    return {
        id: id,
        email: _email
    };

}

//function setAddressLine(customer, addressObject, defaultField) {
//    customer.selectNewLineItem('addressbook');
//
//    for (var name in addressObject) {
//        customer.setCurrentLineItemValue('addressbook', name, addressObject[name]);
//    }
//
//    if (defaultField) customer.setCurrentLineItemValue('addressbook', defaultField, 'T');
//
//    customer.commitLineItem('addressbook');
//}
function setAddressLine(customer, addressObject, specificField) {
    customer.selectNewLineItem('addressbook');

    for (var name in addressObject) {
        customer.setCurrentLineItemValue('addressbook', name, addressObject[name]);
    }

    if (specificField) {
        customer.setCurrentLineItemValue('addressbook', specificField, 'T');
    } else {
        customer.setCurrentLineItemValue('addressbook', 'defaultshipping', 'T');
        customer.setCurrentLineItemValue('addressbook', 'defaultbilling', 'T');
    }

    customer.commitLineItem('addressbook');
}

function lookupExistingAddress(customer, addressObject /*, defaultField */) {

    var addressId = null;
    var linenumber = null;

    var lineCount = customer.getLineItemCount('addressbook');
    if (lineCount) {
        for (var line = 1; line <= lineCount; line++) {

            var address = {
                'country': customer.getLineItemValue('addressbook', 'country', line),
                'state': customer.getLineItemValue('addressbook', 'state', line),
                'city': customer.getLineItemValue('addressbook', 'city', line),
                'zip': customer.getLineItemValue('addressbook', 'zip', line),
                'addressee': customer.getLineItemValue('addressbook', 'addressee', line),
                'addr1': customer.getLineItemValue('addressbook', 'addr1', line),
                'addr2': customer.getLineItemValue('addressbook', 'addr2', line),
                'phone': customer.getLineItemValue('addressbook', 'phone', line)
            };

            if (exactlySame(address, addressObject)) {

                addressId = customer.getLineItemValue('addressbook', 'id', line);
                linenumber = line;

                // : 这段基本没啥用， 准备remove呢
                //if (defaultField) {
                //    if (customer.getLineItemValue('addressbook', defaultField, line) !== 'T') {
                //        customer.setLineItemValue('addressbook', defaultField, line, 'T');
                //        // nlapiSubmitRecord(customer, true);
                //    }
                //}

                break;
            }
        }
    }


    return {
        addressId: addressId,
        linenumber: linenumber
    };

}

function _fieldProcess(key, value) {
    if (key == 'phone') {
        return trimPhone(value);
    } else {
        if (!value) value = '';
        return value;
    }
}

function exactlySame(address, orderAddress) {

    for (var key in address) {

        var field1 = address[key];
        field1 = _fieldProcess(key, field1);

        if (orderAddress.hasOwnProperty(key)) {
            var field2 = orderAddress[key];
            field2 = _fieldProcess(key, field2);

            if (field1 !== field2) {
                _log('different in ' + key);
                return false;
            }

        } else {

            _log('Not in ' + key);
            return false;
        }
    }

    return true;

}

function trimPhone(phone) {
    if (!phone) {
        phone = '';
    }

    if (typeof phone !== 'string') phone = phone.toString();

    var regx = new RegExp('[^0-9]', 'g');
    phone = phone.replace(regx, '');

    return phone;

}