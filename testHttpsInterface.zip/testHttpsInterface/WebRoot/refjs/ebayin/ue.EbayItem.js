function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var ITEM_OPTIONS = [ [ "custitem_var_color", "Colors" ], [ "custitem_var_size", "Sizes" ], [ "custitem_womens_size", "Womens Size" ], [ "custitem_watch_deisgn", "Watch Design" ], [ "custitem_var_assortment", "Assortment" ], [ "custitem_var_bag_pattern", "Bag Pattern" ], [ "custitem_child_size", "Child Size" ], [ "custitem_var_color_temp", "Color Temp" ], [ "custitem_var_compatible_with", "Compatible With" ], [ "custitem_var_legging_design", "Legging Design" ], [ "custitem_var_mens_size", "Mens Size" ], [ "custitem_var_print_design", "Print Design" ], [ "custitem_var_shape", "Shape" ], [ "custitem_var_style", "Style" ], [ "custitem_var_womens_shoe_size", "Shoe Size" ], [ "custitem_var_mens_pant_size", "Mens Pant Size" ], [ "custitem_var_bra_size", "Bra Size" ], [ "custitem_var_child_shoe_size", "Child Shoe Size" ], [ "custitem_var_mens_shoe_size", "Mens Shoe Size" ], [ "custitem_var_amps", "AMPS" ], [ "custitem_zake_option2", "Number" ], [ "custitem_zake_other", "Letter" ] ];

function isMatrixItem(item__internalid) {
    var ismatrix = false;
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
    if (testSearch != null) ismatrix = true;
    return ismatrix;
}

function getItemType(id) {
    return nlapiLookupField("item", id, "type");
}

function isKitItem(id) {
    return getItemType(id) == "Kit";
}

function EbayItem(type, id) {
    this.id = id;
    this.pictureSearch = null;
    Record.call(this, type, id);
}

EbayItem.TYPE = {
    INVENTORY_ITEM: "inventoryitem",
    KIT_ITEM: "kititem"
};

inherit(Record, EbayItem);

EbayItem.prototype.extend({
    getPictureSearch: function() {
        if (this.pictureSearch == null) {
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", [ this.id ]) ], [ new nlobjSearchColumn("custitem_ebay_gallery_pictures"), new nlobjSearchColumn("custitem_ebay_body_pictures") ]);
            var pictureSearch = {
                gallery: [],
                bodyPicture: []
            };
            if (search != null) {
                if (search[0].getValue("custitem_ebay_gallery_pictures")) {
                    pictureSearch.gallery = JSON.parse(search[0].getValue("custitem_ebay_gallery_pictures"));
                } else {
                    pictureSearch.gallery = [];
                }
                if (search[0].getValue("custitem_ebay_body_pictures")) {
                    pictureSearch.bodyPicture = JSON.parse(search[0].getValue("custitem_ebay_body_pictures"));
                } else {
                    pictureSearch.bodyPicture = [];
                }
            }
            this.pictureSearch = pictureSearch;
            return pictureSearch;
        } else {
            return this.pictureSearch;
        }
    },
    getGalleryPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.gallery;
    },
    getBodyPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.bodyPicture;
    }
});

function EbayInventoryItem(id, ismatrix) {
    EbayItem.call(this, "inventoryitem", id);
}

inherit(EbayItem, EbayInventoryItem);

EbayInventoryItem.prototype.getField = function(name) {
    var record = this.rec;
    return {
        name: name,
        value: record.getFieldValue(name),
        text: record.getFieldText(name)
    };
};

EbayInventoryItem.prototype._ismatrix = function() {
    return this.ismatrix == "T";
};

EbayInventoryItem.prototype.getLocationQuantity = function() {
    return this.getSubList("locations", [ "location", "location_display", "quantityavailable" ]);
};

EbayInventoryItem.prototype.getAvailableOptions = function(langCode) {
    var parentRecord = this;
    var availOptions = ITEM_OPTIONS.map(function(o) {
        if (langCode && langCode == "EN") {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: o[1]
            });
        } else {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: ""
            });
        }
    }).filter(function(item) {
        return item.value;
    });
    availOptions.forEach(function(item) {
        item.value = item.value.split("");
        item.text = item.text.split("");
        item.options = item.value.map(function(v, i) {
            if (langCode && langCode == "EN") {
                return {
                    id: v,
                    value: item.text[i],
                    translation: item.text[i]
                };
            } else {
                return {
                    id: v,
                    value: item.text[i],
                    translation: ""
                };
            }
        });
        delete item.value;
        delete item.text;
    });
    return availOptions;
};

EbayInventoryItem.prototype.getChildRecord = function() {
    var parentRecord = this;
    var availOptions = this.getAvailableOptions();
    var matrixOptionsColumns = availOptions.map(function(option) {
        return new nlobjSearchColumn(option.name).setLabel(option.label);
    });
    var columns = [ new nlobjSearchColumn("itemid"), new nlobjSearchColumn("upccode"), new nlobjSearchColumn("custitem_item_picture"), new nlobjSearchColumn("custitem_item_var_picture") ];
    columns = columns.concat(matrixOptionsColumns);
    var itemChildRecordSearchResults = nlapiSearchRecord("inventoryitem", null, [ new nlobjSearchFilter("parent", null, "is", parentRecord.getId()), new nlobjSearchFilter("isinactive", null, "is", "F") ], columns);
    var searchList = [];
    if (itemChildRecordSearchResults != null) {
        for (var i = 0, len = itemChildRecordSearchResults.length; i < len; i++) {
            var childRecord = itemChildRecordSearchResults[i];
            var record = {};
            record["__id"] = childRecord.getId();
            record["__type"] = childRecord.getRecordType();
            var options = [];
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var label = column.getLabel();
                var value = childRecord.getValue(column);
                var text = childRecord.getText(column);
                if (value && text) {
                    var optionName = availOptions.filter(function(item) {
                        return item.name == name;
                    });
                    if (optionName.length && optionName.length == 1) {
                        optionName = optionName[0];
                        options.push({
                            label: {
                                name: optionName.name,
                                label: optionName.label,
                                translation: optionName.translation
                            },
                            option: {
                                name: name,
                                value: value,
                                text: text,
                                translation: ""
                            }
                        });
                    } else {
                        record[name] = {
                            value: value,
                            text: text
                        };
                    }
                } else {
                    if (name == "itemid") {
                        if (value.indexOf(" : ") != -1) value = value.substring(value.indexOf(" : ") + 3);
                    }
                    record[name] = value;
                }
            }
            record.options = options;
            searchList.push(record);
        }
    }
    return searchList;
};

EbayInventoryItem.getAvailableOptions = function(parentId, langCode) {
    return new EbayInventoryItem(parentId).getAvailableOptions(langCode);
};

function EbayKitItem(id) {
    EbayItem.call(this, "kititem", id);
}

inherit(EbayItem, EbayKitItem);

EbayKitItem.prototype.getOption = function() {
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var name = "custitem_var_kit";
    var value = [];
    var text = [];
    var options = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        var var_name = line[3].trim();
        index++;
        value.push(id + "_" + index);
        text.push(var_name);
        return {
            id: id + "_" + index,
            value: var_name,
            translation: ""
        };
    });
    return {
        availOptions: [ {
            name: name,
            value: value,
            text: text,
            label: "Kit Variation",
            translation: "",
            options: options
        } ]
    };
};

function getVariationQuantity(id_expression, mainLocation) {
    id_expression = id_expression.map(function(id) {
        var qtyIndex = id.indexOf("*");
        if (qtyIndex != -1) {
            return {
                _id: id.substring(0, qtyIndex),
                _qty: id.substring(qtyIndex + 1)
            };
        } else {
            return {
                _id: id,
                _qty: "1"
            };
        }
    });
    var columns = [];
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", id_expression.map(function(item) {
        return item._id;
    })), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ mainLocation ]) ], columns);
    var list = [];
    if (search != null) {
        search.forEach(function(searchResult, index) {
            var total = searchResult.getValue("formulanumeric");
            _log("total" + index, total);
            if (total) {
                _log("searchResult.getId()", searchResult.getId());
                _log("id_expression", id_expression);
                var qty = id_expression.filter(function(item) {
                    return item._id == searchResult.getId();
                })[0]._qty;
                list.push(Math.floor(parseInt(total) / parseInt(qty)));
            }
        });
    } else {
        return 0;
    }
    _log("getVariationQuantity: " + JSON.stringify(id_expression), list);
    if (list.length) {
        var qty = _.min(list);
        if (!qty) qty = 0;
        _log(typeof qty, qty);
        return qty;
    } else {
        return 0;
    }
}

EbayKitItem.prototype.getChildRecord = function() {
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var childRecordList = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        index++;
        var line_id = line[0].trim();
        var line_sku = line[1].trim();
        var kit_var_id = line_id.replace(/\,/g, "^").replace(/\s/g, "");
        return {
            __id: kit_var_id,
            __type: "KIT_INV",
            itemid: kit_var_id,
            baseprice: line[2].trim(),
            custitem_ebay_variation_picture: "",
            custitem_var_kit: {
                value: id + "_" + index,
                text: line[3].trim(),
                translation: ""
            },
            locationquantityavailable: getVariationQuantity(line_id.split(",").map(function(id) {
                return id.trim();
            }), mainLocation)
        };
    });
    _log("EbayKitItem.prototype.getChildRecord", childRecordList);
    return {
        childRecordList: childRecordList
    };
};

function beforeLoad(type, form, request) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        nlapiLogExecution("debug", "beforeLoad____________ id: " + id, "recType: " + recType + " type: " + type);
        if (type == "view") {
            if (recType == "inventoryitem") {
                form.setScript("customscript_ebay_item_client");
                form.addButton("custpage_print_label", "Print Item Label", "printItemLabel");
                var parent = nlapiGetFieldValue("parent");
                if (!parent) {
                    form.addButton("custpage_new_ebay_feeds", "Submit Ebay Feeds", "newFeeds");
                    form.addButton("custpage_view_ebay_feeds", "View Ebay Feeds", "viewFeeds");
                }
            }
        }
        nlapiLogExecution("debug", "beforeLoad____________end");
    } catch (e) {
        processException(e, "beforeLoad" + id);
    }
}

function beforeSubmit(type) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        if (recType == "inventoryitem" || recType == "kititem") {}
    } catch (e) {
        processException(e, "beforeSubmit" + id);
    }
}

function afterSubmit(type) {
    var roleId = nlapiGetRole();
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    try {
        if (recType == "inventoryitem") {
            if (type == "create" || type == "edit") {
                var variations = null;
                if (id) {
                    if (isMatrixItem(id)) {
                        variations = EbayInventoryItem.getAvailableOptions(id);
                    }
                    if (variations) {
                        var languageSetSearchResults = nlapiSearchRecord("customrecord_ebay_item_language", null, [ new nlobjSearchFilter("custrecord_eil_item_link", null, "is", id) ], [ new nlobjSearchColumn("custrecord_eil_language"), new nlobjSearchColumn("custrecord_eil_variations") ]);
                        if (languageSetSearchResults != null) {
                            for (var i = 0; i < languageSetSearchResults.length; i++) {
                                var langSearchResult = languageSetSearchResults[i];
                                var variationsClone = cloneObj(variations);
                                var itemLanguageSetRecord = nlapiLoadRecord("customrecord_ebay_item_language", langSearchResult.getId());
                                if (langSearchResult.getValue("custrecord_eil_variations")) {
                                    if (langSearchResult.getValue("custrecord_eil_variations") != JSON.stringify(variations)) {
                                        var mergedValue = JSON.stringify(deepmerge(variationsClone, JSON.parse(langSearchResult.getValue("custrecord_eil_variations"))));
                                        itemLanguageSetRecord.setFieldValue("custrecord_eil_variations", mergedValue);
                                        nlapiSubmitRecord(itemLanguageSetRecord, true);
                                    }
                                } else {
                                    if (langSearchResult.getValue("custrecord_eil_language") == "1") {
                                        autoSetEnglishTranslation(variationsClone);
                                    }
                                    itemLanguageSetRecord.setFieldValue("custrecord_eil_variations", JSON.stringify(variationsClone));
                                    nlapiSubmitRecord(itemLanguageSetRecord, true);
                                }
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        processException(e, "afterSubmit id: " + id + " type: " + type + " recType: " + recType + " roleId: " + roleId);
    }
}