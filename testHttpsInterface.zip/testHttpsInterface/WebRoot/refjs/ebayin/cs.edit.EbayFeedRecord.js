initNProgress();

var NS_PAGE_TYPE = "";

function saveRecord() {
    try {
        var combo = nlapiGetFieldValue("custrecord_ebay_feed_combo");
        if (combo == "F") {
            var custrecord_ebay_feed_item = nlapiGetFieldValue("custrecord_ebay_feed_item");
            if (!custrecord_ebay_feed_item) {
                alert("Please select a Item!");
                return false;
            }
        } else {
            var custrecord_ef_kit = nlapiGetFieldValue("custrecord_ef_kit");
            if (!custrecord_ef_kit) {
                alert("Please select an Kit!");
                return false;
            }
        }
        if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
            if (nlapiGetFieldValue("custrecord_ef_subsidiary") == Subsidiaries.TaiwuInternational) {
                if (NS_PAGE_TYPE == "create") {
                    var suffix = _uniqid();
                    var feedSku = nlapiGetFieldValue("custrecord_ebay_feed_sku");
                    nlapiSetFieldValue("custrecord_ebay_feed_sku", feedSku + "|" + suffix);
                    var json = getVarsJSON();
                    if (json.custrecord_ef_subfeeds.length) {
                        nlapiSetFieldValue("custrecord_ebay_feed_matrix_item", "T");
                        nlapiSetFieldValue("custrecord_ebay_feed_variations", JSON.stringify(json.custrecord_ebay_feed_variations));
                        var title = nlapiGetFieldValue("custrecord_ebay_feed_api_title");
                        json.custrecord_ef_subfeeds.forEach(function(feed) {
                            feed.custrecord_ebay_feed_sku = feed.sku + "|" + suffix;
                            feed.custrecord_ebay_feed_api_title = title;
                        });
                        nlapiSetFieldValue("custrecord_ef_subfeeds", JSON.stringify(json.custrecord_ef_subfeeds));
                    }
                }
            }
            var s = [];
            for (var i = 1; i <= 15; i++) {
                var sname = nlapiGetFieldValue("custpage_s_name" + i);
                var svalue = nlapiGetFieldValue("custpage_s_value" + i);
                if (sname && sname) {
                    s.push({
                        specificName: sname,
                        specificValue: svalue
                    });
                }
            }
            console.log(JSON.stringify(s));
            nlapiSetFieldValue("custrecord_ebay_feed_specifics", JSON.stringify(s));
            if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "T") {
                if (NS_PAGE_TYPE != "create") {
                    _catchNSSubFeedList();
                }
            }
        }
    } catch (e) {
        processException(e);
        return false;
    }
    return true;
}

function _controlLineButton() {
    var custpage_ebay_variation_list_splits = jQuery("#custpage_ebay_variation_list_splits");
    var firstButton = custpage_ebay_variation_list_splits.find("#custpage_ebay_variation_list_addedit");
    if (firstButton.val() == "Add") {
        firstButton.hide();
    }
}

function _catchNSSubFeedList() {
    var variationObject = {
        availOptions: []
    };
    var nameList = [];
    var linecount = nlapiGetLineItemCount("custpage_ebay_var_spec_list");
    for (var line = 1; line <= linecount; line++) {
        nameList.push(nlapiGetLineItemValue("custpage_ebay_var_spec_list", "variation_var_name", line));
    }
    console.log(NAME_LIST);
    console.log(nameList);
    if (JSON.stringify(NAME_LIST) != JSON.stringify(nameList)) {
        console.log("NameList 有变化！");
        nameList = nameList.map(function(item) {
            return {
                name: "",
                label: "",
                translation: item,
                options: []
            };
        });
        variationObject.availOptions = nameList;
        nlapiSetFieldValue("custrecord_ebay_feed_variations", JSON.stringify(variationObject));
        return true;
    }
    var NS_SUBFEED_LIST = window.NS_SUBFEED_LIST;
    console.log("-------NSSubfeed----");
    console.log(NS_SUBFEED_LIST);
    console.log("-------NSSubfeed----");
    var ns_subfeed_title = NS_SUBFEED_LIST.TITLE;
    var variationListCount = nlapiGetLineItemCount("custpage_ebay_variation_list");
    console.log(variationListCount);
    var nsFeedListCompare = [];
    var nsFeedList = [];
    if (variationListCount > 0) {
        var optionGroup = {};
        for (var line = 1; line <= variationListCount; line++) {
            var ns_line_obj = {};
            var _list = [];
            for (var i = 0; i < ns_subfeed_title.length; i++) {
                var field = ns_subfeed_title[i];
                var _v = nlapiGetLineItemValue("custpage_ebay_variation_list", ns_subfeed_title[i], line);
                if (_v == null) _v = "";
                ns_line_obj[ns_subfeed_title[i]] = _v;
                var f = nlapiGetLineItemField("custpage_ebay_variation_list", ns_subfeed_title[i], line);
                if (field.indexOf("variation_vname_") != -1) {
                    _v = _v.trim();
                    var key_name = f.getLabel();
                    if (optionGroup.hasOwnProperty(key_name)) {
                        var fl = optionGroup[key_name].filter(function(item) {
                            return item.toUpperCase() == _v.toUpperCase();
                        });
                        if (!fl.length) {
                            optionGroup[key_name].push(_v);
                        }
                    } else {
                        optionGroup[key_name] = [ _v ];
                    }
                }
                var lineObject = {};
                lineObject.label = f.getLabel();
                lineObject.name = f.getName();
                lineObject.value = _v;
                _list.push(lineObject);
            }
            nsFeedListCompare.push(ns_line_obj);
            nsFeedList.push(_list);
        }
        console.log("optionGroup: " + JSON.stringify(optionGroup, null, 2));
        for (var _name in optionGroup) {
            var _valueList = optionGroup[_name];
            _valueList = _valueList.unique();
            var _opt = {
                name: "",
                label: "",
                translation: _name,
                options: _valueList.map(function(item) {
                    return {
                        id: "",
                        value: "",
                        translation: item
                    };
                })
            };
            variationObject.availOptions.push(_opt);
        }
    }
    console.log("nsFeedListCompare: " + JSON.stringify(nsFeedListCompare, null, 2));
    console.log("nsFeedList: " + JSON.stringify(nsFeedList, null, 2));
    _log("variationObject", variationObject);
    var changed_flag = false;
    if (JSON.stringify(NS_SUBFEED_LIST.ROWS) != JSON.stringify(nsFeedListCompare)) {
        changed_flag = true;
        console.log(changed_flag);
        nlapiSetFieldValue("custrecord_ebay_feed_variations", JSON.stringify(variationObject));
        nlapiSetFieldValue("custrecord_ef_variations_changed", JSON.stringify(nsFeedList));
        var mdf = nlapiGetFieldValue("custrecord_ebay_feed_pending_mdf");
        if (mdf) {
            mdf = mdf.trim();
            mdf = JSON.parse(mdf);
            if (!Array.isArray(mdf)) throw createEbayError("mdf not array");
        } else {
            mdf = [];
        }
        mdf = mdf.unique();
        mdf.push("variations");
        nlapiSetFieldValue("custrecord_ebay_feed_pending_mdf", JSON.stringify(mdf));
    }
}

function pageInit(type) {
    console.log("pageInit Yes!" + type);
    NS_PAGE_TYPE = type;
    if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
        jQuery("#custrecord_ebay_feed_gallery").ossImage({
            Display: false
        });
        jQuery("#custrecord_ebay_feed_body_picture").ossImage({
            Display: false
        });
        var $ZakeTable = jQuery("#ZakeTable");
        $ZakeTable.parents(".uir-outside-fields-table").css("width", "100%");
        if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "T") {
            jQuery(".SUBFEED_PICTURE").ossImage({
                Type: "textbox"
            });
        }
        var STYLE = "<style>" + ".afterOptions{background-color:#fff;position:absolute;width:300px;border:1px solid #00f}.afterOptions li{padding:5px} #custpage_tab_specifics_wrapper{border-top:1px solid #CCCCCC}" + ".afterOptions li:hover{background-color:#ffefd0}" + ".popupOption{border:1px solid blue!important;}" + "</style>";
        jQuery("head").append(STYLE);
        var POPUP_SPECIFIC_BUTTON = "<input " + 'style="padding: 6px; margin-left: 5px; cursor: pointer; font-family: arial,sans-serif;" ' + 'onclick="POPUP_SPECIFIC(); return false;" type="button" ' + 'value="Popup Ebay Category Recommendation Specific"' + ' id="popupCategorySpeicfic" name="popupCategorySpeicfic" />';
        jQuery("#custrecord_ebay_feed_category_id").after(POPUP_SPECIFIC_BUTTON);
    } else {
        jQuery("#custrecord_ef_picture2").ossImage({
            Type: "textbox"
        });
    }
    var custrecord_ebay_feed_item = nlapiGetFieldValue("custrecord_ebay_feed_item");
    var custrecord_ef_kit = nlapiGetFieldValue("custrecord_ef_kit");
    if (custrecord_ebay_feed_item && !custrecord_ef_kit) {
        nlapiDisableField("custrecord_ef_kit", true);
    } else if (custrecord_ef_kit && !custrecord_ebay_feed_item) {
        nlapiDisableField("custrecord_ebay_feed_item", true);
    }
}

function previewDescription() {
    post_to_url("https://system.na1.netsuite.com/app/site/hosting/scriptlet.nl?script=120&deploy=2", {
        desc: nlapiGetFieldValue("custrecord_ebay_feed_description").replace(/\r|\n|\r\n/g, "")
    });
}

function fieldChanged(type, name, linenum) {
    if ("custrecord_ef_cease_when_sold_out" == name) {
        var custrecord_ef_cease_when_sold_out = nlapiGetFieldValue("custrecord_ef_cease_when_sold_out");
        if (custrecord_ef_cease_when_sold_out == "T") {
            var custrecord_ebay_feed_push_qty = nlapiGetFieldValue("custrecord_ebay_feed_push_qty");
            if (!custrecord_ebay_feed_push_qty) {
                alert("If checked CASE WHEN SOLD OUT you MUST fill the value for PUSH QTY.");
            }
        }
    } else if (name == "custrecord_ef_kit") {
        var kititem = nlapiGetFieldValue("custrecord_ef_kit");
        if (kititem) {
            var custrecord_ebay_feed_combo = nlapiGetField("custrecord_ebay_feed_combo");
            nlapiSetFieldValue("custrecord_ebay_feed_combo", "T");
            nlapiDisableField("custrecord_ebay_feed_combo", true);
            _fieldDisable([ "custrecord_ebay_feed_item", "custrecord_ebay_feed_api_sku", "custrecord_ebay_feed_legacysku", "custrecord_ef_max_push_qty", "custrecord_ebay_feed_matrix_item", "custrecord_ebay_feed_matrix_child_item" ], true);
            nlapiSetFieldValue("custrecord_ef_max_push_qty", "");
            nlapiSetFieldValue("custrecord_ebay_feed_matrix_item", "F");
            nlapiSetFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
            var kitSKU = nlapiLookupField("customrecord_kit", kititem, "custrecord_kit_sku");
            nlapiSetFieldValue("custrecord_ebay_feed_sku", kitSKU + "|" + _uniqid());
            jQuery("#custom117lnk").hide();
            jQuery("#custom117_wrapper").hide();
        } else {
            nlapiSetFieldValue("custrecord_ebay_feed_combo", "F");
            nlapiDisableField("custrecord_ebay_feed_combo", false);
            _fieldDisable([ "custrecord_ebay_feed_item", "custrecord_ebay_feed_api_sku", "custrecord_ebay_feed_legacysku", "custrecord_ebay_feed_location", "custrecord_ef_max_push_qty", "custrecord_ebay_feed_matrix_item", "custrecord_ebay_feed_matrix_child_item" ], false);
            jQuery("#custom117lnk").show();
            jQuery("#custom117_wrapper").show();
        }
    } else if (name == "custrecord_ebay_feed_item") {
        var custrecord_ebay_feed_item = nlapiGetFieldValue("custrecord_ebay_feed_item");
        if (custrecord_ebay_feed_item) {
            _fieldDisable([ "custrecord_ef_kit", "custrecord_ebay_feed_combo" ], true);
            nlapiSetFieldValue("custrecord_ef_kit", null);
            nlapiSetFieldValue("custrecord_ebay_feed_combo", "F");
        } else {
            _fieldDisable([ "custrecord_ef_kit", "custrecord_ebay_feed_combo" ], true);
        }
    } else if (type == "custpage_ebay_var_spec_list" && name == "variation_var_name") {}
    if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
        if (NS_PAGE_TYPE == "create") {
            if (name == "custrecord_ebay_feed_api_sku") {
                nlapiSetFieldValue("custrecord_ebay_feed_sku", nlapiGetFieldValue("custrecord_ebay_feed_api_sku"));
            } else if (name == "custrecord_ef_upc") {
                if (!nlapiGetFieldValue("custrecord_ef_upc")) {
                    nlapiSetFieldValue("custrecord_ef_upc", "Does not apply");
                }
            }
        }
    }
}

function lineInit(type) {
    _log("lineInit", arguments);
    return true;
}

function validateLine(type) {
    _log("validateLine", arguments);
    return true;
}

function recalc(type) {
    _log("recalc", type);
    return true;
}

function validateInsert(type) {
    _log("validateInsert", arguments);
    return true;
}

function validateDelete(type) {
    _log("validateDelete", arguments);
    return true;
}

function _fieldDisable(arr, val) {
    arr.forEach(function(field) {
        nlapiDisableField(field, val);
    });
}

(function($, window, document) {
    $.fn.afterOptions = function(options) {
        return this.each(function() {
            var $THE_TEXT_BOX = $(this);
            $THE_TEXT_BOX.parent().addClass("popupOption");
            function getAfterOptions() {
                return $THE_TEXT_BOX.next(".afterOptions");
            }
            var optionsMenu = '<ul class="afterOptions">';
            optionsMenu += options.map(function(o) {
                return "<li>" + o + "</li>";
            }).join("");
            optionsMenu += "</ul>";
            function hideOptions() {
                if ($THE_TEXT_BOX.next(".afterOptions").length) {
                    $THE_TEXT_BOX.next(".afterOptions").hide();
                }
            }
            $THE_TEXT_BOX.on("focusin dblclick", function() {
                var ao = getAfterOptions();
                if (!ao.length) {
                    $THE_TEXT_BOX.after(optionsMenu);
                    ao = getAfterOptions();
                    ao.children("li").on("click", function() {
                        $THE_TEXT_BOX.val($(this).html().trim());
                        $THE_TEXT_BOX.focus();
                        ao.hide();
                    });
                    ao.on({
                        mouseenter: function() {
                            $THE_TEXT_BOX.off("focusout");
                        },
                        mouseleave: function() {
                            $THE_TEXT_BOX.on("focusout", hideOptions);
                        }
                    });
                } else {
                    ao.show();
                }
            }).on("focusout", hideOptions);
        });
    };
    $.fn.afterOptions.format = function(txt) {
        return "<strong>" + txt + "</strong>";
    };
    $.fn.afterOptions.defaults = {};
})(jQuery, window, document, undefined);

function convert_to_array(obj) {
    if (!Array.isArray(obj)) {
        return [ obj ];
    } else {
        return obj;
    }
}

function POPUP_SPECIFIC() {
    try {
        var site_id = nlapiLookupField("customrecord_ebay_global", nlapiGetFieldValue("custrecord_ebay_feed_global_site"), "custrecord_ebay_site_id");
        if (!site_id) {
            alert("Site ID error.");
            return;
        }
        var cateid = nlapiGetFieldValue("custrecord_ebay_feed_category_id");
        if (!cateid) {
            alert("Please input the category ID.");
            return;
        }
        NProgress.start();
        var token = nlapiLookupField("customrecord_ebay_account", nlapiGetFieldValue("custrecord_ebay_feed_account"), "custrecord_ebay_api_token");
        var xml = "";
        xml += '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<GetCategorySpecificsRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
        xml += "  <WarningLevel>High</WarningLevel>";
        xml += "  <CategorySpecific>";
        xml += "    <CategoryID>" + cateid + "</CategoryID>";
        xml += "  </CategorySpecific>";
        xml += "  <RequesterCredentials>";
        xml += "        <eBayAuthToken>" + token + "</eBayAuthToken>";
        xml += "  </RequesterCredentials>";
        xml += "</GetCategorySpecificsRequest>";
        console.log(xml);
        var res = EbayRequest.call({
            "X-EBAY-API-COMPATIBILITY-LEVEL": "933",
            "X-EBAY-API-SITEID": site_id,
            "X-EBAY-API-CALL-NAME": "GetCategorySpecifics"
        }, xml);
        console.log(JSON.stringify(res));
        if (res.success) {
            if (res.response.GetCategorySpecificsResponse.Ack == "Success") {
                if (res.response.GetCategorySpecificsResponse.Recommendations.hasOwnProperty("NameRecommendation")) {
                    res = res.response.GetCategorySpecificsResponse.Recommendations.NameRecommendation;
                    var specificList = res.map(function(NameRecommendation) {
                        var recs = [];
                        if (NameRecommendation.hasOwnProperty("ValueRecommendation")) {
                            recs = convert_to_array(NameRecommendation.ValueRecommendation).map(function(value) {
                                return value.Value;
                            });
                        }
                        return {
                            Name: NameRecommendation.Name,
                            ValueRecommendation: recs
                        };
                    });
                    console.log(JSON.stringify(specificList, null, 2));
                    var lastSpecificNo = 0;
                    for (var i = 1; i <= 15; i++) {
                        lastSpecificNo = i;
                        if (!specificList.length) break;
                        var specific_name = nlapiGetFieldValue("custpage_s_name" + i);
                        if (specific_name) {
                            var recommendation = findRecommendation(specificList, specific_name);
                            if (recommendation) {
                                jQuery("#custpage_s_value" + i).afterOptions(recommendation.Recommendation.ValueRecommendation);
                                specificList.splice(recommendation.Index, 1);
                            }
                        } else {
                            var recommendation = specificList[0];
                            nlapiSetFieldValue("custpage_s_name" + i, recommendation.Name);
                            jQuery("#custpage_s_value" + i).afterOptions(recommendation.ValueRecommendation);
                            specificList.splice(0, 1);
                        }
                    }
                }
            } else {
                alert(JSON.stringify(res.response.GetCategorySpecificsResponse.Errors, null, 2));
            }
        } else {
            alert(res.message);
        }
        NProgress.done(true);
    } catch (e) {
        NProgress.done(true);
        processException(e);
    }
}

function findRecommendation(arr, specific_name) {
    for (var i = 0, len = arr.length; i < len; i++) {
        if (arr[i].Name == specific_name) {
            return {
                Recommendation: arr[i],
                Index: i
            };
        }
    }
    return null;
}