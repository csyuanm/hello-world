/**
 * 深圳
 * @type {string|String}
 */

Date.prototype.addHours = function (h) {
    this.setHours(this.getHours() + h);
    return this;
};
// alert(new Date().addHours(4));

var DEPLOYMENT_ID = nlapiGetContext().getDeploymentId();
_audit('DEPLOYMENT_ID', DEPLOYMENT_ID);

function run() {

    var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [
        //new nlobjSearchFilter('internalid', null, 'anyof', EBAY_UPLOAD_TRACKING_NUMBER_ACCOUNTS.map(function (item) {
        //    return item.InternalID;
        //}))
        new nlobjSearchFilter('custrecord_ea_subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
        new nlobjSearchFilter('isinactive', null, 'is', "F")
    ], [
        new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_ebay_shortname'),
        new nlobjSearchColumn('custrecord_ebay_api_token'),
        new nlobjSearchColumn('custrecord_ebay_global_site_access'),

        new nlobjSearchColumn('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
        new nlobjSearchColumn('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
        new nlobjSearchColumn('custrecord_ed_cert_name', 'custrecord_ebay_dev_account')
        // new nlobjSearchColumn('custrecord_acc_deployment_upload_track')
    ]);

    var ebayAccountMapping = {};
    ebayAccountSearch.forEach(function (searchResult) {

        var token = searchResult.getValue('custrecord_ebay_api_token');
        var ebayAccountId = searchResult.getId();

        //_log(searchResult.getValue('name') + ' -- ' + ebayAccountId);

        var devHeader = {
            'X-EBAY-API-APP-NAME': searchResult.getValue('custrecord_ed_app_name', 'custrecord_ebay_dev_account'),
            'X-EBAY-API-DEV-NAME': searchResult.getValue('custrecord_ed_dev_name', 'custrecord_ebay_dev_account'),
            'X-EBAY-API-CERT-NAME': searchResult.getValue('custrecord_ed_cert_name', 'custrecord_ebay_dev_account'),
            'Content-Type': 'application/xml'
        };

        ebayAccountMapping[ebayAccountId] = {
            short_name: searchResult.getValue('custrecord_ebay_shortname'),
            devHeader: devHeader,
            token: token
        };

    });


    try {
        uploadTrackingNumber(ebayAccountMapping);
    } catch (e) {
        processException(e)
    }


}


function uploadTrackingNumber(ebayAccountMapping) {

    // var dId = nlapiGetContext().getDeploymentId();

    //var searchResults = null;

    //if (dId == 'customdeploy_sc_shenzhen_uploadtrack') {
    //    searchResults = _search();
    //}
    //
    ////else if (dId == 'customdeploy_sc_shenzhen_uploadtrack_fix') {
    ////    searchResults = _searchFix(ebayAccountId);
    ////}
    //
    //else if (dId == 'customdeploy_sc_sz_uploadtrack_auto') {
    //    searchResults = _autoUploadList();
    //}
    //
    //else {
    //    _log_email('没有这个配置ID');
    //    return;
    //}

    // 7/3/2017 新改版
    var searchResults = nlapiSearchRecord(null, '2594');

    if (searchResults != null) {

        var len = searchResults.length;
        _log('updateWooTracking--- Size: ', len);
        if (len == 1000) {
            _log_email('Search 超过了 1000 in Shenzhen update tracking number', len);
        }

        // var updateList = [];
        var syncList = [];

        for (var i = 0; i < len; i++) {

            var syncmsg = [];
            try {

                var ebayAccountId = searchResults[i].getValue('custbody_linked_ebay_account');
                if (ebayAccountMapping.hasOwnProperty(ebayAccountId)) {

                    var accInfo = ebayAccountMapping[ebayAccountId];
                    // var ebayAccountName = searchResults[i].getValue('custrecord_ebay_shortname', 'custbody_linked_ebay_account');
                    var ebayOrderId = searchResults[i].getValue('custbody_ebay_order_id');
                    var otherrefnum = searchResults[i].getValue('otherrefnum');
                    var soId = searchResults[i].getId();
                    var ordertype = searchResults[i].getValue('custbody_order_type');
                    syncmsg.push(otherrefnum);
                    syncmsg.push(ordertype);
                    //  syncmsg.push(ebayAccountName);

                    // 正常的单子
                    //if (!searchResults[i].getValue('custbody_parent_sales_order') && searchResults[i].getValue('custbody_zake_haschildorder') == 'F') {

                    // var carrierCode = searchResults[i].getValue('custrecord_sz_carrier_code_ebay', 'CUSTBODY_SZ_CARRIER');
                    var carrierCode = searchResults[i].getValue('custrecord_sz_sm_carriercodeebay', 'custbody_ship_method_sz');
                    if (!carrierCode) carrierCode = 'ChinaPost';

                    _audit('carrierCode', carrierCode);

                    var trackingnumbers = searchResults[i].getValue('custbody_sz_carrier_trackingnumber');

                    if (ordertype == 4) { // 合单
                        ebayOrderId = ebayOrderId.split('|');
                        for (var j = 0; j < ebayOrderId.length; j++) { // 同一个Ebay account的单是可以合并的！ 否则不行！
                            completeOrderSale(carrierCode, trackingnumbers, accInfo, ebayOrderId[j], soId, syncmsg);
                        }
                    } else {
                        completeOrderSale(carrierCode, trackingnumbers, accInfo, ebayOrderId, soId, syncmsg);
                    }


                } else {

                    syncmsg.push('No link for SO ID: ' + searchResults[i].getId());
                    _log_email('没有这个Ebay Account Mapping', ebayAccountId + ' -- SO ID: ' + searchResults[i].getId());
                    //  continue;
                }


            } catch (e) {
                e = processException(e);
                syncmsg.push(searchResults[i].getId() + ' - ' + e.getUserMessage());
            }


            checkGovernance();

            syncList.push(syncmsg.join(' - '));
        }

        _log('Taiwu - Ebay Standard Tracking Updated! - ' + ' syncList: ' + syncList.length, JSON.stringify(syncList, null, 2));

    } else {
        _log('Taiwu - Ebay Standard Tracking Updated! - ' + ' No updated.', 'Nothing for search');
    }
}

function completeOrderSale(carrierCode, trackingnumbers, accInfo, ebayOrderId, soId, syncmsg) {

    var txml = '' +
        '    <ShipmentTrackingDetails>' +  // 	Optional,repeatable: [0..*]
        '      <ShippingCarrierUsed>' + carrierCode + '</ShippingCarrierUsed>' +  // http://developer.ebay.com/devzone/xml/docs/reference/ebay/types/ShippingCarrierCodeType.html

        '      <ShipmentTrackingNumber>' + trackingnumbers + '</ShipmentTrackingNumber>' +
            // 9400110200881897372752
            //'      <ShipmentTrackingNumber>9400110200881897376666</ShipmentTrackingNumber>' +

        '    </ShipmentTrackingDetails>';


    // }

    // 分单后的子订单
    // else if (!searchResults[i].getValue('custbody_parent_sales_order') && searchResults[i].getValue('custbody_zake_haschildorder') == 'T') {
    //var ffJSON = searchResults[i].getValue('custbody_zake_fulfillmentjson');
    //ffJSON = JSON.parse(ffJSON);
    //
    //
    //var txml = ffJSON.map(function (ff) {
    //
    //    var carrierCode = nlapiLookupField('customrecord_sz_carrier', ff.carrierId, 'custrecord_sz_carrier_code_ebay');
    //    if (!carrierCode) carrierCode = 'ChinaPost';
    //
    //    var trackingnumbers = ff.trackNumber;
    //
    //    return '' +
    //        '    <ShipmentTrackingDetails>' +  // 	Optional,repeatable: [0..*]
    //        '      <ShippingCarrierUsed>' + carrierCode + '</ShippingCarrierUsed>' +  // http://developer.ebay.com/devzone/xml/docs/reference/ebay/types/ShippingCarrierCodeType.html
    //
    //        '      <ShipmentTrackingNumber>' + trackingnumbers + '</ShipmentTrackingNumber>' +
    //            // 9400110200881897372752
    //            //'      <ShipmentTrackingNumber>9400110200881897376666</ShipmentTrackingNumber>' +
    //
    //        '    </ShipmentTrackingDetails>';
    //
    //}).join('');
    //} else {
    //
    //    _log_email("What it is??" + ebayOrderId);
    //    continue;
    //}

    var xml = ['<?xml version="1.0" encoding="utf-8"?>',
        '<CompleteSaleRequest xmlns="urn:ebay:apis:eBLBaseComponents">',
        '  <RequesterCredentials>',
        '    <eBayAuthToken>' + accInfo.token + '</eBayAuthToken>',
        '  </RequesterCredentials>',
        '  <WarningLevel>High</WarningLevel>',

        '  <OrderID>' + ebayOrderId + '</OrderID>',
        '  <Shipped>true</Shipped>',
        //'  <TransactionID>0</TransactionID>',
        '  <Shipment>',

        //'    <ShipmentTrackingDetails>', // 	Optional,repeatable: [0..*]
        //'      <ShippingCarrierUsed>' + carrierCode + '</ShippingCarrierUsed>', // http://developer.ebay.com/devzone/xml/docs/reference/ebay/types/ShippingCarrierCodeType.html
        //'      <ShipmentTrackingNumber>' + searchResult[i].getValue('trackingnumbers') + '</ShipmentTrackingNumber>',
        //'    </ShipmentTrackingDetails>',
        txml,

        '  </Shipment>',
        '</CompleteSaleRequest>'].map(function (node) {
            return node.trim();
        }).join('');

    _log('xml', xml);

    var header = extend(accInfo.devHeader, {
        'X-EBAY-API-SITEID': '0', // for US
        'X-EBAY-API-CALL-NAME': 'CompleteSale',
        'X-EBAY-API-COMPATIBILITY-LEVEL': '925'
    });

    var response = nlapiRequestURL('https://api.ebay.com/ws/api.dll', xml, header);

    response = new X2JS().xml_str2json(response.getBody());

    _log('response', response);

    //{
    //    "CompleteSaleResponse": {
    //        "Timestamp": "2016-02-01T03:22:42.105Z",
    //        "Ack": "Success",
    //        "Version": "949",
    //        "Build": "E949_CORE_APIXO_17770993_R1",
    //        "_xmlns": "urn:ebay:apis:eBLBaseComponents"
    //    }
    //}

    //var soRec = nlapiLoadRecord('salesorder', soId);
    //
    //if (response.CompleteSaleResponse.Ack == 'Success') {
    //    soRec.setFieldValue('custbody_script_memo', 'Ebay 跟踪代码上传成功');
    //    soRec.setFieldValue('custbody_tracking_number_sync', 'T');
    //
    //    syncmsg.push('OK')
    //} else {
    //    //  the maximum number ( 300 )
    //    var smemo = JSON.stringify(response.CompleteSaleResponse);
    //    if (smemo.length > 300) smemo = smemo.substring(0, 300);
    //
    //    soRec.setFieldValue('custbody_script_memo', smemo);
    //    soRec.setFieldValue('custbody_tracking_number_sync', 'F');
    //    syncmsg.push('ERROR');
    //    _log_email('跟踪代码上传错误 - Ebay Order ID: ' + ebayOrderId + ' SO: ' + soRec.getId() + ' - ' + trackingnumbers,
    //        '<pre>' + xml + '</pre>' +
    //        '<br/>' + JSON.stringify(response.CompleteSaleResponse));
    //}
    //
    //nlapiSubmitRecord(soRec, true);


    if (response.CompleteSaleResponse.Ack == 'Success') {
        nlapiSubmitField('salesorder', soId, [
            'custbody_script_memo',
            'custbody_tracking_number_sync'
        ], [
            'Ebay 跟踪代码上传成功',
            'T'
        ]);
        syncmsg.push('OK')
    } else {
        //  the maximum number ( 300 )
        var smemo = JSON.stringify(response.CompleteSaleResponse);
        if (smemo.length > 300) smemo = smemo.substring(0, 300);

        nlapiSubmitField('salesorder', soId, [
            'custbody_script_memo',
            'custbody_tracking_number_sync'
        ], [
            smemo,
            'F'
        ]);

        syncmsg.push('ERROR');

        _log_email('跟踪代码上传错误 - Ebay Order ID: ' + ebayOrderId + ' - ' + trackingnumbers,
            '<pre>' + xml + '</pre>' +
            '<br/>' + JSON.stringify(response.CompleteSaleResponse));
    }


    //updateList.push(searchResults[i].getId());
    //} else {
    //    _log_email('not found ebay id on upload tracking number', searchResults[i].getId());
    //}
    // if (i == 0) throw nlapiCreateError('ZAKETEST', ebayOrderId);
}

//function _searchFix(ebayAccountId) {
//
//    return nlapiSearchRecord('salesorder', null, [
//
//        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
//        new nlobjSearchFilter('mainline', null, 'is', 'T'),
//        new nlobjSearchFilter('custbody_tw_fulfillment_status', null, 'is', 3), // 成功获取了 跟踪代码 最后的成功！
//
//        new nlobjSearchFilter('custbody_tracking_number_sync', null, 'is', 'T'), // 还有没有同步Tracking 的
//        new nlobjSearchFilter('custbody_sz_carrier_trackingnumber', null, 'isnotempty'),
//
//        new nlobjSearchFilter('custbody_sz_carrier', null, 'anyof', [3, 4]), // 亚太深圳和义乌的
//
//        new nlobjSearchFilter('custbody_linked_ebay_account', null, 'is', ebayAccountId), // 是Ebay的单
//
//        // 除了关闭和取消的
//        new nlobjSearchFilter('status', null, 'noneof', [
//            'SalesOrd:C',
//            'SalesOrd:H'
//        ]),
//
//        new nlobjSearchFilter('custbody_ebay_order_id', null, 'isnotempty')
//    ], [
//        new nlobjSearchColumn('internalid').setSort(),
//        new nlobjSearchColumn('otherrefnum'),
//        new nlobjSearchColumn('custbody_ebay_order_id'),
//        new nlobjSearchColumn('custbody_sz_carrier_trackingnumber'),
//        new nlobjSearchColumn('custbody_tw_fulfillment_status'),
//        new nlobjSearchColumn('custbody_tracking_number_sync'),
//        new nlobjSearchColumn('custrecord_sz_carrier_code_ebay', 'CUSTBODY_SZ_CARRIER'),
//
//        // new nlobjSearchColumn('custbody_zake_haschildorder'),
//        new nlobjSearchColumn('custbody_parent_sales_order'),
//        new nlobjSearchColumn('custbody_zake_fulfillmentjson')
//    ]);
//}

//function _autoUploadList(ebayAccountId) {
//
//    var list = [];
//
//    //Type	is Sales Order
//    //Subsidiary	is Taiwu 太武国际
//    //Main Line	is true
//    //Marketplace (Custom Body)	is eBay
//    //Tracking Number Sync (Custom Body)	is false
//    //Location	is any of 杨美仓, 义乌仓
//    //物流商跟踪代码_trackingno (Custom Body)	is not empty
//    //Ebay Order ID (Custom Body)	is not empty
//    //Status	is none of Sales Order:Cancelled, Sales Order:Closed
//    //太武国际包裹发货状态 (Custom Body)	is 3. ~~~物流商对接（获取跟踪号）成功！
//    var search = nlapiSearchRecord(null, '1658');
//
//    for (var i = 0, len = search.length; i < len; i++) {
//
//        // if (i == 1) break;
//        var searchResult = search[i];
//        var datecreated = searchResult.getValue('datecreated'); // 东部时间
//        _log('-----------datecreated 创建时间 东部时间', datecreated);
//        datecreated = nlapiStringToDate(datecreated); //.getTime();
//        _audit('datecreated -3 东部转西部时间 - and UTC时间', datecreated.addHours(-3));
//
//        // 东部时间比西部时间快3小时 -- 系统Script是西部时间 -- 系统外部是西部时间太平洋时间
//        var today = new Date(); // UTC时间
//        _audit('today ---UTC 时间', today);
//        var diff = today.getTime() - datecreated.getTime();
//        _log('diff', diff);
//        var limit = 20 * 60 * 60 * 1000;
//
//        if (diff > limit) {
//
//            _log('Upload! ' + searchResult.getValue('otherrefnum'),
//                'More than ' + _mathround((diff - limit) / (1000 * 60 * 60)) + ' Hours');
//            list.push(searchResult);
//        }
//    }
//
//    _log('list SIZE', list.length);
//
//    //return []; // test
//    return list;
//
//}
//
//function _search(ebayAccountId) {
//
//    return nlapiSearchRecord('salesorder', null, [
//
//        new nlobjSearchFilter('subsidiary', null, 'is', Subsidiaries.TaiwuInternational),
//        new nlobjSearchFilter('mainline', null, 'is', 'T'),
//        new nlobjSearchFilter('custbody_marketplace', null, 'is', MarketplaceShipName.eBay),
//
//        new nlobjSearchFilter('custbody_tracking_number_sync', null, 'is', 'F'), // 还有没有同步Tracking 的
//        new nlobjSearchFilter('custbody_sz_carrier_trackingnumber', null, 'isnotempty'),
//
//        // 深圳和义乌仓库
//        new nlobjSearchFilter('location', null, 'anyof', [
//            34, 35,
//            73, 84, 85, 86
//        ]),
//        new nlobjSearchFilter('custbody_tw_fulfillment_status', null, 'anyof', [3]), // 成功获取了 跟踪代码 最后的成功！
//
//        // new nlobjSearchFilter('custbody_linked_ebay_account', null, 'is', ebayAccountId), // 是Ebay的单
//        new nlobjSearchFilter('status', null, 'anyof', [
//            'SalesOrd:F', // Pending Billing
//            'SalesOrd:G'  // Billed
//        ]),
//        new nlobjSearchFilter('custbody_ebay_order_id', null, 'isnotempty')
//        //new nlobjSearchFilter('custbody_shiping_changed', null, 'is', 'F')
//
//    ], [
//        new nlobjSearchColumn('internalid').setSort(),
//        new nlobjSearchColumn('otherrefnum'),
//
//        new nlobjSearchColumn('custbody_ebay_order_id'),
//        new nlobjSearchColumn('custbody_sz_carrier_trackingnumber'),
//        new nlobjSearchColumn('custbody_tw_fulfillment_status'),
//        new nlobjSearchColumn('custbody_tracking_number_sync'),
//
//        new nlobjSearchColumn('custbody_linked_ebay_account'),
//        new nlobjSearchColumn('custrecord_ebay_shortname', 'custbody_linked_ebay_account'),
//
//        new nlobjSearchColumn('custrecord_sz_carrier_code_ebay', 'CUSTBODY_SZ_CARRIER'),
//        // custrecord_sz_sm_carriercodeebay
//        new nlobjSearchColumn('custrecord_sz_sm_carriercodeebay', 'custbody_ship_method_sz'),
//
//        //  new nlobjSearchColumn('custbody_zake_haschildorder'),
//        new nlobjSearchColumn('custbody_parent_sales_order'),
//        new nlobjSearchColumn('custbody_zake_fulfillmentjson')
//    ]);
//
//}

