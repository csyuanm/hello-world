function run() {
    var file = nlapiLoadFile(2085683);
    var str = file.getValue(); // mapping.csv

    var papacsv = Papa.parse(str, {header: true});

    if (papacsv.errors.length) {
        throw nlapiCreateError('CSV_ERROR', 'csv errors ' + JSON.stringify(papacsv.errors));
    }
    var csv = papacsv.data;

    _log('csv', csv);

    var resultCSV = [];
    for (var i = 0, len = csv.length; i < len; i++) {

        //if (i == 10) break;

        var obj = {};

        var Seller = csv[i]['Seller'];
        var ItemID = csv[i]['ItemID'];
        var pushqty = csv[i]['auto_quantity'];

        obj['Seller'] = Seller;
        obj['ItemID'] = ItemID;
        obj.success = 'Yes';

        try {

            _audit('i', ItemID);
            var feedSearch = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
                new nlobjSearchFilter('custrecord_ebay_feed_item_id', null, 'is', ItemID)
            ]);
            if (feedSearch != null) {
                for (var j = 0; j < feedSearch.length; j++) {
                    nlapiSubmitField(feedSearch[j].getRecordType(), feedSearch[j].getId(), 'custrecord_ebay_feed_push_qty', pushqty, true);
                }
            }

        } catch (e) {
            e = processException(e);
            obj.success = e.getUserMessage();
        }
        resultCSV.push(obj);
        checkGovernance();
    }

    var csvContent = Papa.unparse(resultCSV, {
        quotes: true
    });

    var resultFile = nlapiCreateFile(file.getName() + '_result.csv', 'CSV', csvContent);
    resultFile.setFolder(1285);
    nlapiSubmitFile(resultFile);
}