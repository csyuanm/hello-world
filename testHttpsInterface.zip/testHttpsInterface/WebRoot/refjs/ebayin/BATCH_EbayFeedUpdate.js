function run() {


    var search = nlapiSearchRecord(null, '');

    // 模板都更新一下

    for (var i = 0, len = search.length; i < len; i++) {

        var feedId = search[i].getId();

        new __EbayFeed(feedId).callReviseItem([''])
    }

}