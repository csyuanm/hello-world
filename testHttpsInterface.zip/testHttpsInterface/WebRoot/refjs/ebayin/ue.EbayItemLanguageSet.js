function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var ITEM_OPTIONS = [ [ "custitem_var_color", "Colors" ], [ "custitem_var_size", "Sizes" ], [ "custitem_womens_size", "Womens Size" ], [ "custitem_watch_deisgn", "Watch Design" ], [ "custitem_var_assortment", "Assortment" ], [ "custitem_var_bag_pattern", "Bag Pattern" ], [ "custitem_child_size", "Child Size" ], [ "custitem_var_color_temp", "Color Temp" ], [ "custitem_var_compatible_with", "Compatible With" ], [ "custitem_var_legging_design", "Legging Design" ], [ "custitem_var_mens_size", "Mens Size" ], [ "custitem_var_print_design", "Print Design" ], [ "custitem_var_shape", "Shape" ], [ "custitem_var_style", "Style" ], [ "custitem_var_womens_shoe_size", "Shoe Size" ], [ "custitem_var_mens_pant_size", "Mens Pant Size" ], [ "custitem_var_bra_size", "Bra Size" ], [ "custitem_var_child_shoe_size", "Child Shoe Size" ], [ "custitem_var_mens_shoe_size", "Mens Shoe Size" ], [ "custitem_var_amps", "AMPS" ], [ "custitem_zake_option2", "Number" ], [ "custitem_zake_other", "Letter" ] ];

function isMatrixItem(item__internalid) {
    var ismatrix = false;
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
    if (testSearch != null) ismatrix = true;
    return ismatrix;
}

function getItemType(id) {
    return nlapiLookupField("item", id, "type");
}

function isKitItem(id) {
    return getItemType(id) == "Kit";
}

function EbayItem(type, id) {
    this.id = id;
    this.pictureSearch = null;
    Record.call(this, type, id);
}

EbayItem.TYPE = {
    INVENTORY_ITEM: "inventoryitem",
    KIT_ITEM: "kititem"
};

inherit(Record, EbayItem);

EbayItem.prototype.extend({
    getPictureSearch: function() {
        if (this.pictureSearch == null) {
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", [ this.id ]) ], [ new nlobjSearchColumn("custitem_ebay_gallery_pictures"), new nlobjSearchColumn("custitem_ebay_body_pictures") ]);
            var pictureSearch = {
                gallery: [],
                bodyPicture: []
            };
            if (search != null) {
                if (search[0].getValue("custitem_ebay_gallery_pictures")) {
                    pictureSearch.gallery = JSON.parse(search[0].getValue("custitem_ebay_gallery_pictures"));
                } else {
                    pictureSearch.gallery = [];
                }
                if (search[0].getValue("custitem_ebay_body_pictures")) {
                    pictureSearch.bodyPicture = JSON.parse(search[0].getValue("custitem_ebay_body_pictures"));
                } else {
                    pictureSearch.bodyPicture = [];
                }
            }
            this.pictureSearch = pictureSearch;
            return pictureSearch;
        } else {
            return this.pictureSearch;
        }
    },
    getGalleryPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.gallery;
    },
    getBodyPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.bodyPicture;
    }
});

function EbayInventoryItem(id, ismatrix) {
    EbayItem.call(this, "inventoryitem", id);
}

inherit(EbayItem, EbayInventoryItem);

EbayInventoryItem.prototype.getField = function(name) {
    var record = this.rec;
    return {
        name: name,
        value: record.getFieldValue(name),
        text: record.getFieldText(name)
    };
};

EbayInventoryItem.prototype._ismatrix = function() {
    return this.ismatrix == "T";
};

EbayInventoryItem.prototype.getLocationQuantity = function() {
    return this.getSubList("locations", [ "location", "location_display", "quantityavailable" ]);
};

EbayInventoryItem.prototype.getAvailableOptions = function(langCode) {
    var parentRecord = this;
    var availOptions = ITEM_OPTIONS.map(function(o) {
        if (langCode && langCode == "EN") {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: o[1]
            });
        } else {
            return extend(parentRecord.getField(o[0]), {
                label: o[1],
                translation: ""
            });
        }
    }).filter(function(item) {
        return item.value;
    });
    availOptions.forEach(function(item) {
        item.value = item.value.split("");
        item.text = item.text.split("");
        item.options = item.value.map(function(v, i) {
            if (langCode && langCode == "EN") {
                return {
                    id: v,
                    value: item.text[i],
                    translation: item.text[i]
                };
            } else {
                return {
                    id: v,
                    value: item.text[i],
                    translation: ""
                };
            }
        });
        delete item.value;
        delete item.text;
    });
    return availOptions;
};

EbayInventoryItem.prototype.getChildRecord = function() {
    var parentRecord = this;
    var availOptions = this.getAvailableOptions();
    var matrixOptionsColumns = availOptions.map(function(option) {
        return new nlobjSearchColumn(option.name).setLabel(option.label);
    });
    var columns = [ new nlobjSearchColumn("itemid"), new nlobjSearchColumn("upccode"), new nlobjSearchColumn("custitem_item_picture"), new nlobjSearchColumn("custitem_item_var_picture") ];
    columns = columns.concat(matrixOptionsColumns);
    var itemChildRecordSearchResults = nlapiSearchRecord("inventoryitem", null, [ new nlobjSearchFilter("parent", null, "is", parentRecord.getId()), new nlobjSearchFilter("isinactive", null, "is", "F") ], columns);
    var searchList = [];
    if (itemChildRecordSearchResults != null) {
        for (var i = 0, len = itemChildRecordSearchResults.length; i < len; i++) {
            var childRecord = itemChildRecordSearchResults[i];
            var record = {};
            record["__id"] = childRecord.getId();
            record["__type"] = childRecord.getRecordType();
            var options = [];
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var label = column.getLabel();
                var value = childRecord.getValue(column);
                var text = childRecord.getText(column);
                if (value && text) {
                    var optionName = availOptions.filter(function(item) {
                        return item.name == name;
                    });
                    if (optionName.length && optionName.length == 1) {
                        optionName = optionName[0];
                        options.push({
                            label: {
                                name: optionName.name,
                                label: optionName.label,
                                translation: optionName.translation
                            },
                            option: {
                                name: name,
                                value: value,
                                text: text,
                                translation: ""
                            }
                        });
                    } else {
                        record[name] = {
                            value: value,
                            text: text
                        };
                    }
                } else {
                    if (name == "itemid") {
                        if (value.indexOf(" : ") != -1) value = value.substring(value.indexOf(" : ") + 3);
                    }
                    record[name] = value;
                }
            }
            record.options = options;
            searchList.push(record);
        }
    }
    return searchList;
};

EbayInventoryItem.getAvailableOptions = function(parentId, langCode) {
    return new EbayInventoryItem(parentId).getAvailableOptions(langCode);
};

function EbayKitItem(id) {
    EbayItem.call(this, "kititem", id);
}

inherit(EbayItem, EbayKitItem);

EbayKitItem.prototype.getOption = function() {
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var name = "custitem_var_kit";
    var value = [];
    var text = [];
    var options = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        var var_name = line[3].trim();
        index++;
        value.push(id + "_" + index);
        text.push(var_name);
        return {
            id: id + "_" + index,
            value: var_name,
            translation: ""
        };
    });
    return {
        availOptions: [ {
            name: name,
            value: value,
            text: text,
            label: "Kit Variation",
            translation: "",
            options: options
        } ]
    };
};

function getVariationQuantity(id_expression, mainLocation) {
    id_expression = id_expression.map(function(id) {
        var qtyIndex = id.indexOf("*");
        if (qtyIndex != -1) {
            return {
                _id: id.substring(0, qtyIndex),
                _qty: id.substring(qtyIndex + 1)
            };
        } else {
            return {
                _id: id,
                _qty: "1"
            };
        }
    });
    var columns = [];
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", id_expression.map(function(item) {
        return item._id;
    })), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ mainLocation ]) ], columns);
    var list = [];
    if (search != null) {
        search.forEach(function(searchResult, index) {
            var total = searchResult.getValue("formulanumeric");
            _log("total" + index, total);
            if (total) {
                _log("searchResult.getId()", searchResult.getId());
                _log("id_expression", id_expression);
                var qty = id_expression.filter(function(item) {
                    return item._id == searchResult.getId();
                })[0]._qty;
                list.push(Math.floor(parseInt(total) / parseInt(qty)));
            }
        });
    } else {
        return 0;
    }
    _log("getVariationQuantity: " + JSON.stringify(id_expression), list);
    if (list.length) {
        var qty = _.min(list);
        if (!qty) qty = 0;
        _log(typeof qty, qty);
        return qty;
    } else {
        return 0;
    }
}

EbayKitItem.prototype.getChildRecord = function() {
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var childRecordList = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        index++;
        var line_id = line[0].trim();
        var line_sku = line[1].trim();
        var kit_var_id = line_id.replace(/\,/g, "^").replace(/\s/g, "");
        return {
            __id: kit_var_id,
            __type: "KIT_INV",
            itemid: kit_var_id,
            baseprice: line[2].trim(),
            custitem_ebay_variation_picture: "",
            custitem_var_kit: {
                value: id + "_" + index,
                text: line[3].trim(),
                translation: ""
            },
            locationquantityavailable: getVariationQuantity(line_id.split(",").map(function(id) {
                return id.trim();
            }), mainLocation)
        };
    });
    _log("EbayKitItem.prototype.getChildRecord", childRecordList);
    return {
        childRecordList: childRecordList
    };
};

function renderChildRecordOptionsUI(type, form, variations, languageId) {
    form.addTab("custpage_var_tab", "Variation Tab");
    form.addField("custpage_style", "inlinehtml", null, null, null).setDefaultValue('<style type="text/css">.uir-machine-headerrow > td{padding-left: 5px !important;}</style>');
    var variationsList = form.addSubList("custpage_variations", "list", "Variations", "custpage_var_tab");
    variations.forEach(function(item) {
        var linename = "var_" + item.name;
        var linename_translation = linename + "_translation";
        variationsList.addField(linename, "text", item.label, null);
        if (type == "create" || type == "edit") {
            variationsList.addField(linename_translation, "text", '<input type="text" class="variations_translation_title" value="' + item.translation + '" name="' + item.name + '"/>', null);
        } else {
            variationsList.addField(linename_translation, "text", item.translation, null);
        }
        var options = item.options;
        options.forEach(function(opt, index) {
            var line = index + 1;
            variationsList.setLineItemValue(linename, line, opt.value);
            if (type == "create") {
                variationsList.setLineItemValue(linename_translation, line, '<input type="text" ' + 'value="" ' + 'name="' + opt.id + "#" + item.name + "#translation" + '" ' + 'class="variations_translation" ' + 'id="' + opt.id + "_translation" + index + '" />');
            } else {
                if (type == "edit") {
                    variationsList.setLineItemValue(linename_translation, line, '<input type="text" ' + 'value="' + opt.translation + '" ' + 'name="' + opt.id + "#" + item.name + "#translation" + '" ' + 'class="variations_translation" ' + 'id="' + opt.id + "_translation" + index + '" />');
                } else if (type == "view") {
                    variationsList.setLineItemValue(linename_translation, line, opt.translation);
                }
            }
        });
    });
}

function generateTitles(keywords) {
    var limit_count = 24;
    var max_char_per_title = 80;
    var sub_library = [ "for=4", "you=u", "at=@", "two=2", "with=w", "adapter=adpt", "Monokini=Mono 9", "Hip-hop=HH" ].map(function(item) {
        return item.split("=");
    });
    function calc_length(title) {
        return (title.join(" ") + " ").replace("- ", " ").replace("+ ", " ").replace("* ", " ").replace("  ", " ").replace('" ', " ").replace(' "', " ").length - 1;
    }
    function get_all_titles(keywords) {
        var result_titles = [];
        for (var i = 0; i < keywords.length; i++) {
            var word_count = keywords[i].length;
            var words = keywords[i];
            var previous_count = result_titles.length;
            if (previous_count == 0) {
                previous_count = word_count;
                for (var sub_ii = 0; sub_ii < word_count; sub_ii++) {
                    result_titles[sub_ii] = [];
                    result_titles[sub_ii][i] = words[sub_ii];
                }
            } else {
                for (var sub_i = 0; sub_i < word_count; sub_i++) {
                    for (var sub_ii = 0; sub_ii < previous_count; sub_ii++) {
                        if (result_titles[previous_count * sub_i + sub_ii] == undefined) {
                            result_titles[previous_count * sub_i + sub_ii] = result_titles[sub_ii].slice();
                        }
                        result_titles[previous_count * sub_i + sub_ii][i] = words[sub_i];
                    }
                }
            }
        }
        return result_titles;
    }
    function substitute(title) {
        for (var subs_idx = 0; subs_idx < sub_library.length; subs_idx++) {
            var index = title.indexOf(sub_library[subs_idx][0]);
            if (index >= 0) {
                title[index] = sub_library[subs_idx][1];
            }
        }
        return title;
    }
    function shorten_title_length(titles) {
        var result = [];
        var count = 0;
        for (var i = 0; i < titles.length; i++) {
            if (calc_length(titles[i]) > max_char_per_title) {
                titles[i] = substitute(titles[i]);
                if (calc_length(titles[i]) > max_char_per_title) {
                    var words = titles[i];
                    for (var word_idx = 0; word_idx < words.length; word_idx++) {
                        if (words[word_idx].indexOf("/") == words[word_idx].length - 1) {
                            titles[i] = titles[i].splice(word_idx, 1);
                        }
                    }
                    titles[i] = words;
                }
            }
            if (calc_length(titles[i]) <= max_char_per_title) {
                result[count] = titles[i];
                count++;
            } else {}
        }
        return result;
    }
    function change_forward_position(title) {
        var words = title;
        for (var word_idx = 0; word_idx < words.length; word_idx++) {
            if (words[word_idx][words[word_idx].length - 1] == "-") {
                if (word_idx != words.length - 1) {
                    var tmp = words[word_idx];
                    words[word_idx] = words[word_idx + 1];
                    words[word_idx + 1] = tmp;
                    word_idx++;
                }
            }
        }
        title = words;
        return title;
    }
    function change_backward_position(title) {
        var words = title;
        for (var word_idx = 0; word_idx < words.length; word_idx++) {
            if (words[word_idx][words[word_idx].length - 1] == "+") {
                if (word_idx != 0) {
                    var tmp = words[word_idx];
                    words[word_idx] = words[word_idx - 1];
                    words[word_idx - 1] = tmp;
                }
            }
        }
        title = words;
        return title;
    }
    function finalize(titles) {
        for (var i = 0; i < titles.length; i++) {
            var words = titles[i].split(" ");
            for (var word_idx = 0; word_idx < words.length; word_idx++) {
                words[word_idx] = words[word_idx].replace("+", "");
                words[word_idx] = words[word_idx].replace("-", "");
                words[word_idx] = words[word_idx].replace("/", "");
                words[word_idx] = words[word_idx].replace('"', "");
                words[word_idx] = words[word_idx].replace("*", "");
            }
            titles[i] = words.join(" ");
        }
        return titles;
    }
    function generate_title() {
        var all_titles = get_all_titles(keywords);
        if (all_titles.length < limit_count) {}
        all_titles = shorten_title_length(all_titles);
        for (var i = 0; i < all_titles.length; i++) {
            if (Math.random() > .5) {
                all_titles[i] = substitute(all_titles[i]);
            }
        }
        for (var i = 0; i < all_titles.length; i++) {
            if (Math.random() > .5) {
                all_titles[i] = change_backward_position(all_titles[i]);
            }
        }
        for (var i = 0; i < all_titles.length; i++) {
            if (Math.random() > .5) {
                all_titles[i] = change_forward_position(all_titles[i]);
            }
        }
        var list = [];
        for (var i = 0; i < all_titles.length; i++) {
            var title = all_titles[i].map(function(item) {
                item = item.replace(/\+|\-/g, "");
                return item;
            });
            list.push(title.join(" "));
        }
        return list;
    }
    return generate_title();
}

function beforeLoad(type, form, request) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("beforeLoad____________ id: " + id + " recType: " + recType + " type: " + type);
        LanguageSetUserEvent.beforeLoad(type, form, request);
        _log("beforeLoad____________end");
    } catch (e) {
        processException(e);
    }
}

function beforeSubmit(type) {
    try {
        LanguageSetUserEvent.beforeSubmit(type);
    } catch (e) {
        processException(e);
    }
}

function lang_extend(_new_variations, _variations) {
    _new_variations.forEach(function(new_variations, index) {
        var variations = _variations[index];
        for (var prop in new_variations) {
            if (variations.hasOwnProperty(prop)) {
                if (prop == "options") {
                    new_variations[prop].forEach(function(item) {
                        var new_id = item.id;
                        var _item = variations[prop].find(function(__item) {
                            return __item.id == new_id;
                        });
                        if (_item) {
                            extend(item, _item);
                        }
                    });
                } else {
                    new_variations[prop] = variations[prop];
                }
            }
        }
    });
}

var LanguageSetUserEvent = {
    beforeLoad: function(type, form, request) {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        var itemId = nlapiGetFieldValue("custrecord_eil_item_link");
        var variations = null;
        if (type == "create") {
            disabledFields([ "custrecord_eil_variations", "custrecord_eil_variation_item", "custrecord_eil_title_permutations" ]);
            if (itemId) {
                variations = _getItemVariations(itemId);
                if (variations) {
                    _audit("Create language", variations);
                    nlapiSetFieldValue("custrecord_eil_variations", JSON.stringify(variations));
                    nlapiSetFieldValue("custrecord_eil_variation_item", "Yes");
                    renderChildRecordOptionsUI(type, form, variations, null);
                } else {
                    nlapiSetFieldValue("custrecord_eil_variation_item", "No");
                }
            }
        } else if (type == "edit") {
            disabledFields([ "custrecord_eil_variations", "custrecord_eil_variation_item", "custrecord_eil_language", "custrecord_eil_title_permutations" ]);
            variations = nlapiGetFieldValue("custrecord_eil_variations");
            if (variations) {
                variations = JSON.parse(variations);
                renderChildRecordOptionsUI(type, form, variations, nlapiGetFieldValue("custrecord_eil_language"));
            }
        } else if (type == "view") {
            variations = nlapiGetFieldValue("custrecord_eil_variations");
            if (variations) {
                renderChildRecordOptionsUI(type, form, JSON.parse(variations), nlapiGetFieldValue("custrecord_eil_language"));
            }
        }
    },
    beforeSubmit: function(type) {
        if (type == "create") {
            _createOrUpdateTitle();
        } else if (type == "edit") {
            var itemId = nlapiGetFieldValue("custrecord_eil_item_link");
            var custrecord_eil_variation_item = nlapiGetFieldValue("custrecord_eil_variation_item");
            if (custrecord_eil_variation_item == "") {
                var lang = nlapiGetFieldValue("custrecord_eil_language");
                var variations = null;
                if (lang == 1) {
                    variations = _getItemVariations(itemId, "EN");
                } else {
                    variations = _getItemVariations(itemId);
                }
                if (variations) {
                    nlapiSetFieldValue("custrecord_eil_variation_item", "Yes");
                    nlapiSetFieldValue("custrecord_eil_variations", JSON.stringify(variations));
                } else {
                    nlapiSetFieldValue("custrecord_eil_variation_item", "No");
                }
            }
            _createOrUpdateTitle();
        }
    }
};

function _getItemVariations(itemId, langCode) {
    var variations = null;
    if (getItemType(itemId) == "Kit") {
        variations = new EbayKitItem(itemId).getOption();
        _log("Kit var", variations);
    } else if (isMatrixItem(itemId)) {
        variations = EbayInventoryItem.getAvailableOptions(itemId, langCode);
    }
    return variations;
}

function _createOrUpdateTitle() {
    var custrecord_eil_title_permutations = nlapiGetFieldValue("custrecord_eil_title_permutations");
    _log(typeof custrecord_eil_title_permutations, custrecord_eil_title_permutations);
    if (typeof custrecord_eil_title_permutations == "string") {
        custrecord_eil_title_permutations = custrecord_eil_title_permutations.trim();
    }
    var current_keywords = nlapiGetFieldValue("custrecord_eil_title_keywords");
    var keywords_changed = false;
    var oldRecord = nlapiGetOldRecord();
    if (oldRecord) {
        var old_keywords = oldRecord.getFieldValue("custrecord_eil_title_keywords");
        if (old_keywords != current_keywords) {
            keywords_changed = true;
        }
    }
    _log("keywords_changed", keywords_changed);
    if (!custrecord_eil_title_permutations || keywords_changed) {
        current_keywords = current_keywords.split("\r\n");
        current_keywords = current_keywords.map(function(item) {
            return item.trim();
        });
        var current_keywords_array = [];
        current_keywords.forEach(function(keywordsLine) {
            var kList = keywordsLine.split(",");
            kList = kList.map(function(w) {
                return w.trim();
            });
            current_keywords_array.push(kList);
        });
        _log("current_keywords_array", current_keywords_array);
        var title_permutations = generateTitles(current_keywords_array);
        title_permutations = title_permutations.map(function(title) {
            return {
                title: title,
                referId: null
            };
        });
        _log("title_permutations", title_permutations);
        if (title_permutations.length) {
            nlapiSetFieldValue("custrecord_eil_title_permutations", JSON.stringify(title_permutations));
        }
    }
}

function createTitleList(keywords) {
    var titleList = [];
    function recurse(s, attrs, k) {
        var args = Array.prototype.slice.call(arguments);
        if (k == attrs.length) {
            titleList.push(s);
        } else {
            for (var i = 0; i < attrs[k].length; i++) {
                if (s == "") {
                    recurse(s + attrs[k][i], attrs, k + 1);
                } else {
                    recurse(s + " " + attrs[k][i], attrs, k + 1);
                }
            }
        }
    }
    recurse("", keywords, 0);
    titleList = titleList.map(function(title) {
        return {
            title: title,
            isUsed: false
        };
    });
    return titleList;
}