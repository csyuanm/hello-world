function beforeLoad(type, form, request) {}

function beforeSubmit(type) {}