var RUNNING_ACCOUNT = {};

function runPost(datain) {
    var info = datain.__info;
    RUNNING_ACCOUNT.EBAY_ACCOUNT_ID = info.EBAY_ACCOUNT_ID;
    var PageNumber = info.pageNumber;
    var timefrom = info.timefrom;
    var timeto = info.timeto;
    var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [ new nlobjSearchFilter("internalid", null, "is", info.EBAY_ACCOUNT_ID) ], [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_ebay_api_token"), new nlobjSearchColumn("custrecord_ebay_global_site_access"), new nlobjSearchColumn("custrecord_ea_subsidiary"), new nlobjSearchColumn("custrecord_ebay_shortname"), new nlobjSearchColumn("custrecord_ebay_account_storefront") ]);
    _log("ebayAccountSearch.length", ebayAccountSearch.length);
    RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN = ebayAccountSearch[0].getValue("custrecord_ebay_api_token");
    RUNNING_ACCOUNT.SUBSIDIARY = ebayAccountSearch[0].getValue("custrecord_ea_subsidiary");
    RUNNING_ACCOUNT.STOREFRONT = ebayAccountSearch[0].getValue("custrecord_ebay_account_storefront");
    var ebay_account = ebayAccountSearch[0];
    var ebayAccountName = ebay_account.getValue("name");
    var GetOrdersResponse = datain.__response;
    refactoryOrdersResponse(GetOrdersResponse.GetOrdersResponse);
    GetOrdersResponse = GetOrdersResponse.GetOrdersResponse;
    var exeReport = [];
    exeReport.push("PageNumber: " + PageNumber);
    exeReport.push("ReturnedOrderCountActual: " + GetOrdersResponse.ReturnedOrderCountActual);
    if (GetOrdersResponse.Ack == "Success" || GetOrdersResponse.Ack == "Warning") {
        if (GetOrdersResponse.Ack == "Warning") {
            _log_email("Ebay get order 有点问题", JSON.stringify(datain));
        }
        if (GetOrdersResponse.ReturnedOrderCountActual != "0") {
            var OrderArray = GetOrdersResponse.OrderArray;
            if (OrderArray) {
                var Order = GetOrdersResponse.OrderArray.Order;
                for (var i = 0; i < Order.length; i++) {
                    var _Order = Order[i];
                    _log("SRN: -------------------------", _Order.ShippingDetails.SellingManagerSalesRecordNumber);
                    try {
                        var OrderResult = createEbaySalesOrder(_Order, ebay_account);
                        exeReport.push(ebayAccountName + " -- OrderID: " + _Order.OrderID + " / SRN: " + _Order.ShippingDetails.SellingManagerSalesRecordNumber + " ---> OrderID: " + OrderResult.id + " --- " + JSON.stringify(OrderResult));
                    } catch (e) {
                        e = parseException(e);
                        nlapiSendEmail(530, "allan@zakeusa.com", ebayAccountName + " / " + e.code + " - RANGE: " + timefrom + "-" + timeto, e.message + JSON.stringify(_Order));
                        _log(e.ERROR_CODE, e.message);
                        exeReport.push("ERROR! " + ebayAccountName + " -- OrderID: " + _Order.OrderID + " / SRN: " + _Order.ShippingDetails.SellingManagerSalesRecordNumber + " ---> " + e.userMessage);
                    }
                    checkGovernance();
                }
            }
        } else {
            _audit("ORDER SIZE: 0");
        }
    } else {
        _log_email("Ebay Ack Error", GetOrdersResponse.Ack + "\r\n" + JSON.stringify(GetOrdersResponse.Errors));
    }
    _audit(exeReport, exeReport);
    RUNNING_ACCOUNT = {};
    return {
        success: true,
        exeReport: exeReport
    };
}

function refactoryOrdersResponse(GetOrdersResponse) {
    if (GetOrdersResponse.hasOwnProperty("OrderArray") && GetOrdersResponse.OrderArray.Order) {
        if (!Array.isArray(GetOrdersResponse.OrderArray.Order)) {
            GetOrdersResponse.OrderArray.Order = [ GetOrdersResponse.OrderArray.Order ];
        }
        GetOrdersResponse.OrderArray.Order.forEach(function(Order) {
            if (!Array.isArray(Order.TransactionArray.Transaction)) {
                Order.TransactionArray.Transaction = [ Order.TransactionArray.Transaction ];
            }
            if (Order.MonetaryDetails) {
                if (!Array.isArray(Order.MonetaryDetails.Payments.Payment)) {
                    Order.MonetaryDetails.Payments.Payment = [ Order.MonetaryDetails.Payments.Payment ];
                }
            }
            Order.ExternalTransaction = _toarray(Order.ExternalTransaction);
        });
    }
}

function makeNSEbayID(id) {
    return "EBAY" + id;
}

function createEbaySalesOrder(ebay_order, ebay_account) {
    _log("ebay_order Status", ebay_order.OrderStatus);
    var createdTime = ebay_order.CreatedTime;
    createdTime = new Date(createdTime);
    createdTime = createdTime.format("yyyy/MM/dd");
    var startTime = new Date(new Date().getTime() - 6 * 7 * 24 * 60 * 60 * 1e3);
    startTime = startTime.format("yyyy/MM/dd");
    _log("time range", createdTime + " --- start from: " + startTime);
    if (DateCompare.compare(createdTime, startTime) == -1) {
        return {
            success: false,
            code: "ORDER_CREATE_TIME_ON_3_WEEKS_AGO",
            id: null
        };
    }
    if (ebay_order.hasOwnProperty("ShippedTime")) {
        return {
            success: false,
            code: "ORDER_HAS_BEEN_SHIPPED",
            id: null
        };
    }
    var isSomeTrackingDetails = ebay_order.TransactionArray.Transaction.some(function(item) {
        return item.hasOwnProperty("ShippingDetails") && item.ShippingDetails.hasOwnProperty("ShipmentTrackingDetails");
    });
    if (isSomeTrackingDetails) {
        return {
            success: false,
            code: "isSomeTrackingDetails",
            id: null
        };
    }
    if (!ebay_order.hasOwnProperty("MonetaryDetails")) {
        return {
            success: false,
            code: "PAYMENT_FALSE",
            id: null
        };
    }
    if (ebay_order.CancelStatus == "NotApplicable" || ebay_order.CancelStatus == "CancelRejected") {
        var PaymentStatus = ebay_order.MonetaryDetails.Payments.Payment.every(function(Payment) {
            return Payment.PaymentStatus == "Succeeded";
        });
        if (ebay_order.hasOwnProperty("PaidTime") && PaymentStatus == true && ebay_order.CheckoutStatus.eBayPaymentStatus == "NoPaymentFailure" && ebay_order.CheckoutStatus.Status == "Complete") {
            var searchExistingOrder = nlapiSearchRecord("salesorder", null, [ new nlobjSearchFilter("externalid", null, "is", makeNSEbayID(ebay_order.OrderID)) ]);
            if (searchExistingOrder != null) {
                return {
                    success: true,
                    code: "EXISTING_SALES_ORDER",
                    id: searchExistingOrder[0].getId()
                };
            }
            var Transaction = ebay_order.TransactionArray.Transaction[0];
            if (!Transaction.Buyer.UserFirstName) {
                Transaction.Buyer.UserFirstName = "*";
            }
            var customerId = saveOrUpdateCustomer(ebay_order, Transaction);
            var customform_id = "178";
            if (IS_NS_SANDBOX) {
                customform_id = "150";
            }
            var memo = [];
            var salesOrder = nlapiCreateRecord("salesorder", {
                recordmode: "dynamic",
                customform: customform_id
            });
            if (ebay_order.CheckoutStatus.PaymentMethod == "CreditCard" || ebay_order.CheckoutStatus.PaymentMethod == "IntegratedMerchantCreditCard") {
                salesOrder.setFieldValue("orderstatus", "A");
                memo.push("The order payment method is CC processed, Please check and manually approve.");
            } else {
                salesOrder.setFieldValue("orderstatus", "B");
            }
            salesOrder.setFieldValue("entity", customerId.id);
            salesOrder.setFieldValue("location", 2);
            salesOrder.setFieldValue("custbody_ebay_seller_id", ebay_order.SellerUserID);
            salesOrder.setFieldValue("custbody_ebay_order_status", ebay_order.OrderStatus);
            salesOrder.setFieldValue("externalid", makeNSEbayID(ebay_order.OrderID));
            salesOrder.setFieldValue("custbody_ebay_order_id", ebay_order.OrderID);
            salesOrder.setFieldValue("custbody_ebay_buyer_id", ebay_order.BuyerUserID);
            var salesRecordNumber = ebay_order.ShippingDetails.SellingManagerSalesRecordNumber;
            salesOrder.setFieldValue("custbody_ebay_sales_record_number", salesRecordNumber);
            salesOrder.setFieldValue("otherrefnum", ebay_account.getValue("custrecord_ebay_shortname") + salesRecordNumber);
            salesOrder.setFieldValue("custbody_storefront_order", salesRecordNumber);
            salesOrder.setFieldValue("custbody_storefront", ebay_order.SellerUserID);
            if (RUNNING_ACCOUNT.STOREFRONT) {
                salesOrder.setFieldValue("custbody_storefront_list", RUNNING_ACCOUNT.STOREFRONT);
            }
            salesOrder.setFieldValue("custbody_marketplace", "3");
            var shippingService = ebay_order.ShippingServiceSelected.ShippingService;
            if (parseFloat(ebay_order.ShippingServiceSelected.ShippingServiceCost.__text)) {
                salesOrder.setFieldValue("shippingcost", ebay_order.ShippingServiceSelected.ShippingServiceCost.__text);
            } else {
                salesOrder.setFieldValue("shippingcost", 0);
            }
            var IsMultiLegShipping = ebay_order.IsMultiLegShipping;
            _log("IsMultiLegShipping", IsMultiLegShipping);
            if (IsMultiLegShipping == "true") {
                salesOrder.setFieldValue("custbody_internal_note", "IsMultiLegShipping for True, Please pay attention.");
                shippingService = ebay_order.MultiLegShippingDetails.SellerShipmentToLogisticsProvider.ShippingServiceDetails.ShippingService;
                salesOrder.setFieldValue("shippingcost", 0);
                if (salesOrder.getFieldValue("shipstate") != "KY") {
                    _log_email("KY Sales Order Not in KY " + salesRecordNumber, salesRecordNumber);
                }
            }
            _log("shippingService", shippingService);
            var shipcode_search = nlapiSearchRecord("customrecord_ebay_ss_mapping", null, [ new nlobjSearchFilter("custrecord_ebay_ss_codetype", null, "is", shippingService) ], [ new nlobjSearchColumn("custrecord_ebay_ss_mss") ]);
            if (shipcode_search != null) {
                salesOrder.setFieldValue("custbody_market_ship_serv_lvl", shipcode_search[0].getValue("custrecord_ebay_ss_mss"));
            } else {
                salesOrder.setFieldValue("custbody_market_ship_serv_lvl", 6);
                _log_email("No found eBay ships service mapping", shippingService + "|" + ebay_order.OrderID);
            }
            salesOrder.setFieldValue("custbody_customer_email", customerId.email);
            memo.push("created by ebay connector");
            salesOrder.setFieldValue("memo", memo.join(" "));
            var in_tax_array = [];
            var ebayFee = 0;
            var ebayFeeCurrencyId = "";
            ebay_order.TransactionArray.Transaction.forEach(function(_Transaction, index) {
                commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
            });
            var total = salesOrder.getFieldValue("total");
            if (parseFloat(total) != parseFloat(ebay_order.Total.__text)) {
                if (IsMultiLegShipping != "true") {
                    _log_email("Ebay order total was different", ebay_order.OrderID + " /// " + total + " - " + ebay_order.Total.__text);
                }
            }
            var paypalFee = 0;
            ebay_order.ExternalTransaction.forEach(function(externalTransaction) {
                paypalFee += parseFloat(externalTransaction.FeeOrCreditAmount.__text);
            });
            paypalFee = _mathround(paypalFee);
            salesOrder.setFieldValue("custbody_paypal_fee", paypalFee);
            if (ebay_order.Total._currencyID == "USD") {
                salesOrder.setFieldValue("currency", 1);
            }
            salesOrder.setFieldValue("custbody_api_data", JSON.stringify(ebay_order));
            salesOrder.setFieldValue("custbody_linked_ebay_account", RUNNING_ACCOUNT.EBAY_ACCOUNT_ID);
            if (ebay_order.hasOwnProperty("ExternalTransaction") && Array.isArray(ebay_order.ExternalTransaction)) {
                var ppid = ebay_order.ExternalTransaction.map(function(item) {
                    return item.ExternalTransactionID;
                });
                if (ppid.length > 1) {
                    _log_email("ppid 大于1", ppid.join(", "));
                }
                salesOrder.setFieldValue("custbody_paypal_transaction_id", ppid.join(","));
            }
            var id = nlapiSubmitRecord(salesOrder, true);
            _log("sales order has been created", id);
            return {
                success: true,
                code: "NEW_SALES_ORDER",
                id: id
            };
        } else {
            return {
                success: false,
                code: "PAYMENT_FALSE",
                id: null
            };
        }
    } else {
        return {
            success: false,
            code: "CancelStatus_is_not_NotApplicable",
            id: null
        };
    }
}

function commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index) {
    var sku = null;
    var ebayItemId = null;
    if (_Transaction.hasOwnProperty("Variation")) {
        sku = _Transaction.Variation.SKU;
        ebayItemId = _Transaction.Variation.ItemID;
    } else {
        sku = _Transaction.Item.SKU;
        ebayItemId = _Transaction.Item.ItemID;
    }
    var atIndex = sku.indexOf("|");
    if (atIndex != -1) {
        sku = sku.split("|");
        sku = sku[0];
    }
    var iteminfo = searchNetSuiteItem(sku, ebay_order.OrderID);
    _log("iteminfo", iteminfo);
    if (Array.isArray(iteminfo)) {
        iteminfo.forEach(function(_item, comboIndex) {
            salesOrder.selectNewLineItem("item");
            salesOrder.setCurrentLineItemValue("item", "item", _item.id);
            salesOrder.setCurrentLineItemValue("item", "location", _item.location);
            salesOrder.setCurrentLineItemValue("item", "quantity", parseInt(_Transaction.QuantityPurchased) * parseInt(_item.qty));
            salesOrder.setCurrentLineItemValue("item", "price", -1);
            if (comboIndex === 0) {
                salesOrder.setCurrentLineItemValue("item", "custcol_linked_kit", _item.kit_id);
                salesOrder.setCurrentLineItemValue("item", "rate", parseFloat(_Transaction.TransactionPrice.__text) / parseInt(_item.qty));
            } else {
                salesOrder.setCurrentLineItemValue("item", "rate", 0);
            }
            _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
            salesOrder.commitLineItem("item");
        });
    } else if (iteminfo.hasOwnProperty("qty")) {
        salesOrder.selectNewLineItem("item");
        salesOrder.setCurrentLineItemValue("item", "item", iteminfo.id);
        salesOrder.setCurrentLineItemValue("item", "location", iteminfo.location);
        salesOrder.setCurrentLineItemValue("item", "quantity", parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty));
        salesOrder.setCurrentLineItemValue("item", "price", -1);
        salesOrder.setCurrentLineItemValue("item", "rate", parseFloat(_Transaction.TransactionPrice.__text) / (parseInt(_Transaction.QuantityPurchased) * parseInt(iteminfo.qty)));
        _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
        salesOrder.commitLineItem("item");
    } else {
        salesOrder.selectNewLineItem("item");
        salesOrder.setCurrentLineItemValue("item", "item", iteminfo.id);
        salesOrder.setCurrentLineItemValue("item", "location", iteminfo.location);
        salesOrder.setCurrentLineItemValue("item", "quantity", _Transaction.QuantityPurchased);
        salesOrder.setCurrentLineItemValue("item", "price", -1);
        salesOrder.setCurrentLineItemValue("item", "rate", _Transaction.TransactionPrice.__text);
        _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index);
        salesOrder.commitLineItem("item");
    }
}

function _commitLineItem(salesOrder, _Transaction, ebay_order, in_tax_array, index) {
    salesOrder.setCurrentLineItemValue("item", "custcol_ebay_item_id", _Transaction.Item.ItemID);
    _log("Order.ShippingDetails.SalesTax.SalesTaxState", ebay_order.ShippingDetails.SalesTax.SalesTaxState);
    salesOrder.setCurrentLineItemValue("item", "custcol_ebay_transaction_id", _Transaction.TransactionID);
    salesOrder.setCurrentLineItemValue("item", "custcol_ebay_transaction_site_id", _Transaction.TransactionSiteID);
    salesOrder.setCurrentLineItemValue("item", "custcol_ebay_item_sku", _Transaction.Item.SKU);
    if (ebay_order.ShippingDetails.SalesTax.SalesTaxState.toUpperCase() == "IN" && parseInt(ebay_order.ShippingDetails.SalesTax.SalesTaxPercent) == 7) {
        in_tax_array.push(index + 1);
        salesOrder.setCurrentLineItemValue("item", "taxcode", "10");
    }
}

function filterSearchResult(sku, items) {
    var arr = [ "itemid", "custitem_legacy_3b_sku", "custitem_legacy_3b_sku_2", "custitem_legacy_3b_sku_3" ];
    for (var i = 0; i < arr.length; i++) {
        var name = arr[i];
        var item = items.filter(function(item) {
            return item[name] == sku;
        });
        if (item.length == 1) {
            return item[0];
        }
    }
    return false;
}

var DEFAULT_LOCATION = "2";

function searchNetSuiteItem(sku, ebay_order_id, onlyInventoryItemTag) {
    _log("searchNetSuiteItem with SKU:", sku);
    var columns = new Array();
    columns[0] = new nlobjSearchColumn("internalid");
    columns[1] = new nlobjSearchColumn("itemid");
    columns[2] = new nlobjSearchColumn("custitem_legacy_3b_sku");
    columns[3] = new nlobjSearchColumn("custitem_legacy_3b_sku_2");
    columns[4] = new nlobjSearchColumn("custitem_legacy_3b_sku_3");
    var search = nlapiSearchRecord("item", null, [ [ "subsidiary", "is", Subsidiaries.ZakeInternational ], "AND", [ [ "name", "is", sku ], "OR", [ "custitem_legacy_3b_sku", "is", sku ], "OR", [ "custitem_legacy_3b_sku_2", "is", sku ], "OR", [ "custitem_legacy_3b_sku_3", "is", sku ] ] ], columns);
    if (search != null) {
        if (search.length > 1) {
            var filterResult = filterSearchResult(sku, search.map(function(sr) {
                return {
                    id: sr.getId(),
                    itemid: sr.getValue("itemid"),
                    custitem_legacy_3b_sku: sr.getValue("custitem_legacy_3b_sku"),
                    custitem_legacy_3b_sku_2: sr.getValue("custitem_legacy_3b_sku_2"),
                    custitem_legacy_3b_sku_3: sr.getValue("custitem_legacy_3b_sku_3")
                };
            }));
            if (filterResult == false) {
                throw createEbayError("1 more same SKU on system! SKU: " + sku);
            } else {
                return {
                    id: filterResult.id,
                    location: DEFAULT_LOCATION
                };
            }
        } else {
            return {
                id: search[0].getId(),
                location: DEFAULT_LOCATION
            };
        }
    } else {
        if (!onlyInventoryItemTag) {
            return searchUSKitItem(sku, ebay_order_id);
        }
    }
}

function searchUSKitItem(kitSku, ebay_order_id) {
    var kitSearch = nlapiSearchRecord("customrecord_kit", null, [ [ "custrecord_kit_subsidiary", "is", Subsidiaries.ZakeInternational ], "AND", [ [ "custrecord_kit_sku", "is", kitSku ], "OR", [ "custrecord_sku_alias", "is", kitSku ] ] ], [ new nlobjSearchColumn("custrecord_kit_mapping") ]);
    if (kitSearch != null) {
        if (kitSearch.length == 1) {
            var kitMapping = kitSearch[0].getValue("custrecord_kit_mapping");
            var kit_id = kitSearch[0].getId();
            kitMapping = kitMapping.split(";");
            var itemResult = [];
            for (var i = 0; i < kitMapping.length; i++) {
                var mapping = kitMapping[i];
                var subSKU = mapping.substring(0, mapping.indexOf("="));
                var qty = parseInt(mapping.substring(mapping.indexOf("=") + 1));
                var item = searchNetSuiteItem(subSKU, null, true);
                item.qty = qty;
                item.kit_id = kit_id;
                itemResult.push(item);
            }
            _log_email("dictionarySearchResults: " + kitSku, kitSku + ", " + ebay_order_id);
            return itemResult;
        } else {
            throw createEbayError("kitSearch: search result size wrong! SKU: " + kitSku + " and search size: " + kitSearch.length);
        }
    } else {
        throw createEbayError("kitSearch: No " + kitSku + " SKU on NetSuite for ---------------.");
    }
}

function searchComboItem(sku) {
    sku = sku.trim();
    var columns = new Array();
    columns[0] = new nlobjSearchColumn("internalid");
    columns[1] = new nlobjSearchColumn("itemid");
    columns[2] = new nlobjSearchColumn("description");
    var search = nlapiSearchRecord("item", null, [ [ "name", "is", sku ], "OR", [ "custitem_legacy_3b_sku", "is", sku ], "OR", [ "custitem_legacy_3b_sku_2", "is", sku ], "OR", [ "custitem_legacy_3b_sku_3", "is", sku ] ], columns);
    if (search != null) {
        if (search.length > 1) {
            throw createEbayError("1 more same SKU on system! SKU: " + sku);
        } else {
            return search[0].getId();
        }
    } else {
        throw createEbayError("No " + sku + " SKU on NetSuite");
    }
}

function GetSellingManagerSaleRecordRequest(orderId) {
    _audit("GetSellingManagerSaleRecordRequest", orderId);
    var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<GetSellingManagerSaleRecordRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "        <eBayAuthToken>" + RUNNING_ACCOUNT.EBAY_ACCOUNT_TOKEN + "</eBayAuthToken>", "  </RequesterCredentials>", "  <OrderID>" + orderId + "</OrderID>", "</GetSellingManagerSaleRecordRequest>" ].join("");
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(EbayRequest.headers, {
        "X-EBAY-API-SITEID": "0",
        "X-EBAY-API-CALL-NAME": "GetSellingManagerSaleRecord",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "945"
    }));
    response = new X2JS().xml_str2json(response.getBody());
    var email = response.GetSellingManagerSaleRecordResponse.SellingManagerSoldOrder.BuyerEmail;
    if (isValidEmailAddress(email)) {
        return email;
    } else {
        return "";
    }
}

function isValidEmailAddress(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}

function getCustomerEmail(Transaction, orderId) {
    var Email = Transaction.Buyer.Email;
    var EbayMemberEmail = Transaction.Buyer.StaticAlias;
    if (Email) {
        if (Email == "Invalid Request") {
            return GetSellingManagerSaleRecordRequest(orderId);
        } else {
            return Email;
        }
    } else {
        return GetSellingManagerSaleRecordRequest(orderId);
    }
}

function createCustomerRecord(Transaction, _ShippingAddress, _BillingAddress, _email) {
    _log("New for customer");
    var newCustomerRecord = nlapiCreateRecord("customer");
    newCustomerRecord.setFieldValue("subsidiary", RUNNING_ACCOUNT.SUBSIDIARY);
    newCustomerRecord.setFieldValue("isperson", "T");
    if (Transaction.Buyer.UserFirstName) {
        newCustomerRecord.setFieldValue("firstname", Transaction.Buyer.UserFirstName);
    } else {
        newCustomerRecord.setFieldValue("firstname", "*");
    }
    if (Transaction.Buyer.UserLastName.length > 32) {
        newCustomerRecord.setFieldValue("lastname", Transaction.Buyer.UserLastName.substring(0, 32));
    } else {
        newCustomerRecord.setFieldValue("lastname", Transaction.Buyer.UserLastName);
    }
    newCustomerRecord.setFieldValue("phone", _ShippingAddress.phone);
    if (_email) newCustomerRecord.setFieldValue("email", _email);
    if (_BillingAddress == null) {
        setAddressLine(newCustomerRecord, _ShippingAddress);
    } else {
        setAddressLine(newCustomerRecord, _ShippingAddress, "defaultshipping");
        setAddressLine(newCustomerRecord, _BillingAddress, "defaultbilling");
    }
    return nlapiSubmitRecord(newCustomerRecord, true);
}

function _processCountryCode(countryCode) {
    if (countryCode == "AA") {
        return "US";
    }
    return countryCode;
}

function hasWhiteSpace(s) {
    return /\s/g.test(s);
}

function saveOrUpdateCustomer(Order, Transaction) {
    var firstname = Transaction.Buyer.UserFirstName;
    if (firstname.length > 32) {
        firstname = firstname.substring(0, 32);
        Transaction.Buyer.UserFirstName = firstname;
    }
    var SUBSIDIARY = RUNNING_ACCOUNT.SUBSIDIARY;
    var ShippingAddress = Order.ShippingAddress;
    var phone = ShippingAddress.Phone;
    if (Array.isArray(phone) && phone.length == 0) {
        phone = "";
    } else {
        phone = phone.replace(/\s+/g, "");
        phone = phone.trim();
        phone = phone.substring(0, 10);
    }
    ShippingAddress.Phone = phone;
    var _ShippingAddress = {
        country: _processCountryCode(ShippingAddress.Country),
        state: ShippingAddress.StateOrProvince,
        city: ShippingAddress.CityName,
        addr1: ShippingAddress.Street1,
        addr2: ShippingAddress.Street2,
        addressee: ShippingAddress.Name,
        zip: ShippingAddress.PostalCode,
        phone: ShippingAddress.Phone || Order.ShippingAddress.Phone || ""
    };
    var _BillingAddress = null;
    if (Order.IsMultiLegShipping == "true") {
        _BillingAddress = _ShippingAddress;
        var logisticAddress = Order.MultiLegShippingDetails.SellerShipmentToLogisticsProvider.ShipToAddress;
        _ShippingAddress = {
            country: _processCountryCode(logisticAddress.Country),
            state: logisticAddress.StateOrProvince,
            city: logisticAddress.CityName,
            addr1: logisticAddress.Street1,
            addr2: logisticAddress.Street2 || "",
            addressee: logisticAddress.ReferenceID,
            zip: logisticAddress.PostalCode,
            phone: ShippingAddress.Phone || Order.ShippingAddress.Phone || ""
        };
    }
    var _email = getCustomerEmail(Transaction, Order.OrderID);
    if (_email.indexOf(".@") != -1) {
        _email = _email.replace(".@", "@");
    }
    var id = null;
    if (_email) {
        var filter = [ new nlobjSearchFilter("isinactive", null, "is", "F") ];
        filter.push(new nlobjSearchFilter("email", null, "is", _email));
        filter.push(new nlobjSearchFilter("subsidiary", null, "is", SUBSIDIARY));
        var customerSearch = nlapiSearchRecord("customer", null, filter);
        if (customerSearch == null) {
            id = createCustomerRecord(Transaction, _ShippingAddress, _BillingAddress, _email);
        } else {
            _log("Update for the customer");
            var customerId = customerSearch[0].getId();
            var existingCustomerRecord = nlapiLoadRecord("customer", customerId);
            if (_BillingAddress == null) {
                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log("Set new address _ShippingAddress for existing customer");
                    setAddressLine(existingCustomerRecord, _ShippingAddress);
                } else {
                    existingCustomerRecord.setLineItemValue("addressbook", "defaultshipping", existingShippingAddress.linenumber, "T");
                    existingCustomerRecord.setLineItemValue("addressbook", "defaultbilling", existingShippingAddress.linenumber, "T");
                }
            } else {
                var existingBillingAddress = lookupExistingAddress(existingCustomerRecord, _BillingAddress);
                if (existingBillingAddress.addressId == null) {
                    _log("Set new address _BillingAddress for existing customer");
                    setAddressLine(existingCustomerRecord, _BillingAddress, "defaultbilling");
                } else {
                    if (existingCustomerRecord.getLineItemValue("addressbook", "defaultbilling", existingBillingAddress.linenumber) !== "T") {
                        existingCustomerRecord.setLineItemValue("addressbook", "defaultbilling", existingBillingAddress.linenumber, "T");
                    }
                }
                var existingShippingAddress = lookupExistingAddress(existingCustomerRecord, _ShippingAddress);
                if (existingShippingAddress.addressId == null) {
                    _log("Set new address existingShippingAddress2222 for existing customer");
                    setAddressLine(existingCustomerRecord, _ShippingAddress, "defaultshipping");
                } else {
                    if (existingCustomerRecord.getLineItemValue("addressbook", "defaultshipping", existingShippingAddress.linenumber) !== "T") {
                        existingCustomerRecord.setLineItemValue("addressbook", "defaultshipping", existingShippingAddress.linenumber, "T");
                    }
                }
            }
            existingCustomerRecord.setFieldValue("isperson", "T");
            existingCustomerRecord.setFieldValue("firstname", Transaction.Buyer.UserFirstName);
            existingCustomerRecord.setFieldValue("lastname", Transaction.Buyer.UserLastName);
            if (existingCustomerRecord.getFieldValue("phone") && ShippingAddress.Phone != existingCustomerRecord.getFieldValue("phone")) {
                existingCustomerRecord.setFieldValue("altphone", existingCustomerRecord.getFieldValue("phone"));
                existingCustomerRecord.setFieldValue("phone", ShippingAddress.Phone);
            } else {
                existingCustomerRecord.setFieldValue("phone", ShippingAddress.Phone);
            }
            id = nlapiSubmitRecord(existingCustomerRecord, true);
        }
    } else {
        nlapiSendEmail(530, "allan@zakeusa.com,johnny@zake.com", "[EBAY_ORDER_NOTIES] ID:" + Order.OrderID, "THE ORDER NO EMAIL.");
        id = createCustomerRecord(Transaction, ShippingAddress, _ShippingAddress, _email);
    }
    return {
        id: id,
        email: _email
    };
}

function setAddressLine(customer, addressObject, specificField) {
    customer.selectNewLineItem("addressbook");
    for (var name in addressObject) {
        customer.setCurrentLineItemValue("addressbook", name, addressObject[name]);
    }
    if (specificField) {
        customer.setCurrentLineItemValue("addressbook", specificField, "T");
    } else {
        customer.setCurrentLineItemValue("addressbook", "defaultshipping", "T");
        customer.setCurrentLineItemValue("addressbook", "defaultbilling", "T");
    }
    customer.commitLineItem("addressbook");
}

function lookupExistingAddress(customer, addressObject) {
    var addressId = null;
    var linenumber = null;
    var lineCount = customer.getLineItemCount("addressbook");
    if (lineCount) {
        for (var line = 1; line <= lineCount; line++) {
            var address = {
                country: customer.getLineItemValue("addressbook", "country", line),
                state: customer.getLineItemValue("addressbook", "state", line),
                city: customer.getLineItemValue("addressbook", "city", line),
                zip: customer.getLineItemValue("addressbook", "zip", line),
                addressee: customer.getLineItemValue("addressbook", "addressee", line),
                addr1: customer.getLineItemValue("addressbook", "addr1", line),
                addr2: customer.getLineItemValue("addressbook", "addr2", line),
                phone: customer.getLineItemValue("addressbook", "phone", line)
            };
            if (exactlySame(address, addressObject)) {
                addressId = customer.getLineItemValue("addressbook", "id", line);
                linenumber = line;
                break;
            }
        }
    }
    return {
        addressId: addressId,
        linenumber: linenumber
    };
}

function _fieldProcess(key, value) {
    if (key == "phone") {
        return trimPhone(value);
    } else {
        if (!value) value = "";
        return value;
    }
}

function exactlySame(address, orderAddress) {
    for (var key in address) {
        var field1 = address[key];
        field1 = _fieldProcess(key, field1);
        if (orderAddress.hasOwnProperty(key)) {
            var field2 = orderAddress[key];
            field2 = _fieldProcess(key, field2);
            if (field1 !== field2) {
                _log("different in " + key);
                return false;
            }
        } else {
            _log("Not in " + key);
            return false;
        }
    }
    return true;
}

function trimPhone(phone) {
    if (!phone) {
        phone = "";
    }
    if (typeof phone !== "string") phone = phone.toString();
    var regx = new RegExp("[^0-9]", "g");
    phone = phone.replace(regx, "");
    return phone;
}