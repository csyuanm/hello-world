var EBAY_UPLOAD_TRACKING_NUMBER_ACCOUNTS = [
    {
        "InternalID": 12,
        "Name": "beauty-locker",
        "Shortname": "BL"
    },

    {
        "InternalID": 15,
        "Name": "claimthis",
        "Shortname": "CLT"
    },
    {
        "InternalID": 34,
        "Name": "globalsalelovely",
        "Shortname": "GSL"
    },
    {
        "InternalID": 16,
        "Name": "maggieknows",
        "Shortname": "MK"
    }
];