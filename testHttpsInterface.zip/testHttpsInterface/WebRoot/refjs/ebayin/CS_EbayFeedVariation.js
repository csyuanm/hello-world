var SL_URL = {
    EbayFeed: "/app/site/hosting/scriptlet.nl?script=114&deploy=1",
    EbayItem: "/app/site/hosting/scriptlet.nl?script=470&deploy=1"
};

function post_to_url(path, params, method) {
    method = method || "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    form.setAttribute("target", "_blank");
    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }
    }
    document.body.appendChild(form);
    form.submit();
}

function openNewTab(url) {
    window.open(url, "_blank");
    window.focus();
}

function bindSelectFn($element, config) {
    var $ = this.jQuery;
    var defaultConfig = {
        highlightClass: "warning"
    };
    config = config || {};
    config = $.extend(defaultConfig, config);
    var $selectAll = $element.find(".selectAll");
    if ($selectAll.length) {
        $selectAll.on("click", function(e) {
            if ($(this).prop("checked") == true) {
                $element.find(".select").each(function() {
                    $(this).prop("checked", true);
                    $(this).closest("tr").addClass(config.highlightClass);
                });
            } else {
                $element.find(".select").each(function() {
                    $(this).prop("checked", false);
                    $(this).closest("tr").removeClass(config.highlightClass);
                });
            }
        });
    }
    var $select = $element.find(".select");
    var select_length = $select.length;
    if ($select.length) {
        $select.on("click", function() {
            var $checkbox = $(this);
            var $tr = $(this).closest("tr");
            var selectList = [];
            $select.each(function() {
                selectList.push($(this).prop("checked"));
            });
            if ($checkbox.prop("checked") == true) {
                $tr.addClass(config.highlightClass);
                var allSelected = selectList.filter(function(item) {
                    return item == true;
                });
                if (allSelected.length == select_length) {
                    $selectAll.length && $selectAll.prop("checked", true);
                }
            } else {
                $tr.removeClass(config.highlightClass);
                var allCancelled = selectList.filter(function(item) {
                    return item == false;
                });
                if (allCancelled.length == select_length) {
                    $selectAll.length && $selectAll.prop("checked", false);
                }
            }
        });
    }
    if (config.hasOwnProperty("allSelected")) {
        if (config.allSelected == true) {
            window.setTimeout(function() {
                $selectAll.trigger("click");
            }, 300);
        }
    }
}

function loadCSS(filename) {
    var fileref = document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function loadJavaScript(filename) {
    var fileref = document.createElement("script");
    fileref.setAttribute("type", "text/javascript");
    fileref.setAttribute("src", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function parseToJSON(data) {
    try {
        if (typeof data == "string") {
            data = data.replace(/(<!--(?:(?!-->).)*-->)/g, "").replace(/\r\n|\n/g, "").trim();
            data = JSON.parse(data);
        }
    } catch (e) {
        if (typeof this.alert == "function") alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

function parseToJSON2(data) {
    if (typeof data == "object") return data;
    try {
        if (typeof data == "string") {
            data = JSON.parse(data);
        }
    } catch (e) {
        if (typeof this.alert == "function") alert(data + " parseDataToJSON on Error!");
        return;
    }
    return data;
}

var PageOverlay = {
    __overlay: jQuery("<div class='zake-overlay'><img src='/core/media/media.nl?id=16957&c=277620&h=ea47479825c0844fc16b' /></div>"),
    showOverlay: function() {
        jQuery(document.body).append(PageOverlay.__overlay);
        PageOverlay.__overlay.css({
            "background-color": "#EEE",
            "-moz-opacity": "0.6",
            opacity: "0.6",
            filter: "alpha(opacity=60)",
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "z-index": "1000"
        });
        PageOverlay.__overlay.show();
    },
    removeOverlay: function() {
        PageOverlay.__overlay.remove();
    }
};

(function($, document, window, undefined) {
    var reviseButton = $("#custpage_variation_revise_price");
    var custpage_variation_list_splits = $("#custpage_variation_list_splits");
    custpage_variation_list_splits.find(".var-price").on("input change", function() {
        var $price = $(this);
        if (!isNaN($price.val())) {
            $price.removeClass("var-new");
        }
    });
    window.revisePrice = function() {
        var newLength = custpage_variation_list_splits.find(".var-new").length;
        console.log("newLength: " + newLength);
        if (newLength) {
            alert("Here has come new prices need to revise.");
        } else {
            var matrixList = [];
            custpage_variation_list_splits.find(".uir-list-row-tr").each(function() {
                var $tr = $(this);
                var id = $tr.children(".uir-list-row-cell:eq(0)").html().trim();
                console.log($tr.find(".var-price").html());
                matrixList.push({
                    id: id,
                    price: $tr.find(".var-price").val()
                });
            });
            if (matrixList.length) {
                $.ajax({
                    url: SL_URL.EbayFeed,
                    type: "POST",
                    data: {
                        action: "reviseVariation",
                        feedId: $("#feed_id").val(),
                        matrixList: JSON.stringify(matrixList)
                    },
                    success: function(data) {
                        data = parseToJSON2(data);
                        if (data.success == true) {
                            reviseButton.val("Matrix Price has been REVISED!");
                            window.setTimeout(function() {
                                parent.jQuery.fancybox.close();
                            }, 3e3);
                        }
                    },
                    beforeSend: function() {
                        reviseButton.val("Waiting...").attr("disabled", "disabled");
                    }
                });
            }
        }
    };
})(jQuery, document, window);