function beforeLoad(type, form, request) {
    try {
        var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
        _log("beforeLoad____________ id: " + id + " recType: " + recType + " type: " + type);
        if (type == "create") {
            disabledFields();
        } else if (type == "edit") {
            disabledFields([ "custrecord_ei_language_set", "custrecord_ei_site" ]);
        }
        var itemRecord = nlapiLoadRecord("inventoryitem", nlapiGetFieldValue("custrecord_ei_item_link"));
        var currencySearch = nlapiSearchRecord("currency", null, null, [ new nlobjSearchColumn("name") ]);
        var basePriceList = [];
        currencySearch.forEach(function(currencySearchResult) {
            var priceID = "price" + currencySearchResult.getId();
            basePriceList.push({
                currencyId: currencySearchResult.getId(),
                currencyName: currencySearchResult.getValue("name"),
                basePrice: itemRecord.getLineItemMatrixValue(priceID, "price", 1, 1),
                onlinePrice: itemRecord.getLineItemMatrixValue(priceID, "price", 4, 1)
            });
        });
        form.addField("custpage_ei_inlinehtml", "inlinehtml").setDefaultValue("<script>var __ItemPriceList = " + JSON.stringify(basePriceList) + ";</script>");
        _log("beforeLoad____________end");
    } catch (e) {
        processException(e);
    }
}