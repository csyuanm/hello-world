/**
 * 这个是Ebay feed的批处理程序 脚本
 */
function run() {
    //removePriceFromMDF();
    // batchUpdatePayPalEmailAddress();
    // subFeed2OfflineIfParentIsOnline();
    runBatch();
}

function runBatch() {

    var context = nlapiGetContext();
    var search = nlapiLoadSearch(null, '546');
    search = search.runSearch();
    search = search.getResults(0, 1000);

    var yes = [];
    var no = [];

    var breakTag = false;
    for (var i = 0, len = search.length; i < len; i++) {

        try {
            // if (i == 1) break;
            var id = search[i].getId();

            _log('ran', id);
            var type = search[i].getRecordType();

            var feed = new __EbayFeed(id);
            // feed.setFieldValue('custrecord_ef_template', 11);
            feed.callReviseItem(['custrecord_ef_template']);

            //var rec = nlapiLoadRecord(type, id);
            //rec.setFieldValue('custrecord_ef_template', 11);
            //nlapiSubmitRecord(rec, true);
            yes.push(id);
            checkGovernance();

        } catch (e) {
            e = parseException(e);
            no.push('Issue occurred. ' + e.userMessage);
        }
    }

    _log_email('RunBatch for ebay feed is done', JSON.stringify({
        yes: yes,
        no: no
    }));

    //if (!breakTag) {
    //    if (len == 1000) {
    //        var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
    //        _audit('nlapiScheduleScript', status);
    //    }
    //}

}

function batchUpdatePayPalEmailAddress() {
    var search = nlapiSearchRecord(null, '2654');
    if (search != null) {
        _log('Size', search.length);
        for (var i = 0, len = search.length; i < len; i++) {

            // if (i == 1) break;
            var id = search[i].getId();
            _log('Feed ID', id);
            //var f = nlapiLoadRecord('customrecord_ebay_item_api_feed', id);
            //f.setFieldValue('custrecord_ef_template', 7);
            //nlapiSubmitRecord(f, true);
            var feed = new __EbayFeed(id);
            feed.callReviseItem(['ppEmail']);
        }
    }

}


function subFeed2OfflineIfParentIsOnline() {
    var search = nlapiSearchRecord(null, '2658');
    if (search != null) {
        _log('Size', search.length);
        for (var i = 0, len = search.length; i < len; i++) {

            // if (i == 1) break;
            var id = search[i].getId();
            nlapiSubmitField('customrecord_ebay_item_api_feed', id, 'custrecord_ebay_feed_status', 2);
        }
    }

}

function removePriceFromMDF() {

    var feedSearch = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
        new nlobjSearchFilter('custrecord_ebay_feed_account', null, 'is', '15') //Claimthis
    ], [
        new nlobjSearchColumn('custrecord_ebay_feed_pending_mdf')
    ]);

    feedSearch.forEach(function (searchResult) {

        try {
            var mdf = searchResult.getValue('custrecord_ebay_feed_pending_mdf');

            if (mdf) {
                mdf = JSON.parse(mdf);
                if (Array.isArray(mdf) && mdf.length) {
                    if (mdf.indexOf('custrecord_ebay_feed_api_price') != -1) {
                        mdf.remove('custrecord_ebay_feed_api_price');

                        if (!mdf.length) {
                            // mdf = '';
                            nlapiSubmitField('customrecord_ebay_item_api_feed', searchResult.getId(), 'custrecord_ebay_feed_pending_mdf', '');
                        } else {
                            nlapiSubmitField('customrecord_ebay_item_api_feed', searchResult.getId(), 'custrecord_ebay_feed_pending_mdf', JSON.stringify(mdf));
                        }

                    }
                }
            }


        } catch (e) {
            processException(e);
        }


    })
}