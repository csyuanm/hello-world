var EbayRecordType = {
    customrecord_ebay_item_site_setting: "customrecord_ebay_item_site_setting",
    customrecord_ebay_item_language: "customrecord_ebay_item_language",
    customrecord_ebay_global: "customrecord_ebay_global",
    customrecord_ebay_item_api_feed: "customrecord_ebay_item_api_feed",
    customrecord_ebay_feed_workflow: "customrecord_ebay_feed_workflow",
    customrecord_ebay_account: "customrecord_ebay_account"
};

var EbayRequest = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll",
    headers: {
        "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
        "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
        "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
        "Content-Type": "application/xml"
    },
    call: function(header, xml) {
        try {
            var message = "OK";
            var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(this.headers, header));
            var x2js = new X2JS();
            var responseJSON = x2js.xml_str2json(response.getBody());
            return {
                success: true,
                message: message,
                response: responseJSON
            };
        } catch (e) {
            e = processException(e);
            return {
                success: false,
                message: e.getMessage()
            };
        }
    }
};

var EBAY_ACCOUNT = {
    "beauty-locker": {
        InternalID: 12,
        Name: "beauty-locker",
        Shortname: "BL",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    betterBrand: {
        InternalID: 26,
        Name: "betterBrand",
        Shortname: "BB",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    charmingtango: {
        InternalID: 27,
        Name: "charmingtango",
        Shortname: "CTG",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    claimthis: {
        InternalID: 15,
        Name: "claimthis",
        Shortname: "CLT",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    globalsalelovely: {
        InternalID: 34,
        Name: "globalsalelovely",
        Shortname: "GSL",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    maggieknows: {
        InternalID: 16,
        Name: "maggieknows",
        Shortname: "MK",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    mightyhand: {
        InternalID: 11,
        Name: "mightyhand",
        Shortname: "MH",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    rubykeeper: {
        InternalID: 22,
        Name: "rubykeeper",
        Shortname: "ru",
        Subsidiary: "Zake USA Holding : Zake International"
    },
    alise258: {
        InternalID: 23,
        Name: "alise258",
        Shortname: "Ali",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    "aloha-time": {
        InternalID: 33,
        Name: "aloha-time",
        Shortname: "AE",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    bingdle: {
        InternalID: 20,
        Name: "bingdle",
        Shortname: "BD",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    cardeddy: {
        InternalID: 9,
        Name: "cardeddy",
        Shortname: "CD",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    "chiliman-trading": {
        InternalID: 28,
        Name: "chiliman-trading",
        Shortname: "CM",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    fashioncoconuts: {
        InternalID: 4,
        Name: "fashioncoconuts",
        Shortname: "COC",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    Fashiondriver: {
        InternalID: 21,
        Name: "Fashiondriver",
        Shortname: "fr",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    "finally-here": {
        InternalID: 25,
        Name: "finally-here",
        Shortname: "FH",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    glasscitypool: {
        InternalID: 13,
        Name: "glasscitypool",
        Shortname: "GCP",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    grandpastore: {
        InternalID: 24,
        Name: "grandpastore",
        Shortname: "GP",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    "janet-beautiful": {
        InternalID: 10,
        Name: "janet-beautiful",
        Shortname: "JB",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    juanzi54: {
        InternalID: 19,
        Name: "juanzi54",
        Shortname: "jz",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    juneebdesigns: {
        InternalID: 2,
        Name: "juneebdesigns",
        Shortname: "JD",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    onlinecarolinaretail: {
        InternalID: 3,
        Name: "onlinecarolinaretail",
        Shortname: "OL",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    peacefulocean: {
        InternalID: 6,
        Name: "peacefulocean",
        Shortname: "PC",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    powerstrike: {
        InternalID: 7,
        Name: "powerstrike",
        Shortname: "PW",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    remotefactors: {
        InternalID: 8,
        Name: "remotefactors",
        Shortname: "RMT",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    "roman-lady": {
        InternalID: 31,
        Name: "roman-lady",
        Shortname: "RO",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    royalknight1560: {
        InternalID: 32,
        Name: "royalknight1560",
        Shortname: "RN",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    ryanhotdeals: {
        InternalID: 14,
        Name: "ryanhotdeals",
        Shortname: "RH",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    Shinetogether: {
        InternalID: 29,
        Name: "Shinetogether",
        Shortname: "ST",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    thinkhhard: {
        InternalID: 30,
        Name: "thinkhhard",
        Shortname: "TH",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    winnerslane: {
        InternalID: 5,
        Name: "winnerslane",
        Shortname: "WIN",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    },
    xian_HK: {
        InternalID: 18,
        Name: "xian_HK",
        Shortname: "xHK",
        Subsidiary: "Zake USA Holding : Taiwu International 太武国际"
    }
};

function saveAPICallResult(fileName, arr, info, pageNumber) {
    pageNumber = pageNumber || 1;
    if (!Array.isArray(arr)) {
        throw createEbayError("Params is error and not array");
    }
    fileName += ".txt";
    var folderId = 295527;
    var file = null;
    var content = null;
    if (pageNumber == 1) {
        content = {
            arr: arr
        };
    } else {
        file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
        content = file.getValue();
        content = JSON.parse(content);
        content.arr = content.arr.concat(arr);
    }
    content.arrLenth = content.arr.length;
    content.info = info;
    file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content, null, 2));
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

var EBAY_FEED_STATUS = {
    OFFLINE: 2,
    ONLINE: 1,
    NEW: 8,
    REJECTED: 7,
    SCHEDULED_IN_QUE_NEW: 4,
    SCHEDULED_IN_QUE_NEW_ERROR: 22,
    SCHEDULED_INQUE_RELIST: 18,
    SCHEDULED_INQUE_RELIST_ERROR: 23,
    SCHEDULED_NON_ACTION: 20,
    WAITING_FOR_APPROVAL: 6,
    IN_QUE_NEW: 21
};

var EBAY_FEED_BUTTON = {
    APPROVE: 1,
    DELIST: 6,
    FORCE_DELIST: 7,
    RE_SUBMIT: 3,
    REJECT: 2,
    RELIST: 5,
    REVISE: 4,
    RELIST_INQUE: 9,
    CANCEL_INQUE: 10,
    VerifyAddItem: 8,
    AddToEbay: {
        id: "add_to_ebay",
        name: "Add to Ebay"
    },
    ADD_TO_EBAY: 12,
    revise_description: {
        id: "revise_description",
        name: "Revise Description"
    },
    use_legacy_description: {
        id: "use_legacy_description",
        name: "Use Legacy Description"
    }
};

function _templateMerge(tpl, obj) {
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            var content = obj[o];
            if (content) {
                content = content.replace(/\r\n/g, "<br/>");
            } else {
                content = "";
            }
            tpl = tpl.replace(new RegExp(k, "g"), content);
        }
    }
    return tpl;
}

function _auditEbayFile(name, content) {
    name = name || "SL_SubmitEbayFeed.txt";
    if (typeof content == "object") {
        content = JSON.stringify(content, null, 2);
    }
    var f = nlapiCreateFile(name, "PLAINTEXT", content);
    f.setFolder(1285);
    return nlapiSubmitFile(f);
}

var EbayFeedStatus = {
    Online: 1,
    Offline: 2,
    ForcedOffline: 3,
    InQue_New: 4,
    InQue_RelistOnline: 9,
    InQue_RelistOffline: 10,
    Error_New: 5,
    Error_RelistOnline: 11,
    Error_RelistOffline: 14,
    Error_Revise: 12,
    Error_Offline: 13,
    WaitingForApproval: 6,
    Rejected: 7,
    New: 8
};

var EbayFeedButtonAction = {
    Submit: 6,
    Relist: 5,
    Delist: 2,
    ForceDelist: 3,
    Approve: 1,
    Reject: 4,
    Revise: 7,
    ReSubmit: 8
};

var ZakeRole = {
    SalesManager: 1021,
    SalesPerson: 1022
};

function createEbayError(details) {
    return nlapiCreateError("EBAY_ERROR", details);
}

function createError(details) {
    return nlapiCreateError("ZAKE_ERROR", details);
}

function getCustomList(customListId, asObject) {
    var col = new Array();
    col[0] = new nlobjSearchColumn("name");
    col[1] = new nlobjSearchColumn("internalId");
    var obj = {};
    var list = [];
    var results = nlapiSearchRecord(customListId, null, null, col);
    for (var i = 0; results != null && i < results.length; i++) {
        var res = results[i];
        var listValue = res.getValue("name");
        var listID = res.getValue("internalId");
        list.push({
            key: listID,
            value: listValue
        });
        obj[listID] = listValue;
    }
    if (asObject == true) {
        return obj;
    } else {
        return list;
    }
}

function deepmerge(target, src) {
    var array = Array.isArray(src);
    var dst = array && [] || {};
    if (array) {
        target = target || [];
        dst = dst.concat(target);
        src.forEach(function(e, i) {
            if (typeof dst[i] === "undefined") {
                dst[i] = e;
            } else if (typeof e === "object") {
                dst[i] = deepmerge(target[i], e);
            } else {
                if (target.indexOf(e) === -1) {
                    dst.push(e);
                }
            }
        });
    } else {
        if (target && typeof target === "object") {
            Object.keys(target).forEach(function(key) {
                dst[key] = target[key];
            });
        }
        Object.keys(src).forEach(function(key) {
            if (typeof src[key] !== "object" || !src[key]) {
                dst[key] = src[key];
            } else {
                if (!target[key]) {
                    dst[key] = src[key];
                } else {
                    dst[key] = deepmerge(target[key], src[key]);
                }
            }
        });
    }
    return dst;
}

function autoSetEnglishTranslation(variations) {
    variations.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = item.label;
        }
        item.options.forEach(function(opt) {
            opt.translation = opt.value;
        });
    });
}

function autoRemoveEnglishTranslation(variations) {
    variations.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = "";
        }
        item.options.forEach(function(opt) {
            opt.translation = "";
        });
    });
}

function _getItemLocationAvailableQuantity(iteminternalid, locationid) {
    var c = [ new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))") ];
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "is", iteminternalid), new nlobjSearchFilter("internalid", "inventorylocation", "is", locationid) ], c);
    if (search) {
        if (search.length && search.length == 1) {
            return parseInt(search[0].getValue(c[0]));
        }
    }
    return 0;
}

var EbayAPI = {};

EbayAPI.parseErrors = function(response) {
    if (response.hasOwnProperty("Errors")) {
        var errors = response.Errors;
        if (!Array.isArray(errors)) errors = [ errors ];
        var msg = errors.filter(function(error) {
            return error.SeverityCode == "Error" || error.SeverityCode == "Warning";
        }).map(function(err) {
            return "[" + err.SeverityCode + "]" + err.LongMessage;
        }).join("\r\n");
        return msg;
    }
    return "";
};

function getEbayConnectedAccounts(id) {
    var filter = [ new nlobjSearchFilter("custrecord_acc_connected", null, "is", "T"), new nlobjSearchFilter("isinactive", null, "is", "F") ];
    if (id) {
        if (!Array.isArray(id)) {
            id = [ id ];
        }
        filter.push(new nlobjSearchFilter("internalid", null, "anyof", id));
    }
    return nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, filter, [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_ebay_api_token"), new nlobjSearchColumn("custrecord_ebay_global_site_access"), new nlobjSearchColumn("custrecord_acc_sellerlist_return_desc"), new nlobjSearchColumn("custrecord_acc_max_push_quantity"), new nlobjSearchColumn("custrecord_ea_subsidiary"), new nlobjSearchColumn("custrecord_ebay_account_is_big"), new nlobjSearchColumn("custrecord_ed_app_name", "custrecord_ebay_dev_account"), new nlobjSearchColumn("custrecord_ed_dev_name", "custrecord_ebay_dev_account"), new nlobjSearchColumn("custrecord_ed_cert_name", "custrecord_ebay_dev_account") ]).map(function(searchResult) {
        return {
            subsidiary: searchResult.getValue("custrecord_ea_subsidiary"),
            name: searchResult.getValue("name"),
            isBig: searchResult.getValue("custrecord_ebay_account_is_big"),
            id: searchResult.getId(),
            custrecord_acc_max_push_quantity: searchResult.getValue("custrecord_acc_max_push_quantity"),
            custrecord_acc_sellerlist_return_desc: searchResult.getValue("custrecord_acc_sellerlist_return_desc"),
            custrecord_ebay_api_token: searchResult.getValue("custrecord_ebay_api_token"),
            "X-EBAY-API-APP-NAME": searchResult.getValue("custrecord_ed_app_name", "custrecord_ebay_dev_account"),
            "X-EBAY-API-DEV-NAME": searchResult.getValue("custrecord_ed_dev_name", "custrecord_ebay_dev_account"),
            "X-EBAY-API-CERT-NAME": searchResult.getValue("custrecord_ed_cert_name", "custrecord_ebay_dev_account")
        };
    });
}