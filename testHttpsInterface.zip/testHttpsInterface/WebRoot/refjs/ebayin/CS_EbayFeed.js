(function($, window, document, undefined) {
    var $feedTable = $("#custpage_feed_list_splits");
    bindSelectFn($feedTable, {
        highlightClass: "selected"
    });
    $(".display-content").on("click", function(e) {
        var $this = $(this);
        var content = $this.parent().data("val");
        var contentDisplay = JSON.stringify(content);
        var name = $this.attr("href").replace("#", "");
        if (name == "custrecord_ebay_feed_gallery" || name == "custrecord_ebay_feed_body_picture") {
            if (Array.isArray(content)) {
                contentDisplay = content.map(function(imglink) {
                    return '<img width="200px" height="200px" style="display: block; float: left; margin-right: 12px; margin-bottom: 12px; box-shadow: 2px 2px 5px #969696; border: #ddd" ' + 'src="' + imglink + '" alt=""/>';
                }).join("");
            }
        }
        $.fancybox.open({
            width: "90%",
            height: "90%",
            autoSize: false,
            autoResize: true,
            helpers: {
                overlay: {
                    closeClick: false
                }
            },
            content: contentDisplay
        });
    });
    window.viewVariation = function(url) {
        $.fancybox.open({
            href: url,
            type: "iframe",
            padding: 12,
            width: "90%",
            height: "90%",
            autoSize: false,
            autoResize: true,
            helpers: {
                overlay: {
                    closeClick: false
                }
            }
        });
    };
    window.submitAction = function() {
        var selectedLineList = [];
        $feedTable.find(".select").each(function() {
            var $line = $(this).closest(".uir-list-row-tr");
            if ($(this).prop("checked") == true) {
                selectedLineList.push({
                    feed_feed_id: $line.children(".feedId").data("val"),
                    feed_next_action: $line.find(".feedAction").val()
                });
            }
        });
        console.log(JSON.stringify(selectedLineList));
        if (selectedLineList.length) {
            $.ajax({
                type: "POST",
                url: SL_URL.EbayFeed,
                data: {
                    action: "submitFeed",
                    actionList: JSON.stringify(selectedLineList)
                },
                success: function(data) {
                    console.log(data);
                    NProgress.done();
                    PageOverlay.showOverlay();
                    window.location.reload();
                },
                beforeSend: function() {
                    NProgress.start();
                }
            });
        } else {
            alert("No selected");
        }
    };
})(jQuery, window, document);