function beforeLoad(type, form, request) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    if (type == 'view') {

        form.setScript('customscript_cs_button_action');

        if (!nlapiGetFieldValue('custrecord_mso_linked_so')) {
            form.addButton("custpage_create_so_btn",
                "创建订单",
                "hitButton();window.location='/app/site/hosting/scriptlet.nl?script=740&deploy=1&mso_id=" + id + "'");
        }

    }

    if (type == 'view' || type == 'edit') {


        try {
            var info = nlapiGetFieldValue('custrecord_mso_info');
            if (info) {
                var Order = JSON.parse(info);

                // Address
                form.addField('custpage_shipcity', 'text', 'Ship City').setDefaultValue(Order.ShippingAddress.CityName);
                form.addField('custpage_shipstate', 'text', 'Ship State').setDefaultValue(Order.ShippingAddress.StateOrProvince);

                // items
                // if (Order.hasOwnProperty('TransactionArray')) {
                var items = Order.TransactionArray.Transaction.map(function (_Transaction) {
                    var sku = null;
                    // var ebayItemId = null;

                    if (_Transaction.hasOwnProperty('Variation')) {
                        sku = _Transaction.Variation.SKU;
                        // ebayItemId = Transaction.Variation.ItemID;
                    } else {
                        sku = _Transaction.Item.SKU;
                        // ebayItemId = Transaction.Item.ItemID;
                    }

                    //sku = sku.trim();
                    //if (sku.indexOf('|') != -1) {
                    //    sku = sku.substring(0, sku.indexOf('|'));
                    //}

                    return {
                        sku: sku,
                        quantity: _Transaction.QuantityPurchased,
                        price: _Transaction.TransactionPrice.__text
                    }
                });
                // }

                var itemList = form.addSubList("custpage_item_list", "list", '产品信息');
                itemList.addField("item_name", 'text', 'Name', null);
                itemList.addField("item_quantity", 'text', 'Quantity', null).setDisplayType('disabled');
                items.forEach(function (item, i) {
                    var ln = i + 1;
                    itemList.setLineItemValue('item_name', ln, item.sku);
                    itemList.setLineItemValue('item_quantity', ln, item.quantity);
                });

                // some info
                var orderinfo = form.addField('custpage_info', 'text', 'Order Info');
                orderinfo.setDefaultValue('Sales Record Number: ' + Order.ShippingDetails.SellingManagerSalesRecordNumber + ', Buyer: ' + Order.BuyerUserID);
                orderinfo.setDisplayType('inline');

                // items
                //var relatedItems = form.addField('custpage_missing_items', 'text', 'Related Items');
                //relatedItems.setDefaultValue(items.map(function (item) {
                //    return item.sku;
                //}).join(', '));
                //// relatedItems.setDisabled(true);
                //relatedItems.setDisplayType('inline');

                // memo
                var cmemo = '';
                if (Order.BuyerCheckoutMessage) {
                    cmemo = _cutTextLength(Order.BuyerCheckoutMessage);
                }
                var customerMemo = form.addField('custpage_cmemo', 'text', 'Customer Memo');
                customerMemo.setDefaultValue(cmemo);
                // relatedItems.setDisabled(true);
                customerMemo.setDisplayType('inline');


            }
        } catch (e) {
            processException(e);
        }


    }
}

//function renderAddress(form, Order) {
//    form.addField('custpage_shipcity', 'text', 'Ship City').setDefaultValue(Order.ShippingAddress.CityName);
//    form.addField('custpage_shipstate', 'text', 'Ship State').setDefaultValue(Order.ShippingAddress.StateOrProvince);
//}

function beforeSubmit(type) {
    var id = nlapiGetRecordId();
    try {
        if (type != 'delete') {

            //var info = nlapiGetFieldValue('custrecord_mso_info');
            //if (info) {
            //    var ebayAccountName = nlapiLookupField('customrecord_ebay_account',
            //        nlapiGetFieldValue('custrecord_mso_ebay_account'), 'custrecord_ebay_shortname');
            //    var Order = JSON.parse(info);
            //    var srn = Order.ShippingDetails.SellingManagerSalesRecordNumber;
            //    nlapiSetFieldValue('custrecord_mso_srn', ebayAccountName + '-' + srn);
            //}

        }

        if (type == 'edit') {

            var custpage_shipcity = nlapiGetFieldValue('custpage_shipcity');
            _log('custpage_shipcity', custpage_shipcity);
            var custpage_shipstate = nlapiGetFieldValue('custpage_shipstate');
            _log('custpage_shipstate', custpage_shipstate);


            var info = nlapiGetFieldValue('custrecord_mso_info');
            if (info) {
                var Order = JSON.parse(info);
                Order.ShippingAddress.CityName = custpage_shipcity;
                Order.ShippingAddress.StateOrProvince = custpage_shipstate;
                nlapiSetFieldValue('custrecord_mso_info', JSON.stringify(Order));
            }
        }

    } catch (e) {
        processException(e, "beforeSubmit" + id);
    }
}