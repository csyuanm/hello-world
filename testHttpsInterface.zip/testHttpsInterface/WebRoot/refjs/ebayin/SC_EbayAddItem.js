function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var EbayFeed = {
    PENDING_MODIFICATION: "custrecord_ebay_feed_pending_mdf",
    TYPE: "customrecord_ebay_item_api_feed"
};

function buildEbayReviseVariationXML(feed) {
    var changed = feed.val("custrecord_ef_variations_changed");
    if (changed && isJsonString(changed)) {
        var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("internalid", null, "anyof", JSON.parse(feed.val("custrecord_ef_variations_changed")).map(function(item) {
            return item.feedId;
        })), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", feed.getId()), new nlobjSearchFilter("inventorylocation", "custrecord_ebay_feed_item", "is", feed.val("custrecord_ebay_feed_location")) ], [ new nlobjSearchColumn("custrecord_ef_ean"), new nlobjSearchColumn("custrecord_ef_isbn"), new nlobjSearchColumn("custrecord_ef_upc"), new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_variations"), new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("custrecord_ebay_feed_api_price"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custitem_item_picture", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("custrecord_ef_picture2") ]);
        var subFeedList = subFeedSearch.map(function(searchResult) {
            return {
                custrecord_ef_ean: searchResult.getValue("custrecord_ef_ean") || "Does not apply",
                custrecord_ef_isbn: searchResult.getValue("custrecord_ef_isbn") || "Does not apply",
                custrecord_ef_upc: searchResult.getValue("custrecord_ef_upc") || "Does not apply",
                variation: JSON.parse(searchResult.getValue("custrecord_ebay_feed_variations")),
                price: searchResult.getValue("custrecord_ebay_feed_api_price"),
                custrecord_ebay_feed_sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                variation_picture: searchResult.getText("custitem_item_picture", "CUSTRECORD_EBAY_FEED_ITEM"),
                custrecord_ef_picture2: searchResult.getValue("custrecord_ef_picture2")
            };
        });
        _audit("subFeedList", subFeedList);
        var xml = "";
        xml += "<Variations>";
        subFeedList.forEach(function(subFeed) {
            xml += "    <Variation>";
            xml += "        <StartPrice>" + (subFeed.price || feed.val("custrecord_ebay_feed_api_price")) + "</StartPrice>";
            xml += "        <SKU>" + subFeed.custrecord_ebay_feed_sku + "</SKU>";
            xml += "    </Variation>";
        });
        xml += "    <Pictures>";
        var specificNameCount = 0;
        subFeedList.forEach(function(subFeed) {
            if (subFeed.custrecord_ef_picture2) {
                _log("__subFeed pic", subFeed);
                var variation = subFeed.variation.options;
                variation = variation[0];
                if (specificNameCount == 0) {
                    xml += "        <VariationSpecificName>" + variation.label.translation + "</VariationSpecificName>";
                }
                xml += "        <VariationSpecificPictureSet>";
                xml += "            <VariationSpecificValue>" + variation.option.translation + "</VariationSpecificValue>";
                xml += "            <PictureURL>" + nlapiEscapeXML(subFeed.custrecord_ef_picture2) + "</PictureURL>";
                xml += "        </VariationSpecificPictureSet>";
                specificNameCount++;
            }
        });
        xml += "    </Pictures>";
        xml += "</Variations>";
        return xml;
    } else {
        return "";
    }
}

function buildEbayVariationXML(parentVariation, feed, _filter) {
    var account_max_push_quantity = undefined;
    var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", feed.getId()), new nlobjSearchFilter("inventorylocation", "custrecord_ebay_feed_item", "is", feed.val("custrecord_ebay_feed_location")) ], [ new nlobjSearchColumn("custrecord_ef_ean"), new nlobjSearchColumn("custrecord_ef_isbn"), new nlobjSearchColumn("custrecord_ef_upc"), new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_variations"), new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("custrecord_ebay_feed_api_price"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_picture2"), new nlobjSearchColumn("custitem_item_picture", "CUSTRECORD_EBAY_FEED_ITEM") ]);
    var subFeedList = subFeedSearch.map(function(searchResult) {
        var locationquantityavailable = 0;
        var qty = searchResult.getValue("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM") || 0;
        qty = parseInt(qty);
        var push_qty = searchResult.getValue("custrecord_ebay_feed_push_qty");
        var max_push_qty = feed.val("custrecord_ef_max_push_qty");
        if (push_qty) {
            push_qty = parseInt(push_qty);
            locationquantityavailable = push_qty;
        } else if (max_push_qty) {
            max_push_qty = parseInt(max_push_qty);
            if (qty > max_push_qty) {
                locationquantityavailable = max_push_qty;
            } else {
                locationquantityavailable = qty;
            }
        } else {
            if (account_max_push_quantity === undefined) {
                account_max_push_quantity = nlapiLookupField("customrecord_ebay_account", feed.val("custrecord_ebay_feed_account"), "custrecord_acc_max_push_quantity");
                if (account_max_push_quantity) {
                    account_max_push_quantity = parseInt(account_max_push_quantity);
                } else {
                    account_max_push_quantity = 5;
                }
            }
            if (qty > account_max_push_quantity) {
                locationquantityavailable = account_max_push_quantity;
            } else {
                locationquantityavailable = qty;
            }
        }
        return {
            custrecord_ef_ean: searchResult.getValue("custrecord_ef_ean") || "Does not apply",
            custrecord_ef_isbn: searchResult.getValue("custrecord_ef_isbn") || "Does not apply",
            custrecord_ef_upc: searchResult.getValue("custrecord_ef_upc") || "Does not apply",
            variation: JSON.parse(searchResult.getValue("custrecord_ebay_feed_variations")),
            locationquantityavailable: locationquantityavailable,
            price: searchResult.getValue("custrecord_ebay_feed_api_price"),
            custrecord_ebay_feed_sku: searchResult.getValue("custrecord_ebay_feed_sku"),
            variation_picture: searchResult.getValue("custrecord_ef_picture2") || searchResult.getValue("custitem_item_var_picture", "CUSTRECORD_EBAY_FEED_ITEM")
        };
    });
    _log("subFeedList", subFeedList);
    var xml = "";
    var feedPriceList = subFeedList.map(function(subFeed) {
        return parseFloat(subFeed.price);
    });
    feedPriceList = feedPriceList.sort(function(a, b) {
        return b - a;
    });
    var paypalEmailAddress = feed.getPayPalEmailAddress(feedPriceList[0]);
    if (!paypalEmailAddress) throw createEbayError("Not found the Paypal emaill address for feed eBay account, please check.");
    xml += "    <PayPalEmailAddress>" + paypalEmailAddress + "</PayPalEmailAddress>";
    xml += "<Variations>";
    xml += "    <VariationSpecificsSet>";
    parentVariation.availOptions.forEach(function(item) {
        xml += "        <NameValueList>";
        xml += "            <Name>" + item.translation + "</Name>";
        xml += item.options.map(function(option) {
            return "        <Value>" + option.translation + "</Value>";
        }).join("");
        xml += "        </NameValueList>";
    });
    xml += "    </VariationSpecificsSet>";
    subFeedList.forEach(function(subFeed) {
        xml += "    <Variation>";
        xml += "        <StartPrice>" + (subFeed.price || feed.val("custrecord_ebay_feed_api_price")) + "</StartPrice>";
        xml += "        <SKU>" + subFeed.custrecord_ebay_feed_sku + "</SKU>";
        xml += "        <Quantity>" + subFeed.locationquantityavailable + "</Quantity>";
        xml += [ "<VariationProductListingDetails>", "    <EAN>" + subFeed.custrecord_ef_ean + "</EAN>", "    <ISBN>" + subFeed.custrecord_ef_isbn + "</ISBN>", "    <UPC>" + subFeed.custrecord_ef_upc + "</UPC>", "    </VariationProductListingDetails>" ].join("");
        xml += "        <VariationSpecifics>";
        var variation = subFeed.variation;
        variation.options.forEach(function(item) {
            xml += "            <NameValueList>";
            xml += "                <Name>" + item.label.translation + "</Name>";
            xml += "                <Value>" + item.option.translation + "</Value>";
            xml += "            </NameValueList>";
        });
        xml += "        </VariationSpecifics>";
        xml += "    </Variation>";
    });
    var pictureSubFeedList = subFeedList.filter(function(item) {
        return item.variation_picture;
    });
    _log("pictureSubFeedList", pictureSubFeedList);
    if (pictureSubFeedList.length) {
        var variationSpecificName = "";
        var var_name = parentVariation.availOptions.filter(function(option) {
            return option.translation.toUpperCase().indexOf("COLOR") != -1;
        });
        if (var_name.length) {
            variationSpecificName = var_name[0].translation;
        } else {
            variationSpecificName = parentVariation.availOptions[0].translation;
        }
        var pictureGroup = {};
        pictureSubFeedList.forEach(function(subFeed) {
            var variationSpecificValue = subFeed.variation.options.filter(function(op) {
                return op.label.translation == variationSpecificName;
            })[0].option.translation;
            var url = "";
            if (subFeed.variation_picture.indexOf("http") == -1) {
                url = "https://" + NS_DOMAIN + nlapiEscapeXML(subFeed.variation_picture);
            } else {
                url += nlapiEscapeXML(subFeed.variation_picture);
            }
            if (pictureGroup.hasOwnProperty(variationSpecificValue)) {
                if (pictureGroup[variationSpecificValue].indexOf(url) == -1) {
                    pictureGroup[variationSpecificValue].push(url);
                }
            } else {
                pictureGroup[variationSpecificValue] = [ url ];
            }
        });
        xml += "    <Pictures>";
        xml += "        <VariationSpecificName>" + variationSpecificName + "</VariationSpecificName>";
        for (var var_value in pictureGroup) {
            xml += "        <VariationSpecificPictureSet>";
            xml += "            <VariationSpecificValue>" + var_value + "</VariationSpecificValue>";
            xml += pictureGroup[var_value].map(function(url) {
                return "<PictureURL>" + url + "</PictureURL>";
            }).join("");
            xml += "        </VariationSpecificPictureSet>";
        }
        xml += "    </Pictures>";
    }
    xml += "</Variations>";
    return xml;
}

function buildFeedReviseXML(feed, fields) {
    var modification_xml = "";
    var modification_fields = [];
    var mdfList = [];
    if (Array.isArray(fields) && fields.length) {
        mdfList = fields;
    } else {
        var pendingModification = feed.getFieldValue(EbayFeed.PENDING_MODIFICATION);
        if (pendingModification) {
            pendingModification = JSON.parse(pendingModification);
            if (Array.isArray(pendingModification) && pendingModification.length > 0) {
                mdfList = pendingModification;
            }
        }
    }
    if (mdfList.length) {
        mdfList.forEach(function(field) {
            switch (field) {
              case "custrecord_ebay_feed_api_title":
                modification_xml += "    <Title><![CDATA[" + feed.val("custrecord_ebay_feed_api_title") + "]]></Title>";
                break;

              case "custrecord_ebay_feed_api_price":
                modification_xml += "    <StartPrice>" + parseFloat(feed.val("custrecord_ebay_feed_api_price")) + "</StartPrice>";
                break;

              case "custrecord_ebay_feed_description":
              case "custrecord_ef_template":
              case "custrecord_ebay_feed_body_picture":
                var custrecord_ebay_feed_body_picture = feed.val("custrecord_ebay_feed_body_picture");
                if (custrecord_ebay_feed_body_picture) {
                    custrecord_ebay_feed_body_picture = JSON.parse(custrecord_ebay_feed_body_picture);
                } else {
                    custrecord_ebay_feed_body_picture = [];
                }
                if (!feed.val("custrecord_ef_template")) {
                    throw createEbayError("Not found the eBay feed template! Please select the template first! " + feed.getId());
                }
                var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", feed.val("custrecord_ef_template"), "custrecord_eat_tpl"), {
                    title: feed.val("custrecord_ebay_feed_api_title"),
                    description: feed.val("custrecord_ebay_feed_description").replace(/\r|\n|\r\n/g, ""),
                    body_pictures: custrecord_ebay_feed_body_picture.map(function(url) {
                        if (url.indexOf("http") != -1) {
                            return '<img src="' + url + '" />';
                        } else {
                            return '<img src="https://' + NS_DOMAIN + url + '" />';
                        }
                    }).join("<br/>")
                });
                modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                break;

              case "custrecord_ebay_feed_condition":
                modification_xml += "    <ConditionID>" + feed.getSearchResult().getValue("custrecord_eic_condition_id", "custrecord_ebay_feed_condition") + "</ConditionID>";
                break;

              case "custrecord_ebay_feed_description_fix":
                var description_fix = feed.val("custrecord_ebay_feed_description");
                if (description_fix && typeof description_fix == "string") {
                    description_fix = description_fix.replace(/\r|\n|\r\n/g, "");
                } else {
                    description_fix = "";
                }
                var tpl = "7";
                var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", tpl, "custrecord_eat_tpl"), {
                    description_fix: description_fix
                });
                modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                break;

              case "custrecord_ef_legacy_description":
                var Description = feed.val("custrecord_ef_legacy_description").replace(/\r|\n|\r\n/g, "");
                modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                break;

              case "custrecord_ebay_feed_push_qty":
              case "custrecord_ef_max_push_qty":
              case "custrecord_ef_ebay_available_qty":
                var f_qty = feed.getQuantity();
                if (parseInt(feed.val("custrecord_ef_ebay_available_qty")) != f_qty) {
                    modification_xml += "    <Quantity>" + f_qty + "</Quantity>";
                    modification_fields.push({
                        name: "custrecord_ef_ebay_available_qty",
                        value: f_qty
                    });
                }
                break;

              case "custrecord_ebay_feed_variations":
                var variations = feed.val("custrecord_ebay_feed_variations");
                if (variations) {
                    variations = JSON.parse(variations);
                    modification_xml += buildEbayVariationXML(variations, feed);
                } else {
                    modification_xml += "";
                }
                break;

              case "variations":
                modification_xml += buildEbayReviseVariationXML(feed);
                break;

              case "custrecord_ebay_feed_gallery":
                var gallery = feed.val("custrecord_ebay_feed_gallery");
                if (gallery) {
                    gallery = JSON.parse(gallery);
                    if (Array.isArray(gallery) && gallery.length) {
                        modification_xml += "    <PictureDetails>";
                        gallery.forEach(function(link) {
                            if (link.indexOf("/core/media/media.nl") == 0) {
                                link = "https://" + NS_DOMAIN + link;
                            }
                            modification_xml += "      <PictureURL>" + nlapiEscapeXML(link) + "</PictureURL>";
                        });
                        modification_xml += "    </PictureDetails>";
                    }
                }
                break;

              case "custrecord_ebay_feed_specifics":
                var specifics = feed.val("custrecord_ebay_feed_specifics");
                if (specifics) {
                    specifics = JSON.parse(specifics);
                    if (Array.isArray(specifics) && specifics.length) {
                        modification_xml += "    <ItemSpecifics>";
                        modification_xml += specifics.map(function(item) {
                            var nameValueList = "";
                            nameValueList += "<NameValueList>";
                            nameValueList += "    <Name>" + nlapiEscapeXML(item.specificName) + "</Name>";
                            nameValueList += "    <Value>" + nlapiEscapeXML(item.specificValue) + "</Value>";
                            nameValueList += "</NameValueList>";
                            return nameValueList;
                        }).join("");
                        modification_xml += "    </ItemSpecifics>";
                    }
                }
                break;

              default:
                modification_xml += "";
            }
        });
    }
    return {
        modification_xml: modification_xml,
        modification_fields: modification_fields
    };
}

function __EbayFeed(id) {
    this.searchResult = null;
    Record.call(this, EbayFeed.TYPE, id);
}

inherit(Record, __EbayFeed);

__EbayFeed.prototype.getSearchResult = function() {
    if (this.searchResult == null) {
        var search = nlapiSearchRecord(EbayFeed.TYPE, null, [ new nlobjSearchFilter("internalid", null, "is", this.id) ], [ new nlobjSearchColumn("custrecord_ebay_api_token", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_ebay_gs_sitecode", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_default_currency", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_ebay_cs_country_code", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_ebay_site_id", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_eic_condition_id", "custrecord_ebay_feed_condition"), new nlobjSearchColumn("city", "custrecord_ebay_feed_location"), new nlobjSearchColumn("custrecord_ef_location_name"), new nlobjSearchColumn("custrecord_paypal_account_linked", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_micro_paypal_account_linked", "custrecord_ebay_feed_account") ]);
        this.searchResult = search[0];
    }
    return this.searchResult;
};

__EbayFeed.prototype.getEbaySiteID = function() {
    return this.searchResult.getValue("custrecord_ebay_site_id", "custrecord_ebay_feed_global_site");
};

function _parsecost(val) {
    if (val) {
        return parseFloat(val);
    }
    return 0;
}

__EbayFeed.prototype.getShippingOptionsXML = function() {
    var feed = this;
    _audit("shipping options record id", this.val("custrecord_ef_shipping_options"));
    var rec = nlapiLoadRecord("customrecord_ebay_shipping_options", this.val("custrecord_ef_shipping_options"));
    var shipping_options = rec.getFieldValue("custrecord_eso_shippingdetails");
    shipping_options = JSON.parse(shipping_options);
    var xml = [ "    <ShippingDetails>", shipping_options.ShippingDetails.ExcludeShipToLocation.map(function(shiptolocation) {
        return "   <ExcludeShipToLocation>" + shiptolocation.text + "</ExcludeShipToLocation>";
    }).join(""), "      <GlobalShipping>" + shipping_options.GlobalShipping.text + "</GlobalShipping>", "      <ShippingType>" + shipping_options.ShippingDetails.ShippingType.text + "</ShippingType>", shipping_options.ShippingDetails.ShippingServiceOptions.map(function(option) {
        var x = [ "      <ShippingServiceOptions>", "        <ShippingService>" + option.ShippingService.text + "</ShippingService>", '        <ShippingServiceCost currencyID="USD">' + _parsecost(option.ShippingServiceCost) + "</ShippingServiceCost>", '        <ShippingServiceAdditionalCost currencyID="USD">' + _parsecost(option.ShippingServiceAdditionalCost) + "</ShippingServiceAdditionalCost>", "        <ShippingServicePriority>" + option.ShippingServicePriority + "</ShippingServicePriority>" ];
        if (option.ShippingSurcharge) {
            var ShippingSurcharge = _parsecost(option.ShippingSurcharge);
            if (ShippingSurcharge) {
                x.push("        <ShippingSurcharge>" + ShippingSurcharge + "</ShippingSurcharge>");
            }
        }
        if (option.ShippingServicePriority == "1") {
            x.push("        <FreeShipping>" + option.FreeShipping.text + "</FreeShipping>");
        }
        x.push("      </ShippingServiceOptions>");
        return x.join("");
    }).join(""), shipping_options.ShippingDetails.InternationalShippingServiceOption.map(function(option) {
        var x = [ "      <InternationalShippingServiceOption>", "        <ShippingService>" + option.ShippingService.text + "</ShippingService>", '        <ShippingServiceCost currencyID="USD">' + _parsecost(option.ShippingServiceCost) + "</ShippingServiceCost>", '        <ShippingServiceAdditionalCost currencyID="USD">' + _parsecost(option.ShippingServiceAdditionalCost) + "</ShippingServiceAdditionalCost>", "        <ShippingServicePriority>" + option.ShippingServicePriority + "</ShippingServicePriority>" ];
        x.push(option.ShipToLocation.map(function(location) {
            return "		 <ShipToLocation>" + location.text + "</ShipToLocation>";
        }).join(""));
        x.push("      </InternationalShippingServiceOption>");
        return x.join("");
    }).join(""), "    </ShippingDetails>", shipping_options.ShipToLocations.map(function(shiptolocation) {
        return "<ShipToLocations>" + shiptolocation.text + "</ShipToLocations>";
    }).join("") ].map(function(node) {
        return node.trim();
    }).join("");
    return xml;
};

__EbayFeed.prototype.isSingleItem = function() {
    var that = this;
    return that.val("custrecord_ebay_feed_matrix_item") == "F" && that.val("custrecord_ebay_feed_matrix_child_item") == "F";
};

__EbayFeed.prototype.isKitFeed = function() {
    var that = this;
    return that.val("custrecord_ebay_feed_combo") == "T";
};

__EbayFeed.prototype.getMainPrice = function() {
    return this.val("custrecord_ebay_feed_api_price");
};

__EbayFeed.prototype.getPayPalEmailAddress = function(price) {
    var big = this.getSearchResult().getText("custrecord_paypal_account_linked", "custrecord_ebay_feed_account");
    var small = this.getSearchResult().getText("custrecord_micro_paypal_account_linked", "custrecord_ebay_feed_account");
    if (!price) {
        _audit("this.getMainPrice()", this.getMainPrice());
        price = this.getMainPrice();
    }
    if (parseFloat(price) > 12) {
        return big;
    } else {
        return small;
    }
};

__EbayFeed.prototype.getVariation = function() {
    var v = this.val("custrecord_ebay_feed_variations");
    if (v && typeof v == "string") {
        return JSON.parse(v);
    }
    return v;
};

__EbayFeed.prototype.getToken = function() {
    return this.getSearchResult().getValue("custrecord_ebay_api_token", "custrecord_ebay_feed_account");
};

__EbayFeed.prototype.getEbayItemId = function() {
    return this.val("custrecord_ebay_feed_item_id") || null;
};

__EbayFeed.prototype.getStatus = function() {
    return this.val("custrecord_ebay_feed_status");
};

__EbayFeed.prototype.updateStatus = function(status, scheduledStatus) {
    if (status) {
        this.setFieldValue("custrecord_ebay_feed_status", status);
    }
    if (scheduledStatus) {
        this.setFieldValue("custrecord_ef_scheduled_status", scheduledStatus);
    } else {
        this.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
    }
    return this.submitRecord();
};

__EbayFeed.prototype.callRelistItem = function() {
    var ebayfeed = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<RelistItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += "  <RequesterCredentials>";
    xml += "        <eBayAuthToken>" + ebayfeed.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <Item>";
    xml += "    <ItemID>" + ebayfeed.getEbayItemId() + "</ItemID>";
    xml += buildFeedReviseXML(ebayfeed);
    xml += "  </Item>";
    xml += "</RelistItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": ebayfeed.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "RelistItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            ebayfeed.setFieldValue("custrecord_ebay_feed_item_id", response.ItemID);
            ebayfeed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
            ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
        } else {
            if (ebayfeed.val("custrecord_ef_scheduled_status") == EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST) {
                ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST_ERROR);
            }
        }
    });
};

__EbayFeed.prototype.callReviseItem = function(fields) {
    var ebayfeed = this;
    var modified = buildFeedReviseXML(ebayfeed, fields);
    _audit("callReviseItem modified", modified);
    if (modified.modification_xml) {
        var xml = "";
        xml += '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<ReviseFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
        xml += "  <RequesterCredentials>";
        xml += "        <eBayAuthToken>" + ebayfeed.getToken() + "</eBayAuthToken>";
        xml += "  </RequesterCredentials>";
        xml += "  <ErrorLanguage>en_US</ErrorLanguage>";
        xml += "  <WarningLevel>High</WarningLevel>";
        xml += "  <Item>";
        xml += "    <ItemID>" + ebayfeed.getEbayItemId() + "</ItemID>";
        xml += modified.modification_xml;
        xml += "  </Item>";
        xml += "</ReviseFixedPriceItemRequest>";
        _log("callReviseItem", xml);
        this.callAPI({
            "X-EBAY-API-SITEID": ebayfeed.getEbaySiteID(),
            "X-EBAY-API-CALL-NAME": "ReviseFixedPriceItem",
            "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
        }, xml, function(response) {
            _log_email("reviseitem", JSON.stringify(response));
            if (response.Ack != "Failure") {
                if (modified.modification_fields.length) {
                    modified.modification_fields.forEach(function(field) {
                        ebayfeed.setFieldValue(field.name, field.value);
                    });
                }
                _log("is go here?", "custrecord_ef_variations_changed---------------------------");
                ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
                ebayfeed.setFieldValue("custrecord_ef_variations_changed", "");
                ebayfeed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
                ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
            }
        });
    } else {
        ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
        ebayfeed.setFieldValue("custrecord_ef_variations_changed", "");
        ebayfeed.submitRecord();
    }
};

__EbayFeed.prototype.callEndItem = function() {
    var feed = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<EndItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += "  <RequesterCredentials>";
    xml += "        <eBayAuthToken>" + feed.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <ItemID>" + feed.getEbayItemId() + "</ItemID>";
    xml += "  <EndingReason>NotAvailable</EndingReason>";
    xml += "</EndItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": feed.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "EndItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            feed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            feed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.OFFLINE);
            feed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
        }
    });
};

__EbayFeed.prototype.callAPI = function(header, xml, callback, updateFeedRecordFlag) {
    if (updateFeedRecordFlag !== false) {
        updateFeedRecordFlag = true;
    }
    _audit("__EbayFeed.prototype.callAPI: " + nlapiGetContext().getExecutionContext(), header["X-EBAY-API-CALL-NAME"]);
    header = extend(EbayRequest.headers, header);
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
    var responseBody = response.getBody();
    var x2js = new X2JS();
    var responseObject = x2js.xml_str2json(responseBody);
    var responseName = header["X-EBAY-API-CALL-NAME"] + "Response";
    if (callback && typeof callback == "function") callback(responseObject[responseName]);
    if (updateFeedRecordFlag) {
        _log("is go here?", "updateFeedRecordFlag---------------------------" + updateFeedRecordFlag);
        var feed = this;
        feed.setFieldValue("custrecord_ebay_feed_last_api_request", xml);
        feed.setFieldValue("custrecord_ebay_feed_last_api_response", responseBody);
        feed.setFieldValue("custrecord_ebay_feed_last_api_datetime", nlapiDateToString(new Date(), "datetimetz"));
        feed.setFieldValue("custrecord_ef_api_name", header["X-EBAY-API-CALL-NAME"]);
        feed.setFieldValue("custrecord_ebay_feed_call_ack", responseObject[responseName].Ack);
        feed.setFieldValue("custrecord_ebay_feed_api_message", EbayAPI.parseErrors(responseObject[responseName]));
        feed.submitRecord();
    }
    return responseObject;
};

__EbayFeed.prototype.getQuantity = function() {
    var c = [ new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))") ];
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "is", this.val("custrecord_ebay_feed_item")), new nlobjSearchFilter("internalid", "inventorylocation", "is", [ this.val("custrecord_ebay_feed_location") ]) ], c);
    var qty = parseInt(search[0].getValue(c[0]) || 0);
    var push_qty = this.val("custrecord_ebay_feed_push_qty");
    var max_push_qty = this.val("custrecord_ef_max_push_qty");
    if (push_qty) {
        push_qty = parseInt(push_qty);
        return push_qty;
    } else if (max_push_qty) {
        max_push_qty = parseInt(max_push_qty);
        if (qty > max_push_qty) {
            return max_push_qty;
        } else {
            return qty;
        }
    } else {
        var account_max_push_quantity = nlapiLookupField("customrecord_ebay_account", this.val("custrecord_ebay_feed_account"), "custrecord_acc_max_push_quantity");
        if (account_max_push_quantity) {
            account_max_push_quantity = parseInt(account_max_push_quantity);
        } else {
            account_max_push_quantity = 5;
        }
        _log_email("Feed ID" + this.getId(), " 动用了Account 上面的设置");
        if (qty > account_max_push_quantity) {
            return account_max_push_quantity;
        } else {
            return qty;
        }
    }
};

__EbayFeed.prototype.buildAddFixedPriceItemXML = function() {
    var that = this;
    var check = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_sku", null, "is", that.val("custrecord_ebay_feed_sku")), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "is", that.val("custrecord_ebay_feed_global_site")), new nlobjSearchFilter("custrecord_ebay_feed_location", null, "is", that.val("custrecord_ebay_feed_location")), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE) ]);
    if (check != null) {
        check = check.map(function(sr) {
            return parseInt(sr.getId());
        });
        check.remove(parseInt(nlapiGetRecordId()));
        throw new Exception("buildAddFixedPriceItemXML", "SKU+SITEID+LOCATION has duplicate.", {
            check: check
        });
    }
    if (!that.val("custrecord_ef_shipping_options")) {
        throw createEbayError("Please fill the Shipping Options field.");
    }
    var xml = "";
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + that.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <ErrorLanguage>en_US</ErrorLanguage>";
    xml += "  <WarningLevel>High</WarningLevel>";
    xml += "  <Item>";
    xml += "    <Site>" + that.getSearchResult().getValue("custrecord_ebay_gs_sitecode", "custrecord_ebay_feed_global_site") + "</Site>";
    xml += "    <SKU>" + that.val("custrecord_ebay_feed_sku") + "</SKU>";
    var title = _.unescape(that.val("custrecord_ebay_feed_api_title"));
    xml += "    <Title><![CDATA[" + title + "]]></Title>";
    xml += "    <Currency>" + that.getSearchResult().getText("custrecord_default_currency", "custrecord_ebay_feed_global_site") + "</Currency>";
    xml += "    <ConditionID>" + that.getSearchResult().getValue("custrecord_eic_condition_id", "custrecord_ebay_feed_condition") + "</ConditionID>";
    xml += "    <Country>" + that.getSearchResult().getValue("custrecord_ebay_cs_country_code", "custrecord_ebay_feed_global_site") + "</Country>";
    var location = that.getSearchResult().getValue("city", "custrecord_ebay_feed_location");
    var location_name = that.getSearchResult().getValue("custrecord_ef_location_name");
    xml += "    <Location>" + (location_name || location) + "</Location>";
    if (that.isSingleItem()) {
        xml += "    <StartPrice>" + that.val("custrecord_ebay_feed_api_price") + "</StartPrice>";
    }
    xml += "    <DispatchTimeMax>2</DispatchTimeMax>";
    xml += "    <HitCounter>BasicStyle</HitCounter>";
    xml += "    <ListingDuration>" + that.getFieldText("custrecord_ef_listing_duration") + "</ListingDuration>";
    xml += "    <ListingType>FixedPriceItem</ListingType>";
    xml += "    <PaymentMethods>PayPal</PaymentMethods>";
    if (that.isSingleItem()) {
        var paypalEmailAddress = that.getPayPalEmailAddress();
        if (!paypalEmailAddress) throw createEbayError("Not found the Paypal emaill address for feed eBay account, please check.");
        xml += "    <PayPalEmailAddress>" + paypalEmailAddress + "</PayPalEmailAddress>";
    }
    xml += "    <PrivateListing>false</PrivateListing>";
    if (that.isSingleItem()) {
        if (that.isKitFeed()) {
            xml += "    <Quantity>" + that.val("custrecord_ebay_feed_push_qty") + "</Quantity>";
        } else {
            xml += "    <Quantity>" + that.getQuantity() + "</Quantity>";
        }
    }
    xml += "    <PrimaryCategory>";
    xml += "      <CategoryID>" + that.val("custrecord_ebay_feed_category_id") + "</CategoryID>";
    xml += "    </PrimaryCategory>";
    var custrecord_ebay_feed_body_picture = that.val("custrecord_ebay_feed_body_picture");
    if (custrecord_ebay_feed_body_picture) {
        custrecord_ebay_feed_body_picture = JSON.parse(custrecord_ebay_feed_body_picture);
    } else {
        custrecord_ebay_feed_body_picture = [];
    }
    var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", that.val("custrecord_ef_template"), "custrecord_eat_tpl"), {
        title: title,
        description: that.val("custrecord_ebay_feed_description"),
        body_pictures: custrecord_ebay_feed_body_picture.map(function(url) {
            if (url.indexOf("http") != -1) {
                return '<img src="' + url + '" />';
            } else {
                return '<img src="https://' + NS_DOMAIN + url + '" />';
            }
        }).join("<br/>")
    });
    xml += "    <Description><![CDATA[" + Description + "]]></Description>";
    var specifics = that.val("custrecord_ebay_feed_specifics");
    if (specifics) {
        specifics = JSON.parse(specifics);
        if (Array.isArray(specifics) && specifics.length) {
            xml += "    <ItemSpecifics>";
            xml += specifics.map(function(item) {
                var nameValueList = "";
                nameValueList += "<NameValueList>";
                nameValueList += "    <Name>" + nlapiEscapeXML(item.specificName) + "</Name>";
                nameValueList += "    <Value>" + nlapiEscapeXML(item.specificValue) + "</Value>";
                nameValueList += "</NameValueList>";
                return nameValueList;
            }).join("");
            xml += "    </ItemSpecifics>";
        }
    }
    var gallery = that.val("custrecord_ebay_feed_gallery");
    if (gallery) {
        gallery = JSON.parse(gallery);
        if (Array.isArray(gallery) && gallery.length) {
            xml += "    <PictureDetails>";
            gallery.forEach(function(link) {
                if (link.indexOf("/core/media/media.nl") == 0) {
                    link = "https://" + NS_DOMAIN + link;
                }
                xml += "      <PictureURL>" + nlapiEscapeXML(link) + "</PictureURL>";
            });
            xml += "    </PictureDetails>";
        }
    }
    xml += [ "<ProductListingDetails>", "    <EAN>" + (that.val("custrecord_ef_ean") || "Does not apply") + "</EAN>", "    <ISBN>" + (that.val("custrecord_ef_isbn") || "Does not apply") + "</ISBN>", "    <UPC>" + (that.val("custrecord_ef_upc") || "Does not apply") + "</UPC>", "    </ProductListingDetails>" ].join("");
    if (!that.isSingleItem()) {
        var variations = that.val("custrecord_ebay_feed_variations");
        variations = JSON.parse(variations);
        xml += buildEbayVariationXML(variations, that);
    }
    var returnPolicyFlag = false;
    var custrecord_ef_prefer_data = that.val("custrecord_ef_prefer_data");
    if (custrecord_ef_prefer_data) {
        custrecord_ef_prefer_data = JSON.parse(custrecord_ef_prefer_data);
        if (custrecord_ef_prefer_data.hasOwnProperty("ReturnPolicy")) {
            returnPolicyFlag = true;
            var ReturnPolicy = custrecord_ef_prefer_data.ReturnPolicy;
            xml += [ "    <ReturnPolicy>", "      <ReturnsAcceptedOption>" + ReturnPolicy.ReturnsAcceptedOption + "</ReturnsAcceptedOption>", "      <RefundOption>" + ReturnPolicy.RefundOption + "</RefundOption>", "      <ReturnsWithinOption>" + ReturnPolicy.ReturnsWithinOption + "</ReturnsWithinOption>", "      <Description>" + ReturnPolicy.Description + "</Description>", "      <ShippingCostPaidByOption>" + ReturnPolicy.ShippingCostPaidByOption + "</ShippingCostPaidByOption>", "    </ReturnPolicy>" ].join("");
        }
    }
    if (returnPolicyFlag == false) {
        xml += [ "    <ReturnPolicy>", "      <ReturnsAcceptedOption>ReturnsAccepted</ReturnsAcceptedOption>", "      <RefundOption>MoneyBack</RefundOption>", "      <ReturnsWithinOption>Days_30</ReturnsWithinOption>", "      <Description>If you are not satisfied, return the item for refund.</Description>", "      <ShippingCostPaidByOption>Buyer</ShippingCostPaidByOption>", "    </ReturnPolicy>" ].join("");
    }
    xml += that.getShippingOptionsXML();
    xml += "  </Item>";
    return xml;
};

__EbayFeed.prototype.callVerifyAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<VerifyAddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += that.buildAddFixedPriceItemXML();
    xml += "</VerifyAddFixedPriceItemRequest>";
    return this.callAPI({
        "X-EBAY-API-SITEID": that.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "VerifyAddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml);
};

__EbayFeed.prototype.callAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<AddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += that.buildAddFixedPriceItemXML();
    xml += "</AddFixedPriceItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": that.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "AddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            _log("response.ItemID", response.ItemID);
            that.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            that.setFieldValue("custrecord_ebay_feed_item_id", response.ItemID);
            that.setFieldValue("custrecord_ebay_feed_first_online_dt", nlapiDateToString(new Date(), "datetimetz"));
            that.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
            that.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
            that.setFieldValue("custrecord_ebay_feed_online_ref", "T");
        }
    });
};

function createProxyImageURL(netsuiteImageURL) {
    netsuiteImageURL = netsuiteImageURL.substring(netsuiteImageURL.indexOf("?") + 1);
    netsuiteImageURL = netsuiteImageURL.split("&");
    var urlParams = {};
    netsuiteImageURL.forEach(function(item) {
        item = item.split("=");
        urlParams[item[0]] = item[1];
    });
    var h = urlParams["h"];
    var id = urlParams["id"];
    var position = {};
    for (var j = 0; j < id.length; j++) {
        var p = j + 1;
        position[p] = id.charAt(j);
    }
    var str = [];
    for (var i = 0; i < h.length; i++) {
        str.push(h.charAt(i));
    }
    var name = [];
    str.forEach(function(char, index) {
        if (position.hasOwnProperty(index)) {
            name.push(position[index]);
        }
        name.push(char);
    });
    return name.join("");
}

function run() {
    var feedSearchResults = null;
    var ebaySiteId = nlapiGetContext().getSetting("SCRIPT", "custscript_ebay_site");
    var custscript_ebay_additem_feedid = nlapiGetContext().getSetting("script", "custscript_ebay_additem_feedid");
    if (custscript_ebay_additem_feedid) {
        feedSearchResults = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("internalid", null, "is", custscript_ebay_additem_feedid), new nlobjSearchFilter("custrecord_ef_scheduled_status", null, "anyof", [ EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW, EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST ]) ], [ new nlobjSearchColumn("custrecord_ebay_feed_status"), new nlobjSearchColumn("custrecord_ef_scheduled_status") ]);
    } else {
        feedSearchResults = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "is", ebaySiteId), new nlobjSearchFilter("custrecord_ef_scheduled_status", null, "anyof", [ EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW, EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST ]), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ef_language", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("internalidnumber", null, "greaterthan", "13185") ], [ new nlobjSearchColumn("custrecord_ebay_feed_status"), new nlobjSearchColumn("custrecord_ef_scheduled_status") ]);
    }
    if (feedSearchResults != null) {
        for (var i = 0; i < feedSearchResults.length; i++) {
            var feedSearchResult = feedSearchResults[i];
            _log("feedSearchResult--- ID ---", feedSearchResult.getId());
            var feed = new __EbayFeed(feedSearchResult.getId());
            try {
                if (feed.getEbayItemId()) {
                    if (feedSearchResult.getValue("custrecord_ebay_feed_status") == EBAY_FEED_STATUS.ONLINE) {
                        feed.callEndItem();
                        feed.refresh();
                    }
                    feed.callRelistItem();
                } else {
                    feed.callAddFixedPriceItem();
                }
            } catch (e) {
                e = processException(e);
                if (e.code == "buildAddFixedPriceItemXML") {
                    feed.setFieldValue("custrecord_ebay_feed_call_ack", "buildAddFixedPriceItemXML");
                    feed.setFieldValue("custrecord_ebay_feed_api_message", e.message);
                    feed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW_ERROR);
                    feed.submitRecord();
                }
            }
            _log("__EbayFeed", "------------------------------ END: " + feed.getId() + " --------------------------------");
        }
    } else {
        _log("feedSearchResults", "No result.");
    }
}