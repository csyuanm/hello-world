function _getFieldArray(field) {
    var ShipToLocations = nlapiGetFieldValue(field);
    var ShipToLocationsText = nlapiGetFieldText(field);
    if (ShipToLocations) {
        ShipToLocations = ShipToLocations.split("");
        ShipToLocationsText = ShipToLocationsText.split("");
        ShipToLocations = ShipToLocations.map(function(loc, index) {
            return {
                value: loc,
                text: ShipToLocationsText[index]
            };
        });
    } else {
        ShipToLocations = [];
    }
    return ShipToLocations;
}

function saveRecord() {
    try {
        var shipping_options = {};
        shipping_options.ShipToLocations = _getFieldArray("custpage_shiptolocations");
        var GlobalShipping = nlapiGetFieldValue("custpage_globalshipping");
        shipping_options.GlobalShipping = {
            value: GlobalShipping,
            text: GlobalShipping == "T" ? true : false
        };
        shipping_options.ShippingDetails = {
            ShippingServiceOptions: [],
            InternationalShippingServiceOption: []
        };
        shipping_options.ShippingDetails.ShippingType = {
            value: nlapiGetFieldValue("custpage_shippingdetails_shippingtype"),
            text: nlapiGetFieldText("custpage_shippingdetails_shippingtype")
        };
        shipping_options.ShippingDetails.ExcludeShipToLocation = _getFieldArray("custpage_exclocation");
        for (var i = 1; i <= 4; i++) {
            var ShippingService = nlapiGetFieldValue("custpage_shipping_service" + i);
            var ShippingServiceCost = nlapiGetFieldValue("custpage_shipping_service_cost" + i);
            var ShippingServiceAdditionalCost = nlapiGetFieldValue("custpage_shipping_service_additional_cost" + i);
            var ShippingSurcharge = nlapiGetFieldValue("custpage_shipping_surcharge" + i);
            if (ShippingService) {
                var option = {
                    ShippingServicePriority: i,
                    ShippingService: {
                        value: nlapiGetFieldValue("custpage_shipping_service" + i),
                        text: nlapiGetFieldText("custpage_shipping_service" + i)
                    },
                    ShippingServiceCost: ShippingServiceCost,
                    ShippingServiceAdditionalCost: ShippingServiceAdditionalCost,
                    ShippingSurcharge: ShippingSurcharge
                };
                if (i == 1) {
                    var FreeShipping = nlapiGetFieldValue("custpage_shipping_service_freeshipping");
                    option.FreeShipping = {
                        value: FreeShipping,
                        text: FreeShipping == "T" ? true : false
                    };
                }
                shipping_options.ShippingDetails.ShippingServiceOptions.push(option);
            }
        }
        for (var j = 1; j <= 5; j++) {
            var ShippingService = nlapiGetFieldValue("custpage_int_shipping_service" + j);
            var ShippingServiceCost = nlapiGetFieldValue("custpage_int_shipping_service_cost" + j);
            var ShippingServiceAdditionalCost = nlapiGetFieldValue("custpage_int_shipping_service_additional_cost" + j);
            var ShipToLocation = nlapiGetFieldValue("custpage_int_shipto_location" + j);
            var ShipToLocationText = nlapiGetFieldText("custpage_int_shipto_location" + j);
            if (ShipToLocation) {
                ShipToLocation = ShipToLocation.split("");
                ShipToLocationText = ShipToLocationText.split("");
                ShipToLocation = ShipToLocation.map(function(location, index) {
                    return {
                        value: location,
                        text: ShipToLocationText[index]
                    };
                });
            } else {
                ShipToLocation = [];
            }
            if (ShippingService) {
                shipping_options.ShippingDetails.InternationalShippingServiceOption.push({
                    ShippingServicePriority: j,
                    ShippingService: {
                        value: nlapiGetFieldValue("custpage_int_shipping_service" + j),
                        text: nlapiGetFieldText("custpage_int_shipping_service" + j)
                    },
                    ShippingServiceCost: ShippingServiceCost,
                    ShippingServiceAdditionalCost: ShippingServiceAdditionalCost,
                    ShipToLocation: _getFieldArray("custpage_int_shipto_location" + j)
                });
            }
        }
        console.log(JSON.stringify(shipping_options, null, 2));
        nlapiSetFieldValue("custrecord_eso_shippingdetails", JSON.stringify(shipping_options));
    } catch (e) {
        processException(e);
    }
    return true;
}