function run(request, response) {
    var deploymentId = nlapiGetContext().getDeploymentId();
    if (deploymentId == "customdeploy_sl_ebayfeedrecord") {
        try {
            var buttonId = request.getParameter("buttonId");
            var feedId = request.getParameter("feedId");
            var ebayItemId = request.getParameter("ebayItemId");
            _log("buttonId", buttonId);
            _log("feedId", feedId);
            var ebayfeed = new __EbayFeed(feedId);
            if (request.getMethod() == "GET") {
                if (buttonId) {
                    if (isNaN(buttonId)) {} else {
                        buttonId = parseInt(buttonId);
                    }
                    var subs = nlapiGetSubsidiary();
                    var status = ebayfeed.val("custrecord_ebay_feed_status");
                    switch (buttonId) {
                      case EBAY_FEED_BUTTON.APPROVE:
                        if (subs == Subsidiaries.TaiwuInternational) {
                            ebayfeed.updateStatus(EBAY_FEED_STATUS.IN_QUE_NEW, EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW, false);
                            ebayfeed.saveAddFixedPriceItem();
                        } else {
                            ebayfeed.updateStatus(EBAY_FEED_STATUS.IN_QUE_NEW, null);
                        }
                        break;

                      case EBAY_FEED_BUTTON.RELIST_INQUE:
                        ebayfeed.updateStatus(null, EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST);
                        break;

                      case EBAY_FEED_BUTTON.CANCEL_INQUE:
                        _log("EBAY_FEED_BUTTON.CANCEL_INQUE", EBAY_FEED_BUTTON.CANCEL_INQUE);
                        if (subs == Subsidiaries.TaiwuInternational) {
                            if (status == EBAY_FEED_STATUS.IN_QUE_NEW) {
                                ebayfeed.updateStatus(EBAY_FEED_STATUS.NEW, EBAY_FEED_STATUS.SCHEDULED_NON_ACTION, false);
                            } else {
                                ebayfeed.updateStatus(null, null, false);
                            }
                            ebayfeed.setFieldValue("custrecord_ef_prep_listing_time_est", "");
                            ebayfeed.cancelAddFixedPriceItem();
                        } else {
                            if (status == EBAY_FEED_STATUS.IN_QUE_NEW) {
                                ebayfeed.updateStatus(EBAY_FEED_STATUS.NEW, EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
                            } else {
                                ebayfeed.updateStatus(null, null);
                            }
                        }
                        break;

                      case EBAY_FEED_BUTTON.RE_SUBMIT:
                        ebayfeed.updateStatus(EBAY_FEED_STATUS.WAITING_FOR_APPROVAL);
                        break;

                      case EBAY_FEED_BUTTON.DELIST:
                      case EBAY_FEED_BUTTON.FORCE_DELIST:
                        ebayfeed.callEndItem();
                        break;

                      case EBAY_FEED_BUTTON.REVISE:
                        ebayfeed.callReviseItem();
                        break;

                      case EBAY_FEED_BUTTON.revise_description.id:
                        ebayfeed.callReviseItem([ "custrecord_ebay_feed_description_fix" ]);
                        break;

                      case EBAY_FEED_BUTTON.use_legacy_description.id:
                        ebayfeed.callReviseItem([ "custrecord_ef_legacy_description" ]);
                        break;

                      case EBAY_FEED_BUTTON.RELIST:
                        if (ebayfeed.getStatus() == EBAY_FEED_STATUS.ONLINE) {
                            ebayfeed.callEndItem();
                            ebayfeed.refresh();
                        }
                        ebayfeed.callRelistItem();
                        break;

                      case EBAY_FEED_BUTTON.VerifyAddItem:
                        response.writeLine(JSON.stringify(ebayfeed.callVerifyAddFixedPriceItem(), null, 2));
                        return;

                      case EBAY_FEED_BUTTON.AddToEbay.id:
                      case EBAY_FEED_BUTTON.ADD_TO_EBAY:
                        ebayfeed.callAddFixedPriceItem();
                        break;

                      default:
                        _log_email("buttonId" + buttonId, "Not the button action in here.");
                        response.writeLine(JSON.stringify({
                            success: false,
                            buttonId: buttonId,
                            message: "Not the button action in here. ID: " + buttonId
                        }));
                        return;
                    }
                }
            } else {
                if (buttonId == EBAY_FEED_BUTTON.REJECT) {
                    ebayfeed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.REJECTED);
                    ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
                    ebayfeed.setFieldValue("custrecord_ebay_feed_reject_reason", request.getParameter("reason"));
                    ebayfeed.submitRecord();
                }
            }
            return response.writeLine(JSON.stringify({
                success: true,
                buttonId: buttonId,
                message: "buttonId" + buttonId + "IsOK"
            }));
        } catch (e) {
            e = processException(e, "buttonId: " + buttonId + " feedId: " + feedId);
            return response.writeLine(JSON.stringify({
                success: false,
                buttonId: buttonId,
                message: e.getUserMessage()
            }));
        }
    } else if (deploymentId == "customdeploy_sl_ebayfeedrecord_2") {
        if (request.getMethod() == "GET") {
            _log_email("sl ebay feed not found deploy for preview action", deploymentId);
        } else {
            var desc = request.getParameter("desc");
            var tpl = "5";
            var description = _templateMerge(nlapiLookupField("customrecord_ebay_template", tpl, "custrecord_eat_tpl"), {
                description_fix: desc
            });
            var html = [ "<!DOCTYPE html>", '<html xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/" lang="en">', "<head>", '    <style type="text/css">', "        body #Body .btn, body #Body c-std {", "            filter: none;", "            -ms-filter: \"progid:DXImageTransform.Microsoft.gradient(startColorstr='#0079bc',endColorstr='#00509d')\";", "        }", "    </style>", "</head>", '<body style="background-color: grey; margin: 0; padding: 0; text-align: center;">', '<div style="width: 1460px; background-color: white; margin: 0 auto;">', '    <div class="desc_div" style="width: 1393px; margin: 0 auto;">', description, "    </div>", "</div>", "</body>", "</html>" ].join("");
            response.write(html);
        }
    } else {
        _log_email("sl ebay feed not found deloy", deploymentId);
    }
}