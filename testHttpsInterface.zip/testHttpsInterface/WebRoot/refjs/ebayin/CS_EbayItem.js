console.log("Item Ebay Client View");

var SL_URL = {
    EbayFeed: "/app/site/hosting/scriptlet.nl?script=114&deploy=1",
    EbayItem: "/app/site/hosting/scriptlet.nl?script=470&deploy=1"
};

function verifyPictures(field, limit) {
    var pics = jQuery("#" + field + "_fs_lbl_uir_label").next("span").html().trim();
    console.log("pics");
    console.log(pics);
    pics = pics.replace(/&nbsp;/g, "");
    if (pics) {
        pics = JSON.parse(pics);
        if (pics.length < limit) {
            alert(field + " pictures size must be " + limit + "+!");
            return false;
        }
    } else {
        alert("There no " + field + "! please have a look this field on Ebay Pictures sub tab and fix it!");
        return false;
    }
    return true;
}

(function($, window, document, undefined) {
    loadCSS("/core/media/media.nl?id=16958&c=277620&h=84dec4ebe21112edc273&whence=");
    $("#recmachcustrecord_ei_item_link_main_form").children(".uir-list-filters").hide();
    $("#recmachcustrecord_eil_item_link_main_form").children(".uir-list-filters").hide();
    function newTabLink($ele) {
        var onclick = $ele.attr("onclick");
        $ele.removeAttr("onclick");
        $ele.on("click", function(e) {
            var link = onclick;
            link = link.replace(/document.location=\'|\'; return false;/g, "");
            console.log(link);
            e.preventDefault();
            openNewTab(link);
        });
    }
    newTabLink($("#newrecrecmachcustrecord_ei_item_link"));
    newTabLink($("#newrecrecmachcustrecord_eil_item_link"));
    function submitFeeds() {
        $.ajax({
            url: SL_URL.EbayItem,
            data: {
                action: "submit",
                item__internalid: nlapiGetFieldValue("id")
            },
            success: function(data) {
                console.log(data);
                PageOverlay.removeOverlay();
                NProgress.done(true);
                data = parseToJSON(data);
                if (data.name == "SUBMIT_FEED") {
                    alert(JSON.stringify(data.SYNC_REPORT, null, 2));
                } else {
                    alert(data.message);
                }
            },
            beforeSend: function() {
                PageOverlay.showOverlay();
                NProgress.start();
            }
        });
    }
    window.newFeeds = submitFeeds;
    window.viewFeeds = function() {
        var url = "/app/common/search/searchresults.nl?rectype=201&searchtype=Custom&CUSTRECORD_EBAY_FEED_ITEM=" + nlapiGetFieldValue("id") + "&CUSTRECORD_EF_LANGUAGE=@ALL@&CUSTRECORD_EBAY_FEED_ACCOUNT=@ALL@&CUSTRECORD_EBAY_FEED_GLOBAL_SITE=@ALL@&CUSTRECORD_EBAY_FEED_STATUS=@ALL@&CUSTRECORD_EBAY_FEED_MATRIX_ITEM=ANY&CUSTRECORD_EBAY_FEED_MATRIX_CHILD_ITEM=ANY&CUSTRECORD_EBAY_FEED_COMBO=ANY&CUSTRECORD_EBAY_FEED_API_SKU=&CUSTRECORD_EBAY_FEED_SKU=&style=NORMAL&CUSTRECORD_EBAY_FEED_API_SKUtype=STARTSWITH&CUSTRECORD_EBAY_FEED_SKUtype=STARTSWITH&report=&grid=&searchid=277" + "&dle=F" + "&sortcol=Custom_CREATED_raw&sortdir=DESC&csv=HTML&OfficeXML=F&pdf=&size=50&twbx=F";
        window.open(url, "_blank");
        window.focus();
    };
    window.printItemLabel = function() {
        var url = SL_URL.EbayItem + "&action=print_label&item__internalid=" + nlapiGetFieldValue("id");
        window.open(url, "_blank");
        window.focus();
    };
})(jQuery, window, document);

ossImageDisplay("custitem_item_var_picture", "textbox");

ossImageDisplay("custitem_ebay_gallery_pictures");

ossImageDisplay("custitem_ebay_body_pictures");

function __pageInit() {
    var $parent_lbl_uir_label = jQuery("#parent_lbl_uir_label");
    if ($parent_lbl_uir_label.length) {
        jQuery("#custom39_form").next().hide();
    }
}

__pageInit();