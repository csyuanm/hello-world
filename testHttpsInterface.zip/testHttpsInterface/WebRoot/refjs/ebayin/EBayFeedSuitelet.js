var Math2 = {
    parseValue: function(value) {
        if (typeof value == "number") {
            return value;
        } else {
            var stringValue = value.toString();
            stringValue = stringValue.replace(/,/g, "");
            if (stringValue.indexOf(".") != -1) {
                stringValue = parseFloat2(stringValue);
            } else {
                stringValue = parseInt2(stringValue);
            }
            return stringValue;
        }
    },
    makeValue: function(val) {
        return Math.round(this.parseValue(val) * 100) / 100;
    },
    add: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a + b) * 100) / 100;
    },
    sub: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a - b) * 100) / 100;
    },
    multiply: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a * b * 100) / 100;
    },
    division: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a / b * 100) / 100;
    },
    compare: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        a = Math.round(a * 100);
        b = Math.round(b * 100);
        if (a > b) {
            return 1;
        } else if (a < b) {
            return -1;
        } else {
            return 0;
        }
    }
};

function parseInt2(value) {
    value = value || 0;
    value = parseInt(value);
    if (isNaN(value)) value = 0;
    return value;
}

function parseFloat2(value) {
    value = value || 0;
    value = parseFloat(value);
    if (isNaN(value)) value = 0;
    return value;
}

if (typeof this.alert == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function processException(e, info) {
    var code, message;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = "nlobjError";
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + e.getStackTrace().join(", ");
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "\r\n" + info;
    }
    nlapiSendEmail(-5, "59532543@qq.com", code, message);
    return {
        code: code,
        message: message
    };
}

function _log(title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 2);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
        } else {
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            console.log(message);
        }
    }
}

function _log_email(title, detail) {
    nlapiSendEmail(-5, "59532543@qq.com", title, detail);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function extendFn(Fn) {
    Fn.extend = Fn.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function emailMergeObj(obj, tplId) {
    var emailResult = nlapiLoadFile(tplId).getValue();
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            emailResult = emailResult.replace(new RegExp(k, "g"), obj[o]);
        }
    }
    return emailResult;
}

function templateMerge(tpl, obj) {
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            var content = obj[o];
            content = content.replace(/\r\n/g, "<br/>");
            tpl = tpl.replace(new RegExp(k, "g"), content);
        }
    }
    return tpl;
}

function createHTML(html, obj) {
    for (var i in obj) {
        var k = "{{" + i + "}}";
        html = html.replace(new RegExp(k, "g"), obj[i]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    record[join] = {};
                    record[join][name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecord " + list.length, list);
    _log("__nlapiSearchRecord columnLabels", columnLabels);
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getSearchResult(search) {
    var columns = search.getColumns();
    var searchList = [];
    var resultSet = search.runSearch();
    resultSet.forEachResult(function(searchResult) {
        var record = {};
        for (var i = 0; i < columns.length; i++) {
            var column = columns[i];
            record[column.getName()] = {
                value: searchResult.getValue(column),
                text: searchResult.getText(column)
            };
        }
        searchList.push(record);
        return true;
    });
    _log("getSearchResult", searchList);
    return searchList;
}

function groupSearchResult(keys, array, toArray) {
    var group = {};
    array.forEach(function(item) {
        var key = "";
        if (typeof keys == "string") {
            key = item[keys].value;
        } else if (Array.isArray(keys)) {
            key = keys.map(function(key_name) {
                return key += item[key_name].value;
            }).join("___");
        } else {
            key = item["internalid"].value;
        }
        if (group.hasOwnProperty(key)) {
            group[key].push(item);
        } else {
            group[key] = [ item ];
        }
    });
    _log("groupSearchResult", group);
    if (toArray) {
        return obj_to_array(group);
    } else {
        return group;
    }
}

function obj_to_array(obj) {
    var list = [];
    for (var i in obj) {
        list.push(obj[i]);
    }
    return list;
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        _log("debug - [Profiling]", Math.round((new Date().getTime() - this.startTime) / 1e3) + "s");
    }
};

var EBayItemFeed = {
    __type: "customrecord_ebay_item_api_feed",
    uploadFeedMapping: {
        custrecord_ebay_feed_item: "itemRecordId",
        custrecord_ebay_feed_language: "eBayItemLanguageSetRecordId",
        custrecord_ebay_feed_site: "eBayItemSiteSettingRecordId",
        custrecord_ebay_feed_account: "eBayGlobalAccountSettingRecordId",
        custrecord_ebay_feed_seq: "itemTitlePictureSequenceId",
        custrecord_ebay_feed_push_qty: "custrecord_ei_qty",
        custrecord_ebay_feed_category_id: "site_category_id",
        custrecord_ebay_feed_specifics: "specificList",
        custrecord_ebay_feed_gallery: "gallery",
        custrecord_ebay_feed_body_picture: "bodyPicture",
        custrecord_ebay_feed_api_site: "country",
        custrecord_ebay_feed_api_sku: "sku",
        custrecord_ebay_feed_api_title: "title",
        custrecord_ebay_feed_api_baseprice: "baseprice",
        custrecord_ebay_feed_api_price: "price",
        custrecord_ebay_feed_currency: "currency",
        custrecord_ebay_feed_description: "description",
        custrecord_ebay_feed_language_code: "language_code",
        custrecord_ebay_feed_shippingdetails: "shippingDetails",
        custrecord_ebay_feed_returnpolicy: "returnPolicy",
        custrecord_ebay_feed_paypalaccount: "paypalAccount",
        custrecord_ebay_feed_seller_id: "sellerId",
        custrecord_ebay_feed_ship_ocation: "defaultShipFromLocation",
        custrecord_ebay_feed_token: "token"
    },
    create: function(feed) {
        var record = nlapiCreateRecord(this.__type);
        this.process(record, feed, "create");
        return nlapiSubmitRecord(record, true);
    },
    update: function(id, feed) {
        var record = nlapiLoadRecord(this.__type, id);
        var processResult = this.process(record, feed, "update");
        if (processResult.recordFieldChangedCount) {
            return nlapiSubmitRecord(record, true);
        } else {
            return id;
        }
    },
    search: function(id) {
        var fieldMapping = this.uploadFeedMapping;
        var columns = [];
        for (var i in fieldMapping) {
            columns.push(new nlobjSearchColumn(i));
        }
        [ "internalid", "custrecord_ebay_feed_category_title" ].forEach(function(name) {
            columns.push(new nlobjSearchColumn(name));
        });
        var searchResult = __nlapiSearchRecord(this.__type, null, [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ id ]) ], columns);
        searchResult.list.forEach(function(item, index) {
            index++;
            item.__no = index;
            item.__link = nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", item.internalid.value);
        });
        return searchResult;
    },
    process: function(record, feed, action) {
        var newFeedFieldMapping = this.uploadFeedMapping;
        var recordFieldChangedCount = 0;
        for (var field in newFeedFieldMapping) {
            var feedFieldValue;
            if (feed.hasOwnProperty(newFeedFieldMapping[field])) {
                feedFieldValue = feed[newFeedFieldMapping[field]];
            }
            if (!feedFieldValue) feedFieldValue = null;
            var setFlag = false;
            if (action == "create") {
                setFlag = true;
                recordFieldChangedCount++;
            } else {
                var recordFieldValue = record.getFieldValue(field) || record.getFieldText(field);
                if (Array.isArray(feedFieldValue)) {
                    feedFieldValue = JSON.stringify(feedFieldValue);
                }
                if (recordFieldValue != feedFieldValue) {
                    setFlag = true;
                    recordFieldChangedCount++;
                }
            }
            if (setFlag) {
                record.setFieldValue(field, feedFieldValue);
            }
        }
        _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
        return {
            recordFieldChangedCount: recordFieldChangedCount
        };
    }
};

function getEbayItemFeedList(item__internalid) {
    _log("getEbayItemFeedList ---- Start", "----------------------Start -------------------------");
    var itemSiteList = getEbayItemSiteList(item__internalid);
    var uploadList = [];
    for (var i = 0; i < itemSiteList.length; i++) {
        var siteItem = itemSiteList[i];
        var eBayGlobalAccountMapping = siteItem.eBayItemSiteSettingRecord.eBayGlobalAccountMapping;
        var price_change_rate = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_global_site_price_change;
        _log("price_change_rate", price_change_rate);
        if (price_change_rate) {
            price_change_rate = parseFloat(price_change_rate);
        } else {
            price_change_rate = 0;
        }
        for (var j = 0; j < eBayGlobalAccountMapping.length; j++) {
            var eBayGlobalAccountRecord = eBayGlobalAccountMapping[j];
            var sequenceList = [];
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence1 == "T") sequenceList.push("custrecord_title_pic_seq1");
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence2 == "T") sequenceList.push("custrecord_title_pic_seq2");
            for (var k = 0; k < sequenceList.length; k++) {
                var itemTitlePictureSequence = eBayGlobalAccountRecord[sequenceList[k]];
                itemTitlePictureSequence = itemTitlePictureSequence.text;
                var eBayFeedItem = {};
                eBayFeedItem.itemRecordId = siteItem.itemRecordId;
                eBayFeedItem.eBayItemSiteSettingRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemSiteSettingRecordId;
                eBayFeedItem.eBayItemLanguageSetRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.eBayItemLanguageSetRecordId;
                eBayFeedItem.eBayGlobalAccountSettingRecordId = eBayGlobalAccountRecord.eBayGlobalAccountSettingRecordId;
                eBayFeedItem.itemTitlePictureSequenceId = eBayGlobalAccountRecord[sequenceList[k]].value;
                if (!eBayFeedItem.itemTitlePictureSequenceId) continue;
                eBayFeedItem.itemTitlePictureSequence = itemTitlePictureSequence;
                eBayFeedItem.sku = siteItem.itemSKU;
                eBayFeedItem.site_category_id = siteItem.eBayItemSiteSettingRecord.custrecord_ei_site_category_id;
                eBayFeedItem.custrecord_ei_qty = siteItem.eBayItemSiteSettingRecord.custrecord_ei_qty;
                if (siteItem.baseprice) {
                    eBayFeedItem.baseprice = Math2.parseValue(siteItem.baseprice);
                    price_change_rate = price_change_rate.toString();
                    if (price_change_rate.charAt(0) == "-") {
                        price_change_rate = price_change_rate.replace("-", "");
                        eBayFeedItem.price = Math2.makeValue(siteItem.baseprice - parseFloat(price_change_rate));
                    } else {
                        eBayFeedItem.price = Math2.makeValue(siteItem.baseprice + parseFloat(price_change_rate));
                    }
                } else {
                    continue;
                }
                eBayFeedItem.specificList = siteItem.eBayItemSiteSettingRecord.specificList;
                eBayFeedItem.country = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_territory_id;
                eBayFeedItem.currency = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_default_currency;
                eBayFeedItem.language_code = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_language_code;
                eBayFeedItem.shippingDetails = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_shipping_details;
                eBayFeedItem.returnPolicy = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_return_policy;
                if (Math2.compare(eBayFeedItem.price, 12) == 1) {
                    eBayFeedItem.paypalAccount = eBayGlobalAccountRecord.custrecord_paypal_account_linked;
                } else {
                    eBayFeedItem.paypalAccount = eBayGlobalAccountRecord.custrecord_micro_paypal_account_linked;
                }
                eBayFeedItem.sellerId = eBayGlobalAccountRecord.sellerId;
                eBayFeedItem.defaultShipFromLocation = eBayGlobalAccountRecord.custrecord_default_ship_from_location;
                eBayFeedItem.token = eBayGlobalAccountRecord.api_token;
                var seq = itemTitlePictureSequence.split("-");
                if (Array.isArray(seq)) {
                    var titleNo = seq[0].replace("T", "");
                    eBayFeedItem.title = "TODO: Title with Junming round to create it.";
                    eBayFeedItem.description = siteItem.eBayItemDescription;
                    var gallerySeq = seq[1];
                    eBayFeedItem.gallery = getItemGallery(gallerySeq, siteItem.custitem_ebay_gallery_picture_columns);
                    var bodyPicSeq = seq[2];
                    eBayFeedItem.bodyPicture = getBodyPicture(bodyPicSeq, siteItem.custitem_ebay_body_picture_columns);
                } else {
                    eBayFeedItem.title = null;
                    eBayFeedItem.description = null;
                    eBayFeedItem.gallery = null;
                    eBayFeedItem.bodyPicture = null;
                }
                uploadList.push(eBayFeedItem);
            }
        }
    }
    _log("uploadList[]0", uploadList[0]);
    return uploadList;
}

function getItemGallery(seq, custitem_ebay_gallery_picture_columns) {
    if (!seq) return null;
    var list = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = seq.charAt(i);
        if (no == "0") no = "10";
        if (custitem_ebay_gallery_picture_columns.hasOwnProperty("custitem_ebay_gallery_picture_" + no)) {
            if (custitem_ebay_gallery_picture_columns["custitem_ebay_gallery_picture_" + no]) {
                list.push(custitem_ebay_gallery_picture_columns["custitem_ebay_gallery_picture_" + no]);
            }
        }
    }
    return list;
}

function getBodyPicture(seq, custitem_ebay_body_picture_columns) {
    if (!seq) return null;
    var list = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = null;
        var name = seq.charAt(i);
        switch (name) {
          case "A":
            no = 1;
            break;

          case "B":
            no = 2;
            break;

          case "C":
            no = 3;
            break;

          case "D":
            no = 4;
            break;

          case "E":
            no = 5;
            break;

          case "F":
            no = 6;
            break;

          case "G":
            no = 7;
            break;

          case "H":
            no = 8;
            break;

          case "I":
            no = 9;
            break;

          case "J":
            no = 10;
            break;

          default:
            no = 0;
        }
        no = "custitem_ebay_body_picture_" + no;
        if (custitem_ebay_body_picture_columns.hasOwnProperty(no) && custitem_ebay_body_picture_columns[no]) {
            list.push(custitem_ebay_body_picture_columns[no]);
        }
    }
    return list;
}

function getEbayItemSiteList(item__internalid) {
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]) ];
    var columns = [ new nlobjSearchColumn("internalid"), new nlobjSearchColumn("itemid"), new nlobjSearchColumn("baseprice"), new nlobjSearchColumn("class") ];
    columns.push(new nlobjSearchColumn("internalid", "custrecord_ei_item_link"));
    var custitem_ebay_gallery_picture_columns = [], custitem_ebay_body_picture_columns = [];
    for (var j = 1; j <= 10; j++) {
        custitem_ebay_gallery_picture_columns.push(new nlobjSearchColumn("custitem_ebay_gallery_picture_" + j));
        custitem_ebay_body_picture_columns.push(new nlobjSearchColumn("custitem_ebay_body_picture_" + j));
    }
    columns = columns.concat(custitem_ebay_gallery_picture_columns, custitem_ebay_body_picture_columns);
    var searchResults = nlapiSearchRecord("item", null, filter, columns);
    var itemSiteList = [];
    if (searchResults != null) {
        for (var i = 0; i < searchResults.length; i++) {
            var searchResult = searchResults[i];
            var itemRecord = {
                itemRecordId: searchResult.getValue("internalid"),
                itemSKU: searchResult.getValue("itemid"),
                baseprice: searchResult.getValue("baseprice"),
                "class": searchResult.getValue("class"),
                custrecord_ei_site_internalid: searchResult.getValue("internalid", "custrecord_ei_item_link")
            };
            itemRecord.eBayItemSiteSettingRecord = itemRecord.custrecord_ei_site_internalid ? loadEbayItemSiteSettingRecord(itemRecord.custrecord_ei_site_internalid) : null;
            var eBayItemTemplate = searchEbayItemTemplate(itemRecord.class, itemRecord.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_site);
            if (eBayItemTemplate == null) {
                itemRecord.eBayItemDescription = "[No description for this item!!]";
            } else {
                itemRecord.eBayItemDescription = templateMerge(eBayItemTemplate, {
                    sales_description: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_sale_description
                });
            }
            itemRecord.custitem_ebay_gallery_picture_columns = setPicture(searchResult, custitem_ebay_gallery_picture_columns);
            itemRecord.custitem_ebay_body_picture_columns = setPicture(searchResult, custitem_ebay_body_picture_columns);
            itemSiteList.push(itemRecord);
        }
    }
    return itemSiteList;
}

function searchEbayItemTemplate(classId, siteId) {
    if (!siteId) return null;
    _log("ON searchEbayItemTemplate", arguments);
    var search = __nlapiSearchRecord("customrecord_ebay_site_template", null, [ new nlobjSearchFilter("custrecordebay_st_class", null, "anyof", classId), new nlobjSearchFilter("custrecord_ebay_st_site", null, "anyof", siteId) ], [ new nlobjSearchColumn("custrecord_ebay_st_template") ]);
    if (search.list.length) {
        return search.list[0].custrecord_ebay_st_template.value;
    }
    return null;
}

function setPicture(searchResult, picture_columns) {
    var picture = {};
    picture_columns.forEach(function(colmun) {
        picture[colmun.getName()] = searchResult.getText(colmun);
    });
    return picture;
}

function loadEbayItemSiteSettingRecord(id) {
    var siteRecord = nlapiLoadRecord("customrecord_ebay_item_site_setting", id);
    var eBayItemSiteSettingRecord = {
        eBayItemSiteSettingRecordId: siteRecord.getId(),
        custrecord_ei_item_link: siteRecord.getFieldValue("custrecord_ei_item_link"),
        custrecord_ei_language_set: siteRecord.getFieldValue("custrecord_ei_language_set"),
        custrecord_ei_use_sequence1: siteRecord.getFieldValue("custrecord_ei_use_sequence1"),
        custrecord_ei_use_sequence2: siteRecord.getFieldValue("custrecord_ei_use_sequence2"),
        custrecord_ei_site_category_id: siteRecord.getFieldValue("custrecord_ei_site_category_id"),
        custrecord_ei_qty: siteRecord.getFieldValue("custrecord_ei_qty"),
        custrecord_ei_ebay_accounts: siteRecord.getFieldValue("custrecord_ei_ebay_accounts"),
        custrecord_ei_site: siteRecord.getFieldValue("custrecord_ei_site")
    };
    var specificList = [];
    for (var i = 0; i < 15; i++) {
        var line = i + 1;
        if (siteRecord.getFieldValue("custrecord_ei_specific" + line) && siteRecord.getFieldValue("custrecord_ei_specific_value" + line)) {
            specificList.push({
                specificName: siteRecord.getFieldValue("custrecord_ei_specific" + line),
                specificValue: siteRecord.getFieldValue("custrecord_ei_specific_value" + line)
            });
        }
    }
    eBayItemSiteSettingRecord.specificList = specificList;
    eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord = loadEbayGlobalSiteSettingRecord(eBayItemSiteSettingRecord.custrecord_ei_site);
    eBayItemSiteSettingRecord.eBayItemLanguageSetRecord = loadEbayItemLanguageSetRecord(eBayItemSiteSettingRecord.custrecord_ei_language_set);
    var eBayAccounts = eBayItemSiteSettingRecord.custrecord_ei_ebay_accounts;
    eBayAccounts = eBayAccounts.split("");
    eBayItemSiteSettingRecord.eBayGlobalAccountMapping = eBayAccounts.map(function(eBayAccountId) {
        return loadEbayGlobalAccountSettingRecord(eBayAccountId);
    });
    return eBayItemSiteSettingRecord;
}

function loadEbayItemLanguageSetRecord(id) {
    var languageRecord = nlapiLoadRecord("customrecord_ebay_item_language", id);
    return {
        eBayItemLanguageSetRecordId: languageRecord.getId(),
        name: languageRecord.getFieldValue("name"),
        custrecord_eil_item_link: languageRecord.getFieldValue("custrecord_eil_item_link"),
        custrecord_eil_sale_description: languageRecord.getFieldValue("custrecord_eil_sale_description"),
        custrecordcustrecord_eil_package_include: languageRecord.getFieldValue("custrecordcustrecord_eil_package_include"),
        custrecord_eil_package_excludes: languageRecord.getFieldValue("custrecord_eil_package_excludes"),
        custrecord_eil_additional_information: languageRecord.getFieldValue("custrecord_eil_additional_information")
    };
}

var __CACHE = {
    EbayGlobalAccountSettingRecord: {},
    EbayGlobalSiteSettingRecord: {}
};

function loadEbayGlobalAccountSettingRecord(eBayAccountId) {
    if (__CACHE.EbayGlobalAccountSettingRecord.hasOwnProperty(eBayAccountId)) {
        return __CACHE.EbayGlobalAccountSettingRecord[eBayAccountId];
    } else {
        _log("ONLY ONE loadEbayGlobalAccountSettingRecord", eBayAccountId);
        var eBayAccountRecord = nlapiLoadRecord("customrecord_ebay_accounts", eBayAccountId);
        var record = {
            eBayGlobalAccountSettingRecordId: eBayAccountRecord.getId(),
            sellerId: eBayAccountRecord.getFieldValue("name"),
            api_token: eBayAccountRecord.getFieldValue("custrecord_ebay_api_token"),
            custrecord_paypal_account_linked: eBayAccountRecord.getFieldText("custrecord_paypal_account_linked"),
            custrecord_micro_paypal_account_linked: eBayAccountRecord.getFieldText("custrecord_micro_paypal_account_linked"),
            custrecord_title_pic_seq1: {
                value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq1"),
                text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq1")
            },
            custrecord_title_pic_seq2: {
                value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq2"),
                text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq2")
            },
            custrecord_default_ship_from_location: eBayAccountRecord.getFieldText("custrecord_default_ship_from_location")
        };
        __CACHE.EbayGlobalAccountSettingRecord[eBayAccountId] = record;
        return record;
    }
}

function loadEbayGlobalSiteSettingRecord(ebayGlobalSiteSettingRecordId) {
    if (__CACHE.EbayGlobalSiteSettingRecord.hasOwnProperty(ebayGlobalSiteSettingRecordId)) {
        return __CACHE.EbayGlobalSiteSettingRecord[ebayGlobalSiteSettingRecordId];
    } else {
        _log("loadEbayGlobalSiteSettingRecord ONLYONE", ebayGlobalSiteSettingRecordId);
        var customrecord_ebay_global_record = nlapiLoadRecord("customrecord_ebay_global", ebayGlobalSiteSettingRecordId);
        var record = {
            custrecord_ebay_language_code: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_language_code"),
            custrecord_ebay_territory_id: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_territory_id"),
            custrecord_default_currency: customrecord_ebay_global_record.getFieldText("custrecord_default_currency"),
            custrecord_global_site_price_change: customrecord_ebay_global_record.getFieldValue("custrecord_global_site_price_change"),
            custrecord_ebay_gs_return_policy: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_return_policy"),
            custrecord_ebay_gs_shipping_details: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_shipping_details"),
            custrecord_ebay_gs_site: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_site")
        };
        __CACHE.EbayGlobalSiteSettingRecord[ebayGlobalSiteSettingRecordId] = record;
        return record;
    }
}

function run(request, response) {
    try {
        var p = new Profiling();
        var feedList = getEbayItemFeedList(request.getParameter("item__internalid"));
        _log("feedList size", feedList.length);
        for (var i = 0, len = feedList.length; i < len; i++) {
            var feed = feedList[i];
            var searchFilter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ feed.itemRecordId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_site", "anyof", [ feed.eBayItemSiteSettingRecordId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_language", "anyof", [ feed.eBayItemLanguageSetRecordId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_account", "anyof", [ feed.eBayGlobalAccountSettingRecordId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_seq", "anyof", [ feed.itemTitlePictureSequenceId ]) ];
            var feedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, searchFilter);
            if (feedSearch != null) {
                if (feedSearch.length && feedSearch.length == 1) {
                    var feedId = feedSearch[0].getId();
                    EBayItemFeed.update(feedId, feed);
                } else if (feedSearch.length > 1) {
                    _log_email("??? 2 record on feed", "check it");
                }
            } else {
                var newFeedId = EBayItemFeed.create(feed);
            }
        }
        p.end();
        response.write(JSON.stringify({
            success: true
        }));
    } catch (e) {
        processException(e, feed);
    }
}