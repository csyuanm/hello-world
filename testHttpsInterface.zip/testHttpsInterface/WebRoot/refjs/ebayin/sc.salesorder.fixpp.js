function run() {

    var yes = [];
    var no = [];

    var search = nlapiSearchRecord(null, '2798');
    if (search != null) {
        for (var i = 0; i < search.length; i++) {
            var so = search[i];
            var soId = so.getId();
            var ppId = so.getValue('custbody_paypal_transaction_id');
            var ppSearch = nlapiSearchRecord('customrecord_paypal_transaction', null, [
                new nlobjSearchFilter('custrecord_pp_id', null, 'is', ppId)
            ], [
                new nlobjSearchColumn('custrecord_pp_fee')
            ]);
            if (ppSearch != null && ppSearch.length == 1) {

                _deleteInvoice2(soId);

                var salesOrder = nlapiLoadRecord('salesorder', so.getId());
                // Payment Line
                // 80447	 	 	Paypal Fee Charge	 	For Sale
                // 98475 this for new one
                salesOrder.selectNewLineItem('item');
                //salesOrder.setCurrentLineItemValue('item', 'item', 102214); // Service Type Item
                salesOrder.setCurrentLineItemValue('item', 'item', 113345); // Paypal fee line item

                // 这个默认为1
                //salesOrder.setCurrentLineItemValue('item', 'quantity', _Transaction.QuantityPurchased);

                salesOrder.setCurrentLineItemValue('item', 'price', -1); // for Custom price level
                salesOrder.setCurrentLineItemValue('item', 'rate', ppSearch[0].getValue('custrecord_pp_fee'));

                salesOrder.commitLineItem('item');

                salesOrder.setFieldValue('custbody_pp_checked', 'F');
                nlapiSubmitRecord(salesOrder, true);

                yes.push(soId);

            } else {
                no.push(so.getId());
            }
        }
    }

    if (yes.length) {
        nlapiSendEmail(530, 'allan@zakeusa.com', 'PP fix yes: ' + yes.length, JSON.stringify({
            yes: yes,
            no: no
        }, null, 2));
    }
}

function _deleteInvoice2(soId) {
    // 如果有Payment 删除 Payment

    var filters = new Array();
    filters.push(new nlobjSearchFilter('subsidiary', null, 'is', 3));
    filters.push(new nlobjSearchFilter('createdfrom', null, 'is', soId));
    filters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
    var columns = new Array();
    columns.push(new nlobjSearchColumn('status'));
    columns.push(new nlobjSearchColumn('tranid'));
    var invList = nlapiSearchRecord('invoice', null, filters, columns);

    if (invList != null) {
        nlapiLogExecution('debug', 'invList', invList.length);
        if (invList.length == 1) {
            for (var i = 0; i < invList.length; i++) {
                var id = invList[i].getId();

                var pmtSearch = nlapiSearchRecord('customerpayment', null, [
                    new nlobjSearchFilter('appliedtotransaction', null, 'anyof', [id])
                ], [
                    new nlobjSearchColumn('total'),
                    new nlobjSearchColumn('total', 'appliedToTransaction')
                ]);

                if (pmtSearch != null) {
                    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId());

                    //if (pmtSearch[0].getValue('total') == pmtSearch[0].getValue('total', 'appliedToTransaction')) {
                    //    _log('删除Pmt', pmtSearch[0].getId());
                    //    nlapiDeleteRecord(pmtSearch[0].getRecordType(), pmtSearch[0].getId())
                    //}
                }

                nlapiDeleteRecord('invoice', id);
            }
        } else {
            nlapiSendEmail(530, 'allan@zakeusa.com', 'SO for multi invoice', soId);
        }

    }
}