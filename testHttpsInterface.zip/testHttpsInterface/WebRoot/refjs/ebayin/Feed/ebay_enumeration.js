var EBAY_SITE_MAPPING = {
    Australia: {
        langId: "1",
        _id: "2"
    },
    Austria: {
        langId: "18",
        _id: "1"
    },
    Belgium_Dutch: {
        langId: "12",
        _id: "19"
    },
    Belgium_French: {
        langId: "16",
        _id: "9"
    },
    Canada: {
        langId: "1",
        _id: "6"
    },
    CanadaFrench: {
        langId: "16",
        _id: "10"
    },
    France: {
        langId: "16",
        _id: "8"
    },
    Germany: {
        langId: "18",
        _id: "5"
    },
    HongKong: {
        langId: "3",
        _id: "12"
    },
    India: {
        langId: "1",
        _id: "14"
    },
    Ireland: {
        langId: "1",
        _id: "13"
    },
    Italy: {
        langId: "25",
        _id: "15"
    },
    Malaysia: {
        langId: "1",
        _id: "17"
    },
    eBayMotors: {
        langId: "1",
        _id: "16"
    },
    Netherlands: {
        langId: "12",
        _id: "18"
    },
    Philippines: {
        langId: "1",
        _id: "20"
    },
    Poland: {
        langId: "31",
        _id: "23"
    },
    Singapore: {
        langId: "1",
        _id: "21"
    },
    Spain: {
        langId: "36",
        _id: "7"
    },
    Switzerland: {
        langId: "18",
        _id: "3"
    },
    UK: {
        langId: "1",
        _id: "11"
    },
    US: {
        langId: "1",
        _id: "22"
    }
};

var EBAY_CONDITION_MAPPING = {
    "6000": "9",
    "7000": "10",
    "5000": "8",
    "2000": "4",
    "1000": "1",
    "1500": "2",
    "1750": "3",
    "2500": "5",
    "3000": "6",
    "4000": "7"
};

var EBAY_LISTING_DURATION = {
    GTC: 1,
    Days_3: 2,
    Days_5: 3,
    Days_7: 4,
    Days_10: 5,
    Days_14: 6,
    Days_1: 7,
    Days_120: 8,
    Days_21: 9,
    Days_30: 10,
    Days_60: 11,
    Days_90: 12
};

var EBAY_LISTING_TYPE = {
    AdType: 1,
    Auction: 2,
    Chinese: 3,
    CustomCode: 4,
    FixedPriceItem: 5,
    Half: 6,
    LeadGeneration: 7,
    PersonalOffer: 8,
    Shopping: 9,
    Unknown: 10
};