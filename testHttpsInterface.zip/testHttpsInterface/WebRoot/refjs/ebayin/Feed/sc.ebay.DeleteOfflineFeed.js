function run() {

    var search = nlapiLoadSearch(null, 544);
    search = search.runSearch();
    search = search.getResults(0, 1000);

    for (var i = 0, len = search.length; i < len; i++) {
        nlapiLogExecution('debug', 'index', i);
        try {
            nlapiDeleteRecord(search[i].getRecordType(), search[i].getId());
        } catch (e) {

            // custrecord_ebay_feed_parent
            var subs = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
                new nlobjSearchFilter('custrecord_ebay_feed_parent', null, 'is', search[i].getId())
            ]);
            if (subs != null) {
                subs.forEach(function (item) {
                    nlapiDeleteRecord(item.getRecordType(), item.getId())
                })
            }

            nlapiDeleteRecord(search[i].getRecordType(), search[i].getId());
        }
        checkGovernance();
    }

    var context = nlapiGetContext();
    if (search.length == 1000) {
        var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        _audit('nlapiScheduleScript', status);
    }

}