var FORCE_UPDATE = false;

var custscript_sellerlist_forceupdate = nlapiGetContext().getSetting("script", "custscript_sellerlist_forceupdate");

if (custscript_sellerlist_forceupdate == "T") {
    FORCE_UPDATE = true;
}

var custscript_syncfeed_returndescription = nlapiGetContext().getSetting("script", "custscript_syncfeed_returndescription");

function run() {
    try {
        var de = nlapiGetContext().getDeploymentId();
        _audit("de", de);
        var ebayAccountSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_account, null, [ new nlobjSearchFilter("custrecord_sync_feed_depolyment", null, "contains", de) ], [ new nlobjSearchColumn("name"), new nlobjSearchColumn("custrecord_ebay_api_token"), new nlobjSearchColumn("custrecord_ebay_global_site_access") ]);
        for (var i = 0, len = ebayAccountSearch.length; i < len; i++) {
            var searchResult = ebayAccountSearch[i];
            var token = searchResult.getValue("custrecord_ebay_api_token");
            var accountid = searchResult.getId();
            var profiling = new Profiling();
            SYNC_REPORT.accountid = accountid;
            _audit("---------- accountid -----------", accountid);
            try {
                getSellerList(accountid, token);
            } catch (e) {
                processException(e, accountid);
            }
            if (SYNC_REPORT.issues.length) {
                if (accountid != "15") {
                    _log_email("Get feed from ebay too mush errors " + accountid, JSON.stringify(SYNC_REPORT.issues));
                }
            }
            _audit("SYNC_REPORT", SYNC_REPORT);
            SYNC_REPORT = {
                accountid: null,
                total: 0,
                issues: [],
                updated: [],
                created: [],
                sync: []
            };
            setRecoveryPoint();
        }
    } catch (e) {
        processException(e);
    }
}

function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint();
    if (state.status == "SUCCESS") return;
    if (state.status == "RESUME") {
        nlapiLogExecution("ERROR", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        handleScriptRecovery();
    } else if (state.status == "FAILURE") {
        nlapiLogExecution("ERROR", "Failed to create recovery point. Reason = " + state.reason + " / Size = " + state.size);
        handleRecoveryFailure(state);
    }
}

function handleScriptRecovery() {}

function handleRecoveryFailure(state) {}

var SYNC_REPORT = {
    accountid: null,
    total: 0,
    issues: [],
    updated: [],
    created: [],
    sync: []
};

function getSellerList(accountid, token, pageNumber) {
    var context = nlapiGetContext();
    pageNumber = pageNumber || 1;
    _audit("pageNumber: " + pageNumber);
    var d = new Date();
    d.setHours(0);
    d.setMinutes(0);
    d.setSeconds(0);
    var endTimeFrom = this.moment(d).subtract(5, "days").format("YYYY-MM-DDTHH:mm:ss") + ".000Z";
    var endTimeTo = this.moment(d).add(35, "days").format("YYYY-MM-DDTHH:mm:ss") + ".000Z";
    var perpage = "    <EntriesPerPage>200</EntriesPerPage>";
    var level = "<GranularityLevel>Coarse</GranularityLevel>";
    if (custscript_syncfeed_returndescription == "T") {
        level = "<DetailLevel>ItemReturnDescription</DetailLevel>";
        perpage = "    <EntriesPerPage>50</EntriesPerPage>";
    }
    var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<GetSellerListRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "   <RequesterCredentials>", "      <eBayAuthToken>" + token + "</eBayAuthToken>", "   </RequesterCredentials>", level, "  <IncludeVariations>true</IncludeVariations>", "  <EndTimeFrom>" + endTimeFrom + "</EndTimeFrom> ", "  <EndTimeTo>" + endTimeTo + "</EndTimeTo>", "  <Pagination> ", perpage, "    <PageNumber>" + pageNumber + "</PageNumber>", "  </Pagination> ", "</GetSellerListRequest>" ];
    xml = _stringxml(xml);
    _audit("xml", xml);
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(EbayRequest.headers, {
        "X-EBAY-API-SITEID": "0",
        "X-EBAY-API-CALL-NAME": "GetSellerList",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "955"
    }));
    response = new X2JS().xml_str2json(response.getBody());
    if (response.GetSellerListResponse.Ack != "Failure") {
        if (response.GetSellerListResponse.PaginationResult.TotalNumberOfEntries != "0") {
            var items = _toarray(response.GetSellerListResponse.ItemArray.Item);
            SYNC_REPORT.total = items.length;
            for (var i = 0, len = items.length; i < len; i++) {
                var item = items[i];
                var itemid = item.ItemID;
                var sku = item.SKU;
                try {
                    syncEbayItemFeed(item);
                } catch (e) {
                    e = processException(e, null, false);
                    SYNC_REPORT.issues.push([ e.code, itemid, sku, item.SellingStatus.ListingStatus, "processException异常！", e.getUserMessage() ].join(", "));
                }
            }
            if (response.GetSellerListResponse.HasMoreItems == "true") {
                pageNumber++;
                response = null;
                _audit("getRemainingUsage", context.getRemainingUsage());
                checkGovernance(1e3);
                return getSellerList(accountid, token, pageNumber);
            }
        }
    }
}

function getNSItem(sku) {
    var skuarray = sku.split("|");
    if (skuarray.length && skuarray.length == 2) {
        sku = skuarray[0];
    }
    var itemSearch = nlapiSearchRecord("inventoryitem", null, [ [ [ "itemid", "is", sku ], "OR", [ "custitem_legacy_3b_sku", "is", sku ], "OR", [ "custitem_legacy_3b_sku_2", "is", sku ], "OR", [ "custitem_legacy_3b_sku_3", "is", sku ] ], "AND", [ [ "isinactive", "is", "F" ] ] ], [ new nlobjSearchColumn("custitem_legacy_3b_sku"), new nlobjSearchColumn("itemid") ]);
    if (itemSearch != null) {
        if (itemSearch.length == 1) {
            return itemSearch[0].getId();
        } else {
            return false;
        }
    } else {
        var dictionarySearchResults = nlapiSearchRecord("customrecord_ebay_account_dictionary", null, [ new nlobjSearchFilter("custrecord_ead_account", null, "is", SYNC_REPORT.accountid), new nlobjSearchFilter("custrecord_ead_ebay_sku", null, "is", sku) ], [ new nlobjSearchColumn("custrecord_ead_ns_mapping2"), new nlobjSearchColumn("custrecord_ead_combo") ]);
        if (dictionarySearchResults != null && dictionarySearchResults.length == 1) {
            var mapping2 = dictionarySearchResults[0].getValue("custrecord_ead_ns_mapping2");
            if (mapping2) {
                mapping2 = JSON.parse(mapping2);
                return {
                    combo: dictionarySearchResults[0].getValue("custrecord_ead_combo"),
                    mapping: mapping2
                };
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}

function syncEbayItemFeed(item) {
    if (item.hasOwnProperty("Variations")) {
        syncEbayItemVariationFeed(item);
    } else {
        if (!item.SKU) {
            throw nlapiCreateError("SINGLE_ITEM_ERROR", [ item.ItemID, item.SKU, item.SellingStatus.ListingStatus, "syncFeed单品 No SKU!!" ].join("~~~"));
        } else {
            syncEbayItemSimpleFeed(item);
        }
    }
}

function syncEbayItemVariationFeed(item) {
    var itemid = item.ItemID;
    var sku = item.SKU;
    var parentFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_item_id", null, "is", itemid), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", "@NONE@") ]);
    var parentFeedRecord = null;
    if (parentFeedSearch == null) {
        parentFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
        _submitParentFeedRefItem(parentFeedRecord, sku);
    } else {
        if (parentFeedSearch.length == 1) {
            parentFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", parentFeedSearch[0].getId());
            if (FORCE_UPDATE) _submitParentFeedRefItem(parentFeedRecord, sku);
        } else {
            throw createEbayError("parentFeedSearch: 发现了 多于一条的记录");
        }
    }
    var variations = {};
    var options_ebay = {};
    item.Variations.Variation.forEach(function(variation) {
        var NameValueList = _toarray(variation.VariationSpecifics.NameValueList);
        NameValueList.forEach(function(NameValue) {
            var Name = NameValue.Name;
            var Value = NameValue.Value;
            if (options_ebay.hasOwnProperty(Name)) {
                if (!options_ebay[Name].contains(Value)) {
                    options_ebay[Name].push(Value);
                }
            } else {
                options_ebay[Name] = [ Value ];
            }
        });
    });
    _log("options_ebay", options_ebay);
    variations.availOptions = [];
    for (var name in options_ebay) {
        var optionObject = {
            name: "",
            label: "",
            translation: name
        };
        optionObject.options = [ options_ebay[name] ];
        variations.availOptions.push(optionObject);
    }
    variations.childRecordList = item.Variations.Variation.map(function(variation) {
        var NameValueList = _toarray(variation.VariationSpecifics.NameValueList);
        return {
            __id: "",
            __type: "",
            itemid: variation.SKU,
            custitem_ebay_variation_picture: "",
            options: NameValueList.map(function(NameValue) {
                return {
                    label: {
                        name: "",
                        label: "",
                        translation: NameValue.Name
                    },
                    option: {
                        name: "",
                        value: "",
                        text: "",
                        translation: NameValue.Value
                    }
                };
            })
        };
    });
    _log("variations", variations);
    syncMasterFeedRecordFields(parentFeedRecord, item);
    var parentId = nlapiSubmitRecord(parentFeedRecord, true);
    if (parentId) {
        submitVariationChildFeedRecord(item, parentId);
    } else {
        throw createEbayError("parentId: Could not created.");
    }
    SYNC_REPORT.sync.push([ itemid, sku, item.SellingStatus.ListingStatus ]);
}

function _submitParentFeedRefItem(parentFeedRecord, sku) {
    if (!sku) {
        parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", null);
    } else {
        var ns_itemid = getNSItem(sku);
        if (ns_itemid == false || isNaN(ns_itemid)) {
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", null);
        } else {
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid);
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
        }
    }
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "T");
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_combo", "F");
}

function _setFeedRecordLocation(feedRecord, item) {
    if (item.Location.indexOf("South Bend") != -1) {
        feedRecord.setFieldValue("custrecord_ebay_feed_location", 2);
    } else if (item.Location.indexOf("United States") != -1) {
        feedRecord.setFieldValue("custrecord_ebay_feed_location", 2);
    } else {
        throw nlapiCreateError("syncMasterFeedRecordFields", "Not found the location on NS --- " + item.Location);
    }
}

function syncMasterFeedRecordFields(feedRecord, item) {
    if (item.hasOwnProperty("Description")) {
        _log("itemdescription", "yes");
        feedRecord.setFieldValue("custrecord_ef_legacy_description", item.Description);
    }
    var itemid = item.ItemID;
    var sku = item.SKU;
    var site = item.Site;
    if (!sku) sku = "";
    if (sku) {
        if (sku.indexOf("|") != -1) {
            feedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "F");
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "T");
        }
    } else {
        feedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "T");
    }
    feedRecord.setFieldValue("custrecord_ef_language", EBAY_SITE_MAPPING[item.Site].langId);
    feedRecord.setFieldValue("custrecord_ebay_feed_global_site", EBAY_SITE_MAPPING[item.Site]._id);
    feedRecord.setFieldValue("custrecord_ebay_feed_account", SYNC_REPORT.accountid);
    feedRecord.setFieldValue("custrecord_ebay_feed_api_price", item.SellingStatus.CurrentPrice.__text);
    feedRecord.setFieldValue("custrecord_ebay_feed_item_id", item.ItemID);
    feedRecord.setFieldValue("custrecord_ebay_feed_api_title", item.Title);
    feedRecord.setFieldValue("custrecord_ebay_feed_sku", sku);
    feedRecord.setFieldValue("custrecord_ebay_feed_online_ref", "T");
    feedRecord.setFieldValue("custrecord_ef_ebay_available_qty", parseInt(item.Quantity) - parseInt(item.SellingStatus.QuantitySold));
    var ListingDuration = item.ListingDuration;
    feedRecord.setFieldValue("custrecord_ef_listing_duration", EBAY_LISTING_DURATION[ListingDuration]);
    if (item.SellingStatus.ListingStatus == "Active") {
        feedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Online);
    } else {
        feedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Offline);
    }
    _setFeedRecordLocation(feedRecord, item);
    feedRecord.setFieldValue("custrecord_ebay_feed_category_id", item.PrimaryCategory.CategoryID);
    feedRecord.setFieldValue("custrecord_ebay_feed_condition", EBAY_CONDITION_MAPPING[item.ConditionID]);
    var prefer_data = {};
    prefer_data.ShipToLocations = _toarray(item.ShipToLocations);
    prefer_data.ReturnPolicy = item.ReturnPolicy;
    feedRecord.setFieldValue("custrecord_ef_prefer_data", JSON.stringify(prefer_data));
    var GalleryURL = _toarray(item.PictureDetails.GalleryURL);
    var PictureURL = _toarray(item.PictureDetails.PictureURL);
    feedRecord.setFieldValue("custrecord_ebay_feed_gallery", JSON.stringify(GalleryURL));
    feedRecord.setFieldValue("custrecord_ebay_feed_body_picture", JSON.stringify(PictureURL));
}

function submitVariationChildFeedRecord(item, parentId) {
    var itemid = item.ItemID;
    var sku = item.SKU;
    var variations = item.Variations.Variation;
    if (variations.some(function(vari) {
        return !vari.SKU;
    })) {
        throw createEbayError("Variation 里面缺失了一些SKU");
    }
    var _issues = [];
    var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", parentId) ], [ new nlobjSearchColumn("custrecord_ebay_feed_sku") ]);
    if (subFeedSearch == null) {
        variations.forEach(function(variation) {
            var ns_itemid = getNSItem(variation.SKU);
            if (ns_itemid == false) {
                _issues.push([ itemid, sku, ns_itemid, variation.SKU + "--- subFeedSearch 变参 SKU 未找到" ].join("///"));
            } else {
                var subFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                subFeedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
                var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                if (flag) {
                    var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                }
            }
        });
    } else {
        var newSKU = variations.map(function(item) {
            return item.SKU;
        });
        var oldSKU = subFeedSearch.map(function(searchResult) {
            return searchResult.getValue("custrecord_ebay_feed_sku");
        });
        var addSKU = newSKU.diff(oldSKU);
        var removeSKU = oldSKU.diff(newSKU);
        var sameSKU = newSKU.same(oldSKU);
        _log("addSKU", addSKU);
        _log("removeSKU", removeSKU);
        _log("sameSKU", sameSKU);
        addSKU.forEach(function(sku) {
            var variation = variations.filter(function(vari) {
                return vari.SKU == sku;
            });
            if (variation.length && variation.length == 1) {
                variation = variation[0];
                var ns_itemid = getNSItem(variation.SKU);
                if (ns_itemid == false) {
                    _issues.push([ itemid, sku, ns_itemid, variation.SKU + "---addSKU: 变参SKU未找到" ].join("///"));
                } else {
                    var subFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                    subFeedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
                    var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                    if (flag) {
                        var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                    }
                }
            } else {
                _issues.push([ itemid, sku, variation.SKU, "------addSKU 发现了更多的Variation" ].join("///"));
            }
        });
        removeSKU.forEach(function(sku) {
            var subFeed = subFeedSearch.filter(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_sku") == sku;
            });
            if (subFeed.length && subFeed.length == 1) {
                nlapiDeleteRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
            } else {
                _issues.push([ itemid, sku, subFeed[0].getId(), "------removeSKU 发现了更多的Variation" ].join("///"));
            }
        });
        sameSKU.forEach(function(sku) {
            var subFeed = subFeedSearch.filter(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_sku") == sku;
            });
            if (subFeed.length && subFeed.length == 1) {
                var variation = variations.filter(function(vari) {
                    return vari.SKU == sku;
                });
                if (variation.length && variation.length == 1) {
                    variation = variation[0];
                    if (FORCE_UPDATE) {
                        var ns_itemid = getNSItem(variation.SKU);
                        if (ns_itemid == false || isNaN(ns_itemid)) {
                            _issues.push([ itemid, sku, variation.SKU + "------sameSKU SKU 未发现" ].join("///"));
                        } else {
                            var subFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
                            var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                            if (flag) {
                                var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                            }
                        }
                    } else {
                        var subFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
                        var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, null, _issues);
                        if (flag) {
                            var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                        }
                    }
                } else {
                    _issues.push([ itemid, sku, subFeed[0].getId(), "------sameSKU 发现了更多的 Variation" ].join("///"));
                }
            } else {
                _issues.push([ itemid, sku, subFeed[0].getId(), "------sameSKU 发现了更多的 Variation" ].join("///"));
            }
        });
    }
    if (_issues.length) {
        throw createEbayError(_issues.join("\r\n"));
    }
}

function submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues) {
    var sku = variation.SKU;
    if (!sku) sku = "";
    if (sku) {
        if (sku.indexOf("|") != -1) {
            subFeedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "F");
        } else {
            subFeedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "T");
        }
    } else {
        subFeedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "T");
    }
    _syncItemInfo(subFeedRecord, ns_itemid);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "T");
    if (item.Location.indexOf("South Bend") != -1) {
        subFeedRecord.setFieldValue("custrecord_ebay_feed_location", 2);
    } else if (item.Location.indexOf("United States") != -1) {
        subFeedRecord.setFieldValue("custrecord_ebay_feed_location", 2);
    } else {
        _issues.push([ itemid, item.SKU, subFeedRecord.getId(), "------Not found the location on NS" ].join("///"));
        return false;
    }
    subFeedRecord.setFieldValue("custrecord_ebay_feed_parent", parentId);
    subFeedRecord.setFieldValue("custrecord_ef_language", EBAY_SITE_MAPPING[item.Site].langId);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_global_site", EBAY_SITE_MAPPING[item.Site]._id);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_account", SYNC_REPORT.accountid);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_api_price", variation.StartPrice.__text);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_item_id", "");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_api_title", "");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_sku", variation.SKU);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_online_ref", "T");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_status", null);
    subFeedRecord.setFieldValue("custrecord_ef_ebay_available_qty", parseInt(variation.Quantity) - parseInt(variation.SellingStatus.QuantitySold));
    var variationSpecifics = variation.VariationSpecifics;
    variationSpecifics = _toarray(variationSpecifics);
    _log("variationSpecifics", variationSpecifics);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_variations", JSON.stringify({
        options: variationSpecifics.map(function(vari) {
            vari = vari.NameValueList;
            return {
                label: {
                    name: "",
                    label: "",
                    translation: vari.Name
                },
                option: {
                    name: "",
                    value: "",
                    text: "",
                    translation: vari.Value
                }
            };
        })
    }));
    return true;
}

function _syncItemInfo(feedRecord, ns_itemid) {
    if (ns_itemid != null) {
        if (typeof ns_itemid == "object") {
            if (ns_itemid.combo == "F") {
                feedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid.mapping.i);
            } else {
                if (Array.isArray(ns_itemid.mapping)) {
                    feedRecord.setFieldValue("custrecord_ebay_feed_item", "");
                } else {
                    feedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid.mapping.i);
                    feedRecord.setFieldValue("custrecord_ef_combo_quantity", ns_itemid.mapping.q);
                }
            }
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
        }
        if (typeof ns_itemid == "object") {
            feedRecord.setFieldValue("custrecord_ebay_feed_combo", ns_itemid.combo);
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_combo", "F");
        }
        if (typeof ns_itemid == "object") {
            if (ns_itemid.combo == "F") {
                feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid.mapping.i);
            } else {
                if (Array.isArray(ns_itemid.mapping)) {
                    feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", JSON.stringify(ns_itemid.mapping));
                } else {
                    feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid.mapping.i);
                }
            }
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid);
        }
    }
}

function syncEbayItemSimpleFeed(item) {
    var itemid = item.ItemID;
    var sku = item.SKU;
    var feedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_item_id", null, "is", itemid) ]);
    if (feedSearch == null) {
        var ns_itemid = getNSItem(sku);
        if (ns_itemid == false) {
            throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, sku, item.SellingStatus.ListingStatus, "submitSingleFeedRecord单品 No SKU!! for false" ].join(", "));
        } else {
            var feedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
            _syncItemInfo(feedRecord, ns_itemid);
            feedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
            feedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
            syncMasterFeedRecordFields(feedRecord, item);
        }
    } else {
        if (feedSearch.length == 1) {
            if (FORCE_UPDATE) {
                var ns_itemid = getNSItem(sku);
                if (ns_itemid == false) {
                    throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, sku, item.SellingStatus.ListingStatus, "submitSingleFeedRecord单品 No SKU!! for false" ].join(", "));
                } else {
                    var feedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", feedSearch[0].getId());
                    _syncItemInfo(feedRecord, ns_itemid);
                    feedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
                    feedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
                    syncMasterFeedRecordFields(feedRecord, item);
                }
            } else {
                var feedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", feedSearch[0].getId());
                syncMasterFeedRecordFields(feedRecord, item);
            }
        } else {
            throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, sku, item.SellingStatus.ListingStatus, "单品 feedSearch.length more than 1" ].join(", "));
        }
    }
    nlapiSubmitRecord(feedRecord, true);
    SYNC_REPORT.sync.push([ itemid, sku, item.SellingStatus.ListingStatus ]);
}