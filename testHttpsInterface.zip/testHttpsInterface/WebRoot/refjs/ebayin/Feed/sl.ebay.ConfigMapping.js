function run() {

    var search = nlapiSearchRecord('customrecord_ebay_global', null, null, [
        new nlobjSearchColumn('custrecord_ebay_gs_sitecode'),
        new nlobjSearchColumn('custrecord_ebay_cs_country_code'),
        new nlobjSearchColumn('custrecord_ebay_site_primary_language')
    ]);

    var obj = {};
    search.forEach(function (searchResult) {
        obj[searchResult.getValue('custrecord_ebay_gs_sitecode')] = {
            langId: searchResult.getValue('custrecord_ebay_site_primary_language'),
            _id: searchResult.getId()
        };
    });

    var content = '';
    content += 'var EBAY_SITE_MAPPING = ' + JSON.stringify(obj) + ';';

    var searchCondition = nlapiSearchRecord('customrecord_ebay_item_condition', null, null, [
        new nlobjSearchColumn('custrecord_eic_condition_id')
    ]);

    var objCondition = {};
    searchCondition.forEach(function (searchResult) {
        objCondition[searchResult.getValue('custrecord_eic_condition_id')] = searchResult.getId();
    });

    content += 'var EBAY_CONDITION_MAPPING = ' + JSON.stringify(objCondition) + ';';

    content += getCustomListMapping();

    var f = nlapiCreateFile('ebay_enumeration.js', 'JAVASCRIPT', content);
    f.setFolder(295527); // Feed folder
    return nlapiSubmitFile(f);
}

function getCustomListMapping() {


    var col = new Array();
    col[0] = new nlobjSearchColumn('name');
    col[1] = new nlobjSearchColumn('internalId');

    var obj = {};

    var results = nlapiSearchRecord('customlist_ebay_listing_duration', null, null, col);
    for (var i = 0; results != null && i < results.length; i++) {
        var res = results[i];
        var listValue = (res.getValue('name'));
        var listID = (res.getValue('internalId'));


        obj[listValue] = listID;
    }

    return 'var EBAY_LISTING_DURATION = ' + JSON.stringify(obj) + ';';
}