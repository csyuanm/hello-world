function run() {


    var feedSearch = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
        new nlobjSearchFilter('custrecord_ebay_feed_status', null, 'is', '1'),
        new nlobjSearchFilter('custrecord_ebay_feed_account', null, 'is', '15'),
        new nlobjSearchFilter('custrecord_ebay_feed_matrix_child_item', null, 'is', 'F'),
        new nlobjSearchFilter('custrecord_ebay_feed_parent', null, 'is', '@NONE@')
    ], [
        new nlobjSearchColumn('custrecord_ef_legacy_description')
    ]);


    if (feedSearch != null) {

        var list = [];
        var len = feedSearch.length;
        if (len > 100) {
            len = 100;
        }
        for (var i = 0; i < len; i++) {
            list.push(feedSearch[i].getValue('custrecord_ef_legacy_description'))
        }


        var f = nlapiCreateFile('itemdescription.txt', 'PLAINTEXT', list.join('\r\n'));
        f.setFolder(1285); // :1285	EbayIntegration
        return nlapiSubmitFile(f);
    }


}