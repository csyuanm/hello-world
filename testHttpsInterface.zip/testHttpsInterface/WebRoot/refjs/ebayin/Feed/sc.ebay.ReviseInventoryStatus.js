var LIMIT_QUANTITY = 50;

var USEbayAccounts = [ EBAY_ACCOUNT.claimthis, EBAY_ACCOUNT.globalsalelovely, EBAY_ACCOUNT.maggieknows, EBAY_ACCOUNT["beauty-locker"] ];

var RunningEbayAccountID = null;

function run() {
    for (var i = 0; i < USEbayAccounts.length; i++) {
        var ebayAccountId = USEbayAccounts[i];
        _audit("ebayAccountId", ebayAccountId);
        RunningEbayAccountID = ebayAccountId;
        try {
            var ptime = new Profiling();
            var ebayaccount = nlapiLoadRecord(EbayRecordType.customrecord_ebay_account, ebayAccountId.InternalID);
            var token = ebayaccount.getFieldValue("custrecord_ebay_api_token");
            var search = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_online_ref", null, "is", "T"), new nlobjSearchFilter("inventorylocation", "custrecord_ebay_feed_item", "anyof", [ "2" ]), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "is", ebayAccountId.InternalID) ], [ new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("itemid", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("custrecord_ebay_feed_item_id"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_api_sku"), new nlobjSearchColumn("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty_override"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty") ]);
            if (search.length == 1e3) {
                _log_email("Update quantity search is reached max limit", "1000");
            }
            if (search != null) {
                _audit("search size", search.length);
                search = search.map(function(searchResult) {
                    var qty = searchResult.getValue("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM");
                    if (qty) {
                        qty = parseInt(qty);
                        if (qty > LIMIT_QUANTITY) {
                            qty = LIMIT_QUANTITY;
                        }
                    } else {
                        qty = 0;
                    }
                    var itemsku = searchResult.getValue("itemid", "CUSTRECORD_EBAY_FEED_ITEM");
                    if (itemsku.indexOf(" : ") != -1) {
                        itemsku = itemsku.substring(itemsku.indexOf(" : ") + 3);
                    }
                    return {
                        id: searchResult.getId(),
                        itemid: searchResult.getValue("custrecord_ebay_feed_item_id"),
                        sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                        itemsku: itemsku,
                        custrecord_ebay_feed_api_sku: searchResult.getValue("custrecord_ebay_feed_api_sku"),
                        qty: qty,
                        parentFeedItemId: searchResult.getValue("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"),
                        custrecord_ebay_feed_push_qty: searchResult.getValue("custrecord_ebay_feed_push_qty"),
                        custrecord_ebay_feed_push_qty_override: searchResult.getValue("custrecord_ebay_feed_push_qty_override"),
                        custrecord_ef_ebay_available_qty: searchResult.getValue("custrecord_ef_ebay_available_qty")
                    };
                });
                var issuesitem = search.filter(function(item) {
                    return item.itemsku != item.custrecord_ebay_feed_api_sku;
                });
                _log("issuesitem.length", issuesitem.length);
                if (issuesitem.length) {
                    search = search.filter(function(item) {
                        return item.itemsku == item.custrecord_ebay_feed_api_sku;
                    });
                    _log_email("issuesitem" + issuesitem.length, JSON.stringify(issuesitem, null, 2));
                }
                search = search.filter(function(item) {
                    return item.custrecord_ebay_feed_push_qty_override == "F" && parseInt(item.qty) != parseInt(item.custrecord_ef_ebay_available_qty) || item.custrecord_ebay_feed_push_qty_override == "T" && parseInt(item.custrecord_ebay_feed_push_qty) > parseInt(item.custrecord_ef_ebay_available_qty);
                });
                _audit("search.len", search.length);
                reviseInventoryStatus(search, token);
            }
            _auditUsage();
            ptime.end();
        } catch (e) {
            processException(e, JSON.stringify(ebayAccountId));
        }
        RunningEbayAccountID = null;
    }
}

function reviseInventoryStatus(search, token) {
    if (search.length) {
        try {
            var group = search.splice(0, 4);
            if (group.length) {
                _log(search.length, group);
                var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<ReviseInventoryStatusRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "        <eBayAuthToken>" + token + "</eBayAuthToken>", "  </RequesterCredentials>", group.map(function(feed) {
                    var qty = feed.qty;
                    if (feed.custrecord_ebay_feed_push_qty_override == "T") {
                        qty = feed.custrecord_ebay_feed_push_qty;
                    }
                    if (feed.parentFeedItemId) {
                        return [ "  <InventoryStatus>", "    <ItemID>" + feed.parentFeedItemId + "</ItemID>", "    <SKU>" + feed.sku + "</SKU>", "    <Quantity>" + qty + "</Quantity>", "  </InventoryStatus>" ].join("");
                    } else {
                        return [ "  <InventoryStatus>", "    <ItemID>" + feed.itemid + "</ItemID>", "    <Quantity>" + qty + "</Quantity>", "  </InventoryStatus>" ].join("");
                    }
                }).join(""), "</ReviseInventoryStatusRequest>" ].join("");
                var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(EbayRequest.headers, {
                    "X-EBAY-API-SITEID": "0",
                    "X-EBAY-API-CALL-NAME": "ReviseInventoryStatus",
                    "X-EBAY-API-COMPATIBILITY-LEVEL": "747"
                }));
                response = new X2JS().xml_str2json(response.getBody());
                if (response.ReviseInventoryStatusResponse.Ack != "Success") {
                    var reviseInventoryErrors = _toarray(response.ReviseInventoryStatusResponse.Errors);
                    reviseInventoryErrors.forEach(function(errorNode, index) {
                        errorNode.ErrorParameters = _toarray(errorNode.ErrorParameters);
                    });
                    group.forEach(function(item) {
                        var recId = item.id;
                        if (item.parentFeedItemId) {
                            var errorNode = _findVariationItemError(item, reviseInventoryErrors);
                            _effectFeedRecord(recId, errorNode);
                        } else {
                            var errorNode = _findItemError(item, reviseInventoryErrors);
                            _effectFeedRecord(recId, errorNode);
                        }
                    });
                } else {
                    group.forEach(function(item) {
                        var recId = item.id;
                        _effectFeedRecord(recId, null);
                    });
                }
            }
        } catch (e) {
            processException(e, {
                group: group,
                response: response
            });
        }
        return reviseInventoryStatus(search, token);
    }
}

function _effectFeedRecord(recId, errorNode) {
    var ignoreCode = [ 21917092, 21919189 ];
    if (errorNode == null) {
        var feedRecord = nlapiLoadRecord(EbayRecordType.customrecord_ebay_item_api_feed, recId);
        feedRecord.setFieldValue("custrecord_ebay_feed_call_ack", "Success");
        feedRecord.setFieldValue("custrecord_ebay_feed_error_code", "");
        feedRecord.setFieldValue("custrecord_ebay_feed_api_message", "");
        nlapiSubmitRecord(feedRecord, true);
    } else {
        if (!ignoreCode.contains(errorNode.ErrorCode)) {}
        var feedRecord = nlapiLoadRecord(EbayRecordType.customrecord_ebay_item_api_feed, recId);
        feedRecord.setFieldValue("custrecord_ebay_feed_call_ack", errorNode.SeverityCode);
        feedRecord.setFieldValue("custrecord_ebay_feed_error_code", errorNode.ErrorCode);
        feedRecord.setFieldValue("custrecord_ebay_feed_api_message", errorNode.LongMessage);
        nlapiSubmitRecord(feedRecord, true);
    }
}

function _findVariationItemError(item, reviseInventoryErrors) {
    for (var i = 0; i < reviseInventoryErrors.length; i++) {
        var error = reviseInventoryErrors[i];
        var itemid_val = error.ErrorParameters.filter(function(ep) {
            return ep.Value == item.itemid;
        });
        var sku_val = error.ErrorParameters.filter(function(ep) {
            return ep.Value == item.sku;
        });
        if (itemid_val.length && sku_val.length) {
            return error;
        }
    }
    return null;
}

function _findItemError(item, reviseInventoryErrors) {
    for (var i = 0; i < reviseInventoryErrors.length; i++) {
        var error = reviseInventoryErrors[i];
        var itemid_val = error.ErrorParameters.filter(function(ep) {
            return ep && ep.hasOwnProperty("Value") && ep.Value == item.itemid;
        });
        if (itemid_val.length) {
            return error;
        }
    }
    return null;
}