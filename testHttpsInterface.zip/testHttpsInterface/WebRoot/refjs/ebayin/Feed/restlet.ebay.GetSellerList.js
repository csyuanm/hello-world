var FORCE_UPDATE_ITEM_FLAG = false;

var SYNC_FEED_RETURN_DESCRIPTION_FLAG = false;

var LIMIT_QUANTITY = 5;

var SYNC_REPORT = {
    accountid: null,
    total: 0,
    issues: [],
    sync: []
};

var SUBS = "";

function getsellerlist_post(datain) {
    _log("postdatain", datain);
    var P = new Profiling();
    var info = datain.info;
    SYNC_REPORT.accountid = info.accountid;
    SYNC_REPORT.pageNumber = info.pageNumber;
    var subsidiary = info.subsidiary;
    if (subsidiary.indexOf("Zake International") != -1) {
        SUBS = "zake";
    } else {
        SUBS = "taiwu";
    }
    var items = _toarray(datain.Item);
    SYNC_REPORT.total = items.length;
    for (var i = 0, len = items.length; i < len; i++) {
        var item = items[i];
        var itemid = item.ItemID;
        var sku = item.SKU;
        if (itemid) {
            try {
                syncEbayItemFeed(item);
            } catch (e) {
                e = processException(e, [ itemid, sku ].join("\r\n") + "\r\n\r\n" + "<pre>" + JSON.stringify(item, null, 2) + "</pre>", false);
                var to = "allan@zakeusa.com";
                if (nlapiGetContext().getDeploymentId() != "customdeploy_ebay_getsellerlist_1") {
                    to = [ "allan@zakeusa.com", "zhonglinju@zakeusa.com", "caoliming@zakeusa.com", "zhengyunhui@zakeusa.com", "pengyafen@zakeusa.com", "zhongxiaoting@zakeusa.com", "zhanghongmei@zakeusa.com" ].join(",");
                }
                _sendEmail(to, e.title + " item id: " + itemid, e.body);
                SYNC_REPORT.issues.push([ e.code, itemid, sku, "processException异常！", e.getUserMessage() ].join(", "));
            }
        }
    }
    SYNC_REPORT._time = P.end();
    return SYNC_REPORT;
}

function syncEbayItemFeed(item) {
    if (item.hasOwnProperty("Variations")) {
        syncEbayItemVariationFeed(item);
    } else {
        if (!item.SKU) {
            if (item.SellingStatus && item.SellingStatus.hasOwnProperty("ListingStatus")) {
                throw nlapiCreateError("SINGLE_ITEM_ERROR", [ item.ItemID, item.SKU, item.SellingStatus.ListingStatus, "syncFeed单品 No SKU!!" ].join(" - "));
            } else {
                throw nlapiCreateError("SINGLE_ITEM_ERROR", [ item.ItemID, item.SKU, "木有ListingStatus", "syncFeed单品 No SKU!!" ].join(" - "));
            }
        } else {
            syncEbayItemSimpleFeed(item);
        }
    }
}

function syncEbayItemVariationFeed(item) {
    var itemid = item.ItemID;
    var sku = item.SKU;
    var parentFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_item_id", null, "is", itemid), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", "@NONE@") ]);
    var parentFeedRecord = null;
    if (parentFeedSearch == null) {
        if (item.SellingStatus.ListingStatus == "Active") {
            parentFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
            _submitParentFeedRefItem(parentFeedRecord, sku, item);
        } else {
            return;
        }
    } else {
        if (parentFeedSearch.length == 1) {
            parentFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", parentFeedSearch[0].getId());
            if (FORCE_UPDATE_ITEM_FLAG) {
                _submitParentFeedRefItem(parentFeedRecord, sku, item);
            }
        } else {
            throw createEbayError("parentFeedSearch: 发现了 多于一条的记录");
        }
    }
    var variations = {};
    var options_ebay = {};
    item.Variations.Variation = _toarray(item.Variations.Variation);
    item.Variations.Variation.forEach(function(variation) {
        var NameValueList = _toarray(variation.VariationSpecifics.NameValueList);
        NameValueList.forEach(function(NameValue) {
            var Name = NameValue.Name;
            var Value = NameValue.Value;
            if (options_ebay.hasOwnProperty(Name)) {
                if (!options_ebay[Name].contains(Value)) {
                    options_ebay[Name].push(Value);
                }
            } else {
                options_ebay[Name] = [ Value ];
            }
        });
    });
    _log("options_ebay", options_ebay);
    variations.availOptions = [];
    for (var name in options_ebay) {
        var optionObject = {
            name: "",
            label: "",
            translation: name
        };
        optionObject.options = options_ebay[name].map(function(item) {
            return {
                id: "",
                value: "",
                translation: item
            };
        });
        variations.availOptions.push(optionObject);
    }
    _log("variations", variations);
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_variations", JSON.stringify(variations));
    syncMasterFeedRecordFields(parentFeedRecord, item);
    var parentId = nlapiSubmitRecord(parentFeedRecord, true);
    if (parentId) {
        submitVariationChildFeedRecord(item, parentId);
    } else {
        throw createEbayError("parentId: Could not created.");
    }
    SYNC_REPORT.sync.push([ itemid, sku, item.SellingStatus.ListingStatus ]);
}

function _setParentFeedTag(parentFeedRecord, matrix, matrixchild, combo) {
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", matrix);
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", matrixchild);
    parentFeedRecord.setFieldValue("custrecord_ebay_feed_combo", combo);
}

function _submitParentFeedRefItem(parentFeedRecord, sku, item) {
    if (item.SellingStatus.ListingStatus == "Active") {
        parentFeedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Online);
    } else {
        parentFeedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Offline);
        return;
    }
    if (!sku) {
        parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", null);
        parentFeedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", "");
        parentFeedRecord.setFieldValue("custrecord_ef_kit", null);
        _setParentFeedTag(parentFeedRecord, "T", "F", "F");
    } else {
        var ns_itemid = getNSItem(sku, "parent");
        if (ns_itemid == false) {
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", null);
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", "");
            parentFeedRecord.setFieldValue("custrecord_ef_kit", null);
            _setParentFeedTag(parentFeedRecord, "T", "F", "F");
        } else if (typeof ns_itemid == "object") {
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", null);
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", "");
            parentFeedRecord.setFieldValue("custrecord_ef_kit", ns_itemid.id);
            _setParentFeedTag(parentFeedRecord, "T", "F", "T");
        } else {
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
            parentFeedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid);
            parentFeedRecord.setFieldValue("custrecord_ef_kit", null);
            _setParentFeedTag(parentFeedRecord, "T", "F", "F");
        }
    }
}

function _setFeedRecordLocation(feedRecord, item) {}

function syncMasterFeedRecordFields(feedRecord, item) {
    feedRecord.setFieldValue("custrecord_ef_api_data", JSON.stringify(item));
    if (item.SellingStatus.ListingStatus == "Active") {
        feedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Online);
    } else {
        feedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Offline);
        return;
    }
    feedRecord.setFieldValue("custrecord_ef_quantitysold", item.SellingStatus.QuantitySold);
    if (item.hasOwnProperty("Description")) {
        _log_email("itemdescription", "yes");
        feedRecord.setFieldValue("custrecord_ef_legacy_description", item.Description);
    }
    var itemid = item.ItemID;
    var sku = item.SKU;
    var site = item.Site;
    if (!sku) sku = "";
    var custrecord_ef_ns_created = feedRecord.getFieldValue("custrecord_ef_ns_created");
    if (!custrecord_ef_ns_created || custrecord_ef_ns_created == "F") {
        feedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "T");
    } else {
        feedRecord.setFieldValue("custrecord_ebay_feed_is_legacy", "F");
    }
    feedRecord.setFieldValue("custrecord_ef_language", EBAY_SITE_MAPPING[item.Site].langId);
    feedRecord.setFieldValue("custrecord_ebay_feed_global_site", EBAY_SITE_MAPPING[item.Site]._id);
    feedRecord.setFieldValue("custrecord_ebay_feed_account", SYNC_REPORT.accountid);
    feedRecord.setFieldValue("custrecord_ebay_feed_api_price", item.SellingStatus.CurrentPrice.__text);
    feedRecord.setFieldValue("custrecord_ebay_feed_item_id", item.ItemID);
    feedRecord.setFieldValue("custrecord_ebay_feed_api_title", item.Title);
    feedRecord.setFieldValue("custrecord_ef_location_country", item.Country);
    feedRecord.setFieldValue("custrecord_ef_location_name", item.Location);
    feedRecord.setFieldValue("custrecord_ebay_feed_sku", sku);
    feedRecord.setFieldValue("custrecord_ebay_feed_online_ref", "T");
    feedRecord.setFieldValue("custrecord_ef_ebay_available_qty", parseInt(item.Quantity) - parseInt(item.SellingStatus.QuantitySold));
    if (SUBS == "taiwu") {
        if (!feedRecord.getFieldValue("custrecord_ebay_feed_push_qty")) {
            feedRecord.setFieldValue("custrecord_ebay_feed_push_qty", parseInt(item.Quantity) - parseInt(item.SellingStatus.QuantitySold));
        }
    }
    var ListingDuration = item.ListingDuration;
    feedRecord.setFieldValue("custrecord_ef_listing_duration", EBAY_LISTING_DURATION[ListingDuration]);
    _setFeedRecordLocation(feedRecord, item);
    feedRecord.setFieldValue("custrecord_ebay_feed_category_id", item.PrimaryCategory.CategoryID);
    if (item.hasOwnProperty("ConditionID")) {
        feedRecord.setFieldValue("custrecord_ebay_feed_condition", EBAY_CONDITION_MAPPING[item.ConditionID]);
    } else {
        feedRecord.setFieldValue("custrecord_ebay_feed_condition", 11);
    }
    var prefer_data = {};
    prefer_data.ShipToLocations = _toarray(item.ShipToLocations);
    prefer_data.ReturnPolicy = item.ReturnPolicy;
    feedRecord.setFieldValue("custrecord_ef_prefer_data", JSON.stringify(prefer_data));
    if (item.ListingType) {
        feedRecord.setFieldValue("custrecord_ef_listing_type", EBAY_LISTING_TYPE[item.ListingType]);
    }
}

function submitVariationChildFeedRecord(item, parentId) {
    var itemid = item.ItemID;
    var sku = item.SKU;
    var variations = item.Variations.Variation;
    if (variations.some(function(vari) {
        return !vari.SKU;
    })) {
        throw createEbayError("Variation 里面缺失了一些SKU");
    }
    var _issues = [];
    var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", parentId) ], [ new nlobjSearchColumn("custrecord_ebay_feed_sku") ]);
    if (subFeedSearch == null) {
        if (item.SellingStatus.ListingStatus == "Active") {
            variations.forEach(function(variation) {
                var ns_itemid = getNSItem(variation.SKU);
                if (ns_itemid == false) {
                    _issues.push([ itemid, sku, ns_itemid, variation.SKU + ": 变参SKU未找到 subFeedSearch" ].join(" - "));
                } else {
                    var subFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                    var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                    if (flag) {
                        var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                    }
                }
            });
        }
    } else {
        var newSKU = variations.map(function(item) {
            return item.SKU;
        });
        var oldSKU = subFeedSearch.map(function(searchResult) {
            return searchResult.getValue("custrecord_ebay_feed_sku");
        });
        var addSKU = newSKU.diff(oldSKU);
        var removeSKU = oldSKU.diff(newSKU);
        var sameSKU = newSKU.same(oldSKU);
        _log("addSKU", addSKU);
        _log("removeSKU", removeSKU);
        _log("sameSKU", sameSKU);
        if (item.SellingStatus.ListingStatus != "Active") {
            subFeedSearch.forEach(function(subFeed) {
                nlapiSubmitField("customrecord_ebay_item_api_feed", subFeed.getId(), "custrecord_ebay_feed_status", EbayFeedStatus.Offline);
            });
            return;
        }
        addSKU.forEach(function(sku) {
            var variation = variations.filter(function(vari) {
                return vari.SKU == sku;
            });
            if (variation.length && variation.length == 1) {
                variation = variation[0];
                var ns_itemid = getNSItem(variation.SKU);
                if (ns_itemid == false) {
                    _issues.push([ itemid, sku, ns_itemid, variation.SKU + ": addSKU变参SKU未找到" ].join(" - "));
                } else {
                    var subFeedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                    var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                    if (flag) {
                        var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                    }
                }
            } else {
                _issues.push([ itemid, sku, variation.SKU, ": addSKU发现了更多的Variation" ].join(" - "));
            }
        });
        removeSKU.forEach(function(sku) {
            var subFeed = subFeedSearch.filter(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_sku") == sku;
            });
            if (subFeed.length && subFeed.length == 1) {
                nlapiDeleteRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
            } else {
                _issues.push([ itemid, sku, subFeed[0].getId(), ": removeSKU发现了更多的Variation" ].join(" - "));
            }
        });
        sameSKU.forEach(function(sku) {
            var subFeed = subFeedSearch.filter(function(searchResult) {
                return searchResult.getValue("custrecord_ebay_feed_sku") == sku;
            });
            if (subFeed.length && subFeed.length == 1) {
                var variation = variations.filter(function(vari) {
                    return vari.SKU == sku;
                });
                if (variation.length && variation.length == 1) {
                    variation = variation[0];
                    if (FORCE_UPDATE_ITEM_FLAG) {
                        var ns_itemid = getNSItem(variation.SKU);
                        if (ns_itemid == false) {
                            _issues.push([ itemid, sku, variation.SKU + ": sameSKU SKU 未发现" ].join(" - "));
                        } else {
                            var subFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
                            var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues);
                            if (flag) {
                                var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                            }
                        }
                    } else {
                        var subFeedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", subFeed[0].getId());
                        var flag = submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, null, _issues);
                        if (flag) {
                            var subFeedId = nlapiSubmitRecord(subFeedRecord, true);
                        }
                    }
                } else {
                    _issues.push([ itemid, sku, subFeed[0].getId(), ": sameSKU 发现了更多的 Variation" ].join(" - "));
                }
            } else {
                _issues.push([ itemid, sku, subFeed[0].getId(), ": sameSKU 发现了更多的 Variation" ].join(" - "));
            }
        });
    }
    if (_issues.length) {
        throw createEbayError(_issues.join("\r\n"));
    }
}

function submitVariationSubFeedRecord(subFeedRecord, item, variation, parentId, itemid, ns_itemid, _issues) {
    if (item.SellingStatus.ListingStatus == "Active") {
        subFeedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Online);
    } else {
        subFeedRecord.setFieldValue("custrecord_ebay_feed_status", EbayFeedStatus.Offline);
        return;
    }
    subFeedRecord.setFieldValue("custrecord_ef_quantitysold", variation.SellingStatus.QuantitySold);
    subFeedRecord.setFieldValue("customform", 173);
    var sku = variation.SKU;
    if (!sku) sku = "";
    _syncItemInfo(subFeedRecord, ns_itemid);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "T");
    if (item.ListingType) {
        subFeedRecord.setFieldValue("custrecord_ef_listing_type", EBAY_LISTING_TYPE[item.ListingType]);
    }
    subFeedRecord.setFieldValue("custrecord_ebay_feed_parent", parentId);
    subFeedRecord.setFieldValue("custrecord_ef_language", EBAY_SITE_MAPPING[item.Site].langId);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_global_site", EBAY_SITE_MAPPING[item.Site]._id);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_account", SYNC_REPORT.accountid);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_api_price", variation.StartPrice.__text);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_item_id", itemid);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_api_title", "");
    subFeedRecord.setFieldValue("custrecord_ebay_feed_sku", variation.SKU);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_online_ref", "T");
    subFeedRecord.setFieldValue("custrecord_ef_ebay_available_qty", parseInt(variation.Quantity) - parseInt(variation.SellingStatus.QuantitySold));
    if (SUBS == "taiwu") {
        if (!subFeedRecord.getFieldValue("custrecord_ebay_feed_push_qty")) {
            subFeedRecord.setFieldValue("custrecord_ebay_feed_push_qty", parseInt(variation.Quantity) - parseInt(variation.SellingStatus.QuantitySold));
        }
    }
    if (variation.hasOwnProperty("VariationProductListingDetails")) {
        var VariationProductListingDetails = variation.VariationProductListingDetails;
        if (VariationProductListingDetails.hasOwnProperty("ISBN")) {
            subFeedRecord.setFieldValue("custrecord_ef_isbn", VariationProductListingDetails.ISBN);
        }
        if (VariationProductListingDetails.hasOwnProperty("UPC")) {
            subFeedRecord.setFieldValue("custrecord_ef_upc", VariationProductListingDetails.UPC);
        }
        if (VariationProductListingDetails.hasOwnProperty("EAN")) {
            subFeedRecord.setFieldValue("custrecord_ef_ean", VariationProductListingDetails.EAN);
        }
    }
    var variationSpecifics = variation.VariationSpecifics;
    _log("variationSpecifics_parent" + parentId, variationSpecifics);
    var NameValueList = _toarray(variationSpecifics.NameValueList);
    subFeedRecord.setFieldValue("custrecord_ebay_feed_variations", JSON.stringify({
        options: NameValueList.map(function(NameValue) {
            return {
                label: {
                    name: "",
                    label: "",
                    translation: NameValue.Name
                },
                option: {
                    name: "",
                    value: "",
                    text: "",
                    translation: NameValue.Value
                }
            };
        })
    }));
    return true;
}

function _syncItemInfo(feedRecord, ns_itemid) {
    if (ns_itemid != null) {
        if (typeof ns_itemid == "object") {
            feedRecord.setFieldValue("custrecord_ebay_feed_item", null);
            feedRecord.setFieldValue("custrecord_ef_kit", ns_itemid.id);
            feedRecord.setFieldValue("custrecord_ebay_feed_combo", "T");
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_item", ns_itemid);
            feedRecord.setFieldValue("custrecord_ef_kit", null);
            feedRecord.setFieldValue("custrecord_ebay_feed_combo", "F");
        }
        if (typeof ns_itemid == "object") {
            feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid.id);
        } else {
            feedRecord.setFieldValue("custrecord_ebay_feed_ns_ref_id", ns_itemid);
        }
    }
}

function syncEbayItemSimpleFeed(item) {
    var itemid = item.ItemID;
    var ebayItemListingSKU = item.SKU;
    var feedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_item_id", null, "is", itemid) ], [ new nlobjSearchColumn("custrecord_ebay_feed_api_sku"), new nlobjSearchColumn("custrecord_ebay_feed_item") ]);
    if (feedSearch == null) {
        if (item.SellingStatus.ListingStatus == "Active") {
            var ns_itemid = getNSItem(ebayItemListingSKU);
            if (ns_itemid == false) {
                throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, ebayItemListingSKU, item.SellingStatus.ListingStatus, "submitSingleFeedRecord单品 No SKU!! for false" ].join(", "));
            } else {
                var feedRecord = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                _syncItemInfo(feedRecord, ns_itemid);
                feedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
                feedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
                feedRecord.setFieldValue("custrecord_ebay_feed_parent", null);
                syncMasterFeedRecordFields(feedRecord, item);
            }
        } else {
            return;
        }
    } else {
        if (feedSearch.length == 1) {
            if (item.SellingStatus.ListingStatus == "Active" && FORCE_UPDATE_ITEM_FLAG) {
                var ns_itemid = getNSItem(ebayItemListingSKU);
                if (ns_itemid == false) {
                    throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, ebayItemListingSKU, item.SellingStatus.ListingStatus, "submitSingleFeedRecord单品 No SKU!! for false" ].join(", "));
                } else {
                    var feedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", feedSearch[0].getId());
                    _syncItemInfo(feedRecord, ns_itemid);
                    feedRecord.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
                    feedRecord.setFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
                    feedRecord.setFieldValue("custrecord_ebay_feed_parent", null);
                    syncMasterFeedRecordFields(feedRecord, item);
                }
            } else {
                var feedRecord = nlapiLoadRecord("customrecord_ebay_item_api_feed", feedSearch[0].getId());
                syncMasterFeedRecordFields(feedRecord, item);
            }
        } else {
            throw nlapiCreateError("SINGLE_ITEM_ERROR", [ itemid, ebayItemListingSKU, item.SellingStatus.ListingStatus, "单品 feedSearch.length more than 1" ].join(", "));
        }
    }
    nlapiSubmitRecord(feedRecord, true);
    SYNC_REPORT.sync.push([ itemid, ebayItemListingSKU, item.SellingStatus.ListingStatus ]);
}

function getNSItem(ebayItemListingSKU, code) {
    var skuarray = ebayItemListingSKU.split("|");
    if (skuarray.length && skuarray.length == 2) {
        ebayItemListingSKU = skuarray[0];
    }
    ebayItemListingSKU = ebayItemListingSKU.trim();
    if (!ebayItemListingSKU) {
        return false;
    }
    if (SUBS == "zake") {
        var filter = [ [ [ "itemid", "is", ebayItemListingSKU ], "OR", [ "custitem_legacy_3b_sku", "is", ebayItemListingSKU ], "OR", [ "custitem_legacy_3b_sku_2", "is", ebayItemListingSKU ], "OR", [ "custitem_legacy_3b_sku_3", "is", ebayItemListingSKU ] ], "AND", [ "isinactive", "is", "F" ], "AND", [ "subsidiary", "is", Subsidiaries.ZakeInternational ] ];
        var itemSearch = nlapiSearchRecord("inventoryitem", null, filter, [ new nlobjSearchColumn("custitem_legacy_3b_sku"), new nlobjSearchColumn("itemid") ]);
        if (itemSearch != null) {
            if (itemSearch.length == 1) {
                return itemSearch[0].getId();
            } else {
                return false;
            }
        } else {
            return _searchKit(ebayItemListingSKU);
        }
    } else if (SUBS == "taiwu") {
        return _searchTaiwuItem(ebayItemListingSKU, code);
    } else {
        throw nlapiCreateError("SINGLE_ITEM_ERROR", "位置的Subsidiary: " + SUBS);
    }
}

function _searchTaiwuItem(sku, code) {
    try {
        var columns = new Array();
        columns[0] = new nlobjSearchColumn("internalid");
        columns[1] = new nlobjSearchColumn("itemid");
        columns[2] = new nlobjSearchColumn("description");
        columns[3] = new nlobjSearchColumn("preferredlocation");
        columns[4] = new nlobjSearchColumn("location");
        var filter = [ [ "subsidiary", "is", Subsidiaries.TaiwuInternational ], "AND", [ "isinactive", "is", "F" ], "AND", [ "matrix", "is", "F" ], "AND", [ [ "name", "is", sku ], "OR", [ "custitem_legacy_tong_sku", "is", sku ] ] ];
        if (code == "parent") {
            filter = [ [ "subsidiary", "is", Subsidiaries.TaiwuInternational ], "AND", [ "isinactive", "is", "F" ], "AND", [ "matrix", "is", "T" ], "AND", [ "matrixchild", "is", "F" ], "AND", [ [ "name", "is", sku ], "OR", [ "custitem_legacy_tong_sku", "is", sku ] ] ];
        }
        var search = nlapiSearchRecord("item", null, filter, columns);
        if (search != null) {
            if (search.length == 1) {
                return search[0].getId();
            } else {
                throw createEbayError("Item search result size wrong! SKU: " + sku + " and search size: " + search.length);
            }
        } else {
            if (code == "parent") {
                return false;
            }
            columns[5] = new nlobjSearchColumn("custitem_sku_alias");
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("subsidiary", null, "is", Subsidiaries.TaiwuInternational), new nlobjSearchFilter("custitem_sku_alias", null, "contains", sku), new nlobjSearchFilter("matrix", null, "is", "F") ], columns);
            if (search != null) {
                var sku_alias = search.map(function(searchResult) {
                    return {
                        id: searchResult.getId(),
                        location: searchResult.getValue("location"),
                        alias: searchResult.getValue("custitem_sku_alias")
                    };
                });
                var match = sku_alias.filter(function(item) {
                    var alias = item.alias.split(";");
                    return alias.indexOf(sku) != -1;
                });
                if (match.length == 1) {
                    _log("match custitem_sku_alias got result");
                    return match[0].id;
                } else {
                    throw createEbayError("Item search custitem_sku_alias result size wrong! SKU: " + sku + " and search size: " + search.length);
                }
            } else {
                return _searchKit(sku);
            }
        }
    } catch (e) {
        processException(e, sku + "|" + code);
    }
    return false;
}

function _searchKit(ebayItemListingSKU) {
    var kitSearch = nlapiSearchRecord("customrecord_kit", null, [ [ "custrecord_kit_marketplace", "noneof", MarketplaceShipName.Amazon ], "AND", [ [ "custrecord_kit_sku", "is", ebayItemListingSKU ], "OR", [ "custrecord_sku_alias", "is", ebayItemListingSKU ] ] ], [ new nlobjSearchColumn("custrecord_kit_mapping") ]);
    if (kitSearch != null && kitSearch.length == 1) {
        return {
            combo: true,
            id: kitSearch[0].getId(),
            mapping: kitSearch[0].getValue("custrecord_kit_mapping")
        };
    } else {
        return false;
    }
}