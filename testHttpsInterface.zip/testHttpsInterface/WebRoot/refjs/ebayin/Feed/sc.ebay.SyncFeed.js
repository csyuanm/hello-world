function runReviseInventoryStatus(ebayAccount, id) {
    if (nlapiGetContext().getDeploymentId() == "customdeploy_sc_ebay_syncfeed_test") {
        try {
            var subsidiary = ebayAccount.subsidiary;
            if (subsidiary == Subsidiaries.ZakeInternational) {
                _updateInventoryStatusByWarehouse(ebayAccount, id);
                _reviseComboFeed(ebayAccount, id);
            } else if (subsidiary == Subsidiaries.TaiwuInternational) {
                _updateInventoryStatusByWarehouse(ebayAccount, id);
            } else {
                _log_email("No this subsidiary, ", JSON.stringify(ebayAccount));
            }
        } catch (e) {
            processException(e, JSON.stringify(ebayAccount));
        }
    }
}

function getAccountAccess(ebayAccount) {
    var token = ebayAccount.custrecord_ebay_api_token;
    var headers = {
        "X-EBAY-API-APP-NAME": ebayAccount["X-EBAY-API-APP-NAME"],
        "X-EBAY-API-DEV-NAME": ebayAccount["X-EBAY-API-DEV-NAME"],
        "X-EBAY-API-CERT-NAME": ebayAccount["X-EBAY-API-CERT-NAME"],
        "Content-Type": "application/xml"
    };
    var isBig = ebayAccount.isBig;
    if (isBig == "T") {
        var otherToken = nlapiSearchRecord("customrecord_ebay_token", null, [ new nlobjSearchFilter("custrecord_ebay_token_of", null, "is", ebayAccount.id) ], [ new nlobjSearchColumn("custrecord_ebay_token_text"), new nlobjSearchColumn("custrecord_ed_app_name", "custrecord_ebay_token_dev_acc"), new nlobjSearchColumn("custrecord_ed_dev_name", "custrecord_ebay_token_dev_acc"), new nlobjSearchColumn("custrecord_ed_cert_name", "custrecord_ebay_token_dev_acc") ]);
        if (otherToken != null) {
            otherToken = otherToken[0];
            token = otherToken.getValue("custrecord_ebay_token_text");
            headers = {
                "X-EBAY-API-APP-NAME": otherToken.getValue("custrecord_ed_app_name", "custrecord_ebay_token_dev_acc"),
                "X-EBAY-API-DEV-NAME": otherToken.getValue("custrecord_ed_dev_name", "custrecord_ebay_token_dev_acc"),
                "X-EBAY-API-CERT-NAME": otherToken.getValue("custrecord_ed_cert_name", "custrecord_ebay_token_dev_acc"),
                "Content-Type": "application/xml"
            };
        }
    }
    return {
        token: token,
        headers: headers
    };
}

function _updateInventoryStatusByWarehouse(ebayAccount, id, location) {
    var ebayAccountId = ebayAccount.id;
    var quantityLimit = LIMIT_QUANTITY;
    var maxPushQuantity = ebayAccount.custrecord_acc_max_push_quantity;
    if (maxPushQuantity) {
        maxPushQuantity = parseInt(maxPushQuantity);
        quantityLimit = maxPushQuantity;
    }
    _audit(ebayAccount.name, "quantityLimit: " + quantityLimit);
    var access = getAccountAccess(ebayAccount);
    var subsidiary = ebayAccount.subsidiary;
    var lastId = 0;
    var count = 0;
    var report = [];
    var apiTimes = 0;
    do {
        count++;
        var filter = [ new nlobjSearchFilter("custrecord_ebay_feed_online_ref", null, "is", "T"), new nlobjSearchFilter("formulatext", null, "is", "yes").setFormula("case when {custrecord_ebay_feed_location.namenohierarchy}={custrecord_ebay_feed_item.inventorylocation} then 'yes' else 'no' end"), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "is", ebayAccountId) ];
        filter.push(new nlobjSearchFilter("internalidnumber", null, "greaterthan", lastId));
        if (id && Array.isArray(id) && id.length) {
            filter.push(new nlobjSearchFilter("internalid", null, "anyof", id));
        }
        var again = false;
        var search = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter, [ new nlobjSearchColumn("internalid").setSort(), new nlobjSearchColumn("custrecord_ebay_feed_call_ack"), new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("itemid", "CUSTRECORD_EBAY_FEED_ITEM"), new nlobjSearchColumn("custrecord_ebay_feed_item_id"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_api_sku"), new nlobjSearchColumn("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"), new nlobjSearchColumn("custrecord_ef_cease_when_sold_out"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty"), new nlobjSearchColumn("custrecord_ebay_feed_combo"), new nlobjSearchColumn("custrecord_ef_combo_quantity"), new nlobjSearchColumn("custrecord_acc_max_push_quantity", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custitem_internal_marketing_position", "custrecord_ebay_feed_item") ]);
        if (search != null && search.length == 1e3) {
            again = true;
        }
        if (search != null) {
            _audit("Count for " + count, search.length);
            lastId = search[search.length - 1].getId();
            _audit("REVISE INVENTORY STATUS --- search size", search.length);
            search = search.map(function(searchResult) {
                var __quantity = 0;
                var act_location_quantity = parseInt(searchResult.getValue("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM") || 0);
                var push_qty = parseInt(searchResult.getValue("custrecord_ebay_feed_push_qty") || 0);
                var max_push_qty = parseInt(searchResult.getValue("custrecord_ef_max_push_qty") || 0);
                _audit("act_location_quantity|push_qty|max_push_qty", act_location_quantity + " | " + push_qty + " | " + max_push_qty);
                var marketPosition = searchResult.getValue("custitem_internal_marketing_position", "custrecord_ebay_feed_item");
                if (!marketPosition) marketPosition = 2;
                if (marketPosition == 1) {
                    if (push_qty) {
                        __quantity = parseInt(push_qty);
                    } else if (max_push_qty) {
                        max_push_qty = parseInt(max_push_qty);
                        if (act_location_quantity > max_push_qty) {
                            __quantity = max_push_qty;
                        } else {
                            __quantity = act_location_quantity;
                        }
                    } else {
                        if (act_location_quantity > quantityLimit) {
                            __quantity = quantityLimit;
                        } else {
                            __quantity = act_location_quantity;
                        }
                    }
                } else if (marketPosition == 2 || marketPosition == 3 || marketPosition == 5 || !marketPosition) {
                    if (!max_push_qty) max_push_qty = 100;
                    if (max_push_qty) {
                        max_push_qty = parseInt(max_push_qty);
                        if (act_location_quantity > max_push_qty) {
                            __quantity = max_push_qty;
                        } else {
                            __quantity = act_location_quantity;
                        }
                    } else {
                        __quantity = act_location_quantity;
                    }
                } else if (marketPosition == 4) {
                    __quantity = 0;
                } else {
                    __quantity = act_location_quantity;
                }
                var itemsku = searchResult.getValue("itemid", "CUSTRECORD_EBAY_FEED_ITEM");
                if (itemsku.indexOf(" : ") != -1) {
                    itemsku = itemsku.substring(itemsku.indexOf(" : ") + 3);
                }
                return {
                    id: searchResult.getId(),
                    custrecord_ebay_feed_call_ack: searchResult.getValue("custrecord_ebay_feed_call_ack"),
                    itemid: searchResult.getValue("custrecord_ebay_feed_item_id"),
                    sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                    itemsku: itemsku,
                    custrecord_ebay_feed_api_sku: searchResult.getValue("custrecord_ebay_feed_api_sku"),
                    qty: __quantity,
                    parentFeedItemId: searchResult.getValue("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"),
                    custrecord_ef_ebay_available_qty: searchResult.getValue("custrecord_ef_ebay_available_qty")
                };
            });
            var needSyncSearch = search.filter(function(item) {
                return parseInt(item.qty) != parseInt(item.custrecord_ef_ebay_available_qty);
            });
            _audit("///准备要reviseInventoryStatus 的Search Length 是", needSyncSearch.length);
            if (needSyncSearch.length) {
                report = report.concat(needSyncSearch);
                var times = reviseInventoryStatus2(needSyncSearch, access.token, access.headers);
                apiTimes += times;
            }
            checkGovernance();
        } else {
            _audit("No search results");
        }
    } while (again);
    if (apiTimes > 150) {
        _log_email(ebayAccount.name, JSON.stringify(report, null, 2));
    }
    return apiTimes;
}

function reviseInventoryStatus(search, token) {
    if (search.length) {
        try {
            var group = search.splice(0, 4);
            if (group.length) {
                var response = _reviseGroup(group, token);
            }
        } catch (e) {
            processException(e, {
                group: group,
                response: response
            });
        }
        checkGovernance();
        return reviseInventoryStatus(search, token);
    }
}

function reviseInventoryStatus2(search, token, headers) {
    var times = 0;
    if (search.length) {
        var group = search.splice(0, 4);
        while (group.length) {
            try {
                var response = _reviseGroup(group, token, headers);
                times++;
            } catch (e) {
                processException(e, {
                    times: times,
                    group: group,
                    response: response
                });
            }
            group = search.splice(0, 4);
            checkGovernance();
        }
    }
    return times;
}

function _reviseGroup(group, token, headers) {
    var xml = [ '<?xml version="1.0" encoding="utf-8"?>', '<ReviseInventoryStatusRequest xmlns="urn:ebay:apis:eBLBaseComponents">', "  <RequesterCredentials>", "        <eBayAuthToken>" + token + "</eBayAuthToken>", "  </RequesterCredentials>", group.map(function(feed) {
        var qty = feed.qty;
        if (feed.parentFeedItemId) {
            return [ "  <InventoryStatus>", "    <ItemID>" + feed.parentFeedItemId + "</ItemID>", "    <SKU>" + feed.sku + "</SKU>", "    <Quantity>" + qty + "</Quantity>", "  </InventoryStatus>" ].join("");
        } else {
            return [ "  <InventoryStatus>", "    <ItemID>" + feed.itemid + "</ItemID>", "    <Quantity>" + qty + "</Quantity>", "  </InventoryStatus>" ].join("");
        }
    }).join(""), "</ReviseInventoryStatusRequest>" ].join("");
    _audit("request xml", xml);
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(headers, {
        "X-EBAY-API-SITEID": "0",
        "X-EBAY-API-CALL-NAME": "ReviseInventoryStatus",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "747"
    }));
    var responseXML = response.getBody();
    response = new X2JS().xml_str2json(responseXML);
    _audit("response", response);
    if (response.ReviseInventoryStatusResponse.Ack == "Success") {
        group.forEach(function(item) {
            var recId = item.id;
            var qty = item.qty;
            _effectFeedRecord(recId, null, "", "", qty);
        });
    } else {
        var Errors = _toarray(response.ReviseInventoryStatusResponse.Errors);
        Errors.forEach(function(Error, index) {
            Error.ErrorParameters = _toarray(Error.ErrorParameters);
        });
        group.forEach(function(item) {
            try {
                var recId = item.id;
                var qty = item.qty;
                if (item.parentFeedItemId) {
                    var errorNode = _findVariationItemError(item, Errors);
                    if (response.ReviseInventoryStatusResponse.Ack == "Warning") {
                        _effectFeedRecord(recId, errorNode, xml, responseXML, qty);
                    } else {
                        _effectFeedRecord(recId, errorNode, xml, responseXML);
                    }
                } else {
                    var errorNode = _findItemError(item, Errors);
                    if (response.ReviseInventoryStatusResponse.Ack == "Warning") {
                        _effectFeedRecord(recId, errorNode, xml, responseXML, qty);
                    } else {
                        _effectFeedRecord(recId, errorNode, xml, responseXML);
                    }
                }
            } catch (e) {
                processException(e, recId + "\r\n" + JSON.stringify(response));
            }
        });
    }
    return response;
}

function _effectFeedRecord(recId, errorNode, requestXML, responseXML, qty) {
    var feedRecord = nlapiLoadRecord(EbayRecordType.customrecord_ebay_item_api_feed, recId);
    var ignoreCode = [ 21917092, 21919189 ];
    if (!errorNode) {
        feedRecord.setFieldValue("custrecord_ebay_feed_call_ack", "Success");
        feedRecord.setFieldValue("custrecord_ebay_feed_error_code", "");
        feedRecord.setFieldValue("custrecord_ebay_feed_api_message", "");
        feedRecord.setFieldValue("custrecord_ebay_feed_last_api_request", requestXML);
        feedRecord.setFieldValue("custrecord_ebay_feed_last_api_response", responseXML);
        feedRecord.setFieldValue("custrecord_ef_ebay_available_qty", qty);
    } else {
        if (!ignoreCode.contains(errorNode.ErrorCode)) {}
        feedRecord.setFieldValue("custrecord_ebay_feed_call_ack", errorNode.SeverityCode);
        feedRecord.setFieldValue("custrecord_ebay_feed_error_code", errorNode.ErrorCode);
        feedRecord.setFieldValue("custrecord_ebay_feed_api_message", errorNode.LongMessage);
        feedRecord.setFieldValue("custrecord_ebay_feed_last_api_request", requestXML);
        feedRecord.setFieldValue("custrecord_ebay_feed_last_api_response", responseXML);
        if (qty) {
            feedRecord.setFieldValue("custrecord_ef_ebay_available_qty", qty);
        }
    }
    feedRecord.setFieldValue("custrecord_ef_api_name", "ReviseInventoryStatus");
    nlapiSubmitRecord(feedRecord, true);
}

function _findVariationItemError(item, Errors) {
    for (var i = 0; i < Errors.length; i++) {
        var Error = Errors[i];
        if (Error.ErrorParameters.length == 1 && Error.ErrorParameters[0] == null) {
            return Error;
        }
        var itemid_val = Error.ErrorParameters.filter(function(ep) {
            return ep.Value == item.itemid;
        });
        var sku_val = Error.ErrorParameters.filter(function(ep) {
            return ep && ep.Value == item.sku;
        });
        if (itemid_val.length && sku_val.length) {
            return Error;
        }
    }
    return Errors[0];
}

function _findItemError(item, Errors) {
    for (var i = 0; i < Errors.length; i++) {
        var error = Errors[i];
        var itemid_val = error.ErrorParameters.filter(function(ep) {
            return ep && ep.hasOwnProperty("Value") && ep.Value == item.itemid;
        });
        if (itemid_val.length) {
            return error;
        }
    }
    return Errors[0];
}

function _reviseComboFeed(ebayAccount, id, location) {
    var ebayAccountId = ebayAccount.id;
    _audit("Kit: ebayAccountId", ebayAccountId);
    var access = getAccountAccess(ebayAccount);
    var quantityLimit = LIMIT_QUANTITY;
    var maxPushQuantity = ebayAccount.custrecord_acc_max_push_quantity;
    if (maxPushQuantity) {
        maxPushQuantity = parseInt(maxPushQuantity);
        quantityLimit = maxPushQuantity;
    }
    _audit("quantityLimit", quantityLimit);
    var apiTimes = 0;
    var lastId = 0;
    do {
        var filter = [ new nlobjSearchFilter("custrecord_ebay_feed_online_ref", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "is", ebayAccountId), new nlobjSearchFilter("custrecord_ef_listing_type", null, "is", 5), new nlobjSearchFilter("internalidnumber", null, "greaterthan", lastId) ];
        if (id && Array.isArray(id) && id.length) {
            filter.push(new nlobjSearchFilter("custrecord_ef_kit", null, "anyof", id));
        }
        var search = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter, [ new nlobjSearchColumn("custrecord_ebay_feed_call_ack"), new nlobjSearchColumn("custrecord_ebay_feed_item_id"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"), new nlobjSearchColumn("custrecord_ef_cease_when_sold_out"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty"), new nlobjSearchColumn("custrecord_ebay_feed_combo"), new nlobjSearchColumn("custrecord_acc_max_push_quantity", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_kit_mapping", "custrecord_ef_kit") ]);
        if (search != null) {
            lastId = search[search.length - 1].getId();
            if (search.length == 1e3) {
                _log_email("Update quantity search is reached max limit", "1000");
            }
            _audit("REVISE INVENTORY STATUS KKKKKIT --- search size", search.length);
            var list = [];
            for (var i = 0; i < search.length; i++) {
                var searchResult = search[i];
                try {
                    var kitmapping = searchResult.getValue("custrecord_kit_mapping", "custrecord_ef_kit");
                    kitmapping = _kit2array(kitmapping);
                    var items = kitmapping.map(function(mp) {
                        var c = [ new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))") ];
                        var searchResult = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("name", null, "is", mp.sku), new nlobjSearchFilter("internalid", "inventorylocation", "is", location) ], c);
                        searchResult = searchResult[0];
                        var comboQuantity = parseInt(mp.qty);
                        var inventoryQuantity = parseInt(searchResult.getValue(c[0]) || 0);
                        return {
                            id: searchResult.getId(),
                            comboQuantity: comboQuantity,
                            inventoryQuantity: inventoryQuantity,
                            _qty: Math.floor(inventoryQuantity / comboQuantity)
                        };
                    });
                    var zeroItems = items.filter(function(item) {
                        return item.inventoryQuantity == 0;
                    });
                    var qty = items.map(function(_item) {
                        return _item._qty;
                    }).min();
                    var __quantity = 0;
                    var push_qty = parseInt(searchResult.getValue("custrecord_ebay_feed_push_qty") || 0);
                    var max_push_qty = parseInt(searchResult.getValue("custrecord_ef_max_push_qty") || 0);
                    if (push_qty) {
                        __quantity = parseInt(push_qty);
                    } else if (zeroItems.length) {
                        __quantity = 0;
                    } else if (max_push_qty) {
                        max_push_qty = parseInt(max_push_qty);
                        if (qty > max_push_qty) {
                            __quantity = max_push_qty;
                        } else {
                            __quantity = qty;
                        }
                    } else {
                        if (qty > quantityLimit) {
                            __quantity = quantityLimit;
                        } else {
                            __quantity = qty;
                        }
                    }
                    list.push({
                        id: searchResult.getId(),
                        custrecord_ebay_feed_call_ack: searchResult.getValue("custrecord_ebay_feed_call_ack"),
                        itemid: searchResult.getValue("custrecord_ebay_feed_item_id"),
                        sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                        qty: __quantity,
                        parentFeedItemId: searchResult.getValue("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"),
                        custrecord_ef_ebay_available_qty: searchResult.getValue("custrecord_ef_ebay_available_qty")
                    });
                } catch (e) {
                    processException(e, JSON.stringify(kitmapping) + searchResult.getId());
                }
            }
            var synchronizedSearch = list.filter(function(item) {
                return parseInt(item.qty) == parseInt(item.custrecord_ef_ebay_available_qty) && item.custrecord_ebay_feed_call_ack != "Success";
            });
            if (synchronizedSearch.length) {
                _audit(ebayAccountId + "synchronizedSearch", JSON.stringify(synchronizedSearch));
                synchronizedSearch.forEach(function(ss) {
                    var rec = nlapiLoadRecord("customrecord_ebay_item_api_feed", ss.id);
                    rec.setFieldValue("custrecord_ebay_feed_call_ack", "Success");
                    rec.setFieldValue("custrecord_ebay_feed_error_code", "");
                    rec.setFieldValue("custrecord_ebay_feed_api_message", "");
                    rec.setFieldValue("custrecord_ef_api_name", "ReviseInventoryStatus");
                    nlapiSubmitRecord(rec, true);
                });
            }
            var needSyncSearch = list.filter(function(item) {
                return parseInt(item.qty) != parseInt(item.custrecord_ef_ebay_available_qty);
            });
            _audit("准备要reviseInventoryStatus 的Search Length 是", needSyncSearch.length);
            apiTimes += reviseInventoryStatus2(needSyncSearch, access.token, access.headers);
        }
    } while (search != null && search.length == 1e3);
    return apiTimes;
}

function _reviseComboFeedTaiwu(ebayAccount, id) {
    var ebayAccountId = ebayAccount.id;
    _audit("Kit: ebayAccountId", ebayAccountId);
    var access = getAccountAccess(ebayAccount);
    var quantityLimit = LIMIT_QUANTITY;
    var maxPushQuantity = ebayAccount.custrecord_acc_max_push_quantity;
    if (maxPushQuantity) {
        maxPushQuantity = parseInt(maxPushQuantity);
        quantityLimit = maxPushQuantity;
    }
    _audit("quantityLimit", quantityLimit);
    var apiTimes = 0;
    var lastId = 0;
    do {
        var filter = [ new nlobjSearchFilter("custrecord_ebay_feed_online_ref", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "is", ebayAccountId), new nlobjSearchFilter("custrecord_ef_listing_type", null, "is", 5), new nlobjSearchFilter("internalidnumber", null, "greaterthan", lastId) ];
        if (id && Array.isArray(id) && id.length) {
            filter.push(new nlobjSearchFilter("custrecord_ef_kit", null, "anyof", id));
        }
        var search = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter, [ new nlobjSearchColumn("custrecord_ebay_feed_call_ack"), new nlobjSearchColumn("custrecord_ebay_feed_item_id"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"), new nlobjSearchColumn("custrecord_ef_cease_when_sold_out"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty"), new nlobjSearchColumn("custrecord_ebay_feed_combo"), new nlobjSearchColumn("custrecord_acc_max_push_quantity", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_kit_mapping", "custrecord_ef_kit") ]);
        if (search != null) {
            lastId = search[search.length - 1].getId();
            if (search.length == 1e3) {
                _log_email("Update quantity search is reached max limit - Taiwu combo update", "1000");
            }
            _audit("REVISE INVENTORY STATUS KKKKKIT --- search size", search.length);
            var list = [];
            for (var i = 0; i < search.length; i++) {
                var searchResult = search[i];
                try {
                    var __quantity = 0;
                    var push_qty = parseInt(searchResult.getValue("custrecord_ebay_feed_push_qty") || 0);
                    var max_push_qty = parseInt(searchResult.getValue("custrecord_ef_max_push_qty") || 0);
                    if (push_qty) {
                        __quantity = parseInt(push_qty);
                    }
                    list.push({
                        id: searchResult.getId(),
                        custrecord_ebay_feed_call_ack: searchResult.getValue("custrecord_ebay_feed_call_ack"),
                        itemid: searchResult.getValue("custrecord_ebay_feed_item_id"),
                        sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                        qty: __quantity,
                        parentFeedItemId: searchResult.getValue("custrecord_ebay_feed_item_id", "CUSTRECORD_EBAY_FEED_PARENT"),
                        custrecord_ef_ebay_available_qty: searchResult.getValue("custrecord_ef_ebay_available_qty")
                    });
                } catch (e) {
                    processException(e);
                }
            }
            var needSyncSearch = list.filter(function(item) {
                return parseInt(item.qty) != parseInt(item.custrecord_ef_ebay_available_qty);
            });
            _audit("准备要reviseInventoryStatus 的Search Length 是", needSyncSearch.length);
            apiTimes += reviseInventoryStatus2(needSyncSearch, access.token, access.headers);
        }
    } while (search != null && search.length == 1e3);
    return apiTimes;
}

function _kit2array(kitMapping) {
    kitMapping = kitMapping.split(";");
    var itemResult = [];
    for (var i = 0; i < kitMapping.length; i++) {
        var mapping = kitMapping[i];
        var subSKU = mapping.substring(0, mapping.indexOf("="));
        var qty = parseInt(mapping.substring(mapping.indexOf("=") + 1));
        itemResult.push({
            sku: subSKU,
            qty: qty
        });
    }
    return itemResult;
}

var FORCE_UPDATE_ITEM_FLAG = false;

var SYNC_FEED_RETURN_DESCRIPTION_FLAG = false;

var LIMIT_QUANTITY = 5;

function sync() {
    var deploymentId = nlapiGetContext().getDeploymentId();
    var ebayAccounts = getEbayConnectedAccounts();
    if (deploymentId == "customdeploy_sc_ebay_syncfeed_inc") {
        syncIncrement();
    } else if (deploymentId == "customdeploy_sc_ebay_syncfeed_zake") {
        ebayAccounts = ebayAccounts.filter(function(ea) {
            return ea.subsidiary == Subsidiaries.ZakeInternational;
        });
        for (var i = 0; i < ebayAccounts.length; i++) {
            var ebayAccount = ebayAccounts[i];
            var ptime = new Profiling();
            var times = 0;
            times += _updateInventoryStatusByWarehouse(ebayAccount, null);
            times += _reviseComboFeed(ebayAccount, null, 2);
            if (times > 10) {
                _log_email("Sync Result: " + ebayAccount.id + " | " + ebayAccount.name + " | apiTimes: " + times, ptime.end());
            }
        }
    } else if (deploymentId == "customdeploy_sc_ebay_syncfeed_taiwu") {
        ebayAccounts = ebayAccounts.filter(function(ea) {
            return ea.subsidiary == Subsidiaries.TaiwuInternational;
        });
        for (var i = 0; i < ebayAccounts.length; i++) {
            var ebayAccount = ebayAccounts[i];
            var ptime = new Profiling();
            var times = 0;
            times += _updateInventoryStatusByWarehouse(ebayAccount, null);
            if (times > 150) {
                _log_email("Sync Result: " + ebayAccount.id + " | " + ebayAccount.name + " | apiTimes: " + times, ptime.end());
            }
        }
    } else if (deploymentId == "customdeploy_sc_ebay_syncfeed_test") {
        var code = nlapiGetContext().getSetting("script", "custscript_sync_code");
        if (code) {
            code = code.split(",");
            runReviseInventoryStatus(ebayAccounts.filter(function(ea) {
                return ea.id == code[0];
            })[0], code[1].split("|"));
        }
    } else {
        _log_email("没有找到 SyncFeed 配置的 Script");
    }
}

function syncIncrement() {
    var timefrom = get_timefrom("feed_increment_time.txt", 716289, 295527);
    _log("timefrom", timefrom);
    var timeto = "8/4/2016 2:00 pm";
    var timeRange = [ timefrom, timeto ];
    _audit("timeRange", timeRange);
    var itemSoldSearch = nlapiSearchRecord("salesorder", null, [ new nlobjSearchFilter("datecreated", null, "within", timeRange), new nlobjSearchFilter("type", "item", "anyof", [ "InvtPart", "Kit" ]) ], [ new nlobjSearchColumn("item", null, "GROUP"), new nlobjSearchColumn("quantity", null, "SUM") ]);
    if (itemSoldSearch != null) {
        var itemSoldList = [];
        itemSoldList = itemSoldSearch.map(function(searchResult) {
            return searchResult.getValue("item", null, "GROUP");
        });
        _audit("itemSoldList" + itemSoldList.length, itemSoldList);
        var feedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_item", null, "anyof", itemSoldList) ], [ new nlobjSearchColumn("custrecord_ebay_feed_api_title"), new nlobjSearchColumn("custrecord_ebay_feed_api_title", "CUSTRECORD_EBAY_FEED_PARENT"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_account"), new nlobjSearchColumn("name", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_acc_max_push_quantity", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_ebay_api_token", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_acc_sellerlist_return_desc", "custrecord_ebay_feed_account") ]);
        var ebayAccountGroup = {};
        feedSearch.forEach(function(searchResult) {
            var ebayAccountId = searchResult.getValue("custrecord_ebay_feed_account");
            var listingSKU = searchResult.getValue("custrecord_ebay_feed_sku");
            var feedInternalId = searchResult.getId();
            if (ebayAccountGroup.hasOwnProperty(ebayAccountId)) {
                ebayAccountGroup[ebayAccountId].list.push({
                    sku: listingSKU,
                    id: feedInternalId
                });
            } else {
                ebayAccountGroup[ebayAccountId] = {
                    info: {
                        name: searchResult.getValue("name", "custrecord_ebay_feed_account"),
                        id: searchResult.getValue("custrecord_ebay_feed_account"),
                        custrecord_acc_max_push_quantity: searchResult.getValue("custrecord_acc_max_push_quantity", "custrecord_ebay_feed_account"),
                        custrecord_ebay_api_token: searchResult.getValue("custrecord_ebay_api_token", "custrecord_ebay_feed_account"),
                        custrecord_acc_sellerlist_return_desc: searchResult.getValue("custrecord_acc_sellerlist_return_desc", "custrecord_ebay_feed_account")
                    },
                    list: [ {
                        sku: listingSKU,
                        id: feedInternalId
                    } ]
                };
            }
        });
        _log("ebayAccountGroup", ebayAccountGroup.list);
        for (var ebayAccountId in ebayAccountGroup) {
            var ebayAccount = ebayAccountGroup[ebayAccountId].info;
            var feedIdList = ebayAccountGroup[ebayAccountId].list.map(function(item) {
                return item.id;
            });
            if (feedIdList.length) {
                runReviseInventoryStatus(ebayAccount, feedIdList);
            }
        }
    }
}

function get_timefrom(fileName, fileId, folderId) {
    try {
        var timefrom = nlapiLoadFile(fileId).getValue();
        timefrom = nlapiStringToDate(timefrom, "datetime");
        return nlapiDateToString(new Date(timefrom.getTime() - 5 * 60 * 1e3), "datetime");
    } catch (e) {
        if (e instanceof nlobjError && e.getCode() == "RCRD_DSNT_EXIST") {
            var d = getUTCDateTime();
            var timefrom = nlapiDateToString(new Date(d.getTime() - 30 * 60 * 1e3), "datetimetz");
            var f = nlapiCreateFile(fileName, "PLAINTEXT", timefrom);
            f.setFolder(folderId);
            nlapiSubmitFile(f);
            return timefrom;
        } else {
            throw e;
        }
    }
}

function save_timeto(timeto, folderId) {
    var f = nlapiCreateFile("feed_increment_time.txt", "PLAINTEXT", timeto);
    f.setFolder(folderId);
    return nlapiSubmitFile(f);
}