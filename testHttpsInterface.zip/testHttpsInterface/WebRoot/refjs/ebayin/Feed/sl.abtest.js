Array.prototype.diff = function (a) {
    return this.filter(function (i) {
        return a.indexOf(i) < 0;
    });
};

function run(request, response) {

    var a = nlapiLoadFile('SuiteScripts/EbayIntegration/Feed/' + 'GetSellerList.txt');
    a = a.getValue();
    a = JSON.parse(a);

    var b = nlapiLoadFile('SuiteScripts/EbayIntegration/Feed/' + 'GetMyeBaySelling.txt');
    b = b.getValue();
    b = JSON.parse(b);

    response.write(JSON.stringify(b.diff(a), null, 2));
}