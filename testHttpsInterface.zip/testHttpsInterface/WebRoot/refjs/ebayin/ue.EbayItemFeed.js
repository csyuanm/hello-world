var UE_EbayFeed = {};

function renderSpecificTab(type, form, request) {
    var field = "custrecord_ebay_feed_specifics";
    var tabName = "Specifics";
    var tabid = "custpage_tab_specifics";
    form.addSubTab(tabid, tabName, "custom216");
    var SpecificsFlag = false;
    var Specifics = nlapiGetFieldValue(field);
    if (Specifics) {
        Specifics = JSON.parse(Specifics);
        if (Array.isArray(Specifics) && Specifics.length) {
            SpecificsFlag = true;
        }
    }
    for (var i = 1; i <= 15; i++) {
        var sname = form.addField("custpage_s_name" + i, "text", "Specific Name " + i, null, tabid);
        var svalue = form.addField("custpage_s_value" + i, "text", "Specific Value " + i, null, tabid);
        if (SpecificsFlag) {
            var s = Specifics[i - 1];
            if (s) {
                sname.setDefaultValue(s.specificName);
                svalue.setDefaultValue(s.specificValue);
            }
        }
    }
}

function _fieldMandatory(fields) {
    if (fields && Array.isArray(fields) && fields.length) {
        fields.forEach(function(field) {
            nlapiGetField(field).setMandatory(true);
        });
    }
}

function _fieldInline(fields) {
    if (fields && Array.isArray(fields) && fields.length) {
        fields.forEach(function(field) {
            nlapiGetField(field).setDisplayType("inline");
        });
    }
}

function _fieldDisplay(fields, val) {
    if (fields && Array.isArray(fields) && fields.length) {
        fields.forEach(function(field) {
            nlapiGetField(field).setDisplayType(val);
        });
    }
}

function _renderVariations(type, form, request, formId) {
    if (type == "create") {
        return;
    }
    var NS_SUBFEED_LIST_HTML = form.addField("custpage_ns_subfeed_html", "inlinehtml", null, null);
    NS_SUBFEED_LIST_HTML.setLayoutType("outside");
    _log("render variations --  type/formid", type + formId);
    var tab = form.addTab("custpage_ebay_variations_tab", "Variations");
    if (type != "create") {
        var variationSubList = form.addSubList("custpage_ebay_variation_list", "inlineeditor", "Variation List", "custpage_ebay_variations_tab");
    }
    var NAME_LIST = [];
    if (type == "create") {
        var nameSubList = form.addSubList("custpage_ebay_var_spec_list", "inlineeditor", "Variation Specifics", "custpage_ebay_variations_tab");
    } else {
        var nameSubList = form.addSubList("custpage_ebay_var_spec_list", "list", "Variation Specifics", "custpage_ebay_variations_tab");
    }
    nameSubList.addField("variation_var_name", "text", "Name", null);
    _fieldDisplay([ "custrecord_ebay_feed_api_price", "custrecord_ebay_feed_push_qty", "custrecord_ef_max_push_qty", "custrecord_ef_cease_when_sold_out" ], "hidden");
    if (type == "create") {
        NS_SUBFEED_LIST_HTML.setDefaultValue("<script>var NAME_LIST = " + JSON.stringify(NAME_LIST) + ";</script>");
        return;
    }
    var filter = [ new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", nlapiGetRecordId()) ];
    var columns = [ new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ef_kit"), new nlobjSearchColumn("custrecord_ebay_feed_status"), new nlobjSearchColumn("custitem_internal_marketing_position", "custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_api_price"), new nlobjSearchColumn("custrecord_ef_picture2"), new nlobjSearchColumn("custrecord_ebay_feed_variations"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_cease_when_sold_out"), new nlobjSearchColumn("isinactive"), new nlobjSearchColumn("custrecord_ebay_feed_api_sku"), new nlobjSearchColumn("custrecord_ef_upc"), new nlobjSearchColumn("custrecord_ef_ean"), new nlobjSearchColumn("custrecord_ef_isbn"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty") ];
    if (nlapiGetFieldValue("custrecord_ebay_feed_item")) {
        var parentLocation = nlapiGetFieldValue("custrecord_ebay_feed_location");
        filter.push(new nlobjSearchFilter("inventorylocation", "custrecord_ebay_feed_item", "is", parentLocation));
        columns.push(new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"));
    }
    var variations_obj = JSON.parse(nlapiGetFieldValue("custrecord_ebay_feed_variations"));
    var nameList = variations_obj.availOptions.map(function(item) {
        return item.translation;
    });
    _log("nameList", nameList);
    nameList.forEach(function(item, i) {
        var ln = i + 1;
        nameSubList.setLineItemValue("variation_var_name", ln, item);
        NAME_LIST.push(item);
    });
    var titleFields = [ "variation_feed_id", "variation_item_id", "variation_status", "variation_market_position", "variation_kit_id", "variation_sku", "variation_feed_sku", "variation_custrecord_ef_ebay_available_qty", "variation_picture", "variation_price", "variation_lqa", "variation_push_qty", "variation_max_push_qty", "variation_discontinued", "variation_isinactive", "variation_custrecord_ef_upc", "variation_custrecord_ef_ean", "variation_custrecord_ef_isbn" ];
    variationSubList.addField("variation_feed_id", "select", "Feed ID", "customrecord_ebay_item_api_feed").setDisplayType("disabled");
    variationSubList.addField("variation_item_id", "select", "Item", "inventoryitem");
    variationSubList.addField("variation_kit_id", "select", "Kit", "customrecord_kit");
    variationSubList.addField("variation_status", "select", "Status", "customrecord_ebay_feed_status");
    variationSubList.addField("variation_market_position", "select", "Market Position", "customlist13").setDisplayType("disabled");
    variationSubList.addField("variation_sku", "text", "SKU").setDisplayType("disabled");
    variationSubList.addField("variation_feed_sku", "text", "Feed SKU").setDisplayType("disabled");
    variationSubList.addField("variation_picture", "text", "Picture", null);
    nameList.forEach(function(vname) {
        var fname = vname.replace(/[：（）!！`~!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/\s]/gi, "_");
        fname = "variation_vname_" + fname.toLowerCase();
        variationSubList.addField(fname, "text", vname, null);
        titleFields.push(fname);
    });
    variationSubList.addField("variation_price", "currency", "Price", null);
    variationSubList.addField("variation_lqa", "text", "Location Quantity Available", null).setDisplayType("disabled");
    variationSubList.addField("variation_custrecord_ef_ebay_available_qty", "integer", "Ebay Available QTY", null).setDisplayType("disabled");
    if (formId == "218") {
        variationSubList.addField("variation_push_qty", "integer", "Push Quantity", null).setMandatory(true);
    } else {
        variationSubList.addField("variation_push_qty", "integer", "Push Quantity", null);
    }
    variationSubList.addField("variation_max_push_qty", "integer", "Max Push QTY", null);
    variationSubList.addField("variation_discontinued", "checkbox", "Discontinued", null);
    variationSubList.addField("variation_custrecord_ef_upc", "text", "UPC", null);
    variationSubList.addField("variation_custrecord_ef_ean", "text", "EAN", null);
    variationSubList.addField("variation_custrecord_ef_isbn", "text", "ISBN", null);
    variationSubList.addField("variation_isinactive", "checkbox", "isinactive", null);
    var NS_SUBFEED_LIST = {};
    var subFeedSearch = nlapiSearchRecord(EbayRecordType.customrecord_ebay_item_api_feed, null, filter, columns);
    if (subFeedSearch != null) {
        _audit("subFeedSearch", subFeedSearch.length);
        var subFeedList = subFeedSearch.map(function(searchResult) {
            var qty = parseInt(searchResult.getValue("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM") || 0);
            var line = {
                feedId: searchResult.getId(),
                custrecord_ebay_feed_status: searchResult.getValue("custrecord_ebay_feed_status"),
                itemInternalId: searchResult.getValue("custrecord_ebay_feed_item"),
                kitInternalId: searchResult.getValue("custrecord_ef_kit"),
                custitem_internal_marketing_position: searchResult.getValue("custitem_internal_marketing_position", "custrecord_ebay_feed_item"),
                itemSKU: searchResult.getValue("custrecord_ebay_feed_sku"),
                price: searchResult.getValue("custrecord_ebay_feed_api_price"),
                picture2: searchResult.getValue("custrecord_ef_picture2"),
                custrecord_ebay_feed_push_qty: searchResult.getValue("custrecord_ebay_feed_push_qty"),
                custrecord_ef_max_push_qty: searchResult.getValue("custrecord_ef_max_push_qty"),
                discontinued: searchResult.getValue("custrecord_ef_cease_when_sold_out"),
                isinactive: searchResult.getValue("isinactive"),
                custrecord_ebay_feed_api_sku: searchResult.getValue("custrecord_ebay_feed_api_sku"),
                custrecord_ef_upc: searchResult.getValue("custrecord_ef_upc"),
                custrecord_ef_ean: searchResult.getValue("custrecord_ef_ean"),
                custrecord_ef_isbn: searchResult.getValue("custrecord_ef_isbn"),
                custrecord_ef_ebay_available_qty: searchResult.getValue("custrecord_ef_ebay_available_qty"),
                locationquantityavailable: qty
            };
            var subFeedVariation = JSON.parse(searchResult.getValue("custrecord_ebay_feed_variations"));
            line.nameValueList = subFeedVariation.options.map(function(item) {
                return {
                    name: item.label.translation,
                    value: item.option.translation
                };
            });
            return line;
        });
        NS_SUBFEED_LIST.ROWS = [];
        for (var j = 0; j < subFeedList.length; j++) {
            var _subfeed = subFeedList[j];
            var row_obj = {
                variation_feed_id: _subfeed.feedId,
                variation_item_id: _subfeed.itemInternalId,
                variation_kit_id: _subfeed.kitInternalId,
                variation_status: _subfeed.custrecord_ebay_feed_status,
                variation_market_position: _subfeed.custitem_internal_marketing_position,
                variation_sku: _subfeed.custrecord_ebay_feed_api_sku,
                variation_feed_sku: _subfeed.itemSKU,
                variation_custrecord_ef_ebay_available_qty: _subfeed.custrecord_ef_ebay_available_qty,
                variation_picture: _subfeed.picture2,
                variation_price: _subfeed.price,
                variation_lqa: _subfeed.locationquantityavailable.toString(),
                variation_push_qty: _subfeed.custrecord_ebay_feed_push_qty,
                variation_max_push_qty: _subfeed.custrecord_ef_max_push_qty,
                variation_discontinued: _subfeed.discontinued,
                variation_isinactive: _subfeed.isinactive,
                variation_custrecord_ef_upc: _subfeed.custrecord_ef_upc,
                variation_custrecord_ef_ean: _subfeed.custrecord_ef_ean,
                variation_custrecord_ef_isbn: _subfeed.custrecord_ef_isbn
            };
            _subfeed.nameValueList.forEach(function(vv) {
                row_obj["variation_vname_" + vv.name.toLowerCase().replace(/\s/g, "_")] = vv.value;
            });
            NS_SUBFEED_LIST.ROWS.push(row_obj);
        }
        for (var k = 0; k < NS_SUBFEED_LIST.ROWS.length; k++) {
            var line = k + 1;
            var rr = NS_SUBFEED_LIST.ROWS[k];
            for (var nn in rr) {
                variationSubList.setLineItemValue(nn, line, rr[nn]);
            }
        }
    } else {
        NS_SUBFEED_LIST = {
            ROWS: []
        };
    }
    NS_SUBFEED_LIST.TITLE = titleFields;
    NS_SUBFEED_LIST_HTML.setDefaultValue("<script>var NS_SUBFEED_LIST = " + JSON.stringify(NS_SUBFEED_LIST) + "; var NAME_LIST = " + JSON.stringify(NAME_LIST) + ";</script>");
}

UE_EbayFeed.beforeLoad = function(type, form, request) {
    var envContext = nlapiGetContext().getExecutionContext();
    _log("envContext", envContext);
    var subsidiary = nlapiGetContext().getSubsidiary();
    if (envContext == "userinterface") {
        if (nlapiGetFieldValue("custrecord_ef_subsidiary") == Subsidiaries.TaiwuInternational) {} else {
            _fieldDisplay([ "custrecord_ef_cease_when_sold_out" ], "hidden");
        }
        _fieldDisplay([ "custrecord_ebay_feed_ns_ref_id", "custrecord_ef_legacy_description", "custrecord_ef_scheduled_status" ], "hidden");
        if (type == "create") {
            nlapiSetFieldValue("custrecord_ef_subsidiary", nlapiGetSubsidiary());
            nlapiSetFieldValue("custrecord_ebay_feed_condition", 1);
            nlapiSetFieldValue("custrecord_ef_listing_type", 5);
            nlapiSetFieldValue("custrecord_ebay_feed_status", 21);
            nlapiSetFieldValue("custrecord_ef_ns_created", "T");
            _fieldInline([ "custrecord_ef_scheduled_status", "custrecord_ebay_feed_online_ref", "custrecord_ebay_feed_item_id", "custrecord_ebay_feed_item_link", "custrecord_ebay_feed_call_ack", "custrecord_ebay_feed_error_code", "custrecord_ebay_feed_api_message", "custrecord_ebay_feed_is_legacy", "custrecord_ef_ns_created", "custrecord_ef_ebay_available_qty", "custrecord_ebay_feed_matrix_item", "custrecord_ebay_feed_matrix_child_item", "custrecord_ebay_feed_combo", "custrecord_ebay_feed_parent", "custrecord_ef_duplications", "custrecord_ebay_feed_reject_reason", "custrecord_ebay_feed_last_api_request", "custrecord_ebay_feed_last_api_response", "custrecord_ebay_feed_last_api_datetime", "custrecord_ebay_feed_first_online_dt", "custrecord_ebay_feed_pending_mdf", "custrecord_ef_prefer_data" ]);
            _fieldMandatory([ "custrecord_ebay_feed_sku", "custrecord_ebay_feed_category_id", "custrecord_ebay_feed_condition", "custrecord_ebay_feed_location", "custrecord_ef_subsidiary", "custrecord_ef_shipping_options", "custrecord_ef_listing_duration", "custrecord_ef_template", "custrecord_ef_listing_type", "custrecord_ef_language", "custrecord_ebay_feed_global_site", "custrecord_ebay_feed_account" ]);
            _fieldDisplay([ "custrecord_ef_item_site_setting", "custrecord_ebay_feed_language", "custrecord_ef_quantitysold", "custrecord_ebay_feed_parent" ], "hidden");
            _fieldDisplay([ "custrecord_ebay_feed_sku" ], "disabled");
            renderSpecificTab(type, form, request);
            var formId = nlapiGetFieldValue("customform");
            if (218 == formId) {
                nlapiSetFieldValue("custrecord_ebay_feed_matrix_item", "T");
                nlapiSetFieldValue("custrecord_ebay_feed_matrix_child_item", "F");
                nlapiSetFieldValue("custrecord_ebay_feed_combo", "T");
                _fieldInline([ "custrecord_ebay_feed_api_sku", "custrecord_ebay_feed_legacysku", "custrecord_ebay_feed_matrix_item", "custrecord_ebay_feed_matrix_child_item", "custrecord_ebay_feed_combo", "custrecord_ef_kit", "custrecord_ebay_feed_item" ]);
                _renderVariations(type, form, null, formId);
            }
            if (subsidiary == Subsidiaries.TaiwuInternational) {
                var tab = form.addTab("custpage_ebay_variations_tab", "变参养成");
                var html = nlapiLoadFile("SuiteScripts/EbayIntegration/create_variations.html").getValue();
                var inlinehtml = form.addField("custpage_create_variations_html", "inlinehtml", null, null, "custpage_ebay_variations_tab");
                inlinehtml.setDefaultValue(html);
            }
            return;
        } else if (type == "edit") {
            if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "T" && nlapiGetFieldValue("custrecord_ebay_feed_combo") == "T") {
                nlapiSetFieldValue("customform", 218);
            }
            _fieldInline([ "customform", "custrecord_ebay_feed_status", "custrecord_ef_scheduled_status", "custrecord_ebay_feed_online_ref", "custrecord_ebay_feed_item_id", "custrecord_ebay_feed_item_link", "custrecord_ebay_feed_call_ack", "custrecord_ebay_feed_error_code", "custrecord_ebay_feed_api_message", "custrecord_ebay_feed_picture", "custrecord_ef_ebay_available_qty", "custrecord_ebay_feed_last_api_datetime", "custrecord_ebay_feed_first_online_dt", "custrecord_ebay_feed_pending_mdf", "custrecord_ebay_feed_variations", "custrecord_ebay_feed_var_reviewed", "custrecord_ebay_feed_api_sku", "custrecord_ebay_feed_legacysku", "custrecord_ebay_feed_gallery", "custrecord_ebay_feed_body_picture", "custrecord_ebay_feed_is_legacy", "custrecord_ef_subsidiary", "custrecord_ef_ns_created", "custrecord_ebay_feed_matrix_item", "custrecord_ebay_feed_matrix_child_item", "custrecord_ebay_feed_combo", "custrecord_ebay_feed_submitted_by", "custrecord_ebay_feed_parent", "custrecord_ef_duplications", "custrecord_ebay_feed_item_type" ]);
            if (nlapiGetFieldValue("custrecord_ebay_feed_status") != EBAY_FEED_STATUS.NEW) {
                _fieldInline([ "custrecord_ef_language", "custrecord_ebay_feed_global_site", "custrecord_ebay_feed_account", "custrecord_ef_item_site_setting", "custrecord_ebay_feed_language" ]);
            }
            if (173 == nlapiGetFieldValue("customform")) {
                _fieldDisplay([ "custrecord_ef_listing_type" ], "hidden");
            }
        } else if (type == "view") {
            form.setScript("customscript_cs_ebayfeedrecord_view");
        }
        if (nlapiGetFieldValue("custrecord_ebay_feed_combo") == "F") {
            if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "F") {
                var iteminternalid = nlapiGetFieldValue("custrecord_ebay_feed_item");
                var locationid = nlapiGetFieldValue("custrecord_ebay_feed_location");
                if (iteminternalid && locationid) {
                    var qty = _getItemLocationAvailableQuantity(iteminternalid, locationid);
                    var q = form.addField("custpage_locationquantityavailable", "integer", "Location Available Quantity");
                    q.setDefaultValue(qty);
                    q.setDisabled(true);
                }
            }
        }
        var custrecord_ebay_feed_item = nlapiGetFieldValue("custrecord_ebay_feed_item");
        if (custrecord_ebay_feed_item) {
            var mp = form.addField("custpage_item_market_position", "text", "Market Position");
            mp.setDefaultValue(nlapiLookupField("inventoryitem", custrecord_ebay_feed_item, "custitem_internal_marketing_position", true));
            mp.setDisabled(true);
        }
        if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
            if (type == "edit") {
                _fieldMandatory([ "custrecord_ebay_feed_sku", "custrecord_ebay_feed_category_id", "custrecord_ebay_feed_condition", "custrecord_ebay_feed_location" ]);
            }
            if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "T") {
                _renderVariations(type, form, null, nlapiGetFieldValue("customform"));
            } else {}
            renderSpecificTab(type, form, request);
            var rejectReason = nlapiGetField("custrecord_ebay_feed_reject_reason");
            rejectReason.setDisplayType("hidden");
            var status = nlapiGetFieldValue("custrecord_ebay_feed_status");
            if (status == EBAY_FEED_STATUS.NEW || status == EBAY_FEED_STATUS.REJECTED || status == EBAY_FEED_STATUS.WAITING_FOR_APPROVAL) {
                rejectReason.setDisplayType("normal");
            }
            if (type == "view") {
                var subs = nlapiGetSubsidiary();
                var role = nlapiGetRole();
                _log("role", role);
                if (subs == Subsidiaries.ZakeInternational) {
                    if ([ 3, 1096, 1097, 1054, 1048 ].contains(role)) {
                        if (status) {
                            _displayButton(form, status, subs);
                        }
                    }
                } else if (subs == Subsidiaries.TaiwuInternational) {
                    if ([ 3, 1125 ].contains(role)) {
                        var scheduledStatus = nlapiGetFieldValue("custrecord_ef_scheduled_status");
                        _audit("scheduledStatus", scheduledStatus);
                        _displayButton(form, status, subs);
                    }
                }
            }
        }
    }
};

function _displayButton(form, status, subs) {
    var buttonSearch = nlapiSearchRecord("customrecord_feed_button_display", null, [ new nlobjSearchFilter("isinactive", null, "is", "F"), new nlobjSearchFilter("custrecord_fbd_subsidiary", null, "is", subs), new nlobjSearchFilter("custrecord_fbd_status", null, "is", status) ], [ new nlobjSearchColumn("name", "custrecord_fbd_buttons"), new nlobjSearchColumn("internalid", "custrecord_fbd_buttons") ]);
    if (buttonSearch != null) {
        _log("buttonSearch", buttonSearch.length);
        buttonSearch.forEach(function(_btn) {
            var id = _btn.getValue("internalid", "custrecord_fbd_buttons");
            var name = _btn.getValue("name", "custrecord_fbd_buttons");
            if (id && name) {
                if (id == EBAY_FEED_BUTTON.REVISE && !nlapiGetFieldValue("custrecord_ebay_feed_pending_mdf")) {} else {
                    form.addButton("custpage_action" + id, name, "doAction(" + nlapiGetRecordId() + ", " + id + ")");
                }
            }
        });
    }
}

function addFormButton(form, buttons) {
    var btnSearch = nlapiSearchRecord("customrecord_ebay_feed_button", null, [ new nlobjSearchFilter("internalid", null, "anyof", buttons) ], [ new nlobjSearchColumn("name") ]);
    btnSearch.forEach(function(_btn) {
        var id = _btn.getId();
        var name = _btn.getValue("name");
        if (id && name) {
            var btn = form.addButton("custpage_action" + id, name, "doAction(" + nlapiGetRecordId() + ", " + id + ")");
        }
    });
}

UE_EbayFeed.watchField = [ "custrecord_ebay_feed_api_sku", "custrecord_ebay_feed_api_title", "custrecord_ebay_feed_api_price", "custrecord_ebay_feed_description", "custrecord_ebay_feed_push_qty", "custrecord_ef_max_push_qty", "custrecord_ef_ebay_available_qty", "custrecord_ebay_feed_variations", "custrecord_ebay_feed_gallery", "custrecord_ebay_feed_body_picture", "custrecord_ebay_feed_shippingdetails", "custrecord_ebay_feed_specifics", "custrecord_ef_template", "custrecord_ef_location_country", "custrecord_ef_location_name", "custrecord_ebay_feed_condition" ];

function _beforeSubmitCheck(type) {
    nlapiSetFieldValue("custrecord_ef_duplications", "");
    if (type == "create" || type == "edit") {
        var check = null;
        var feedsku = nlapiGetFieldValue("custrecord_ebay_feed_sku");
        if (feedsku) {
            feedsku = feedsku.split("|");
            if (feedsku.length > 2) {
                throw nlapiCreateError("EBAY_CHECK", "有问题的Feed SKU " + [ JSON.stringify(feedsku), type, nlapiGetContext().getExecutionContext() ].join("\r\n"));
            }
        }
        var filter = null;
        if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F" || nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "") {
            if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_item") == "T") {
                if (feedsku) {
                    filter = [ [ [ "custrecord_ebay_feed_sku", "is", nlapiGetFieldValue("custrecord_ebay_feed_sku") ], "OR", [ "custrecord_ebay_feed_api_title", "is", nlapiGetFieldValue("custrecord_ebay_feed_api_title") ] ], "AND", [ [ "custrecord_ebay_feed_global_site", "is", nlapiGetFieldValue("custrecord_ebay_feed_global_site") ], "AND", [ "custrecord_ebay_feed_location", "is", nlapiGetFieldValue("custrecord_ebay_feed_location") ], "AND", [ "custrecord_ebay_feed_status", "is", EBAY_FEED_STATUS.ONLINE ] ] ];
                } else {
                    filter = [ new nlobjSearchFilter("custrecord_ebay_feed_api_title", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_api_title")), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_global_site")), new nlobjSearchFilter("custrecord_ebay_feed_location", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_location")), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE) ];
                }
            } else {
                filter = [ [ [ "custrecord_ebay_feed_sku", "is", nlapiGetFieldValue("custrecord_ebay_feed_sku") ], "OR", [ "custrecord_ebay_feed_api_title", "is", nlapiGetFieldValue("custrecord_ebay_feed_api_title") ] ], "AND", [ [ "custrecord_ebay_feed_global_site", "is", nlapiGetFieldValue("custrecord_ebay_feed_global_site") ], "AND", [ "custrecord_ebay_feed_location", "is", nlapiGetFieldValue("custrecord_ebay_feed_location") ], "AND", [ "custrecord_ebay_feed_status", "is", EBAY_FEED_STATUS.ONLINE ] ] ];
            }
        } else {
            filter = [ new nlobjSearchFilter("custrecord_ebay_feed_sku", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_sku")), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_global_site")), new nlobjSearchFilter("custrecord_ebay_feed_location", null, "is", nlapiGetFieldValue("custrecord_ebay_feed_location")), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE) ];
        }
        if (filter != null) {
            check = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter);
            if (type == "create") {
                if (check != null) {
                    nlapiSetFieldValue("custrecord_ef_duplications", JSON.stringify(check.map(function(sr) {
                        return sr.getId();
                    })));
                }
            } else if (type == "edit") {
                if (check != null) {
                    if (check.length > 1) {
                        check = check.map(function(sr) {
                            return parseInt(sr.getId());
                        });
                        check.remove(parseInt(nlapiGetRecordId()));
                        nlapiSetFieldValue("custrecord_ef_duplications", JSON.stringify(check));
                    }
                }
            }
        }
    }
}

function convert2est() {
    var offset = nlapiLookupField("customrecord_ebay_global", nlapiGetFieldValue("custrecord_ebay_feed_global_site"), "custrecord_ebay_site_utc_offset");
    offset = offset || -8;
    offset = parseInt(offset);
    offset = "0";
    var datetime = nlapiStringToDate(nlapiGetFieldValue("custrecord_ef_prep_listing_time"), "datetimez");
    _audit("datetime taipingyang shijian", datetime);
    var d = new Date(datetime.getTime() + (offset + 8) * 60 * 60 * 1e3);
    return this.moment(d).format("M/D/YYYY hh:mm:ss a");
}

function _calculateDatetime() {
    nlapiSetFieldValue("custrecord_ef_prep_listing_time_est", convert2est());
}

UE_EbayFeed.beforeSubmit = function(type) {
    var envContext = nlapiGetContext().getExecutionContext();
    _log("beforeSubmit envContext in type " + type, envContext);
    var custrecord_ef_upc = nlapiGetFieldValue("custrecord_ef_upc");
    if (!custrecord_ef_upc) {
        nlapiSetFieldValue("custrecord_ef_upc", "Does not apply");
    }
    _log("custrecord_ef_subsidiary", nlapiGetFieldValue("custrecord_ef_subsidiary"));
    _log("is matrix child item?", nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item"));
    if (envContext == "userinterface") {
        _beforeSubmitCheck(type);
    }
    if (envContext == "userinterface") {
        if (type == "create" || type == "edit") {
            if (nlapiGetFieldValue("custrecord_ef_subsidiary") == Subsidiaries.TaiwuInternational) {}
        }
    }
    if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F" || nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "") {
        var ebayItemId = nlapiGetFieldValue("custrecord_ebay_feed_item_id");
        if (ebayItemId) {
            var ebayItemLink = nlapiGetFieldValue("custrecord_ebay_feed_item_link");
            if (ebayItemLink) {
                var existingId = ebayItemLink.replace("http://www.ebay.com/itm/", "");
                if (existingId != ebayItemId) {
                    nlapiSetFieldValue("custrecord_ebay_feed_item_link", "http://www.ebay.com/itm/" + ebayItemId);
                }
            } else {
                nlapiSetFieldValue("custrecord_ebay_feed_item_link", "http://www.ebay.com/itm/" + ebayItemId);
            }
        }
        if (type == "edit") {
            if (envContext == "userinterface") {
                _setMDF(this.watchField);
                _submitSubFeedRecord();
            }
        } else if (type == "delete") {
            var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", nlapiGetRecordId()) ]);
            if (subFeedSearch != null) {
                _log("subFeedSearch", subFeedSearch.length);
                subFeedSearch.forEach(function(feedSearchResult) {
                    nlapiDeleteRecord("customrecord_ebay_item_api_feed", feedSearchResult.getId());
                });
            }
        }
    } else if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "T") {
        if (type == "edit" && envContext == "userinterface") {
            var subFeedWatchingFileds = [ "custrecord_ef_picture2", "custrecord_ebay_feed_api_price", "custrecord_ebay_feed_push_qty", "custrecord_ef_max_push_qty", "custrecord_ef_cease_when_sold_out", "isinactive", "custrecord_ebay_feed_sku", "custrecord_ef_upc", "custrecord_ef_ean", "custrecord_ef_isbn" ];
            var oldRecord = nlapiGetOldRecord();
            var subFeedChangedFlag = false;
            for (var j = 0; j < subFeedWatchingFileds.length; j++) {
                var field = subFeedWatchingFileds[j];
                var oldValue = oldRecord.getFieldValue(field);
                var currentValue = nlapiGetFieldValue(field);
                if (!oldValue) oldValue = null;
                if (!currentValue) currentValue = null;
                if (oldValue !== currentValue) {
                    subFeedChangedFlag = true;
                    break;
                }
            }
            if (subFeedChangedFlag == true) {
                nlapiSubmitField("customrecord_ebay_item_api_feed", nlapiGetFieldValue("custrecord_ebay_feed_parent"), "custrecord_ebay_feed_pending_mdf", JSON.stringify([ "variations" ]));
            }
        }
    }
};

function _submitSubFeedRecord() {
    var ef_variations_changed = nlapiGetFieldValue("custrecord_ef_variations_changed");
    _audit("ef_variations_changed", ef_variations_changed);
    if (ef_variations_changed) {
        ef_variations_changed = JSON.parse(ef_variations_changed);
        var addFeedFlag = false;
        for (var k = 0; k < ef_variations_changed.length; k++) {
            var feedWithoutId = ef_variations_changed[k].find(function(item) {
                return item.name == "variation_feed_id" && !item.value;
            });
            if (feedWithoutId) {
                addFeedFlag = true;
                break;
            }
        }
        _log("addFeedFlag", addFeedFlag);
        var skuSuffix = "";
        if (addFeedFlag) {
            var skuRef = "";
            for (var j = 0; j < ef_variations_changed.length; j++) {
                var _sku = ef_variations_changed[j].find(function(item) {
                    return item.name == "variation_feed_sku" && item.value;
                });
                if (_sku) {
                    _sku = _sku.value;
                    skuRef = _sku;
                    break;
                }
            }
            if (skuRef.indexOf("|") != -1) {
                skuSuffix = skuRef.substring(skuRef.indexOf("|") + 1);
            } else {
                skuSuffix = _uniqid();
            }
        }
        ef_variations_changed.forEach(function(line) {
            var feedId = line.find(function(item) {
                return item.name == "variation_feed_id";
            }).value;
            var isinactive = line.find(function(item) {
                return item.name == "variation_isinactive";
            }).value;
            var createFlag = false;
            var subFeedRec = null;
            if (feedId) {
                subFeedRec = nlapiLoadRecord(EbayRecordType.customrecord_ebay_item_api_feed, feedId);
            } else {
                createFlag = true;
                subFeedRec = nlapiCreateRecord(EbayRecordType.customrecord_ebay_item_api_feed);
                subFeedRec.setFieldValue("customform", 173);
                subFeedRec.setFieldValue("custrecord_ebay_feed_matrix_item", "F");
                subFeedRec.setFieldValue("custrecord_ebay_feed_matrix_child_item", "T");
                subFeedRec.setFieldValue("custrecord_ebay_feed_parent", nlapiGetRecordId());
                subFeedRec.setFieldValue("custrecord_ebay_feed_location", nlapiGetFieldValue("custrecord_ebay_feed_location"));
                var itemInternalId = line.find(function(item) {
                    return item.name == "variation_item_id";
                }).value;
                if (itemInternalId) {
                    var itemSKU = nlapiLookupField("inventoryitem", itemInternalId, "itemid");
                    subFeedRec.setFieldValue("custrecord_ebay_feed_item", itemInternalId);
                    subFeedRec.setFieldValue("custrecord_ebay_feed_sku", itemSKU + "|" + skuSuffix);
                    subFeedRec.setFieldValue("custrecord_ebay_feed_api_title", itemSKU);
                }
                var kitId = line.find(function(item) {
                    return item.name == "variation_kit_id";
                }).value;
                if (kitId) {
                    var itemSKU = nlapiLookupField("customrecord_kit", kitId, "custrecord_kit_sku");
                    subFeedRec.setFieldValue("custrecord_ef_kit", kitId);
                    subFeedRec.setFieldValue("custrecord_ebay_feed_sku", itemSKU + "|" + skuSuffix);
                    subFeedRec.setFieldValue("custrecord_ebay_feed_api_title", itemSKU);
                }
            }
            var subVariationObject = {
                options: []
            };
            for (var i = 0; i < line.length; i++) {
                var obj = line[i];
                switch (obj.name) {
                  case "variation_picture":
                    subFeedRec.setFieldValue("custrecord_ef_picture2", obj.value);
                    break;

                  case "variation_price":
                    subFeedRec.setFieldValue("custrecord_ebay_feed_api_price", obj.value);
                    break;

                  case "variation_push_qty":
                    subFeedRec.setFieldValue("custrecord_ebay_feed_push_qty", obj.value);
                    break;

                  case "variation_max_push_qty":
                    subFeedRec.setFieldValue("custrecord_ef_max_push_qty", obj.value);
                    break;

                  case "variation_discontinued":
                    subFeedRec.setFieldValue("custrecord_ef_cease_when_sold_out", obj.value);
                    break;

                  case "variation_isinactive":
                    subFeedRec.setFieldValue("isinactive", obj.value);
                    break;

                  case "variation_feed_sku":
                    if (!createFlag) {
                        subFeedRec.setFieldValue("custrecord_ebay_feed_sku", obj.value);
                    }
                    break;

                  case "variation_kit_id":
                    if (obj.value) {
                        subFeedRec.setFieldValue("custrecord_ebay_feed_combo", "T");
                    } else {
                        subFeedRec.setFieldValue("custrecord_ebay_feed_combo", "F");
                    }
                    break;

                  case "variation_custrecord_ef_upc":
                    subFeedRec.setFieldValue("custrecord_ef_upc", obj.value);
                    break;

                  case "variation_custrecord_ef_ean":
                    subFeedRec.setFieldValue("custrecord_ef_ean", obj.value);
                    break;

                  case "variation_custrecord_ef_isbn":
                    subFeedRec.setFieldValue("custrecord_ef_isbn", obj.value);
                    break;
                }
                if (obj.name.indexOf("variation_vname_") != -1) {
                    subVariationObject.options.push({
                        label: {
                            name: "",
                            label: "",
                            translation: obj.label
                        },
                        option: {
                            name: "",
                            value: "",
                            text: "",
                            translation: obj.value
                        }
                    });
                }
            }
            var old_var = subFeedRec.getFieldValue("custrecord_ebay_feed_variations");
            if (old_var) {
                old_var = JSON.parse(old_var);
                var oldNameValueList = _getNameValueList(old_var);
                var newNameValueList = _getNameValueList(subVariationObject);
                _audit("newNameValueList", newNameValueList);
                _audit("oldNameValueList", oldNameValueList);
                if (JSON.stringify(oldNameValueList) != JSON.stringify(newNameValueList)) {
                    subFeedRec.setFieldValue("custrecord_ebay_feed_variations_old", JSON.stringify(old_var));
                } else {
                    subFeedRec.setFieldValue("custrecord_ebay_feed_variations_old", "");
                }
            }
            subFeedRec.setFieldValue("custrecord_ebay_feed_variations", JSON.stringify(subVariationObject));
            nlapiSubmitRecord(subFeedRec, true);
        });
    }
    nlapiSetFieldValue("custrecord_ef_variations_changed", "");
}

function _getNameValueList(subFeedVarObject) {
    var nameValueList = subFeedVarObject.options.map(function(item) {
        return {
            name: item.label.translation,
            value: item.option.translation
        };
    });
    return nameValueList;
}

function _setMDF(monitoring_fields) {
    var mdf = nlapiGetFieldValue("custrecord_ebay_feed_pending_mdf");
    if (mdf) {
        mdf = mdf.trim();
        mdf = JSON.parse(mdf);
        if (!Array.isArray(mdf)) throw createEbayError("mdf not array");
    } else {
        mdf = [];
    }
    var oldRecord = nlapiGetOldRecord();
    monitoring_fields.forEach(function(field) {
        var oldValue = oldRecord.getFieldValue(field);
        var currentValue = nlapiGetFieldValue(field);
        if (!oldValue) oldValue = null;
        if (!currentValue) currentValue = null;
        _audit(field, typeof oldValue + "///" + oldValue + "|||" + typeof currentValue + "///" + currentValue);
        if (oldValue !== currentValue) {
            if (mdf.indexOf(field) == -1) {
                mdf.push(field);
            }
        }
    });
    mdf = mdf.unique();
    _audit("before submit mdf", mdf);
    if (mdf.length) {
        nlapiSetFieldValue("custrecord_ebay_feed_pending_mdf", JSON.stringify(mdf));
    } else {
        nlapiSetFieldValue("custrecord_ebay_feed_pending_mdf", "");
    }
}

function beforeLoad(type, form, request) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    var _info = "beforeLoad  id: " + id + " recType: " + recType + " type: " + type;
    nlapiLogExecution("debug", _info);
    try {
        UE_EbayFeed.beforeLoad(type, form, request);
    } catch (e) {
        processException(e, _info);
    }
}

function beforeSubmit(type) {
    var id = nlapiGetRecordId(), recType = nlapiGetRecordType();
    var _info = "beforeSubmit  id: " + id + " recType: " + recType + " type: " + type;
    try {
        UE_EbayFeed.beforeSubmit(type);
    } catch (e) {
        var ex = processException(e, "id: " + id + _info);
        if (ex.code == "EBAY_CHECK") {
            throw e;
        }
    }
}

function afterSubmit(type) {
    var envContext = nlapiGetContext().getExecutionContext();
    try {
        var feedId = nlapiGetRecordId();
        if (feedId && envContext == "userinterface") {
            if (type == "edit") {
                if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
                    var feed = new __EbayFeed(feedId);
                    if (feed.val("custrecord_ebay_feed_status") == EBAY_FEED_STATUS.ONLINE) {
                        var pendingModification = feed.getFieldValue(EbayFeed.PENDING_MODIFICATION);
                        _audit("pendingModification", pendingModification);
                        if (pendingModification) {
                            pendingModification = JSON.parse(pendingModification);
                            if (Array.isArray(pendingModification) && pendingModification.length > 0) {
                                feed.callReviseItem(pendingModification);
                            }
                        }
                    }
                } else {}
            } else if (type == "create") {
                if (nlapiGetFieldValue("custrecord_ebay_feed_matrix_child_item") == "F") {
                    var custrecord_ef_subfeeds = nlapiGetFieldValue("custrecord_ef_subfeeds");
                    if (custrecord_ef_subfeeds) {
                        _log_email("custrecord_ef_subfeeds of feed " + feedId, custrecord_ef_subfeeds);
                        var subfeeds = JSON.parse(custrecord_ef_subfeeds);
                        var subfeeds2 = [];
                        for (var i = 0; i < subfeeds.length; i++) {
                            var subfeed = subfeeds[i];
                            var itemSearch = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("itemid", null, "is", subfeed.sku) ], [ new nlobjSearchColumn("upccode"), new nlobjSearchColumn("location"), new nlobjSearchColumn("itemid") ]);
                            if (itemSearch != null && itemSearch.length == 1) {
                                subfeeds2.push({
                                    custrecord_ebay_feed_sku: subfeed.custrecord_ebay_feed_sku,
                                    custrecord_ebay_feed_api_title: subfeed.custrecord_ebay_feed_api_title,
                                    custrecord_ef_upc: itemSearch[0].getValue("upccode") || "Does not apply",
                                    custrecord_ef_ean: "Does not apply",
                                    custrecord_ef_isbn: "Does not apply",
                                    custrecord_ebay_feed_item: itemSearch[0].getId(),
                                    custrecord_ef_language: nlapiGetFieldValue("custrecord_ef_language"),
                                    custrecord_ebay_feed_global_site: nlapiGetFieldValue("custrecord_ebay_feed_global_site"),
                                    custrecord_ebay_feed_account: nlapiGetFieldValue("custrecord_ebay_feed_account"),
                                    custrecord_ebay_feed_submitted_by: nlapiGetFieldValue("custrecord_ebay_feed_submitted_by"),
                                    custrecord_ebay_feed_picture: null,
                                    custrecord_ef_picture2: subfeed.picURL,
                                    custrecord_ebay_feed_location: itemSearch[0].getValue("location"),
                                    _itemid: itemSearch[0].getValue("itemid"),
                                    custrecord_ebay_feed_api_price: subfeed.price,
                                    custrecord_ef_max_push_qty: nlapiGetFieldValue("custrecord_ef_max_push_qty"),
                                    custrecord_ebay_feed_push_qty: nlapiGetFieldValue("custrecord_ebay_feed_push_qty"),
                                    custrecord_ebay_feed_matrix_item: "F",
                                    custrecord_ebay_feed_matrix_child_item: "T",
                                    custrecord_ebay_feed_combo: "F",
                                    custrecord_ebay_feed_parent: feedId,
                                    custrecord_ebay_feed_variations: {
                                        options: subfeed.options
                                    }
                                });
                            } else {
                                _audit(subfeed.sku + " found N records!");
                            }
                        }
                        if (subfeeds2.length) {
                            for (var j = 0; j < subfeeds2.length; j++) {
                                var record = nlapiCreateRecord("customrecord_ebay_item_api_feed");
                                var submittedFeed = subfeeds2[j];
                                for (var field in submittedFeed) {
                                    _audit(">>>>>>>>>>>>>>>>>>>>>>>>>> " + field, submittedFeed[field]);
                                    if (field.indexOf("_") == 0) {
                                        continue;
                                    }
                                    if (field == "eBayFeedChildList" || field == "_exclude") {
                                        continue;
                                    }
                                    var feedFieldValue = submittedFeed[field];
                                    if (Array.isArray(feedFieldValue)) {
                                        feedFieldValue = JSON.stringify(feedFieldValue);
                                    } else if (typeof feedFieldValue == "object") {
                                        if (feedFieldValue != null) {
                                            feedFieldValue = JSON.stringify(feedFieldValue);
                                        }
                                    }
                                    if (!feedFieldValue) feedFieldValue = null;
                                    record.setFieldValue(field, feedFieldValue);
                                }
                                nlapiSubmitRecord(record, true);
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        if (envContext == "userinterface") {
            throw e;
        } else {
            processException(e, {
                feedId: feedId,
                stage: "afterSubmit in Ebay Feed record"
            });
        }
    }
}