var Math2 = {
    parseValue: function(value) {
        if (typeof value == "number") {
            return value;
        } else {
            var stringValue = value.toString();
            stringValue = stringValue.replace(/,/g, "");
            if (stringValue.indexOf(".") != -1) {
                stringValue = parseFloat2(stringValue);
            } else {
                stringValue = parseInt2(stringValue);
            }
            return stringValue;
        }
    },
    makeValue: function(val) {
        return Math.round(this.parseValue(val) * 100) / 100;
    },
    add: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a + b) * 100) / 100;
    },
    sub: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round((a - b) * 100) / 100;
    },
    multiply: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a * b * 100) / 100;
    },
    division: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        return Math.round(a / b * 100) / 100;
    },
    compare: function(a, b) {
        a = this.parseValue(a);
        b = this.parseValue(b);
        a = Math.round(a * 100);
        b = Math.round(b * 100);
        if (a > b) {
            return 1;
        } else if (a < b) {
            return -1;
        } else {
            return 0;
        }
    }
};

function parseInt2(value) {
    value = value || 0;
    value = parseInt(value);
    if (isNaN(value)) value = 0;
    return value;
}

function parseFloat2(value) {
    value = value || 0;
    value = parseFloat(value);
    if (isNaN(value)) value = 0;
    return value;
}

if (typeof this.console == "function" && !window.console) {
    window.console = {
        log: function() {}
    };
}

function parseException(e) {
    var code, message;
    var userMessage = null;
    if (typeof e == "object") {
        if (e instanceof nlobjError) {
            code = e.getCode() || "nlobjError";
            var st = e.getStackTrace();
            st = st.toString();
            message = "Code: " + e.getCode() + " Detail: " + e.getDetails() + " Trace: " + st;
            userMessage = e.getDetails();
        } else if (e instanceof TypeError) {
            code = "TypeError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else if (e instanceof ReferenceError) {
            code = "ReferenceError";
            message = "Detail: " + e.message + " line: " + e.lineNumber;
        } else {
            code = e.code || "EXCEPTION_ERROR_CODE";
            message = e.message || "Detail: " + e.toString();
        }
    } else {
        code = "NS_ERROR";
        message = e.toString();
    }
    if (userMessage == null) userMessage = message;
    var context = nlapiGetContext();
    var sname = [ context.getDeploymentId(), "@Subsidiary" + context.getSubsidiary(), context.getEmail() ].join(" ");
    return {
        code: "[" + code + "] " + sname,
        ERROR_CODE: code,
        message: message,
        userMessage: userMessage
    };
}

function processException(e, info, sendEmail) {
    e = parseException(e);
    var code = e.code;
    var message = e.message;
    if (info) {
        if (typeof info == "object") {
            info = JSON.stringify(info);
        }
        message += "<br/><br/>" + info;
    }
    if (typeof console == "undefined") {
        if (sendEmail != false) {
            _log("nlapiSendEmail", code);
            nlapiSendEmail(530, "allan@zakeusa.com", code, message);
        }
    } else {
        alert(code + "///" + message);
    }
    _nlapiLogExecution("ERROR", code, message);
    return {
        code: code,
        message: message,
        getMessage: function() {
            return code + ": " + message;
        },
        getUserMessage: function() {
            return e.userMessage;
        }
    };
}

function disabledFields(fields) {
    var defaultFields = [ "customform", "name" ];
    if (typeof fields != "undefined" && Array.is(fields)) {
        fields = fields.concat(defaultFields);
    } else {
        fields = defaultFields;
    }
    _disabledFields(fields);
}

function _disabledFields(fields) {
    if (fields && Array.isArray(fields) && fields.length) {
        fields.forEach(function(field) {
            nlapiGetField(field).setDisplayType("disabled");
        });
    }
}

function _nlapiLogExecution(logType, title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (typeof console == "undefined") {
            if (detail) {
                if (typeof detail == "object") {
                    if (format) {
                        nlapiLogExecution(logType, title, JSON.stringify(detail, undefined, 4));
                    } else {
                        nlapiLogExecution(logType, title, JSON.stringify(detail));
                    }
                } else {
                    nlapiLogExecution(logType, title, detail);
                }
            } else {
                nlapiLogExecution(logType, title, detail);
            }
        } else {
            if (typeof title == "object") {
                title = JSON.stringify(title, null, 2);
            }
            if (typeof detail == "object") {
                console.log(title + "///" + JSON.stringify(detail, null, 2));
            } else {
                console.log(title + "///" + detail);
            }
        }
    }
}

function _log(title, detail) {
    var logType = "debug";
    _nlapiLogExecution(logType, title, detail);
}

function _audit(title, detail) {
    _nlapiLogExecution("AUDIT", title, detail);
}

function _log_email(title, detail) {
    nlapiSendEmail(530, "allan@zakeusa.com", nlapiGetContext().getDeploymentId() + ": " + title, detail);
}

function _sendEmail(to, title, detail) {
    title = nlapiGetContext().getDeploymentId() + ": " + title;
    _log("[SENTEMAIL] " + to + " " + title, detail);
    nlapiSendEmail(530, to, title, detail);
}

function simpleCreateRecord(type, obj) {
    var rec = nlapiCreateRecord(type);
    for (var field in obj) {
        rec.setFieldValue(field, obj[field]);
    }
    return nlapiSubmitRecord(rec, true);
}

Array.prototype.contains = function(value) {
    var a = this;
    for (var i = 0; i < a.length; i++) {
        if (a[i] == value) {
            return true;
        }
    }
    return false;
};

Array.prototype.remove = function(value) {
    var a = this;
    var index = a.indexOf(value);
    if (index > -1) {
        a.splice(index, 1);
    }
};

Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) < 0;
    });
};

Array.prototype.same = function(a) {
    return this.filter(function(i) {
        return a.indexOf(i) >= 0;
    });
};

function _toarray(obj) {
    if (!Array.isArray(obj)) obj = [ obj ];
    return obj;
}

function inherit(parent, children) {
    children.prototype = Object.create(parent.prototype);
    children.prototype.constructor = children;
    children.extend = parent.extend;
    children.prototype.extend = function() {
        var source = arguments[0];
        if (source) {
            for (var prop in source) {
                this[prop] = source[prop];
            }
        }
    };
}

function extend(targetObj) {
    var list = Array.prototype.slice.call(arguments, 1);
    for (var i = 0; i < list.length; i++) {
        var source = list[i];
        for (var prop in source) {
            targetObj[prop] = source[prop];
        }
    }
    return targetObj;
}

function createTextFile(name, content, folderId) {
    folderId = folderId || 80473;
    var file = nlapiCreateFile(name + ".txt", "PLAINTEXT", content);
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    return fmt;
};

function _renderPage(html, obj) {
    for (var o in obj) {
        var k = "{{" + o + "}}";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function _renderPage2(html, obj) {
    for (var o in obj) {
        var k = "#" + o + "#";
        html = html.replace(new RegExp(k, "g"), obj[o]);
    }
    return html;
}

function renderPage(html, page_object) {
    _log("page_object", page_object);
    var template = Handlebars.compile(html);
    return template(page_object);
}

function __nlapiSearchRecord(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    var joinname = join + "." + name;
                    record[joinname] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                } else {
                    record[name] = {
                        value: search_record.getValue(column),
                        text: search_record.getText(column)
                    };
                }
            }
            list.push(record);
        }
    }
    return {
        columnLabels: columnLabels,
        list: list
    };
}

function __nlapiSearchRecordX(type, id, filters, columns) {
    var list = [];
    var search = nlapiSearchRecord(type, id, filters, columns);
    if (search != null) {
        for (var i = 0, len = search.length; i < len; i++) {
            var search_record = search[i];
            var record = {};
            record["__id"] = search_record.getId();
            record["__type"] = search_record.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var value = search_record.getValue(column);
                var text = search_record.getText(column);
                if (value && text) {
                    record[name] = {
                        value: value,
                        text: text
                    };
                } else {
                    record[name] = value;
                }
            }
            list.push(record);
        }
    }
    _log("__nlapiSearchRecordX", list);
    return list;
}

function __nlapiSearchRecord2(type, id, filters, columns) {
    var columnLabels = columns.map(function(searchColumn) {
        return searchColumn.getLabel() || searchColumn.getName();
    });
    return {
        columnLabels: columnLabels,
        list: __nlapiSearchRecordX(type, id, filters, columns)
    };
}

function cloneObj(obj) {
    return JSON.parse(JSON.stringify(obj));
}

function getActionURL() {
    var context = nlapiGetContext();
    return nlapiResolveURL("SUITELET", context.getScriptId(), context.getDeploymentId());
}

function _auditUsage() {
    _audit("getRemainingUsage USAGE", nlapiGetContext().getRemainingUsage());
}

function Profiling() {
    this.startTime = new Date().getTime();
}

Profiling.prototype = {
    end: function() {
        var spendTime = Math.round((new Date().getTime() - this.startTime) / 1e3) + "s";
        _audit("_audit - [Profiling]", spendTime);
        return spendTime;
    }
};

function serializeURL(obj) {
    var str = [];
    for (var p in obj) if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
    return str.join("&");
}

function getURLParameter(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(url ? url : location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var IS_NS_SANDBOX = false;

var NS_DOMAIN = "system.na1.netsuite.com";

if (nlapiGetContext().getEnvironment() == "SANDBOX") {
    IS_NS_SANDBOX = true;
    NS_DOMAIN = "system.sandbox.netsuite.com";
}

var Subsidiaries = {
    ZakeUSAHolding: 2,
    Swagway: 4,
    TaiwuInternational: 3,
    ZakeInternational: 1
};

function logparams(request) {
    _log("request.getMethod()----", request.getMethod());
    _log("---logparams---", getparams(request));
}

function getparams(request) {
    var params = request.getAllParameters();
    var paramlist = [];
    for (var param in params) {
        paramlist.push({
            parameter: param,
            value: params[param]
        });
    }
    return paramlist;
}

function checkGovernance() {
    if (nlapiGetContext().getExecutionContext() != "scheduled") {
        return;
    }
    if (nlapiGetContext().getRemainingUsage() < 500) {
        nlapiLogExecution("AUDIT", "checkGovernance---", nlapiGetContext().getRemainingUsage());
        var state = nlapiYieldScript();
        _audit("state.status", state.status);
        if (state.status == "FAILURE") {
            throw nlapiCreateError("YIELD_SCRIPT_ERROR", "Failed to yield script, exiting<br/>Reason = " + state.reason + "<br/>Size = " + state.size + "<br/>Information = " + state.information);
        } else if (state.status == "RESUME") {
            nlapiLogExecution("debug", "checkGovernance-------------", nlapiGetContext().getRemainingUsage());
            nlapiLogExecution("AUDIT", "Resuming script because of " + state.reason + ".  Size = " + state.size);
        }
    } else {
        nlapiGetContext().setPercentComplete((1e4 - nlapiGetContext().getRemainingUsage()) / 100);
    }
}

function rescheduled(params) {
    var context = nlapiGetContext();
    if (context.getExecutionContext() != "scheduled") {
        return false;
    }
    var remainingUsage = nlapiGetContext().getRemainingUsage();
    if (remainingUsage < 500) {
        _audit("remainingUsage", remainingUsage);
        var status = null;
        if (params) {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
        } else {
            status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
        }
        _audit("status", status);
        if (status == "QUEUED") {
            _audit("Reschedule for usage reset ...", remainingUsage);
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

var MarketplaceShipService = {
    ToBeDetermined: 6,
    Standard: 1,
    ThirdDaySelect: 2,
    SecondDayAir: 3,
    NextDay: 4,
    InternationalShippingFromUS: 5
};

var MarketplaceShipName = {
    AliExpress: 1,
    Amazon: 2,
    eBay: 3,
    Wish: 4,
    _3BBestbuy: 5,
    _3BNewegg: 6,
    Rakuten: 7,
    PCDirect: 8,
    _3Btech: 9,
    Swagway: 10
};

var MARKETPLACE_LIST = [ {
    marketplaceId: 10,
    ARAccount: "177",
    formid: "151",
    name: "Swagway"
}, {
    marketplaceId: 3,
    ARAccount: "1127",
    formid: "178",
    name: "EbayClaimthis"
}, {
    marketplaceId: 2,
    ARAccount: "176",
    formid: "263",
    name: "SavannahAmazon",
    store: "1"
}, {
    marketplaceId: 2,
    ARAccount: "174",
    formid: "199",
    name: "BetterChoiceAmazon",
    store: "8"
}, {
    marketplaceId: 5,
    ARAccount: "1126",
    formid: "220",
    name: "ThreeBTechBestBuy"
}, {
    marketplaceId: 7,
    ARAccount: "1129",
    formid: "220",
    name: "ThreeBTechRakuten"
}, {
    marketplaceId: 6,
    ARAccount: "1128",
    formid: "150",
    name: "NeweggZake"
}, {
    marketplaceId: 9,
    ARAccount: "1130",
    formid: "150",
    name: "ThreeBTechNet"
}, {
    marketplaceId: 8,
    ARAccount: "1131",
    formid: "150",
    name: "PCDirect"
} ];

var SALES_ORDER_FORM = {
    SWAGWAY: 151,
    EBAY: 178
};

function getUTCDateTime() {
    var now = new Date();
    var offset = now.getTimezoneOffset();
    var utcDate = new Date(now.getTime() + offset * 60 * 1e3);
    nlapiLogExecution("debug", "getUTCDateTime", utcDate);
    return utcDate;
}

var DateCompare = {
    convert: function(d) {
        return d.constructor === Date ? d : d.constructor === Array ? new Date(d[0], d[1], d[2]) : d.constructor === Number ? new Date(d) : d.constructor === String ? new Date(d) : typeof d === "object" ? new Date(d.year, d.month, d.date) : NaN;
    },
    compare: function(a, b) {
        return isFinite(a = this.convert(a).valueOf()) && isFinite(b = this.convert(b).valueOf()) ? (a > b) - (a < b) : NaN;
    },
    inRange: function(d, start, end) {
        return isFinite(d = this.convert(d).valueOf()) && isFinite(start = this.convert(start).valueOf()) && isFinite(end = this.convert(end).valueOf()) ? start <= d && d <= end : NaN;
    }
};

function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    val2: function(name) {
        return {
            name: name,
            value: this.rec.getFieldValue(name),
            text: this.rec.getFieldText(name)
        };
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var EbayRecordType = {
    customrecord_ebay_item_site_setting: "customrecord_ebay_item_site_setting",
    customrecord_ebay_item_language: "customrecord_ebay_item_language",
    customrecord_ebay_global: "customrecord_ebay_global",
    customrecord_ebay_item_api_feed: "customrecord_ebay_item_api_feed",
    customrecord_ebay_feed_workflow: "customrecord_ebay_feed_workflow",
    customrecord_ebay_account: "customrecord_ebay_account"
};

var EbayRequest = {
    production: "https://api.ebay.com/ws/api.dll",
    sandbox: "https://api.sandbox.ebay.com/ws/api.dll",
    headers: {
        "X-EBAY-API-DEV-NAME": "bb0adac2-2404-4f42-a70f-3412a33e51fc",
        "X-EBAY-API-APP-NAME": "zakeusaf2-c89a-477d-a620-8c8d46f6bdd",
        "X-EBAY-API-CERT-NAME": "c2017a04-a780-456a-86db-a4f994d4e44a",
        "Content-Type": "application/xml"
    },
    call: function(header, xml) {
        try {
            var message = "OK";
            var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, extend(this.headers, header));
            var x2js = new X2JS();
            var responseJSON = x2js.xml_str2json(response.getBody());
            return {
                success: true,
                message: message,
                response: responseJSON
            };
        } catch (e) {
            e = processException(e);
            return {
                success: false,
                message: e.getMessage()
            };
        }
    }
};

function saveAPICallResult(fileName, pageNumber, arr) {
    if (!Array.isArray(arr)) {
        throw createEbayError("Params is error and not array");
    }
    fileName += ".txt";
    var folderId = 295527;
    var file = null;
    if (pageNumber == 1) {
        var content = {
            startTime: new Date().getTime(),
            arr: arr
        };
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content));
    } else {
        file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
        var content = file.getValue();
        content = JSON.parse(content);
        content.arr = content.arr.concat(arr);
        content.arrLenth = content.arr.length;
        content.endTime = new Date().getTime();
        content.spendTime = Math.round((content.endTime - content.startTime) / 1e3) + "s";
        file = nlapiCreateFile(fileName, "PLAINTEXT", JSON.stringify(content, null, 2));
    }
    file.setFolder(folderId);
    nlapiSubmitFile(file);
}

function sendAPICallResult(fileName) {
    fileName += ".txt";
    var file = nlapiLoadFile("SuiteScripts/EbayIntegration/Feed/" + fileName);
    var content = file.getValue();
    _log_email(fileName, content);
}

var EbayFeedStatus = {
    Online: 1,
    Offline: 2,
    ForcedOffline: 3,
    InQue_New: 4,
    InQue_RelistOnline: 9,
    InQue_RelistOffline: 10,
    Error_New: 5,
    Error_RelistOnline: 11,
    Error_RelistOffline: 14,
    Error_Revise: 12,
    Error_Offline: 13,
    WaitingForApproval: 6,
    Rejected: 7,
    New: 8
};

var EbayFeedButtonAction = {
    Submit: 6,
    Relist: 5,
    Delist: 2,
    ForceDelist: 3,
    Approve: 1,
    Reject: 4,
    Revise: 7,
    ReSubmit: 8
};

var ZakeRole = {
    SalesManager: 1021,
    SalesPerson: 1022
};

function createEbayError(details) {
    return nlapiCreateError("EBAY_ERROR", details);
}

function createError(details) {
    return nlapiCreateError("ZAKE_ERROR", details);
}

function getCustomList(customListId, asObject) {
    var col = new Array();
    col[0] = new nlobjSearchColumn("name");
    col[1] = new nlobjSearchColumn("internalId");
    var obj = {};
    var list = [];
    var results = nlapiSearchRecord(customListId, null, null, col);
    for (var i = 0; results != null && i < results.length; i++) {
        var res = results[i];
        var listValue = res.getValue("name");
        var listID = res.getValue("internalId");
        list.push({
            key: listID,
            value: listValue
        });
        obj[listID] = listValue;
    }
    if (asObject == true) {
        return obj;
    } else {
        return list;
    }
}

function deepmerge(target, src) {
    var array = Array.isArray(src);
    var dst = array && [] || {};
    if (array) {
        target = target || [];
        dst = dst.concat(target);
        src.forEach(function(e, i) {
            if (typeof dst[i] === "undefined") {
                dst[i] = e;
            } else if (typeof e === "object") {
                dst[i] = deepmerge(target[i], e);
            } else {
                if (target.indexOf(e) === -1) {
                    dst.push(e);
                }
            }
        });
    } else {
        if (target && typeof target === "object") {
            Object.keys(target).forEach(function(key) {
                dst[key] = target[key];
            });
        }
        Object.keys(src).forEach(function(key) {
            if (typeof src[key] !== "object" || !src[key]) {
                dst[key] = src[key];
            } else {
                if (!target[key]) {
                    dst[key] = src[key];
                } else {
                    dst[key] = deepmerge(target[key], src[key]);
                }
            }
        });
    }
    return dst;
}

function autoSetEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = item.label;
        }
        item.options.forEach(function(opt) {
            opt.translation = opt.value;
        });
    });
}

function autoRemoveEnglishTranslation(variations) {
    variations.availOptions.forEach(function(item) {
        if (typeof item == "object" && item.hasOwnProperty("translation")) {
            item.translation = "";
        }
        item.options.forEach(function(opt) {
            opt.translation = "";
        });
    });
}

Array.prototype.unique = function() {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j]) a.splice(j--, 1);
        }
    }
    return a;
};

var ITEM_OPTIONS = [ [ "custitem_var_color", "Colors" ], [ "custitem_var_size", "Sizes" ], [ "custitem_womens_size", "Womens Size" ], [ "custitem_watch_deisgn", "Watch Design" ], [ "custitem_var_assortment", "Assortment" ], [ "custitem_var_bag_pattern", "Bag Pattern" ], [ "custitem_child_size", "Child Size" ], [ "custitem_var_color_temp", "Color Temp" ], [ "custitem_var_compatible_with", "Compatible With" ], [ "custitem_var_legging_design", "Legging Design" ], [ "custitem_var_mens_size", "Mens Size" ], [ "custitem_var_print_design", "Print Design" ], [ "custitem_var_shape", "Shape" ], [ "custitem_var_style", "Style" ], [ "custitem_var_womens_shoe_size", "Shoe Size" ], [ "custitem_var_mens_pant_size", "Mens Pant Size" ], [ "custitem_var_bra_size", "Bra Size" ], [ "custitem_var_child_shoe_size", "Child Shoe Size" ], [ "custitem_var_mens_shoe_size", "Mens Shoe Size" ], [ "custitem_var_amps", "AMPS" ] ];

function isMatrixItem(item__internalid) {
    var ismatrix = false;
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
    if (testSearch != null) ismatrix = true;
    return ismatrix;
}

function getItemType(id) {
    return nlapiLookupField("item", id, "type");
}

function isKitItem(id) {
    return getItemType(id) == "Kit";
}

function EbayItem(type, id) {
    this.id = id;
    this.pictureSearch = null;
    Record.call(this, type, id);
}

EbayItem.TYPE = {
    INVENTORY_ITEM: "inventoryitem",
    KIT_ITEM: "kititem"
};

inherit(Record, EbayItem);

EbayItem.prototype.extend({
    getPictureSearch: function() {
        if (this.pictureSearch == null) {
            var c = [];
            var custitem_ebay_gallery_picture_columns = [];
            for (var j = 1; j <= 10; j++) {
                custitem_ebay_gallery_picture_columns.push("custitem_ebay_gallery_picture_" + j);
            }
            var custitem_ebay_body_picture_columns = [];
            for (var x = 1; x <= 15; x++) {
                custitem_ebay_body_picture_columns.push("custitem_ebay_body_picture_" + x);
            }
            c = c.concat(custitem_ebay_gallery_picture_columns, custitem_ebay_body_picture_columns);
            var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", [ this.id ]) ], c.map(function(name) {
                return new nlobjSearchColumn(name);
            }));
            if (search == null) {
                throw createEbayError("Not pic in item.");
            } else {
                search = search[0];
                var pictureSearch = {
                    gallery: custitem_ebay_gallery_picture_columns.map(function(name) {
                        return {
                            name: name,
                            value: search.getValue(name),
                            text: search.getText(name)
                        };
                    }),
                    bodyPicture: custitem_ebay_body_picture_columns.map(function(name) {
                        return {
                            name: name,
                            value: search.getValue(name),
                            text: search.getText(name)
                        };
                    })
                };
                this.pictureSearch = pictureSearch;
                return pictureSearch;
            }
        } else {
            return this.pictureSearch;
        }
    },
    getGalleryPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.gallery;
    },
    getBodyPicture: function() {
        var pictureSearch = this.getPictureSearch();
        return pictureSearch.bodyPicture;
    }
});

function EbayInventoryItem(id, ismatrix) {
    this.locationId = null;
    EbayItem.call(this, "inventoryitem", id);
}

inherit(EbayItem, EbayInventoryItem);

EbayInventoryItem.prototype.getField = function(name) {
    var record = this.rec;
    return {
        name: name,
        value: record.getFieldValue(name),
        text: record.getFieldText(name)
    };
};

EbayInventoryItem.prototype._ismatrix = function() {
    return this.ismatrix == "T";
};

EbayInventoryItem.prototype.getLocationQuantity = function() {
    return this.getSubList("locations", [ "location", "location_display", "quantityavailable" ]);
};

EbayInventoryItem.prototype.getChildRecord = function() {
    var variations = {};
    var parentRecord = this;
    var availOptions = this.getRecordVariations();
    var availOptionNameList = [];
    var matrixOptionsColumns = availOptions.availOptions.map(function(option) {
        availOptionNameList.push(option.name);
        return new nlobjSearchColumn(option.name).setLabel(option.label);
    });
    var columns = [ new nlobjSearchColumn("itemid"), new nlobjSearchColumn("baseprice"), new nlobjSearchColumn("custitem_ebay_variation_picture") ];
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    columns = columns.concat(matrixOptionsColumns);
    var itemChildRecordSearchResults = nlapiSearchRecord("inventoryitem", null, [ new nlobjSearchFilter("parent", null, "is", parentRecord.getId()), new nlobjSearchFilter("isinactive", null, "is", "F"), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ 7 ]) ], columns);
    var searchList = [];
    if (itemChildRecordSearchResults != null) {
        for (var i = 0, len = itemChildRecordSearchResults.length; i < len; i++) {
            var childRecord = itemChildRecordSearchResults[i];
            var record = {};
            record["__id"] = childRecord.getId();
            record["__type"] = childRecord.getRecordType();
            for (var j = 0; j < columns.length; j++) {
                var column = columns[j];
                var name = column.getName();
                var join = column.getJoin();
                if (join) {
                    join = join.toLowerCase();
                    name = join + "." + name;
                }
                var label = column.getLabel();
                var value = childRecord.getValue(column);
                var text = childRecord.getText(column);
                if (value && text) {
                    if (availOptionNameList.indexOf(name) != -1) {
                        record[name] = {
                            value: value,
                            text: text,
                            translation: ""
                        };
                    } else {
                        record[name] = {
                            value: value,
                            text: text
                        };
                    }
                } else {
                    if (name == "itemid") {
                        if (value.indexOf(" : ") != -1) value = value.substring(value.indexOf(" : ") + 3);
                    }
                    record[name] = value;
                }
            }
            record["locationquantityavailable"] = childRecord.getValue("formulanumeric");
            searchList.push(record);
        }
    }
    variations.childRecordList = searchList;
    _log("childRecordList", variations);
    return variations;
};

EbayInventoryItem.prototype.getRecordVariations = function() {
    var parentRecord = this;
    var variations = {};
    variations.availOptions = ITEM_OPTIONS.map(function(o) {
        return extend(parentRecord.getField(o[0]), {
            label: o[1],
            translation: ""
        });
    }).filter(function(item) {
        return item.value;
    });
    variations.availOptions.forEach(function(item) {
        item.value = item.value.split("");
        item.text = item.text.split("");
        item.options = item.value.map(function(v, i) {
            return {
                id: v,
                value: item.text[i],
                translation: ""
            };
        });
    });
    return variations;
};

EbayInventoryItem.getMatrixItemVariations = function(parentId) {
    return new EbayInventoryItem(parentId).getRecordVariations();
};

function EbayKitItem(id) {
    EbayItem.call(this, "kititem", id);
}

inherit(EbayItem, EbayKitItem);

EbayKitItem.prototype.getOption = function() {
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var name = "custitem_var_kit";
    var value = [];
    var text = [];
    var options = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        var var_name = line[3].trim();
        index++;
        value.push(id + "_" + index);
        text.push(var_name);
        return {
            id: id + "_" + index,
            value: var_name,
            translation: ""
        };
    });
    return {
        availOptions: [ {
            name: name,
            value: value,
            text: text,
            label: "Kit Variation",
            translation: "",
            options: options
        } ]
    };
};

function getVariationQuantity(id_expression, mainLocation) {
    id_expression = id_expression.map(function(id) {
        var qtyIndex = id.indexOf("*");
        if (qtyIndex != -1) {
            return {
                _id: id.substring(0, qtyIndex),
                _qty: id.substring(qtyIndex + 1)
            };
        } else {
            return {
                _id: id,
                _qty: "1"
            };
        }
    });
    var columns = [];
    if (mainLocation == "2") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sb_avail},0))"));
    } else if (mainLocation == "7") {
        columns.push(new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))+TO_NUMBER(NVL({custitem_supplier_sz_avail},0))"));
    } else {
        throw createEbayError("No Main Location for the matrix item.");
    }
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "anyof", id_expression.map(function(item) {
        return item._id;
    })), new nlobjSearchFilter("internalid", "inventorylocation", "anyof", [ mainLocation ]) ], columns);
    var list = [];
    if (search != null) {
        search.forEach(function(searchResult, index) {
            var total = searchResult.getValue("formulanumeric");
            _log("total" + index, total);
            if (total) {
                _log("searchResult.getId()", searchResult.getId());
                _log("id_expression", id_expression);
                var qty = id_expression.filter(function(item) {
                    return item._id == searchResult.getId();
                })[0]._qty;
                list.push(Math.floor(parseInt(total) / parseInt(qty)));
            }
        });
    } else {
        return 0;
    }
    _log("getVariationQuantity: " + JSON.stringify(id_expression), list);
    if (list.length) {
        var qty = _.min(list);
        if (!qty) qty = 0;
        _log(typeof qty, qty);
        return qty;
    } else {
        return 0;
    }
}

EbayKitItem.prototype.getChildRecord = function() {
    var mainLocation = this.val("custitem_main_location");
    if (this.locationId == null) this.locationId = mainLocation;
    var id = this.getId();
    var kvar = this.getFieldValue("custitem_kit_variation");
    kvar = kvar.split("\r\n");
    var childRecordList = kvar.filter(function(line) {
        return line.trim() != "";
    }).map(function(line, index) {
        line = line.split("|");
        index++;
        var line_id = line[0].trim();
        var line_sku = line[1].trim();
        var kit_var_id = line_id.replace(/\,/g, "^").replace(/\s/g, "");
        return {
            __id: kit_var_id,
            __type: "KIT_INV",
            itemid: kit_var_id,
            baseprice: line[2].trim(),
            custitem_ebay_variation_picture: "",
            custitem_var_kit: {
                value: id + "_" + index,
                text: line[3].trim(),
                translation: ""
            },
            locationquantityavailable: getVariationQuantity(line_id.split(",").map(function(id) {
                return id.trim();
            }), mainLocation)
        };
    });
    _log("EbayKitItem.prototype.getChildRecord", childRecordList);
    return {
        childRecordList: childRecordList
    };
};

var EbayFeed = {
    PENDING_MODIFICATION: "custrecord_ebay_feed_pending_mdf",
    TYPE: "customrecord_ebay_item_api_feed",
    FIELD_MAPPING: {
        custrecord_ebay_feed_item: "itemRecordId",
        custrecord_ebay_feed_language_id: "languageId",
        custrecord_ebay_feed_global_site: "eBayGlobalSiteRecordId",
        custrecord_ebay_feed_account: "eBayGlobalAccountSettingRecordId",
        custrecord_ebay_feed_seq: "itemTitlePictureSequenceId",
        custrecord_ebay_feed_language: "eBayItemLanguageSetRecordId",
        custrecord_ebay_feed_site: "eBayItemSiteSettingRecordId",
        custrecord_ebay_feed_push_qty: "push_qty",
        custrecord_ebay_feed_category_id: "site_category_id",
        custrecord_ebay_feed_specifics: "specificList",
        custrecord_ebay_feed_gallery: "gallery",
        custrecord_ebay_feed_body_picture: "bodyPicture",
        custrecord_ebay_feed_api_site: "country",
        custrecord_ebay_feed_api_sku: "sku",
        custrecord_ebay_feed_api_title: "title",
        custrecord_ebay_feed_api_baseprice: "baseprice",
        custrecord_ebay_feed_api_price: "price",
        custrecord_ebay_feed_currency: "currency",
        custrecord_ebay_feed_description: "description",
        custrecord_ebay_feed_paypalaccount: "paypalAccount",
        custrecord_ebay_feed_seller_id: "sellerId",
        custrecord_ebay_feed_location: "defaultShipFromLocation",
        custrecord_ebay_feed_token: "token",
        custrecord_ebay_feed_site_id: "apiSiteId",
        custrecord_ebay_feed_matrix_item: "ismatrix",
        custrecord_ebay_feed_variations: "variation",
        custrecord_ebay_feed_item_type: "itemType",
        custrecord_ebay_feed_is_var: "isVar",
        custrecord_ebay_feed_submitted_by: "submittedBy",
        custrecord_ebay_feed_picture: "picture",
        custrecord_ebay_feed_skuat: "skuat",
        custrecord_ebay_feed_status: "_status"
    },
    getRecordFieldList: function() {
        var f = this.FIELD_MAPPING;
        var list = [];
        for (var i in f) {
            list.push(i);
        }
        return list;
    },
    create: function(feed) {
        feed._status = EbayFeedStatus.New;
        var record = nlapiCreateRecord(this.TYPE);
        this.processFeedRecord(record, feed, "create");
        return nlapiSubmitRecord(record, true);
    },
    update: function(id, feed) {
        var record = nlapiLoadRecord(this.TYPE, id);
        var processResult = this.processFeedRecord(record, feed, "update");
        if (processResult.recordFieldChangedCount) {
            return {
                recordFieldChangedCount: processResult.recordFieldChangedCount,
                recordFieldChangedList: processResult.recordFieldChangedList,
                id: nlapiSubmitRecord(record, true)
            };
        } else {
            return {
                recordFieldChangedCount: 0,
                recordFieldChangedList: processResult.recordFieldChangedList,
                id: id
            };
        }
    },
    search: function(id, addFilter) {
        var fieldMapping = this.FIELD_MAPPING;
        var columns = [];
        for (var i in fieldMapping) {
            columns.push(new nlobjSearchColumn(i));
        }
        [ "internalid", "custrecord_ebay_feed_category_title", "lastmodified", "lastmodifiedby" ].forEach(function(name) {
            columns.push(new nlobjSearchColumn(name));
        });
        var filter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ id ]), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_language_id", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_account", null, "noneof", "@NONE@"), new nlobjSearchFilter("custrecord_ebay_feed_seq", null, "noneof", "@NONE@") ];
        if (addFilter && Array.isArray(addFilter)) {
            filter = filter.concat(addFilter);
        }
        var searchResult = __nlapiSearchRecord(this.TYPE, null, filter, columns);
        searchResult.list.forEach(function(item, index) {
            index++;
            item.__no = index;
            item.__link = nlapiResolveURL("RECORD", "customrecord_ebay_item_api_feed", item.internalid.value);
        });
        return searchResult;
    },
    processFeedRecord: function(record, feed, action) {
        var FIELD_MAPPING = this.FIELD_MAPPING;
        var recordFieldChangedCount = 0;
        var recordFieldChangedList = [];
        for (var ebay_feed_record_field in FIELD_MAPPING) {
            var feedFieldValue;
            if (feed.hasOwnProperty(FIELD_MAPPING[ebay_feed_record_field])) {
                feedFieldValue = feed[FIELD_MAPPING[ebay_feed_record_field]];
            }
            if (feedFieldValue) {
                if (Array.isArray(feedFieldValue)) {
                    feedFieldValue = JSON.stringify(feedFieldValue);
                } else if (typeof feedFieldValue == "object") {
                    feedFieldValue = JSON.stringify(feedFieldValue);
                }
            } else {
                feedFieldValue = null;
            }
            var SET_FLAG = false;
            if (action == "create") {
                SET_FLAG = true;
                recordFieldChangedCount++;
                recordFieldChangedList.push("--all_field--");
            } else {
                var recordFieldValue = record.getFieldValue(ebay_feed_record_field) || record.getFieldText(ebay_feed_record_field);
                if (ebay_feed_record_field == "custrecord_ebay_feed_status") {
                    continue;
                } else if (ebay_feed_record_field == "custrecord_ebay_feed_api_price" && record.getFieldValue("custrecord_ebay_feed_api_price_noo") == "T") {
                    continue;
                } else if (ebay_feed_record_field == "custrecord_ebay_feed_push_qty" && record.getFieldValue("custrecord_ebay_feed_push_qty_noo") == "T") {
                    continue;
                } else {
                    if (recordFieldValue != feedFieldValue) {
                        SET_FLAG = true;
                        recordFieldChangedCount++;
                        recordFieldChangedList.push(FIELD_MAPPING[ebay_feed_record_field]);
                    }
                }
            }
            if (SET_FLAG) {
                record.setFieldValue(ebay_feed_record_field, feedFieldValue);
            }
        }
        _log("record Log Info", "FieldChangedCount --- " + recordFieldChangedCount + " " + action + " Record ID: " + record.getId());
        return {
            recordFieldChangedCount: recordFieldChangedCount,
            recordFieldChangedList: recordFieldChangedList
        };
    }
};

function __EbayFeed(id) {
    Record.call(this, EbayFeed.TYPE, id);
}

inherit(Record, __EbayFeed);

__EbayFeed.prototype.getVariation = function() {
    var v = this.val("custrecord_ebay_feed_variations");
    if (v && typeof v == "string") {
        return JSON.parse(v);
    }
    return v;
};

__EbayFeed.prototype.getToken = function() {
    return this.val("custrecord_ebay_feed_token");
};

__EbayFeed.prototype.getEbayItemId = function() {
    return this.val("custrecord_ebay_feed_item_id") || null;
};

__EbayFeed.prototype.getSiteId = function() {
    return this.val("custrecord_ebay_feed_site_id");
};

__EbayFeed.prototype.getStatus = function() {
    return this.val("custrecord_ebay_feed_status");
};

__EbayFeed.prototype.getEbayAuthToken = function() {
    var xml = "";
    xml += "  <RequesterCredentials>";
    xml += "        <eBayAuthToken>" + this.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    return xml;
};

__EbayFeed.searchActionButton = function(role, status) {
    return __nlapiSearchRecordX("customrecord_ebay_feed_workflow", null, [ new nlobjSearchFilter("custrecord_efw_status_before", null, "anyof", [ status ]) ], [ new nlobjSearchColumn("custrecord_efw_action_button") ]);
};

__EbayFeed.searchLegacyActionButton = function(buttons) {
    return __nlapiSearchRecordX("customrecord_ebay_feed_workflow", null, [ new nlobjSearchFilter("custrecord_efw_action_button", null, "anyof", buttons) ], [ new nlobjSearchColumn("custrecord_efw_action_button") ]);
};

var FEED_WARNING_LIST = [];

function getEbayItemFeedList(item__internalid) {
    _log("getEbayItemFeedList ---- Start", "----------------------Start -------------------------");
    var ebayItemRecord = LOAD_EBAY_ITEM_RECORD(item__internalid);
    var itemSiteList = ebayItemRecord.SITELIST;
    var uploadList = [];
    for (var i = 0; i < itemSiteList.length; i++) {
        var siteItem = itemSiteList[i];
        var eBayGlobalAccountMapping = siteItem.eBayItemSiteSettingRecord.eBayGlobalAccountMapping;
        var titleList = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_title_permutations;
        titleList = JSON.parse(titleList);
        if (!titleList) throw createEbayError("Ebay Language record no the title permutations, Please check the records.");
        for (var j = 0; j < eBayGlobalAccountMapping.length; j++) {
            var eBayGlobalAccountRecord = eBayGlobalAccountMapping[j];
            _log("-------------------------------eBayAccountSetting-------------------------------------");
            var sequenceList = [];
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence1 == "T") sequenceList.push("custrecord_title_pic_seq1");
            if (siteItem.eBayItemSiteSettingRecord.custrecord_ei_use_sequence2 == "T") sequenceList.push("custrecord_title_pic_seq2");
            for (var k = 0; k < sequenceList.length; k++) {
                var seqFieldName = sequenceList[k];
                var priceVariant = eBayGlobalAccountRecord["custrecord_ebay_price_variant" + seqFieldName.replace("custrecord_title_pic_seq", "")];
                _log("priceVariant", priceVariant);
                if (!priceVariant) {
                    priceVariant = 0;
                } else if (priceVariant.charAt(0) == ".") {
                    priceVariant = "0" + priceVariant;
                }
                var itemPictureSequence = eBayGlobalAccountRecord[seqFieldName];
                itemPictureSequence = itemPictureSequence.text;
                var eBayFeedItem = {};
                eBayFeedItem.submittedBy = ebayItemRecord.userId;
                eBayFeedItem.ismatrix = ebayItemRecord.ismatrix;
                eBayFeedItem.variation = siteItem.variation;
                eBayFeedItem.itemType = ebayItemRecord.type;
                if (eBayFeedItem.itemType == "kititem") {
                    eBayFeedItem.isVar = "T";
                } else if (eBayFeedItem.itemType == "inventoryitem") {
                    eBayFeedItem.isVar = eBayFeedItem.ismatrix == "T" ? "T" : "F";
                }
                eBayFeedItem.itemRecordId = ebayItemRecord.id;
                eBayFeedItem.languageId = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_language;
                eBayFeedItem.eBayGlobalSiteRecordId = siteItem.eBayItemSiteSettingRecord.custrecord_ei_site;
                eBayFeedItem.eBayGlobalAccountSettingRecordId = eBayGlobalAccountRecord.eBayGlobalAccountSettingRecordId;
                eBayFeedItem.itemTitlePictureSequenceId = eBayGlobalAccountRecord[seqFieldName].value;
                eBayFeedItem.eBayItemSiteSettingRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemSiteSettingRecordId;
                eBayFeedItem.eBayItemLanguageSetRecordId = siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.eBayItemLanguageSetRecordId;
                _log("eBayFeedItem.itemTitlePictureSequenceId", eBayFeedItem.itemTitlePictureSequenceId);
                if (!eBayFeedItem.itemTitlePictureSequenceId) continue;
                eBayFeedItem.itemTitlePictureSequence = itemPictureSequence;
                eBayFeedItem.skuat = [ eBayFeedItem.languageId, eBayFeedItem.eBayGlobalSiteRecordId, eBayFeedItem.eBayGlobalAccountSettingRecordId, eBayFeedItem.itemTitlePictureSequenceId ].join("-");
                eBayFeedItem.sku = ebayItemRecord.id + "@" + ebayItemRecord.itemid + "@" + eBayFeedItem.skuat;
                eBayFeedItem.site_category_id = siteItem.eBayItemSiteSettingRecord.custrecord_ei_site_category_id;
                var locationQuantity = parseInt(siteItem.quantity);
                var maxPushQuantity = parseInt(siteItem.eBayItemSiteSettingRecord.custrecord_ei_qty);
                if (locationQuantity > maxPushQuantity) {
                    eBayFeedItem.push_qty = maxPushQuantity;
                } else {
                    eBayFeedItem.push_qty = locationQuantity;
                }
                eBayFeedItem.push_qty = eBayFeedItem.push_qty.toString();
                if (ebayItemRecord.type == "inventoryitem") {
                    eBayFeedItem.baseprice = siteItem.sitePrice;
                    _log("eBayFeedItem.baseprice", eBayFeedItem.baseprice);
                    if (!eBayFeedItem.baseprice) continue;
                    if (priceVariant !== 0) {
                        priceVariant = priceVariant.toString();
                        if (priceVariant.charAt(0) == "-") {
                            priceVariant = priceVariant.replace("-", "");
                            eBayFeedItem.price = Math2.makeValue(siteItem.sitePrice - parseFloat(priceVariant));
                        } else {
                            eBayFeedItem.price = Math2.makeValue(siteItem.sitePrice + parseFloat(priceVariant));
                        }
                    } else {
                        eBayFeedItem.price = Math2.makeValue(siteItem.sitePrice);
                    }
                } else if (ebayItemRecord.type == "kititem") {
                    eBayFeedItem.price = _.min(siteItem.variation.childRecordList.map(function(item) {
                        return Math2.parseValue(item.baseprice);
                    }));
                    eBayFeedItem.baseprice = eBayFeedItem.price;
                    if (!eBayFeedItem.baseprice) continue;
                } else {
                    continue;
                }
                eBayFeedItem.baseprice = eBayFeedItem.baseprice.toString();
                eBayFeedItem.price = eBayFeedItem.price.toString();
                eBayFeedItem.specificList = siteItem.eBayItemSiteSettingRecord.specificList;
                eBayFeedItem.country = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_api_site;
                eBayFeedItem.currency = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_default_currency;
                eBayFeedItem.apiSiteId = siteItem.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_site_id;
                if (Math2.compare(eBayFeedItem.price, 12) == 1) {
                    eBayFeedItem.paypalAccount = eBayGlobalAccountRecord.custrecord_paypal_account_linked;
                } else {
                    eBayFeedItem.paypalAccount = eBayGlobalAccountRecord.custrecord_micro_paypal_account_linked;
                }
                eBayFeedItem.sellerId = eBayGlobalAccountRecord.sellerId;
                eBayFeedItem.defaultShipFromLocation = siteItem.locationCity;
                eBayFeedItem.token = eBayGlobalAccountRecord.api_token;
                var _title = "";
                var existingTitle = titleList.filter(function(title) {
                    return title.referId == eBayFeedItem.sku;
                });
                if (existingTitle.length) {
                    _title = existingTitle[0].title;
                } else {
                    var availReferIdTitle = titleList.filter(function(title) {
                        return title.referId == null;
                    });
                    if (availReferIdTitle.length) {
                        var aTitle = availReferIdTitle[0];
                        _title = aTitle.title;
                        aTitle.referId = eBayFeedItem.sku;
                    } else {
                        _title = "TODO:  Title!!!!!!!!!!!!!!!!!!! " + new Date().getTime();
                    }
                }
                eBayFeedItem.title = _title;
                var seq = itemPictureSequence.split("-");
                if (Array.isArray(seq)) {
                    var gallerySeq = seq[0];
                    var _gallery = getItemGallery(gallerySeq, ebayItemRecord.gallery);
                    eBayFeedItem.gallery = _gallery.list;
                    var bodyPicSeq = seq[1];
                    eBayFeedItem.bodyPicture = getBodyPicture(bodyPicSeq, ebayItemRecord.bodyPicture);
                    eBayFeedItem.picture = _gallery.mainPicture;
                } else {
                    eBayFeedItem.gallery = null;
                    eBayFeedItem.bodyPicture = null;
                    _log("Item without pictures!", "----");
                    continue;
                }
                eBayFeedItem.description = siteItem.eBayItemDescription.replace("#body_picture#", eBayFeedItem.bodyPicture.map(function(url) {
                    return '<img src="https://' + NS_DOMAIN + url + '" />';
                }).join("<br/>"));
                uploadList.push(eBayFeedItem);
            }
        }
        nlapiSubmitField("customrecord_ebay_item_language", siteItem.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.eBayItemLanguageSetRecordId, "custrecord_eil_title_permutations", JSON.stringify(titleList), true);
    }
    _log("GETEBAYITEMFEEDLIST -- FIRST RECORD", uploadList[0]);
    return uploadList;
}

function getItemGallery(seq, custitem_ebay_gallery_picture_columns) {
    if (!seq) return [];
    var list = [];
    var pList = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = seq.charAt(i);
        if (no == "0") no = "10";
        var pic = _.find(custitem_ebay_gallery_picture_columns, function(_pic) {
            return _pic.name == "custitem_ebay_gallery_picture_" + no;
        });
        if (pic && pic.text) {
            list.push(pic.text);
            pList.push(pic.value);
        }
    }
    return {
        list: list,
        mainPicture: pList[0]
    };
}

function getBodyPicture(seq, custitem_ebay_body_picture_columns) {
    if (!seq) return [];
    var list = [];
    var size = seq.length;
    for (var i = 0; i < size; i++) {
        var no = null;
        var name = seq.charAt(i);
        switch (name) {
          case "A":
            no = 1;
            break;

          case "B":
            no = 2;
            break;

          case "C":
            no = 3;
            break;

          case "D":
            no = 4;
            break;

          case "E":
            no = 5;
            break;

          case "F":
            no = 6;
            break;

          case "G":
            no = 7;
            break;

          case "H":
            no = 8;
            break;

          case "I":
            no = 9;
            break;

          case "J":
            no = 10;
            break;

          default:
            no = 0;
        }
        no = "custitem_ebay_body_picture_" + no;
        var pic = _.find(custitem_ebay_body_picture_columns, function(_pic) {
            return _pic.name == no;
        });
        if (pic && pic.text) list.push(pic.text);
    }
    return list;
}

var LOCATION_QUANTITY_CONFIG = {
    2: "custitem_supplier_sb_avail",
    7: "custitem_supplier_sz_avail"
};

function LOAD_EBAY_ITEM_RECORD(item__internalid, languageId, siteId, ebayAccountId, seqId) {
    var ITEM_RECORD = {};
    ITEM_RECORD.userId = nlapiGetContext().getUser();
    var ismatrix = "F";
    var filter = [ new nlobjSearchFilter("internalid", null, "anyof", [ item__internalid ]), new nlobjSearchFilter("matrix", null, "is", "T") ];
    if (getItemType(item__internalid) == "Kit") {
        ITEM_RECORD.type = "kititem";
    } else {
        ITEM_RECORD.type = "inventoryitem";
        var testSearch = nlapiSearchRecord("item", null, filter, [ new nlobjSearchColumn("internalid") ]);
        if (testSearch != null) ismatrix = "T";
    }
    _log("ismatrix", ismatrix);
    ITEM_RECORD.ismatrix = ismatrix;
    var __item = null;
    if (ITEM_RECORD.type == "kititem") {
        __item = new EbayKitItem(item__internalid);
    } else {
        __item = new EbayInventoryItem(item__internalid, ismatrix);
    }
    ITEM_RECORD.id = __item.getId();
    if (!__item.getFieldValue("class")) throw createEbayError("The item record needs Class value for template creation.");
    var childRecordList = null;
    if (ITEM_RECORD.type == "inventoryitem" && ismatrix == "T") {
        childRecordList = __item.getChildRecord();
    } else if (ITEM_RECORD.type == "kititem") {
        childRecordList = __item.getChildRecord();
    }
    if (childRecordList != null) childRecordList = childRecordList.childRecordList;
    ITEM_RECORD.internalid = __item.val("internalid");
    ITEM_RECORD.itemid = __item.val("itemid");
    ITEM_RECORD.baseprice = __item.val("baseprice");
    ITEM_RECORD.class = __item.val("class");
    if (!ITEM_RECORD.class) throw createEbayError("No Class setting for the item.");
    ITEM_RECORD.gallery = __item.getGalleryPicture();
    ITEM_RECORD.bodyPicture = __item.getBodyPicture();
    var siteFilter = [ new nlobjSearchFilter("custrecord_ei_item_link", null, "anyof", [ item__internalid ]) ];
    if (siteId) siteFilter.push(new nlobjSearchFilter("custrecord_ei_item_link", null, "anyof", siteId));
    if (languageId) siteFilter.push(new nlobjSearchFilter("custrecord_eil_language", "custrecord_ei_language_set", "anyof", languageId));
    var siteSearchResults = nlapiSearchRecord("customrecord_ebay_item_site_setting", null, siteFilter);
    var SITELIST = [];
    if (siteSearchResults != null) {
        var SITE_ERRORS = [];
        for (var i = 0; i < siteSearchResults.length; i++) {
            try {
                var siteSearchResult = siteSearchResults[i];
                var itemSiteRecord = {
                    id: siteSearchResult.getId()
                };
                itemSiteRecord.eBayItemSiteSettingRecord = loadEbayItemSiteSettingRecord(itemSiteRecord.id, ebayAccountId);
                if (itemSiteRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_language == "1") {
                    var bodyEnglishDescription = __item.getFieldValue("custitem_body_template");
                    if (bodyEnglishDescription) {
                        itemSiteRecord.eBayItemDescription = bodyEnglishDescription;
                    } else {
                        buildItemDescription(itemSiteRecord, ITEM_RECORD.class);
                    }
                } else {
                    buildItemDescription(itemSiteRecord, ITEM_RECORD.class);
                }
                if (ITEM_RECORD.type == "inventoryitem") {
                    itemSiteRecord.sitePrice = Math2.parseValue(itemSiteRecord.eBayItemSiteSettingRecord.custrecord_ei_site_price);
                }
                if (ITEM_RECORD.type == "inventoryitem" && ismatrix == "T" || ITEM_RECORD.type == "kititem") {
                    var currency = itemSiteRecord.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_default_currency;
                    var availOptions = itemSiteRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_variations;
                    availOptions = JSON.parse(availOptions);
                    _log("-----availOptions----", availOptions);
                    var optionSet = {};
                    availOptions.availOptions.forEach(function(opt) {
                        optionSet[opt.name] = {};
                        opt.options.forEach(function(o) {
                            optionSet[opt.name][o.id] = o;
                        });
                    });
                    _log("optionSet", optionSet);
                    var __childRecordList = cloneObj(childRecordList);
                    __childRecordList.forEach(function(matrixRecord) {
                        matrixRecord.currency = currency;
                        Object.keys(matrixRecord).forEach(function(key) {
                            if (typeof matrixRecord[key] == "object" && matrixRecord[key].hasOwnProperty("translation")) {
                                matrixRecord[key].translation = optionSet[key][matrixRecord[key].value].translation;
                            } else if (key == "baseprice") {
                                if (ITEM_RECORD.type == "kititem") {
                                    matrixRecord[key] = Math2.parseValue(matrixRecord.baseprice);
                                } else {
                                    matrixRecord[key] = itemSiteRecord.sitePrice;
                                }
                            }
                        });
                    });
                    itemSiteRecord.variation = {
                        availOptions: availOptions.availOptions,
                        childRecordList: __childRecordList
                    };
                }
                if (ITEM_RECORD.type == "inventoryitem") {
                    if (ismatrix == "F") {
                        var location1 = itemSiteRecord.eBayItemSiteSettingRecord.location1;
                        var location2 = itemSiteRecord.eBayItemSiteSettingRecord.location2;
                        var locationId = null;
                        var itemLocationQuantity = __item.getLocationQuantity();
                        var qty = 0;
                        var location1_quantity = calculateLocationQuantity(__item, itemLocationQuantity, location1);
                        if (location1_quantity) {
                            qty = location1_quantity;
                            locationId = location1;
                        } else {
                            qty = calculateLocationQuantity(__item, itemLocationQuantity, location2);
                            locationId = location2;
                        }
                        itemSiteRecord.quantity = qty;
                        itemSiteRecord.locationCity = locationId;
                    } else {
                        itemSiteRecord.locationCity = __item.locationId;
                    }
                }
                SITELIST.push(itemSiteRecord);
                _log("------------------------------- a site item record has been push to list =====================================");
            } catch (e) {
                SITE_ERRORS.push(processException(e).getUserMessage());
            }
        }
        if (SITE_ERRORS.length) throw createEbayError("SITE_ERRORS: " + "\n" + SITE_ERRORS.join("\n"));
    } else {
        throw createEbayError("Not found Ebay Item Site Setting record.");
    }
    ITEM_RECORD.SITELIST = SITELIST;
    _log("ITEM_RECORD", ITEM_RECORD);
    return ITEM_RECORD;
}

function calculateLocationQuantity(__item, itemLocationQuantity, locationId) {
    var location_available = _.find(itemLocationQuantity, function(_itemLocationQuantity) {
        return _itemLocationQuantity.location.v == locationId;
    });
    var location_quantityavailable = location_available.quantityavailable.v;
    if (!location_quantityavailable) location_quantityavailable = 0;
    var avail_quantity = __item.val(LOCATION_QUANTITY_CONFIG[locationId]) || 0;
    return parseInt(location_quantityavailable) + parseInt(avail_quantity);
}

function templateMerge(tpl, obj) {
    for (var o in obj) {
        if (obj.hasOwnProperty(o)) {
            var k = "#" + o + "#";
            var content = obj[o];
            if (content) {
                content = content.replace(/\r\n/g, "<br/>");
            } else {
                content = "";
            }
            tpl = tpl.replace(new RegExp(k, "g"), content);
        }
    }
    return tpl;
}

function buildItemDescription(itemRecord, classId) {
    itemRecord.eBayItemDescription = itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_sale_description;
    if (itemRecord.eBayItemDescription) {
        if (!itemRecord.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_site) throw createEbayError("No site setting on Global Ebay Site record.");
        var eBayItemTemplate = nlapiSearchRecord("customrecord_ebay_site_template", null, [ new nlobjSearchFilter("custrecordebay_st_class", null, "anyof", classId), new nlobjSearchFilter("custrecord_ebay_st_site", null, "anyof", itemRecord.eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord.custrecord_ebay_gs_site) ], [ new nlobjSearchColumn("custrecord_ebay_st_template") ]);
        if (eBayItemTemplate == null) {
            throw createEbayError("No Ebay description template for the class ID: " + classId);
        } else {
            itemRecord.eBayItemDescription = templateMerge(eBayItemTemplate[0].getValue("custrecord_ebay_st_template"), {
                sales_description: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_sale_description,
                item_features: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecordcustrecord_eil_item_features,
                custrecord_eil_feature_description: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_feature_description,
                custrecordcustrecord_eil_package_include: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecordcustrecord_eil_package_include,
                custrecord_eil_package_excludes: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_package_excludes,
                custrecord_eil_additional_information: itemRecord.eBayItemSiteSettingRecord.eBayItemLanguageSetRecord.custrecord_eil_additional_information
            });
        }
    } else {
        throw createEbayError("No description for this item.");
    }
}

function setPicture(searchResult, picture_columns) {
    var picture = {};
    picture_columns.forEach(function(colmun) {
        picture[colmun.getName()] = searchResult.getText(colmun);
    });
    return picture;
}

function loadEbayItemSiteSettingRecord(id, ebayAccountId) {
    if (ebayAccountId) {
        if (!Array.isArray(ebayAccountId)) ebayAccountId = [ ebayAccountId ];
    }
    var siteRecord = nlapiLoadRecord("customrecord_ebay_item_site_setting", id);
    var eBayItemSiteSettingRecord = {
        eBayItemSiteSettingRecordId: siteRecord.getId(),
        custrecord_ei_item_link: siteRecord.getFieldValue("custrecord_ei_item_link"),
        custrecord_ei_language_set: siteRecord.getFieldValue("custrecord_ei_language_set"),
        custrecord_ei_use_sequence1: siteRecord.getFieldValue("custrecord_ei_use_sequence1"),
        custrecord_ei_use_sequence2: siteRecord.getFieldValue("custrecord_ei_use_sequence2"),
        custrecord_ei_site_category_id: siteRecord.getFieldValue("custrecord_ei_site_category_id"),
        custrecord_ei_qty: siteRecord.getFieldValue("custrecord_ei_qty"),
        custrecord_ei_ebay_accounts: siteRecord.getFieldValue("custrecord_ei_ebay_accounts"),
        custrecord_ei_site: siteRecord.getFieldValue("custrecord_ei_site"),
        custrecord_ei_site_price: siteRecord.getFieldValue("custrecord_ei_site_price"),
        location1: siteRecord.getFieldValue("custrecord_ei_location1"),
        location2: siteRecord.getFieldValue("custrecord_ei_location2"),
        custrecord_ei_shipping_lead_time: siteRecord.getFieldValue("custrecord_ei_shipping_lead_time"),
        custrecord_ei_ebay_free_shipping: siteRecord.getFieldValue("custrecord_ei_ebay_free_shipping"),
        custrecord_ei_listing_duration: siteRecord.getFieldValue("custrecord_ei_listing_duration")
    };
    var specificList = [];
    for (var i = 0; i < 15; i++) {
        var line = i + 1;
        if (siteRecord.getFieldValue("custrecord_ei_specific" + line) && siteRecord.getFieldValue("custrecord_ei_specific_value" + line)) {
            specificList.push({
                specificName: siteRecord.getFieldValue("custrecord_ei_specific" + line),
                specificValue: siteRecord.getFieldValue("custrecord_ei_specific_value" + line)
            });
        }
    }
    eBayItemSiteSettingRecord.specificList = specificList;
    eBayItemSiteSettingRecord.eBayGlobalSiteSettingRecord = loadEbayGlobalSiteSettingRecord(eBayItemSiteSettingRecord.custrecord_ei_site);
    eBayItemSiteSettingRecord.eBayItemLanguageSetRecord = loadEbayItemLanguageSetRecord(eBayItemSiteSettingRecord.custrecord_ei_language_set);
    var eBayAccounts = eBayItemSiteSettingRecord.custrecord_ei_ebay_accounts;
    eBayAccounts = eBayAccounts.split("");
    if (ebayAccountId) {
        eBayItemSiteSettingRecord.eBayGlobalAccountMapping = ebayAccountId.map(function(accountId) {
            return loadEbayGlobalAccountSettingRecord(accountId);
        });
    } else {
        eBayItemSiteSettingRecord.eBayGlobalAccountMapping = eBayAccounts.map(function(accountId) {
            return loadEbayGlobalAccountSettingRecord(accountId);
        });
    }
    return eBayItemSiteSettingRecord;
}

function loadEbayItemLanguageSetRecord(id) {
    var languageRecord = nlapiLoadRecord("customrecord_ebay_item_language", id);
    return {
        eBayItemLanguageSetRecordId: languageRecord.getId(),
        custrecord_eil_title_permutations: languageRecord.getFieldValue("custrecord_eil_title_permutations"),
        custrecord_eil_variations: languageRecord.getFieldValue("custrecord_eil_variations"),
        name: languageRecord.getFieldValue("name"),
        custrecord_eil_item_link: languageRecord.getFieldValue("custrecord_eil_item_link"),
        custrecord_eil_language: languageRecord.getFieldValue("custrecord_eil_language"),
        custrecord_eil_sale_description: languageRecord.getFieldValue("custrecord_eil_sale_description"),
        custrecordcustrecord_eil_item_features: languageRecord.getFieldValue("custrecordcustrecord_eil_item_features"),
        custrecord_eil_feature_description: languageRecord.getFieldValue("custrecord_eil_feature_description"),
        custrecordcustrecord_eil_package_include: languageRecord.getFieldValue("custrecordcustrecord_eil_package_include"),
        custrecord_eil_package_excludes: languageRecord.getFieldValue("custrecord_eil_package_excludes"),
        custrecord_eil_additional_information: languageRecord.getFieldValue("custrecord_eil_additional_information")
    };
}

var __CACHE = {
    EbayGlobalAccountSettingRecord: {},
    EbayGlobalSiteSettingRecord: {},
    LOCATION: {}
};

function loadEbayGlobalAccountSettingRecord(eBayAccountId) {
    if (__CACHE.EbayGlobalAccountSettingRecord.hasOwnProperty(eBayAccountId)) {
        return __CACHE.EbayGlobalAccountSettingRecord[eBayAccountId];
    } else {
        _log("ONLY ONE loadEbayGlobalAccountSettingRecord", eBayAccountId);
        var eBayAccountRecord = nlapiLoadRecord("customrecord_ebay_account", eBayAccountId);
        var record = {
            eBayGlobalAccountSettingRecordId: eBayAccountRecord.getId(),
            sellerId: eBayAccountRecord.getFieldValue("name"),
            api_token: eBayAccountRecord.getFieldValue("custrecord_ebay_api_token"),
            custrecord_ebay_price_variant1: eBayAccountRecord.getFieldValue("custrecord_ebay_price_variant1"),
            custrecord_ebay_price_variant2: eBayAccountRecord.getFieldValue("custrecord_ebay_price_variant2"),
            custrecord_paypal_account_linked: eBayAccountRecord.getFieldText("custrecord_paypal_account_linked"),
            custrecord_micro_paypal_account_linked: eBayAccountRecord.getFieldText("custrecord_micro_paypal_account_linked"),
            custrecord_title_pic_seq1: {
                value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq1"),
                text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq1")
            },
            custrecord_title_pic_seq2: {
                value: eBayAccountRecord.getFieldValue("custrecord_title_pic_seq2"),
                text: eBayAccountRecord.getFieldText("custrecord_title_pic_seq2")
            }
        };
        __CACHE.EbayGlobalAccountSettingRecord[eBayAccountId] = record;
        return record;
    }
}

function loadEbayGlobalSiteSettingRecord(ebayGlobalSiteSettingRecordId) {
    if (__CACHE.EbayGlobalSiteSettingRecord.hasOwnProperty(ebayGlobalSiteSettingRecordId)) {
        return __CACHE.EbayGlobalSiteSettingRecord[ebayGlobalSiteSettingRecordId];
    } else {
        _log("loadEbayGlobalSiteSettingRecord ONLYONE", ebayGlobalSiteSettingRecordId);
        var customrecord_ebay_global_record = nlapiLoadRecord("customrecord_ebay_global", ebayGlobalSiteSettingRecordId);
        var record = {
            custrecord_ebay_language_code: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_language_code"),
            custrecord_ebay_territory_id: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_territory_id"),
            custrecord_default_currency: customrecord_ebay_global_record.getFieldText("custrecord_default_currency"),
            custrecord_global_site_price_change: customrecord_ebay_global_record.getFieldValue("custrecord_global_site_price_change"),
            custrecord_ebay_gs_site: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_site"),
            custrecord_ebay_gs_api_errorlanguage: customrecord_ebay_global_record.getFieldText("custrecord_ebay_gs_api_errorlanguage"),
            custrecord_ebay_gs_exchange_rate: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_exchange_rate"),
            custrecord_ebay_site_id: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_site_id"),
            custrecord_ebay_gs_api_site: customrecord_ebay_global_record.getFieldValue("custrecord_ebay_gs_api_site")
        };
        __CACHE.EbayGlobalSiteSettingRecord[ebayGlobalSiteSettingRecordId] = record;
        return record;
    }
}

function run(request, response) {
    try {
        var action = request.getParameter("action");
        var item__internalid = request.getParameter("item__internalid");
        if (request.getMethod() == "GET") {
            if (!item__internalid) {
                response.write("No Item ID!");
                return;
            }
            if (action == "submit") {
                response.writeLine(JSON.stringify(createFeeds(item__internalid)));
            } else if (action == "print_label") {
                renderInlineLabelPDF(request, response);
            }
        } else {}
    } catch (e) {
        processException(e);
    } finally {}
}

function renderInlineLabelPDF(request, response) {
    var item__internalid = request.getParameter("item__internalid");
    var item = nlapiLoadRecord("inventoryitem", item__internalid);
    var renderer = nlapiCreateTemplateRenderer();
    renderer.setTemplate(nlapiLoadFile("SuiteScripts/PDF/ItemLabel.html").getValue());
    renderer.addRecord("record", item);
    var xml = renderer.renderToString();
    var file = nlapiXMLToPDF(xml);
    response.setContentType("PDF", item.getFieldValue("itemid") + ".pdf", "inline");
    response.write(file);
}

function createFeeds(item__internalid) {
    var p = new Profiling();
    var feedList = [];
    try {
        feedList = getEbayItemFeedList(item__internalid);
    } catch (e) {
        e = processException(e);
        return {
            name: "SUBMIT_FEED_ERROR",
            message: e.getUserMessage()
        };
    }
    _log("---- FEEDLIST SIZE ------", feedList.length);
    if (!feedList.length) return {
        name: "SUBMIT_FEED_ERROR",
        message: "No feed found."
    };
    var newFeedList = [], updateFeedList = [], errorFeedList = [];
    for (var i = 0, len = feedList.length; i < len; i++) {
        var feed = feedList[i];
        try {
            var searchFilter = [ new nlobjSearchFilter("internalid", "custrecord_ebay_feed_item", "anyof", [ feed.itemRecordId ]), new nlobjSearchFilter("custrecord_ebay_feed_language_id", null, "anyof", [ feed.languageId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_global_site", "anyof", [ feed.eBayGlobalSiteRecordId ]), new nlobjSearchFilter("internalid", "custrecord_ebay_feed_account", "anyof", [ feed.eBayGlobalAccountSettingRecordId ]), new nlobjSearchFilter("custrecord_ebay_feed_seq", null, "anyof", [ feed.itemTitlePictureSequenceId ]) ];
            var feedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, searchFilter);
            if (feedSearch != null) {
                if (feedSearch.length && feedSearch.length == 1) {
                    var feedId = feedSearch[0].getId();
                    updateFeedList.push(EbayFeed.update(feedId, feed));
                } else {
                    _log_email("??? warning record on feed and LENGTH: " + feedSearch.length, "check it");
                }
            } else {
                var newFeedId = EbayFeed.create(feed);
                newFeedList.push(newFeedId);
            }
        } catch (e) {
            e = processException(e, feed);
            errorFeedList.push(e.getUserMessage());
        }
    }
    return {
        name: "SUBMIT_FEED",
        newFeedList: newFeedList,
        updateFeedList: updateFeedList,
        errorFeedList: errorFeedList,
        spendTime: p.end()
    };
}