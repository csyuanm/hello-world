var CLOG_FLAG = true;

function client_log(title, detail) {
    var logSwitch = true, format = false;
    if (logSwitch) {
        if (detail && typeof detail == "object") {
            if (format) {
                detail = JSON.stringify(detail, undefined, 4);
            } else {
                detail = JSON.stringify(detail);
            }
        }
        if (typeof console == "undefined") {
            nlapiLogExecution("debug", title, detail);
        } else {
            if (typeof title == "object") title = JSON.stringify(title);
            var message = title;
            if (detail) {
                message = title + ": " + detail;
            }
            if (CLOG_FLAG) console.log(message);
        }
    }
}

function $nlapiGetFieldValue(name) {
    return jQuery("#" + name + "_fs_lbl_uir_label");
}

function post_to_url(path, params, method) {
    method = method || "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    form.setAttribute("target", "_blank");
    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }
    }
    document.body.appendChild(form);
    form.submit();
}

function clientException(e) {
    if (typeof NProgress != "undefined") {
        NProgress.done(true);
    }
    alert(e.toString());
}

function parseToJSON(data) {
    try {
        if (typeof data == "string") {
            data = data.replace(/\r\n|\n/g, "").trim();
            console.log("[" + data.substring(data.length - 7) + "]");
            if (data.substring(data.length - 7) == "SQL -->") {
                console.log("77777777777777777");
                data = data.replace(/(<!--(?:(?!-->).)*-->)/g, "").replace(/\r\n|\n/g, "").trim();
            }
            data = JSON.parse(data);
        }
    } catch (e) {
        if (typeof this.alert == "function") alert(data + " parseDataToJSON on Error!");
        return false;
    }
    return data;
}

function openNewTab(url) {
    window.open(url, "_blank");
    window.focus();
}

function loadCSS(filename) {
    var fileref = document.createElement("link");
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function loadJavaScript(filename) {
    var fileref = document.createElement("script");
    fileref.setAttribute("type", "text/javascript");
    fileref.setAttribute("src", filename);
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

var PageOverlay = {
    __overlay: jQuery("<div class='zake-overlay'><img src='/core/media/media.nl?id=16957&c=277620&h=ea47479825c0844fc16b' /></div>"),
    showOverlay: function() {
        jQuery(document.body).append(PageOverlay.__overlay);
        PageOverlay.__overlay.css({
            "background-color": "#EEE",
            "-moz-opacity": "0.6",
            opacity: "0.6",
            filter: "alpha(opacity=60)",
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "z-index": "1000"
        });
        PageOverlay.__overlay.show();
    },
    removeOverlay: function() {
        PageOverlay.__overlay.remove();
    }
};

function NProgressInit() {
    loadCSS("/core/media/media.nl?id=16958&c=277620&h=84dec4ebe21112edc273&mv=i9ntaoio&_xt=.css&whence=");
    loadJavaScript("/core/media/media.nl?id=67957&c=277620&h=3b5646eb584f926e20bc&mv=ic1mclbs&_xt=.js&whence=");
}

function initNProgress() {
    loadCSS("/core/media/media.nl?id=16958&c=277620&h=84dec4ebe21112edc273&mv=i9ntaoio&_xt=.css&whence=");
    loadJavaScript("/core/media/media.nl?id=67957&c=277620&h=3b5646eb584f926e20bc&mv=ic1mclbs&_xt=.js&whence=");
}

initNProgress();