function Record(type, id) {
    this.type = type;
    this.id = id;
    this.rec = nlapiLoadRecord(type, id);
    _log("nlapiLoadRecord", type + ": " + id);
}

extend(Record.prototype, {
    getId: function() {
        return this.rec.getId();
    },
    getFieldValue: function(name) {
        return this.rec.getFieldValue(name);
    },
    val: function(name) {
        return this.rec.getFieldValue(name);
    },
    getFieldText: function(name) {
        return this.rec.getFieldText(name);
    },
    text: function(name) {
        return this.rec.getFieldText(name);
    },
    setFieldValue: function(name, value) {
        this.rec.setFieldValue(name, value);
    },
    setFieldText: function(name, text) {
        this.rec.setFieldText(name, text);
    },
    submitRecord: function(refresh) {
        nlapiSubmitRecord(this.rec, true);
        if (refresh == true) this.refresh();
    },
    refresh: function() {
        this.rec = nlapiLoadRecord(this.type, this.id);
    }
});

Record.prototype.getSubList = function(group, fields) {
    var rec = this.rec;
    var list = [];
    var itemCount = rec.getLineItemCount(group);
    for (var b = 1; b <= itemCount; b++) {
        var lineitem = {};
        fields.forEach(function(field) {
            lineitem[field] = {
                v: rec.getLineItemValue(group, field, b),
                t: rec.getLineItemText(group, field, b)
            };
        });
        list.push(lineitem);
    }
    return list;
};

var EbayFeed = {
    PENDING_MODIFICATION: "custrecord_ebay_feed_pending_mdf",
    TYPE: "customrecord_ebay_item_api_feed"
};

function _getQuantityByEbayAccount(ebayAccountId, qty) {
    var account_max_push_quantity = nlapiLookupField("customrecord_ebay_account", ebayAccountId, "custrecord_acc_max_push_quantity");
    if (account_max_push_quantity) {
        account_max_push_quantity = parseInt(account_max_push_quantity);
    } else {
        account_max_push_quantity = 5;
    }
    _audit("account_max_push_quantity", account_max_push_quantity);
    if (qty > account_max_push_quantity) {
        return account_max_push_quantity;
    } else {
        return qty;
    }
}

function _getSubfeedList(feed) {
    var filter = [ new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", feed.getId()) ];
    var columns = [ new nlobjSearchColumn("isinactive"), new nlobjSearchColumn("custrecord_ef_ean"), new nlobjSearchColumn("custrecord_ef_isbn"), new nlobjSearchColumn("custrecord_ef_upc"), new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_variations"), new nlobjSearchColumn("custrecord_ebay_feed_variations_old"), new nlobjSearchColumn("custrecord_ebay_feed_api_price"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_picture2"), new nlobjSearchColumn("custrecord_ebay_feed_pending_mdf"), new nlobjSearchColumn("custrecord_ebay_feed_combo"), new nlobjSearchColumn("custitem_internal_marketing_position", "custrecord_ebay_feed_item") ];
    if (!feed.isKitFeed()) {
        filter.push(new nlobjSearchFilter("inventorylocation", "custrecord_ebay_feed_item", "is", feed.val("custrecord_ebay_feed_location")));
        columns.push(new nlobjSearchColumn("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM"));
    }
    var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, filter, columns);
    var subFeedList = subFeedSearch.map(function(searchResult) {
        var locationquantityavailable = 0;
        var comboFeed = searchResult.getValue("custrecord_ebay_feed_combo");
        var push_qty = parseInt(searchResult.getValue("custrecord_ebay_feed_push_qty") || 0);
        var max_push_qty = parseInt(searchResult.getValue("custrecord_ef_max_push_qty") || 0);
        if (comboFeed == "F") {
            var qty = parseInt(searchResult.getValue("locationquantityavailable", "CUSTRECORD_EBAY_FEED_ITEM") || 0);
            _audit("qty", qty);
            _audit("push_qty", push_qty);
            _audit("max_push_qty", max_push_qty);
            var marketPosition = searchResult.getValue("custitem_internal_marketing_position", "custrecord_ebay_feed_item");
            if (marketPosition == 1) {
                if (push_qty != "") {
                    push_qty = parseInt(push_qty);
                    locationquantityavailable = push_qty;
                } else if (max_push_qty) {
                    max_push_qty = parseInt(max_push_qty);
                    if (qty > max_push_qty) {
                        locationquantityavailable = max_push_qty;
                    } else {
                        locationquantityavailable = qty;
                    }
                } else {
                    locationquantityavailable = _getQuantityByEbayAccount(feed.val("custrecord_ebay_feed_account"), qty);
                }
            } else if (marketPosition == 2 || marketPosition == 3 || marketPosition == 5 || !marketPosition) {
                if (max_push_qty) {
                    max_push_qty = parseInt(max_push_qty);
                    if (qty > max_push_qty) {
                        locationquantityavailable = max_push_qty;
                    } else {
                        locationquantityavailable = qty;
                    }
                } else {
                    locationquantityavailable = qty;
                }
            } else if (marketPosition == 4) {
                locationquantityavailable = 0;
            } else {
                locationquantityavailable = qty;
            }
        } else {
            locationquantityavailable = parseInt(push_qty);
        }
        _audit("locationquantityavailable", locationquantityavailable);
        return {
            isinactive: searchResult.getValue("isinactive"),
            pending_mdf: searchResult.getValue("custrecord_ebay_feed_pending_mdf"),
            custrecord_ef_ean: searchResult.getValue("custrecord_ef_ean") || "Does not apply",
            custrecord_ef_isbn: searchResult.getValue("custrecord_ef_isbn") || "Does not apply",
            custrecord_ef_upc: searchResult.getValue("custrecord_ef_upc") || "Does not apply",
            variation: JSON.parse(searchResult.getValue("custrecord_ebay_feed_variations")),
            variation_old: searchResult.getValue("custrecord_ebay_feed_variations_old"),
            locationquantityavailable: locationquantityavailable,
            price: searchResult.getValue("custrecord_ebay_feed_api_price"),
            custrecord_ebay_feed_sku: searchResult.getValue("custrecord_ebay_feed_sku"),
            variation_picture: searchResult.getValue("custrecord_ef_picture2")
        };
    });
    _log("subFeedList", subFeedList);
    return subFeedList;
}

function buildEbayVariationXML(parentVariationJSONObject, feed, _fromRevise) {
    var subFeedList = _getSubfeedList(feed);
    var xml = "";
    xml += "<Variations>";
    xml += "    <VariationSpecificsSet>";
    parentVariationJSONObject.availOptions.forEach(function(item) {
        xml += "        <NameValueList>";
        xml += "            <Name>" + nlapiEscapeXML(item.translation) + "</Name>";
        xml += item.options.map(function(option) {
            return "        <Value>" + nlapiEscapeXML(option.translation) + "</Value>";
        }).join("");
        xml += "        </NameValueList>";
    });
    xml += "    </VariationSpecificsSet>";
    subFeedList.forEach(function(subFeed) {
        if (_fromRevise == true) {
            if (subFeed.isinactive == "T") {
                xml += _buildVariationXML(feed, subFeed, subFeed.variation, true);
            } else {
                if (subFeed.variation_old) {
                    subFeed.variation_old = JSON.parse(subFeed.variation_old);
                    xml += _buildVariationXML(feed, subFeed, subFeed.variation_old, true);
                    xml += _buildVariationXML(feed, subFeed, subFeed.variation);
                } else {
                    xml += _buildVariationXML(feed, subFeed, subFeed.variation);
                }
            }
        } else {
            xml += _buildVariationXML(feed, subFeed, subFeed.variation);
        }
    });
    if (_fromRevise == true) {
        xml += _deleteVariations(feed);
    }
    var pictureSubFeedList = subFeedList.filter(function(item) {
        return item.variation_picture;
    });
    _log("pictureSubFeedList", pictureSubFeedList);
    if (pictureSubFeedList.length) {
        var variationSpecificName = "";
        var var_name = parentVariationJSONObject.availOptions.filter(function(option) {
            return option.translation.toUpperCase().indexOf("COLOR") != -1;
        });
        if (var_name.length) {
            variationSpecificName = var_name[0].translation;
        } else {
            variationSpecificName = parentVariationJSONObject.availOptions[0].translation;
        }
        var pictureGroup = {};
        pictureSubFeedList.forEach(function(subFeed) {
            var variationSpecificValue = subFeed.variation.options.filter(function(op) {
                return op.label.translation == variationSpecificName;
            })[0].option.translation;
            var url = "";
            if (subFeed.variation_picture.indexOf("http") == -1) {
                url = "https://" + NS_DOMAIN + nlapiEscapeXML(subFeed.variation_picture);
            } else {
                url += nlapiEscapeXML(subFeed.variation_picture);
            }
            if (pictureGroup.hasOwnProperty(variationSpecificValue)) {
                if (pictureGroup[variationSpecificValue].indexOf(url) == -1) {
                    pictureGroup[variationSpecificValue].push(url);
                }
            } else {
                pictureGroup[variationSpecificValue] = [ url ];
            }
        });
        xml += "    <Pictures>";
        xml += "        <VariationSpecificName>" + variationSpecificName + "</VariationSpecificName>";
        for (var var_value in pictureGroup) {
            xml += "        <VariationSpecificPictureSet>";
            xml += "            <VariationSpecificValue>" + nlapiEscapeXML(var_value) + "</VariationSpecificValue>";
            xml += pictureGroup[var_value].map(function(url) {
                return "<PictureURL>" + url + "</PictureURL>";
            }).join("");
            xml += "        </VariationSpecificPictureSet>";
        }
        xml += "    </Pictures>";
    }
    xml += "</Variations>";
    return xml;
}

function _deleteVariations(feed) {
    var subFeedSearch = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_matrix_item", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_matrix_child_item", null, "is", "T"), new nlobjSearchFilter("custrecord_ebay_feed_combo", null, "is", "F"), new nlobjSearchFilter("custrecord_ebay_feed_parent", null, "is", feed.getId()), new nlobjSearchFilter("custrecord_ebay_feed_item", null, "is", "@NONE@") ], [ new nlobjSearchColumn("isinactive"), new nlobjSearchColumn("custrecord_ef_ean"), new nlobjSearchColumn("custrecord_ef_isbn"), new nlobjSearchColumn("custrecord_ef_upc"), new nlobjSearchColumn("custrecord_ebay_feed_item"), new nlobjSearchColumn("custrecord_ebay_feed_sku"), new nlobjSearchColumn("custrecord_ebay_feed_variations"), new nlobjSearchColumn("custrecord_ebay_feed_variations_old"), new nlobjSearchColumn("custrecord_ebay_feed_api_price"), new nlobjSearchColumn("custrecord_ef_ebay_available_qty"), new nlobjSearchColumn("custrecord_ebay_feed_push_qty"), new nlobjSearchColumn("custrecord_ef_max_push_qty"), new nlobjSearchColumn("custrecord_ef_picture2"), new nlobjSearchColumn("custrecord_ebay_feed_pending_mdf") ]);
    if (subFeedSearch != null) {
        var subFeedList = subFeedSearch.map(function(searchResult) {
            return {
                custrecord_ef_ean: searchResult.getValue("custrecord_ef_ean") || "Does not apply",
                custrecord_ef_isbn: searchResult.getValue("custrecord_ef_isbn") || "Does not apply",
                custrecord_ef_upc: searchResult.getValue("custrecord_ef_upc") || "Does not apply",
                variation: JSON.parse(searchResult.getValue("custrecord_ebay_feed_variations")),
                variation_old: searchResult.getValue("custrecord_ebay_feed_variations_old"),
                price: searchResult.getValue("custrecord_ebay_feed_api_price"),
                custrecord_ebay_feed_sku: searchResult.getValue("custrecord_ebay_feed_sku"),
                locationquantityavailable: parseInt(searchResult.getValue("custrecord_ef_ebay_available_qty"))
            };
        });
        var xml = "";
        subFeedList.forEach(function(subFeed) {
            xml += _buildVariationXML(feed, subFeed, subFeed.variation, true);
        });
        return xml;
    } else {
        return "";
    }
}

function _buildVariationXML(feed, subFeed, variation, isDelete) {
    var xml = "";
    xml += "    <Variation>";
    if (isDelete === true) {
        xml += "    <Delete>true</Delete>";
    }
    xml += "        <StartPrice>" + (subFeed.price || feed.val("custrecord_ebay_feed_api_price")) + "</StartPrice>";
    xml += "        <SKU>" + subFeed.custrecord_ebay_feed_sku + "</SKU>";
    xml += "        <Quantity>" + subFeed.locationquantityavailable + "</Quantity>";
    xml += [ "<VariationProductListingDetails>", "    <EAN>" + subFeed.custrecord_ef_ean + "</EAN>", "    <ISBN>" + subFeed.custrecord_ef_isbn + "</ISBN>", "    <UPC>" + subFeed.custrecord_ef_upc + "</UPC>", "    </VariationProductListingDetails>" ].join("");
    xml += "        <VariationSpecifics>";
    variation.options.forEach(function(item) {
        xml += "            <NameValueList>";
        xml += "                <Name>" + nlapiEscapeXML(item.label.translation) + "</Name>";
        xml += "                <Value>" + nlapiEscapeXML(item.option.translation) + "</Value>";
        xml += "            </NameValueList>";
    });
    xml += "        </VariationSpecifics>";
    xml += "    </Variation>";
    return xml;
}

function __buildFeedReviseXML(feed, fields) {
    var custrecord_ef_subsidiary = feed.val("custrecord_ef_subsidiary");
    var modification_xml = "";
    var modification_fields = [];
    var mdfList = [];
    if (Array.isArray(fields) && fields.length) {
        mdfList = fields;
    } else {
        var pendingModification = feed.getFieldValue(EbayFeed.PENDING_MODIFICATION);
        if (pendingModification) {
            pendingModification = JSON.parse(pendingModification);
            if (Array.isArray(pendingModification) && pendingModification.length > 0) {
                mdfList = pendingModification;
            }
        }
    }
    _log("mdfList", mdfList);
    if (mdfList.length) {
        var Description_Count = 0;
        var Quantity_Count = 0;
        var Var_Count = 0;
        var Location_Count = 0;
        mdfList.forEach(function(field) {
            switch (field) {
              case "ppEmail":
                modification_xml += feed.buildPaypalEmailXML();
                break;

              case "custrecord_ebay_feed_api_title":
                modification_xml += "    <Title><![CDATA[" + feed.val("custrecord_ebay_feed_api_title") + "]]></Title>";
                break;

              case "custrecord_ebay_feed_api_price":
                if (feed.isSingleItem()) {
                    modification_xml += "    <StartPrice>" + parseFloat(feed.val("custrecord_ebay_feed_api_price")) + "</StartPrice>";
                }
                break;

              case "custrecord_ebay_feed_description":
              case "custrecord_ef_template":
              case "custrecord_ebay_feed_body_picture":
                if (feed.val("custrecord_ebay_feed_is_legacy") == "T") {
                    break;
                }
                if (!Description_Count) {
                    var custrecord_ebay_feed_body_picture = feed.val("custrecord_ebay_feed_body_picture");
                    if (custrecord_ebay_feed_body_picture) {
                        custrecord_ebay_feed_body_picture = JSON.parse(custrecord_ebay_feed_body_picture);
                    } else {
                        custrecord_ebay_feed_body_picture = [];
                    }
                    if (!feed.val("custrecord_ef_template")) {
                        throw createEbayError("Not found the eBay feed template! Please select the template first! " + feed.getId());
                    }
                    var _desc = feed.val("custrecord_ebay_feed_description");
                    if (_desc) {
                        _desc = _desc.replace(/\r|\n|\r\n/g, "");
                    } else {
                        _desc = "";
                    }
                    var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", feed.val("custrecord_ef_template"), "custrecord_eat_tpl"), {
                        title: feed.val("custrecord_ebay_feed_api_title"),
                        description: _desc,
                        body_pictures: custrecord_ebay_feed_body_picture.map(function(url) {
                            if (url.indexOf("http") != -1) {
                                return '<img src="' + url + '" />';
                            } else {
                                return '<img src="https://' + NS_DOMAIN + url + '" />';
                            }
                        }).join("<br/>")
                    });
                    modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                }
                Description_Count++;
                break;

              case "custrecord_ebay_feed_condition":
                modification_xml += "    <ConditionID>" + feed.getSearchResult().getValue("custrecord_eic_condition_id", "custrecord_ebay_feed_condition") + "</ConditionID>";
                break;

              case "custrecord_ebay_feed_description_fix":
                var description_fix = feed.val("custrecord_ebay_feed_description");
                if (description_fix && typeof description_fix == "string") {
                    description_fix = description_fix.replace(/\r|\n|\r\n/g, "");
                } else {
                    description_fix = "";
                }
                var tpl = "5";
                var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", tpl, "custrecord_eat_tpl"), {
                    description_fix: description_fix
                });
                modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                break;

              case "custrecord_ef_legacy_description":
                var Description = feed.val("custrecord_ef_legacy_description").replace(/\r|\n|\r\n/g, "");
                modification_xml += "    <Description><![CDATA[" + Description + "]]></Description>";
                break;

              case "custrecord_ebay_feed_push_qty":
              case "custrecord_ef_max_push_qty":
              case "custrecord_ef_ebay_available_qty":
                if (!Quantity_Count) {
                    if (feed.isSingleItem()) {
                        var f_qty = 0;
                        if (feed.isKitFeed()) {
                            f_qty = feed.val("custrecord_ebay_feed_push_qty");
                        } else {
                            f_qty = feed.getQuantity();
                        }
                        if (parseInt(feed.val("custrecord_ef_ebay_available_qty")) != f_qty) {
                            modification_xml += "    <Quantity>" + f_qty + "</Quantity>";
                            modification_fields.push({
                                name: "custrecord_ef_ebay_available_qty",
                                value: f_qty
                            });
                        }
                    }
                }
                Quantity_Count++;
                break;

              case "custrecord_ebay_feed_variations":
              case "variations":
                if (!Var_Count) {
                    var variations = feed.val("custrecord_ebay_feed_variations");
                    if (variations) {
                        variations = JSON.parse(variations);
                        modification_xml += buildEbayVariationXML(variations, feed, true);
                    } else {
                        modification_xml += "";
                    }
                }
                Var_Count++;
                break;

              case "custrecord_ebay_feed_gallery":
                var gallery = feed.val("custrecord_ebay_feed_gallery");
                if (gallery) {
                    gallery = JSON.parse(gallery);
                    if (Array.isArray(gallery) && gallery.length) {
                        modification_xml += "    <PictureDetails>";
                        gallery.forEach(function(link) {
                            if (link.indexOf("/core/media/media.nl") == 0) {
                                link = "https://" + NS_DOMAIN + link;
                            }
                            modification_xml += "      <PictureURL>" + nlapiEscapeXML(link) + "</PictureURL>";
                        });
                        modification_xml += "    </PictureDetails>";
                    }
                }
                break;

              case "custrecord_ebay_feed_specifics":
                var specifics = feed.val("custrecord_ebay_feed_specifics");
                if (specifics) {
                    specifics = JSON.parse(specifics);
                    if (Array.isArray(specifics) && specifics.length) {
                        modification_xml += "    <ItemSpecifics>";
                        modification_xml += specifics.map(function(item) {
                            var nameValueList = "";
                            nameValueList += "<NameValueList>";
                            nameValueList += "    <Name>" + nlapiEscapeXML(item.specificName) + "</Name>";
                            nameValueList += "    <Value>" + nlapiEscapeXML(item.specificValue) + "</Value>";
                            nameValueList += "</NameValueList>";
                            return nameValueList;
                        }).join("");
                        modification_xml += "    </ItemSpecifics>";
                    }
                }
                break;

              case "custrecord_ef_location_country":
              case "custrecord_ef_location_name":
                if (!Location_Count) {
                    if (custrecord_ef_subsidiary == Subsidiaries.TaiwuInternational) {
                        var country = feed.val("custrecord_ef_location_country");
                        if (country) {
                            modification_xml += "    <Country>" + country + "</Country>";
                        } else {
                            modification_xml += "    <Country>CN</Country>";
                        }
                    } else {
                        modification_xml += "    <Country>US</Country>";
                    }
                    if (custrecord_ef_subsidiary == Subsidiaries.TaiwuInternational) {
                        var location_name = feed.val("custrecord_ef_location_name");
                        if (location_name) {
                            modification_xml += "    <Location>" + location_name + "</Location>";
                        }
                    }
                }
                Location_Count++;
                break;

              default:
                modification_xml += "";
            }
        });
    }
    _audit("modification_xml", modification_xml);
    return {
        modification_xml: modification_xml,
        modification_fields: modification_fields
    };
}

function __EbayFeed(id) {
    this.searchResult = null;
    Record.call(this, EbayFeed.TYPE, id);
}

inherit(Record, __EbayFeed);

__EbayFeed.prototype.getSearchResult = function() {
    if (this.searchResult == null) {
        var search = nlapiSearchRecord(EbayFeed.TYPE, null, [ new nlobjSearchFilter("internalid", null, "is", this.id) ], [ new nlobjSearchColumn("custrecord_ebay_api_token", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_ebay_gs_sitecode", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_default_currency", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_ebay_cs_country_code", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_ebay_site_id", "custrecord_ebay_feed_global_site"), new nlobjSearchColumn("custrecord_eic_condition_id", "custrecord_ebay_feed_condition"), new nlobjSearchColumn("city", "custrecord_ebay_feed_location"), new nlobjSearchColumn("custrecord_ef_location_name"), new nlobjSearchColumn("custrecord_paypal_account_linked", "custrecord_ebay_feed_account"), new nlobjSearchColumn("custrecord_micro_paypal_account_linked", "custrecord_ebay_feed_account") ]);
        this.searchResult = search[0];
    }
    return this.searchResult;
};

__EbayFeed.prototype.getEbaySiteID = function() {
    return this.searchResult.getValue("custrecord_ebay_site_id", "custrecord_ebay_feed_global_site");
};

function _parsecost(val) {
    if (val) {
        return parseFloat(val);
    }
    return 0;
}

__EbayFeed.prototype.getShippingOptionsXML = function() {
    var feed = this;
    var currencyID = feed.getSearchResult().getText("custrecord_default_currency", "custrecord_ebay_feed_global_site");
    _audit("shipping options record id", this.val("custrecord_ef_shipping_options"));
    var rec = nlapiLoadRecord("customrecord_ebay_shipping_options", this.val("custrecord_ef_shipping_options"));
    var shipping_options = rec.getFieldValue("custrecord_eso_shippingdetails");
    shipping_options = JSON.parse(shipping_options);
    var xml = [ "    <ShippingDetails>", shipping_options.ShippingDetails.ExcludeShipToLocation.map(function(shiptolocation) {
        return "   <ExcludeShipToLocation>" + shiptolocation.text + "</ExcludeShipToLocation>";
    }).join(""), "      <GlobalShipping>" + shipping_options.GlobalShipping.text + "</GlobalShipping>", "      <ShippingType>" + shipping_options.ShippingDetails.ShippingType.text + "</ShippingType>", shipping_options.ShippingDetails.ShippingServiceOptions.map(function(option) {
        var x = [ "      <ShippingServiceOptions>", "        <ShippingService>" + option.ShippingService.text + "</ShippingService>", '        <ShippingServiceCost currencyID="' + currencyID + '">' + _parsecost(option.ShippingServiceCost) + "</ShippingServiceCost>", '        <ShippingServiceAdditionalCost currencyID="' + currencyID + '">' + _parsecost(option.ShippingServiceAdditionalCost) + "</ShippingServiceAdditionalCost>", "        <ShippingServicePriority>" + option.ShippingServicePriority + "</ShippingServicePriority>" ];
        if (option.ShippingSurcharge) {
            var ShippingSurcharge = _parsecost(option.ShippingSurcharge);
            if (ShippingSurcharge) {
                x.push("        <ShippingSurcharge>" + ShippingSurcharge + "</ShippingSurcharge>");
            }
        }
        if (option.ShippingServicePriority == "1") {
            x.push("        <FreeShipping>" + option.FreeShipping.text + "</FreeShipping>");
        }
        x.push("      </ShippingServiceOptions>");
        return x.join("");
    }).join(""), shipping_options.ShippingDetails.InternationalShippingServiceOption.map(function(option) {
        var x = [ "      <InternationalShippingServiceOption>", "        <ShippingService>" + option.ShippingService.text + "</ShippingService>", '        <ShippingServiceCost currencyID="' + currencyID + '">' + _parsecost(option.ShippingServiceCost) + "</ShippingServiceCost>", '        <ShippingServiceAdditionalCost currencyID="' + currencyID + '">' + _parsecost(option.ShippingServiceAdditionalCost) + "</ShippingServiceAdditionalCost>", "        <ShippingServicePriority>" + option.ShippingServicePriority + "</ShippingServicePriority>" ];
        if (option.ShipToLocation.length) {
            x.push(option.ShipToLocation.map(function(location) {
                return "		 <ShipToLocation>" + location.text + "</ShipToLocation>";
            }).join(""));
        } else {
            x.push("		 <ShipToLocation>Worldwide</ShipToLocation>");
        }
        x.push("      </InternationalShippingServiceOption>");
        return x.join("");
    }).join(""), "    </ShippingDetails>", _writeShipToLocationsXML(feed, shipping_options) ].map(function(node) {
        return node.trim();
    }).join("");
    return xml;
};

function _writeShipToLocationsXML(feed, shipping_options) {
    if (feed.val("custrecord_ef_subsidiary") == Subsidiaries.TaiwuInternational) {
        return "";
    } else {
        return shipping_options.ShipToLocations.map(function(shiptolocation) {
            return "<ShipToLocations>" + shiptolocation.text + "</ShipToLocations>";
        }).join("");
    }
}

__EbayFeed.prototype.isSingleItem = function() {
    var that = this;
    return that.val("custrecord_ebay_feed_matrix_item") == "F" && that.val("custrecord_ebay_feed_matrix_child_item") == "F";
};

__EbayFeed.prototype.isKitFeed = function() {
    var that = this;
    return that.val("custrecord_ebay_feed_combo") == "T";
};

__EbayFeed.prototype.getMainPrice = function() {
    return this.val("custrecord_ebay_feed_api_price");
};

__EbayFeed.prototype.getPayPalEmailAddress3B = function(price) {
    var big = this.getSearchResult().getText("custrecord_paypal_account_linked", "custrecord_ebay_feed_account");
    var small = this.getSearchResult().getText("custrecord_micro_paypal_account_linked", "custrecord_ebay_feed_account");
    if (!price) {
        price = this.getMainPrice();
    }
    if (parseFloat(price) > 12) {
        return _trimppemail(big);
    } else {
        return _trimppemail(small);
    }
};

__EbayFeed.prototype.getPayPalEmailAddress = function(price) {
    if (this.val("custrecord_ef_subsidiary") == Subsidiaries.ZakeInternational) {
        return this.getPayPalEmailAddress3B(price);
    } else if (this.val("custrecord_ef_subsidiary") == Subsidiaries.TaiwuInternational) {
        var big = this.getSearchResult().getValue("custrecord_paypal_account_linked", "custrecord_ebay_feed_account");
        var small = this.getSearchResult().getValue("custrecord_micro_paypal_account_linked", "custrecord_ebay_feed_account");
        var bigEmail = "";
        if (big) {
            bigEmail = nlapiLookupField("account", big, "custrecord_taiwu_acctppacct", true);
        }
        var smallEmail = "";
        if (small) {
            smallEmail = nlapiLookupField("account", small, "custrecord_taiwu_acctppacct", true);
        }
        _log("PP Emails", bigEmail + " | " + smallEmail);
        if (!price) {
            price = this.getMainPrice();
        }
        if (bigEmail && smallEmail) {
            if (parseFloat(price) > 12) {
                return bigEmail;
            } else {
                return smallEmail;
            }
        } else {
            var ppEmail = bigEmail || smallEmail;
            if (ppEmail) {
                return ppEmail;
            } else {
                throw createEbayError("木有找到 PP收款Email哦！");
            }
        }
    } else {
        throw createEbayError("The feed record without subsidiary, please fix it!");
    }
};

function _trimppemail(email) {
    email = email.replace("- RMB", "");
    return email.trim();
}

__EbayFeed.prototype.getVariation = function() {
    var v = this.val("custrecord_ebay_feed_variations");
    if (v && typeof v == "string") {
        return JSON.parse(v);
    }
    return v;
};

__EbayFeed.prototype.getToken = function() {
    return this.getSearchResult().getValue("custrecord_ebay_api_token", "custrecord_ebay_feed_account");
};

__EbayFeed.prototype.getEbayItemId = function() {
    return this.val("custrecord_ebay_feed_item_id") || null;
};

__EbayFeed.prototype.getStatus = function() {
    return this.val("custrecord_ebay_feed_status");
};

__EbayFeed.prototype.updateStatus = function(status, scheduledStatus, submitTag) {
    if (status) {
        this.setFieldValue("custrecord_ebay_feed_status", status);
    }
    if (scheduledStatus) {
        this.setFieldValue("custrecord_ef_scheduled_status", scheduledStatus);
    } else {
        this.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
    }
    if (submitTag === false) {
        return this.getId();
    } else {
        return this.submitRecord();
    }
};

__EbayFeed.prototype.callRelistItem = function() {
    var ebayfeed = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<RelistItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += "  <RequesterCredentials>";
    xml += "        <eBayAuthToken>" + ebayfeed.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <Item>";
    xml += "    <ItemID>" + ebayfeed.getEbayItemId() + "</ItemID>";
    xml += __buildFeedReviseXML(ebayfeed).modification_xml;
    xml += "  </Item>";
    xml += "</RelistItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": ebayfeed.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "RelistItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            ebayfeed.setFieldValue("custrecord_ebay_feed_item_id", response.ItemID);
            ebayfeed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
            ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
        } else {
            if (ebayfeed.val("custrecord_ef_scheduled_status") == EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST) {
                ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST_ERROR);
            }
        }
    });
};

__EbayFeed.prototype.callReviseItem = function(fields) {
    var ebayfeed = this;
    var modified = __buildFeedReviseXML(ebayfeed, fields);
    _audit("callReviseItem modified", modified);
    if (modified.modification_xml) {
        var xml = "";
        xml += '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<ReviseFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
        xml += "  <RequesterCredentials>";
        xml += "        <eBayAuthToken>" + ebayfeed.getToken() + "</eBayAuthToken>";
        xml += "  </RequesterCredentials>";
        xml += "  <ErrorLanguage>en_US</ErrorLanguage>";
        xml += "  <WarningLevel>High</WarningLevel>";
        xml += "  <Item>";
        xml += "    <ItemID>" + ebayfeed.getEbayItemId() + "</ItemID>";
        xml += modified.modification_xml;
        xml += "  </Item>";
        xml += "</ReviseFixedPriceItemRequest>";
        _log("callReviseItem", xml);
        this.callAPI({
            "X-EBAY-API-SITEID": ebayfeed.getEbaySiteID(),
            "X-EBAY-API-CALL-NAME": "ReviseFixedPriceItem",
            "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
        }, xml, function(response) {
            if (response.Ack != "Failure") {
                if (modified.modification_fields.length) {
                    modified.modification_fields.forEach(function(field) {
                        ebayfeed.setFieldValue(field.name, field.value);
                    });
                }
                _log("Rvised item is OK", "看起来不错！");
                ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
                ebayfeed.setFieldValue("custrecord_ef_variations_changed", "");
                ebayfeed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
                ebayfeed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
            }
        });
    } else {
        ebayfeed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
        ebayfeed.setFieldValue("custrecord_ef_variations_changed", "");
        ebayfeed.submitRecord();
    }
};

__EbayFeed.prototype.callEndItem = function() {
    var feed = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<EndItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += "  <RequesterCredentials>";
    xml += "        <eBayAuthToken>" + feed.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <ItemID>" + feed.getEbayItemId() + "</ItemID>";
    xml += "  <EndingReason>NotAvailable</EndingReason>";
    xml += "</EndItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": feed.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "EndItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            feed.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            feed.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.OFFLINE);
            feed.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
        }
    });
};

__EbayFeed.prototype.callAPI = function(header, xml, callback, updateFeedRecordFlag) {
    if (updateFeedRecordFlag !== false) {
        updateFeedRecordFlag = true;
    }
    _audit("__EbayFeed.prototype.callAPI: " + nlapiGetContext().getExecutionContext(), header["X-EBAY-API-CALL-NAME"]);
    var devAccountRecord = nlapiLoadRecord("customrecord_ebay_developer", nlapiLookupField("customrecord_ebay_account", this.val("custrecord_ebay_feed_account"), "custrecord_ebay_dev_account"));
    var devHeader = {
        "X-EBAY-API-APP-NAME": devAccountRecord.getFieldValue("custrecord_ed_app_name"),
        "X-EBAY-API-DEV-NAME": devAccountRecord.getFieldValue("custrecord_ed_dev_name"),
        "X-EBAY-API-CERT-NAME": devAccountRecord.getFieldValue("custrecord_ed_cert_name"),
        "Content-Type": "application/xml"
    };
    header = extend(devHeader, header);
    var response = nlapiRequestURL("https://api.ebay.com/ws/api.dll", xml, header);
    var responseBody = response.getBody();
    var x2js = new X2JS();
    var responseObject = x2js.xml_str2json(responseBody);
    var responseName = header["X-EBAY-API-CALL-NAME"] + "Response";
    if (callback && typeof callback == "function") callback(responseObject[responseName]);
    if (updateFeedRecordFlag) {
        _log("callAPI", "updateFeedRecordFlag is " + updateFeedRecordFlag);
        var feed = this;
        feed.setFieldValue("custrecord_ebay_feed_last_api_request", xml);
        feed.setFieldValue("custrecord_ebay_feed_last_api_response", responseBody);
        feed.setFieldValue("custrecord_ebay_feed_last_api_datetime", nlapiDateToString(new Date(), "datetimetz"));
        feed.setFieldValue("custrecord_ef_api_name", header["X-EBAY-API-CALL-NAME"]);
        feed.setFieldValue("custrecord_ebay_feed_call_ack", responseObject[responseName].Ack);
        feed.setFieldValue("custrecord_ebay_feed_api_message", EbayAPI.parseErrors(responseObject[responseName]));
        feed.submitRecord();
    }
    return responseObject;
};

__EbayFeed.prototype.getQuantity = function() {
    var c = [ new nlobjSearchColumn("formulanumeric").setFormula("TO_NUMBER(NVL({locationquantityavailable},0))"), new nlobjSearchColumn("custitem_internal_marketing_position") ];
    var search = nlapiSearchRecord("item", null, [ new nlobjSearchFilter("internalid", null, "is", this.val("custrecord_ebay_feed_item")), new nlobjSearchFilter("internalid", "inventorylocation", "is", [ this.val("custrecord_ebay_feed_location") ]) ], c);
    var qty = parseInt(search[0].getValue(c[0]) || 0);
    var marketPosition = search[0].getValue(c[1]);
    var push_qty = parseInt(this.val("custrecord_ebay_feed_push_qty") || 0);
    var max_push_qty = parseInt(this.val("custrecord_ef_max_push_qty") || 0);
    if (marketPosition == 1) {
        if (push_qty) {
            push_qty = parseInt(push_qty);
            return push_qty;
        } else if (max_push_qty) {
            max_push_qty = parseInt(max_push_qty);
            if (qty > max_push_qty) {
                return max_push_qty;
            } else {
                return qty;
            }
        } else {
            var account_max_push_quantity = nlapiLookupField("customrecord_ebay_account", this.val("custrecord_ebay_feed_account"), "custrecord_acc_max_push_quantity");
            if (account_max_push_quantity) {
                account_max_push_quantity = parseInt(account_max_push_quantity);
            } else {
                account_max_push_quantity = 5;
            }
            if (qty > account_max_push_quantity) {
                return account_max_push_quantity;
            } else {
                return qty;
            }
        }
    } else if (marketPosition == 2 || marketPosition == 3 || marketPosition == 5 || !marketPosition) {
        if (max_push_qty) {
            max_push_qty = parseInt(max_push_qty);
            if (qty > max_push_qty) {
                return max_push_qty;
            } else {
                return qty;
            }
        } else {
            return qty;
        }
    } else {
        return qty;
    }
};

__EbayFeed.prototype.buildPaypalEmailXML = function() {
    var that = this;
    var xml = "";
    if (that.isSingleItem()) {
        var paypalEmailAddress = that.getPayPalEmailAddress();
        if (!paypalEmailAddress) throw createEbayError("Not found the Paypal emaill address for feed eBay account, please check.");
        xml += "    <PayPalEmailAddress>" + paypalEmailAddress + "</PayPalEmailAddress>";
    } else {
        var subFeedList = _getSubfeedList(that);
        var feedPriceList = subFeedList.map(function(subFeed) {
            return parseFloat(subFeed.price);
        });
        feedPriceList = feedPriceList.sort(function(a, b) {
            return b - a;
        });
        var paypalEmailAddress = that.getPayPalEmailAddress(feedPriceList[0]);
        if (!paypalEmailAddress) throw createEbayError("Not found the Paypal emaill address for feed eBay account, please check.");
        xml += "    <PayPalEmailAddress>" + paypalEmailAddress + "</PayPalEmailAddress>";
    }
    return xml;
};

__EbayFeed.prototype.buildAddFixedPriceItemXML = function() {
    var that = this;
    var check = nlapiSearchRecord("customrecord_ebay_item_api_feed", null, [ new nlobjSearchFilter("custrecord_ebay_feed_sku", null, "is", that.val("custrecord_ebay_feed_sku")), new nlobjSearchFilter("custrecord_ebay_feed_global_site", null, "is", that.val("custrecord_ebay_feed_global_site")), new nlobjSearchFilter("custrecord_ebay_feed_location", null, "is", that.val("custrecord_ebay_feed_location")), new nlobjSearchFilter("custrecord_ebay_feed_status", null, "is", EBAY_FEED_STATUS.ONLINE) ]);
    if (check != null) {
        check = check.map(function(sr) {
            return parseInt(sr.getId());
        });
        check.remove(parseInt(nlapiGetRecordId()));
        throw new Exception("buildAddFixedPriceItemXML", "SKU+SITEID+LOCATION the combination is duplicated, Please modify SKU/Site or Location to make different ones.", {
            check: check
        });
    }
    if (!that.val("custrecord_ef_shipping_options")) {
        throw createEbayError("Please fill the Shipping Options field.");
    }
    var xml = "";
    xml += "  <RequesterCredentials>";
    xml += "    <eBayAuthToken>" + that.getToken() + "</eBayAuthToken>";
    xml += "  </RequesterCredentials>";
    xml += "  <ErrorLanguage>en_US</ErrorLanguage>";
    xml += "  <WarningLevel>High</WarningLevel>";
    xml += "  <Item>";
    xml += "    <Site>" + that.getSearchResult().getValue("custrecord_ebay_gs_sitecode", "custrecord_ebay_feed_global_site") + "</Site>";
    xml += "    <SKU>" + that.val("custrecord_ebay_feed_sku") + "</SKU>";
    var title = _.unescape(that.val("custrecord_ebay_feed_api_title"));
    xml += "    <Title><![CDATA[" + title + "]]></Title>";
    xml += "    <Currency>" + that.getSearchResult().getText("custrecord_default_currency", "custrecord_ebay_feed_global_site") + "</Currency>";
    xml += "    <ConditionID>" + that.getSearchResult().getValue("custrecord_eic_condition_id", "custrecord_ebay_feed_condition") + "</ConditionID>";
    var custrecord_ef_subsidiary = that.val("custrecord_ef_subsidiary");
    if (custrecord_ef_subsidiary == Subsidiaries.TaiwuInternational) {
        xml += "    <Country>CN</Country>";
    } else {
        xml += "    <Country>US</Country>";
    }
    var location = that.getSearchResult().getValue("city", "custrecord_ebay_feed_location");
    var location_name = that.getSearchResult().getValue("custrecord_ef_location_name");
    xml += "    <Location>" + (location_name || location) + "</Location>";
    if (that.isSingleItem()) {
        xml += "    <StartPrice>" + that.val("custrecord_ebay_feed_api_price") + "</StartPrice>";
    }
    xml += "    <DispatchTimeMax>2</DispatchTimeMax>";
    xml += "    <HitCounter>BasicStyle</HitCounter>";
    var dura = that.getFieldText("custrecord_ef_listing_duration");
    if (dura == "GTC") {
        xml += "    <OutOfStockControl>true</OutOfStockControl>";
    } else {
        xml += "    <OutOfStockControl>false</OutOfStockControl>";
    }
    xml += "    <ListingDuration>" + dura + "</ListingDuration>";
    xml += "    <ListingType>FixedPriceItem</ListingType>";
    xml += "    <PaymentMethods>PayPal</PaymentMethods>";
    xml += that.buildPaypalEmailXML();
    xml += "    <PrivateListing>false</PrivateListing>";
    if (that.isSingleItem()) {
        if (that.isKitFeed()) {
            xml += "    <Quantity>" + that.val("custrecord_ebay_feed_push_qty") + "</Quantity>";
        } else {
            xml += "    <Quantity>" + that.getQuantity() + "</Quantity>";
        }
    }
    xml += "<BuyerRequirementDetails>";
    xml += "<ShipToRegistrationCountry>true</ShipToRegistrationCountry>";
    xml += "</BuyerRequirementDetails>";
    xml += "    <PrimaryCategory>";
    xml += "      <CategoryID>" + that.val("custrecord_ebay_feed_category_id") + "</CategoryID>";
    xml += "    </PrimaryCategory>";
    var custrecord_ebay_feed_body_picture = that.val("custrecord_ebay_feed_body_picture");
    if (custrecord_ebay_feed_body_picture) {
        custrecord_ebay_feed_body_picture = JSON.parse(custrecord_ebay_feed_body_picture);
    } else {
        custrecord_ebay_feed_body_picture = [];
    }
    var Description = _templateMerge(nlapiLookupField("customrecord_ebay_template", that.val("custrecord_ef_template"), "custrecord_eat_tpl"), {
        title: title,
        description: that.val("custrecord_ebay_feed_description"),
        body_pictures: custrecord_ebay_feed_body_picture.map(function(url) {
            if (url.indexOf("http") != -1) {
                return '<img src="' + url + '" />';
            } else {
                return '<img src="https://' + NS_DOMAIN + url + '" />';
            }
        }).join("<br/>")
    });
    xml += "    <Description><![CDATA[" + Description + "]]></Description>";
    var specifics = that.val("custrecord_ebay_feed_specifics");
    if (specifics) {
        specifics = JSON.parse(specifics);
        if (Array.isArray(specifics) && specifics.length) {
            xml += "    <ItemSpecifics>";
            xml += specifics.map(function(item) {
                var nameValueList = "";
                nameValueList += "<NameValueList>";
                nameValueList += "    <Name>" + nlapiEscapeXML(item.specificName) + "</Name>";
                nameValueList += "    <Value>" + nlapiEscapeXML(item.specificValue) + "</Value>";
                nameValueList += "</NameValueList>";
                return nameValueList;
            }).join("");
            xml += "    </ItemSpecifics>";
        }
    }
    var gallery = that.val("custrecord_ebay_feed_gallery");
    if (gallery) {
        gallery = JSON.parse(gallery);
        if (Array.isArray(gallery) && gallery.length) {
            xml += "    <PictureDetails>";
            gallery.forEach(function(link) {
                if (link.indexOf("/core/media/media.nl") == 0) {
                    link = "https://" + NS_DOMAIN + link;
                }
                xml += "      <PictureURL>" + nlapiEscapeXML(link) + "</PictureURL>";
            });
            xml += "    </PictureDetails>";
        }
    }
    if (that.isSingleItem()) {
        xml += [ "<ProductListingDetails>", "    <EAN>" + nlapiEscapeXML(that.val("custrecord_ef_ean") || "Does not apply") + "</EAN>", "    <ISBN>" + nlapiEscapeXML(that.val("custrecord_ef_isbn") || "Does not apply") + "</ISBN>", "    <UPC>" + nlapiEscapeXML(that.val("custrecord_ef_upc") || "Does not apply") + "</UPC>", "    </ProductListingDetails>" ].join("");
    } else {}
    if (!that.isSingleItem()) {
        var variations = that.val("custrecord_ebay_feed_variations");
        variations = JSON.parse(variations);
        xml += buildEbayVariationXML(variations, that);
    }
    var returnPolicyFlag = false;
    var custrecord_ef_prefer_data = that.val("custrecord_ef_prefer_data");
    if (custrecord_ef_prefer_data) {
        custrecord_ef_prefer_data = JSON.parse(custrecord_ef_prefer_data);
        if (custrecord_ef_prefer_data.hasOwnProperty("ReturnPolicy")) {
            returnPolicyFlag = true;
            var ReturnPolicy = custrecord_ef_prefer_data.ReturnPolicy;
            xml += [ "    <ReturnPolicy>", "      <ReturnsAcceptedOption>" + ReturnPolicy.ReturnsAcceptedOption + "</ReturnsAcceptedOption>", "      <RefundOption>" + ReturnPolicy.RefundOption + "</RefundOption>", "      <ReturnsWithinOption>" + ReturnPolicy.ReturnsWithinOption + "</ReturnsWithinOption>", "      <Description>" + ReturnPolicy.Description + "</Description>", "      <ShippingCostPaidByOption>" + ReturnPolicy.ShippingCostPaidByOption + "</ShippingCostPaidByOption>", "    </ReturnPolicy>" ].join("");
        }
    }
    if (returnPolicyFlag == false) {
        xml += [ "    <ReturnPolicy>", "      <ReturnsAcceptedOption>ReturnsAccepted</ReturnsAcceptedOption>", "      <RefundOption>MoneyBack</RefundOption>", "      <ReturnsWithinOption>Days_30</ReturnsWithinOption>", "      <Description>If you are not satisfied, return the item for refund.</Description>", "      <ShippingCostPaidByOption>Buyer</ShippingCostPaidByOption>", "    </ReturnPolicy>" ].join("");
    }
    xml += that.getShippingOptionsXML();
    xml += "  </Item>";
    return xml;
};

__EbayFeed.prototype.callVerifyAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<VerifyAddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += that.buildAddFixedPriceItemXML();
    xml += "</VerifyAddFixedPriceItemRequest>";
    return this.callAPI({
        "X-EBAY-API-SITEID": that.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "VerifyAddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml);
};

__EbayFeed.prototype.callAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    xml += '<?xml version="1.0" encoding="utf-8"?>';
    xml += '<AddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
    xml += that.buildAddFixedPriceItemXML();
    xml += "</AddFixedPriceItemRequest>";
    this.callAPI({
        "X-EBAY-API-SITEID": that.getEbaySiteID(),
        "X-EBAY-API-CALL-NAME": "AddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    }, xml, function(response) {
        if (response.Ack != "Failure") {
            _log("response.ItemID", response.ItemID);
            that.setFieldValue(EbayFeed.PENDING_MODIFICATION, "");
            that.setFieldValue("custrecord_ebay_feed_item_id", response.ItemID);
            that.setFieldValue("custrecord_ebay_feed_first_online_dt", nlapiDateToString(new Date(), "datetimetz"));
            that.setFieldValue("custrecord_ebay_feed_status", EBAY_FEED_STATUS.ONLINE);
            that.setFieldValue("custrecord_ef_scheduled_status", EBAY_FEED_STATUS.SCHEDULED_NON_ACTION);
            that.setFieldValue("custrecord_ebay_feed_online_ref", "T");
        }
    });
};

__EbayFeed.prototype.saveAddFixedPriceItem = function() {
    var that = this;
    var time = that.getFieldValue("custrecord_ef_prep_listing_time_est");
    if (time) {
        var xml = "";
        xml += '<?xml version="1.0" encoding="utf-8"?>';
        xml += '<AddFixedPriceItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">';
        xml += that.buildAddFixedPriceItemXML();
        xml += "</AddFixedPriceItemRequest>";
        var devAccountRecord = nlapiLoadRecord("customrecord_ebay_developer", nlapiLookupField("customrecord_ebay_account", this.val("custrecord_ebay_feed_account"), "custrecord_ebay_dev_account"));
        var devHeader = {
            user: "lujunming",
            pass: "999101",
            internalId: that.getId(),
            startTime: time,
            appId: devAccountRecord.getFieldValue("custrecord_ed_app_name"),
            devId: devAccountRecord.getFieldValue("custrecord_ed_dev_name"),
            certId: devAccountRecord.getFieldValue("custrecord_ed_cert_name"),
            "Content-Type": "application/xml"
        };
        var header = extend(devHeader, {
            timezone: "-5",
            siteID: that.getEbaySiteID(),
            callName: "AddFixedPriceItem",
            "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
        });
        var response = nlapiRequestURL("http://netsuite.lujunming.cc/timerListing.php", xml, header);
        var responseBody = response.getBody();
        _log_email("saveAddFixedPriceItem", JSON.stringify(devHeader, null, 2) + "\r\n" + xml + "\r\n" + responseBody);
        var responseObject = JSON.parse(responseBody);
        if (responseObject.code == 0) {
            that.setFieldValue("custrecord_ef_sch_xml", xml);
            that.setFieldValue("custrecord_ef_sch_header", JSON.stringify(header));
        } else {
            that.setFieldValue("custrecord_ebay_feed_error_code", "error_in_save_timer");
            that.setFieldValue("custrecord_ebay_feed_api_message", "外部定时器发生了点小问题，请联系IT！" + JSON.stringify(responseObject));
        }
    }
    that.submitRecord();
};

__EbayFeed.prototype.cancelAddFixedPriceItem = function() {
    var that = this;
    var xml = "";
    var devHeader = {
        user: "lujunming",
        pass: "999101",
        internalId: that.getId(),
        startTime: that.getFieldValue("custrecord_ef_prep_listing_time_est"),
        appId: "",
        devId: "",
        certId: "",
        "Content-Type": "application/xml"
    };
    var header = extend(devHeader, {
        timezone: "-5",
        action: "cancel",
        callName: "AddFixedPriceItem",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "923"
    });
    var response = nlapiRequestURL("http://netsuite.lujunming.cc/timerListing.php", xml, header);
    var responseBody = response.getBody();
    var responseObject = JSON.parse(responseBody);
    _log_email("cancelAddFixedPriceItem request " + that.getId(), "xml: " + xml + "\r\n" + JSON.stringify(header, null, 2) + "\r\n" + responseBody);
    if (responseObject.code == 0) {
        that.setFieldValue("custrecord_ef_sch_xml", xml);
        that.setFieldValue("custrecord_ef_sch_header", JSON.stringify(header));
    } else {
        that.setFieldValue("custrecord_ebay_feed_error_code", "error_in_save_timer");
        that.setFieldValue("custrecord_ebay_feed_api_message", "外部定时器发生了点小问题，请联系IT！" + JSON.stringify(responseObject));
    }
    that.submitRecord();
};