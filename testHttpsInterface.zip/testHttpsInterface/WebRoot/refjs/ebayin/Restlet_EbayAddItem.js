function run_get(datain) {
    _log('datain', datain);
    var feedSearchResults = null;

    var result = {
        ns_response: 'yes',
        total: 0,
        all: [],
        ok: [],
        error: []
    };

    var ebaySiteId = datain.ebaySiteId; //nlapiGetContext().getSetting("SCRIPT", "custscript_ebay_site");
    var feedId = datain.feedId; //nlapiGetContext().getSetting('script', 'custscript_ebay_additem_feedid');
    if (feedId) {
        feedSearchResults = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [
            new nlobjSearchFilter('internalid', null, 'is', feedId),
            new nlobjSearchFilter('custrecord_ef_scheduled_status', null, 'anyof', [
                EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW,
                // EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW_ERROR, Ack替代了
                EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST
                // EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST_ERROR
            ])
        ], [
            new nlobjSearchColumn('custrecord_ebay_feed_status'),
            new nlobjSearchColumn('custrecord_ef_scheduled_status')
        ]);
    } else {
        _log('current date time', nlapiDateToString(new Date(), 'datetimetz'));
        feedSearchResults = nlapiSearchRecord('customrecord_ebay_item_api_feed', null, [

            new nlobjSearchFilter('custrecord_ebay_feed_global_site', null, 'is', ebaySiteId),

            // https://debugger.na1.netsuite.com/app/common/custom/custrecordentrylist.nl?rectype=1310
            new nlobjSearchFilter('custrecord_ef_scheduled_status', null, 'anyof', [
                EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW,
                EBAY_FEED_STATUS.SCHEDULED_INQUE_RELIST
            ]),


            new nlobjSearchFilter('custrecord_ebay_feed_item', null, 'noneof', '@NONE@'),
            new nlobjSearchFilter('custrecord_ef_language', null, 'noneof', '@NONE@'),
            new nlobjSearchFilter('custrecord_ebay_feed_global_site', null, 'noneof', '@NONE@'),
            new nlobjSearchFilter('custrecord_ebay_feed_account', null, 'noneof', '@NONE@'),

            new nlobjSearchFilter('custrecord_ebay_feed_matrix_child_item', null, 'is', 'F'),
            new nlobjSearchFilter('custrecord_ebay_feed_combo', null, 'is', 'F'),

            //// : for testing
            //new nlobjSearchFilter('internalidnumber', null, 'greaterthan', '13185'),

            //name = {string} custrecord_ef_prep_listing_time
            //join = null
            //operator = {string} onorbefore
            //formula = null
            //summarytype = null
            //values = {array} length=2
            //    [0] = {string} 10/10/2016 12:00 am
            //[1] = {string} 10/9/2016 3:41 am
            new nlobjSearchFilter('custrecord_ef_prep_listing_time', null, 'onorbefore', nlapiDateToString(new Date(), 'datetime'))

        ], [
            new nlobjSearchColumn('custrecord_ebay_feed_status'),
            new nlobjSearchColumn('custrecord_ef_scheduled_status')
        ]);
    }


    // feedSearchResults = feedSearchResults.list;

    if (feedSearchResults != null) {

        result.total = feedSearchResults.length;
        for (var i = 0; i < feedSearchResults.length; i++) {

            var feedSearchResult = feedSearchResults[i];
            _log('feedSearchResult--- ID ---', feedSearchResult.getId());
            result.all.push(feedSearchResult.getId());
            var feed = new __EbayFeed(feedSearchResult.getId());


            try {

                if (feed.getEbayItemId()) {
                    if (feedSearchResult.getValue('custrecord_ebay_feed_status') == EBAY_FEED_STATUS.ONLINE) {
                        feed.callEndItem();
                        feed.refresh();
                    }
                    feed.callRelistItem();
                } else {
                    feed.callAddFixedPriceItem(); // New a item to eBay
                }
                result.ok.push(feedSearchResult.getId());
            } catch (e) {
                // e = parseException(e);
                e = processException(e);
                if (e.code == 'buildAddFixedPriceItemXML') {
                    feed.setFieldValue('custrecord_ebay_feed_call_ack', 'buildAddFixedPriceItemXML');
                    feed.setFieldValue('custrecord_ebay_feed_api_message', e.message);
                    feed.setFieldValue('custrecord_ef_scheduled_status', EBAY_FEED_STATUS.SCHEDULED_IN_QUE_NEW_ERROR);
                    feed.submitRecord();
                }
                result.error.push(feedSearchResult.getId());
                //_log_email('Feed ID: ' + feed.getId() + ' has error', e.code + ": " + e.message + '<br/><br/>' + JSON.stringify(feed));
            }


            _log("__EbayFeed", '------------------------------ END: ' + feed.getId() + ' --------------------------------');

        }
    } else {
        _log('feedSearchResults', 'No result.');
    }


    return result;

}


function run_post(datain) {
    ////_log('datain', datain);
    //
    //return {
    //    test: 'Yes'
    //}
}
