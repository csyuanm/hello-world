function run() {

    var search = nlapiSearchRecord('customrecord_3p_location_order', null, [
        new nlobjSearchFilter('isinactive', null, 'is', 'F'),
        new nlobjSearchFilter('custrecord_3p_imported', null, 'is', 'F')
    ], [
        //new nlobjSearchColumn('name'),
        new nlobjSearchColumn('custrecord_3p_ordernumber'),
        new nlobjSearchColumn('custrecord_3p_tracking_number'),
        new nlobjSearchColumn('custrecord_3p_wuliushang'),
        new nlobjSearchColumn('custrecord_3p_fangshi')
    ]);

    if (search != null) {
        var issue = [];
        _log('3P 订单的需要导入的总数是： ', search.length);
        for (var i = 0, len = search.length; i < len; i++) {
            var tpOrderSearchResult = search[i]; // Third party order
            _log('order', tpOrderSearchResult.getId());
            var orderSearch = nlapiSearchRecord('salesorder', null, [
                new nlobjSearchFilter('mainline', null, 'is', 'T'),
                new nlobjSearchFilter('subsidiary', null, 'is', '3'), // Taiwu
                //new nlobjSearchFilter('status', null, 'anyof', [
                //    //'SalesOrd:A', // Pending Approval
                //    'SalesOrd:B', // Pending Fulfillment
                //    'SalesOrd:D'  // 部分Fulfill
                //]),
                new nlobjSearchFilter('otherrefnum', null, 'equalto', tpOrderSearchResult.getValue('custrecord_3p_ordernumber'))
            ], [
                new nlobjSearchColumn('location'),
                new nlobjSearchColumn('custbody_sz_carrier_trackingnumber')
            ]);

            var tpOrder = nlapiLoadRecord('customrecord_3p_location_order', tpOrderSearchResult.getId());

            if (orderSearch != null) {
                if (orderSearch.length == 1) {

                    _log('找了Order ID', orderSearch[0].getId());

                    var location = orderSearch[0].getValue('location');
                    if (location == '73' || location == '84' || location == '85' || location == '86') {
                        var soRec = nlapiLoadRecord('salesorder', orderSearch[0].getId());
                        soRec.setFieldValue('custbody_sz_carrier', tpOrderSearchResult.getValue('custrecord_3p_wuliushang'));
                        soRec.setFieldValue('custbody_ship_method_sz', tpOrderSearchResult.getValue('custrecord_3p_fangshi'));
                        soRec.setFieldValue('custbody_tw_fulfillment_status', 3);
                        soRec.setFieldValue('custbody_sz_carrier_trackingnumber', tpOrderSearchResult.getValue('custrecord_3p_tracking_number'));
                        nlapiSubmitRecord(soRec, true);

                        //nlapiSubmitField('salesorder', orderSearch[0].getId(),
                        //    'custbody_sz_carrier_trackingnumber', torder.getValue('custrecord_3p_tracking_number'));
                        // nlapiSubmitField('customrecord_3p_location_order', torder.getId(), 'custrecord_3p_linked_so', orderSearch[0].getId());


                        tpOrder.setFieldValue('custrecord_3p_linked_so', orderSearch[0].getId());

                        if (orderSearch[0].getValue('custbody_sz_carrier_trackingnumber')) {
                            tpOrder.setFieldValue('custrecord_3p_memo', 'OK imported. 不过是更新哦。。');
                        } else {
                            tpOrder.setFieldValue('custrecord_3p_memo', 'OK imported.');
                        }

                        tpOrder.setFieldValue('custrecord_3p_imported', 'T');

                    } else {
                        tpOrder.setFieldValue('custrecord_3p_memo', '这个不是海外仓Location哦');
                        tpOrder.setFieldValue('custrecord_3p_imported', 'F');

                    }

                } else {
                    tpOrder.setFieldValue('custrecord_3p_memo', 'Error 搜索的订单有很多条');
                    tpOrder.setFieldValue('custrecord_3p_imported', 'F');
                }
            } else {
                tpOrder.setFieldValue('custrecord_3p_memo', 'Error 没找到这个订单哦');
                tpOrder.setFieldValue('custrecord_3p_imported', 'F');
            }

            nlapiSubmitRecord(tpOrder, true);

            checkGovernance();
        }

        if (issue.length) {
            _log_email('导入有问题的单', JSON.stringify(issue, null, 2));
        }
    }
}